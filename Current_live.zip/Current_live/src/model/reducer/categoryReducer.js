import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    status: "loading",
    category: [], // All categories from shop
    selectedCategory: null, // Currently selected category
    currentCategoryChildren: [] // Children of selected category
};

export const categoryReducer = createSlice({
    name: "category",
    initialState,
    reducers: {
        setAllCategories: (state, action) => {
            state.status = "fulfill";
            state.category = action.payload;
        },
        setSelectedCategory: (state, action) => {
            state.selectedCategory = action.payload.category;
            state.currentCategoryChildren = action.payload.children || [];
        },
        setCurrentCategoryChildren: (state, action) => {
            state.currentCategoryChildren = action.payload;
        },
        clearSelectedCategory: (state) => {
            state.selectedCategory = null;
            state.currentCategoryChildren = [];
        }
    }
});

export const { 
    setAllCategories, 
    setSelectedCategory, 
    setCurrentCategoryChildren,
    clearSelectedCategory 
} = categoryReducer.actions;
export default categoryReducer.reducer;