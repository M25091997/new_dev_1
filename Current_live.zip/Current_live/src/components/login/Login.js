import { useState, useEffect, useRef } from "react"
import { useNavigate } from "react-router-dom"
import { signInWithPhoneNumber, RecaptchaVerifier } from "firebase/auth"
import FirebaseData from "../utils/firebase/FirebaseData"
import { login } from "../api/apiCollection"
import { useDispatch, useSelector } from "react-redux"
import { setCurrentUser, setAuthType, setAuthId } from "../model/reducer/authReducer"
import { Toast } from "../Components/Toast/Toast"
import {
  setIsGuest,
  setCart,
  setCartProducts,
  setCartSubTotal,
  setGuestCartTotal,
  addtoGuestCart,
} from "../model/reducer/cartReducer"
import NewUserRegisterModal from "../Components/Register/NewUserRegisterModal"
import * as newApi from "../api/apiCollection"
import { setTokenThunk } from "../model/thunk/loginThunk"
import { setSetting } from "../model/reducer/settingReducer"
import { setFavouriteLength, setFavouriteProducts } from "../model/reducer/favouriteReducer"
import api from "../api/api"
import loginBackground from "../assets/loginBackground.png"
import { toast } from "react-toastify"

const MobileLoggin = () => {
  const [mobileNumber, setMobileNumber] = useState("")
  const [otp, setOtp] = useState("")
  const [isValidMobile, setIsValidMobile] = useState(false)
  const [showOtp, setShowOtp] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [confirmationResult, setConfirmationResult] = useState(null)
  const [backgroundPosition, setBackgroundPosition] = useState(0)
  const animationRef = useRef()
  const [otpTimer, setOtpTimer] = useState(0) // 90 seconds = 1 minute 30 seconds
  const [canResendOtp, setCanResendOtp] = useState(false)

  const [registerModalShow, setRegisterModalShow] = useState(false)
  const [userEmail, setUserEmail] = useState("")
  const [userName, setUserName] = useState("")
  const [recaptchaToken, setRecaptchaToken] = useState("")
  const [fcmToken, setFcmToken] = useState("")

  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { auth, messaging } = FirebaseData()
  const city = useSelector((state) => state.city)
  const cart = useSelector((state) => state.cart)
  const { user } = useSelector((state) => state.user)
  const setting = useSelector((state) => state.setting)

  // Format time for display (MM:SS)
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  // Timer countdown effect
  useEffect(() => {
    let interval
    if (otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => prev - 1)
      }, 1000)
    } else if (otpTimer === 0) {
      setCanResendOtp(true)
    }
    return () => clearInterval(interval)
  }, [otpTimer])

  // Preload background image
  useEffect(() => {
    const img = new Image()
    img.src = loginBackground
  }, [])

  // Auto-sliding background animation (left to right)
  useEffect(() => {
    let startTime = null
    const animationDuration = 20000 // 20 seconds for one complete cycle
    const maxOffset = 100 // Maximum offset percentage

    const animateBackground = (timestamp) => {
      if (!startTime) startTime = timestamp
      const elapsed = timestamp - startTime

      // Calculate progress (0 to 1) and reset when complete
      const progress = (elapsed % animationDuration) / animationDuration

      // Create smooth left-to-right sliding motion
      // Goes from -maxOffset to +maxOffset and back
      const position = Math.sin(progress * Math.PI * 2) * maxOffset

      setBackgroundPosition(position)
      animationRef.current = requestAnimationFrame(animateBackground)
    }

    animationRef.current = requestAnimationFrame(animateBackground)

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  // Initialize Firebase Messaging
  useEffect(() => {
    const initializeFirebaseMessaging = async () => {
      if (setting?.setting && messaging) {
        try {
          const permission = await Notification.requestPermission()
          if (permission === "granted") {
            const currentToken = await messaging.getToken()
            if (currentToken) {
              setFcmToken(currentToken)
            }
          }
        } catch (error) {
          console.error("Error getting FCM token:", error)
        }
      }
    }

    if (setting.setting?.firebase) {
      initializeFirebaseMessaging()
    }
  }, [setting, messaging])

  // reCAPTCHA initialization
  useEffect(() => {
    const initializeRecaptcha = async () => {
      if (!window.recaptchaVerifier) {
        window.recaptchaVerifier = new RecaptchaVerifier(auth, "recaptcha-container", {
          size: "invisible",
          callback: (token) => {
            setRecaptchaToken(token)
          },
          "expired-callback": () => {
            setRecaptchaToken("")
            window.recaptchaVerifier = null
            initializeRecaptcha()
          },
        })
      }
    }

    initializeRecaptcha()

    return () => {
      if (window.recaptchaVerifier) {
        window.recaptchaVerifier.clear()
        window.recaptchaVerifier = null
      }
    }
  }, [auth])

  // Validate Indian mobile number
  const validateMobileNumber = (number) => /^[6-9]\d{9}$/.test(number)

  const handleMobileChange = (e) => {
    const number = e.target.value
    setMobileNumber(number)
    setIsValidMobile(validateMobileNumber(number))
    setError("")
  }

  const handleContinue = async () => {
    if (isValidMobile) {
      try {
        setLoading(true)
        const appVerifier = window.recaptchaVerifier

        const formattedPhoneNumber = `+91${mobileNumber}`
        const result = await signInWithPhoneNumber(auth, formattedPhoneNumber, appVerifier)

        setConfirmationResult(result)
        setShowOtp(true)
        setError("")
        setOtpTimer(90) // Start 1 minute 30 seconds timer
        setCanResendOtp(false)
      } catch (error) {
        setError("Failed to send OTP. Please try again.")
        console.error("Error sending OTP:", error)
      } finally {
        setLoading(false)
      }
    }
  }

  // Resend OTP handler
  const handleResendOtp = async () => {
    if (!canResendOtp) return
    
    try {
      setLoading(true)
      const appVerifier = window.recaptchaVerifier
      const formattedPhoneNumber = `+91${mobileNumber}`
      const result = await signInWithPhoneNumber(auth, formattedPhoneNumber, appVerifier)

      setConfirmationResult(result)
      setOtpTimer(90) // Reset timer
      setCanResendOtp(false)
      setError("")
      toast.success("OTP resent successfully!")
    } catch (error) {
      setError("Failed to resend OTP. Please try again.")
      console.error("Error resending OTP:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleOtpChange = (e) => {
    setOtp(e.target.value)
    setError("")
  }

  const fetchCart = async () => {
    try {
      const latitude = city?.city?.latitude || 0
      const longitude = city?.city?.longitude || 0

      const response = await newApi.getCart({ latitude, longitude })
      const result = await response.json()

      if (result.status === 1) {
        dispatch(setCart({ data: result.data }))
        const productsData = result?.data?.cart.map((product) => ({
          product_id: product.product_id,
          product_variant_id: product.product_variant_id,
          qty: product.qty,
        }))
        dispatch(setCartProducts({ data: productsData }))
        dispatch(setCartSubTotal({ data: result.data.sub_total }))
      } else {
        dispatch(setCartProducts({ data: [] }))
        dispatch(setCartSubTotal({ data: 0 }))
      }
    } catch (error) {
      console.error("Error fetching cart:", error)
    }
  }

  const getCurrentUser = async () => {
    try {
      const response = await newApi.getUser()
      dispatch(setCurrentUser({ data: response.user }))
      Toast.success("You're successfully Logged In")
    } catch (error) {
      console.error("Error getting user:", error)
    }
  }

  const handleFetchSetting = async () => {
    try {
      const setting = await newApi.getSetting()
      dispatch(setSetting({ data: setting?.data }))
      dispatch(setFavouriteLength({ data: setting?.data?.favorite_product_ids?.length }))
      dispatch(setFavouriteProducts({ data: setting?.data?.favorite_product_ids }))
    } catch (error) {
      console.error("Error fetching settings:", error)
    }
  }

  const addToCartBulk = async (token) => {
    try {
      const variantIds = cart?.guestCart?.map((p) => p.product_variant_id)
      const quantities = cart?.guestCart?.map((p) => p.qty)

      const response = await api.bulkAddToCart(token, variantIds.join(","), quantities.join(","))
      const result = await response.json()

      if (result.status === 1) {
        // Clear guest cart after successful merge
        dispatch(setGuestCartTotal({ data: 0 }))
        dispatch(addtoGuestCart({ data: [] }))

        // Refresh the cart
        await fetchCart()
      } else {
        throw new Error(result.message || "Failed to merge cart")
      }
    } catch (error) {
      console.error("Error adding bulk cart:", error)
      toast.error("Failed to merge your guest cart items. Please try again.")
    }
  }

  const handleLogin = async () => {
    if (otp.length === 6 && confirmationResult) {
      try {
        setLoading(true)
        setError("")

        // Verify OTP using Firebase
        const result = await confirmationResult.confirm(otp)
        const user = result?.user
        dispatch(setAuthId({ data: user.uid }))

        // Prepare login payload
        const loginPayload = {
          id: mobileNumber,
          fcm: fcmToken || "",
          type: "phone",
          platform: "web",
          clientType: "CLIENT_TYPE_WEB",
          captchaResponse: "VALID_RECAPTCHA",
          recaptchaToken: recaptchaToken,
          recaptchaVersion: "RECAPTCHA_ENTERPRISE",
        }

        // Call backend API
        const response = await login(loginPayload)
        const loginResponse = response

        if (loginResponse.status === 1) {
          // Successful login
          const tokenSet = await dispatch(setTokenThunk(loginResponse?.data?.access_token))
          await getCurrentUser()
          dispatch(setAuthType({ data: "phone" }))

          if (loginResponse?.data?.user?.status === 1) {
            dispatch(setIsGuest({ data: false }))

            // Merge guest cart if exists
            if (cart?.guestCart?.length > 0) {
              await addToCartBulk(loginResponse?.data.access_token)
            }
          }

          await handleFetchSetting()
          await fetchCart()
          navigate("/")
        } else if (loginResponse.message === "user_does_not_exist") {
          setRegisterModalShow(true)
          setShowOtp(false)
        } else {
          setError(loginResponse.message || "Login failed")
        }
      } catch (error) {
        console.error("Login error:", error)
        setError("Login failed. Please try again.")
      } finally {
        setLoading(false)
      }
    }
  }

  return (
    <div className="login-page-container h-screen w-full overflow-hidden relative">
      {/* Animated sliding background */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(${loginBackground})`,
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
          backgroundPosition: `${50 + backgroundPosition}% center`,
          transition: "none",
          willChange: "background-position",
        }}
      />

      {/* Animated gradient overlay with subtle pulsing */}
      <div
        className="absolute inset-0 z-10"
        style={{
          background: "linear-gradient(135deg, rgba(255,255,255,0.3) 0%, rgba(252,46,107,0.5) 100%)",
          animation: "pulse 4s ease-in-out infinite alternate",
        }}
      />

      {/* Main content container */}
      <div className="container max-w-md w-full m-auto h-full flex justify-center items-center relative z-20">
        <div className="p-8 bg-white/90 backdrop-blur-md rounded-2xl shadow-2xl w-full border border-white/20">
          {/* Logo placeholder */}
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-full bg-gradient-to-r from-[#fc2e6bed] to-[#ff6b8b] flex items-center justify-center shadow-lg">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-white"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 0015.171 17m3.839 1.132c.645-2.266.99-4.659.99-7.132A8 8 0 008 4.07M3 15.364c.64-1.319 1-2.8 1-4.364 0-1.457.39-2.823 1.07-4"
                />
              </svg>
            </div>
          </div>

          <h2 className="text-3xl font-bold text-center mb-6 bg-gradient-to-r from-[#fc2e6bed] to-[#ff6b8b] bg-clip-text text-transparent">
            {!showOtp ? "Welcome Back" : "Verify Your Phone"}
          </h2>

          <p className="text-gray-600 text-center mb-8">
            {!showOtp ? "Please enter your mobile number to continue" : "Enter the OTP sent to your mobile number"}
          </p>

          {error && (
            <div className="bg-red-50 text-red-800 p-4 mb-6 rounded-lg border-l-4 border-red-500 flex items-center animate-fadeIn">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                  clipRule="evenodd"
                />
              </svg>
              {error}
            </div>
          )}

          <div className="space-y-6">
            {!showOtp ? (
              <>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 text-gray-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                      />
                    </svg>
                  </div>
                  <input
                    type="tel"
                    value={mobileNumber}
                    onChange={handleMobileChange}
                    placeholder="Mobile number (10 digits)"
                    maxLength="10"
                    className="w-full p-4 pl-10 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#fc2e6bed] focus:border-transparent transition-all bg-white/80 backdrop-blur-sm"
                  />
                </div>
                <button
                  onClick={handleContinue}
                  disabled={!isValidMobile || loading}
                  className={`w-full py-4 rounded-lg transition transform hover:scale-[1.02] font-semibold ${
                    isValidMobile
                      ? "bg-gradient-to-r from-[#fc2e6bed] to-[#ff6b8b] text-white shadow-lg hover:shadow-xl"
                      : "bg-gray-100 text-gray-400"
                  }`}
                >
                  {loading ? (
                    <div className="flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Sending OTP...
                    </div>
                  ) : (
                    "CONTINUE"
                  )}
                </button>
              </>
            ) : (
              <>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 text-gray-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                      />
                    </svg>
                  </div>
                  <input
                    type="number"
                    value={otp}
                    onChange={handleOtpChange}
                    placeholder="Enter 6-digit OTP"
                    maxLength="6"
                    pattern="\d*"
                    inputMode="numeric"
                    className="w-full p-4 pl-10 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#fc2e6bed] focus:border-transparent transition-all bg-white/80 backdrop-blur-sm"
                  />
                </div>
                
                {/* Resend OTP section */}
                <div className="text-center text-sm">
                  {otpTimer > 0 ? (
                    <span className="text-gray-600">
                      Resend OTP in <span className="font-semibold">{formatTime(otpTimer)}</span>
                    </span>
                  ) : (
                    <button
                      onClick={handleResendOtp}
                      disabled={!canResendOtp || loading}
                      className="text-[#fc2e6bed] hover:underline transition-all font-medium"
                    >
                      Resend OTP
                    </button>
                  )}
                </div>
                
                <button
                  onClick={handleLogin}
                  disabled={otp.length !== 6 || loading}
                  className={`w-full py-4 rounded-lg transition transform hover:scale-[1.02] font-semibold ${
                    otp.length === 6
                      ? "bg-gradient-to-r from-[#fc2e6bed] to-[#ff6b8b] text-white shadow-lg hover:shadow-xl"
                      : "bg-gray-100 text-gray-400"
                  }`}
                >
                  {loading ? (
                    <div className="flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Verifying...
                    </div>
                  ) : (
                    "VERIFY & LOGIN"
                  )}
                </button>
                <div className="text-center">
                  <button
                    onClick={() => {
                      setShowOtp(false)
                      setOtpTimer(0)
                      setCanResendOtp(false)
                    }}
                    className="text-[#fc2e6bed] hover:underline transition-all font-medium"
                  >
                    Change Mobile Number
                  </button>
                </div>
              </>
            )}
          </div>

          <p className="text-xs text-gray-500 text-center mt-8">
            This site is protected by reCAPTCHA and the Google{" "}
            <a href="#" className="text-[#fc2e6bed] hover:underline">
              Privacy Policy
            </a>{" "}
            and{" "}
            <a href="#" className="text-[#fc2e6bed] hover:underline">
              Terms of Service
            </a>{" "}
            apply.
          </p>
        </div>
      </div>

      {/* Invisible reCAPTCHA container */}
      <div id="recaptcha-container" />

      {/* Registration Modal for New Users */}
      <NewUserRegisterModal
        show={registerModalShow}
        onClose={() => setRegisterModalShow(false)}
        mobileNumber={mobileNumber}
        email={userEmail}
        setEmail={setUserEmail}
        name={userName}
        setName={setUserName}
        loading={loading}
        authType="phone"
        fcmToken={fcmToken}
      />

      <style jsx>{`
        @keyframes pulse {
          0% { opacity: 0.3; }
          100% { opacity: 0.5; }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-in-out;
        }
        
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  )
}

export default MobileLoggin  