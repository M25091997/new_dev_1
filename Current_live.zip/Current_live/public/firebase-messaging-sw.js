importScripts('https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.10.0/firebase-messaging.js');


firebase.initializeApp({
    // EDITME:
    apiKey: 'AIzaSyDZa7lBmso3o6xV19ZMjlL1lJfWUF0V3WQ',
    authDomain: 'bringmart-6b09e.firebaseapp.com',
    projectId: 'bringmart-6b09e',
    storageBucket: '1032180515549',
    messagingSenderId: 'bringmart-6b09e.appspot.com',
    appId: '1:1032180515549:web:38838a202f3883b8021134',
    measurementId: 'G-6568B5CJE0',
});

const messaging = firebase.messaging();

try {
    messaging.setBackgroundMessageHandler(function (payload) {
        let data = payload?.notification;
        const notificationTitle = data?.title;
        const notificationOptions = {
            body: data?.body,
            icon: './logo.png' || 0,
            image: data?.image
        };

        return self.registration.showNotification(notificationTitle,
            notificationOptions);
    });

} catch (error) {
    console.log("This is an error ->", error);
}
