// firebase.js
import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/messaging";

// Create a singleton to prevent re-initialization
let firebaseApp = null;

export const initializeFirebase = (firebaseConfig) => {
  if (!firebase.apps.length) {
    firebaseApp = firebase.initializeApp(firebaseConfig);
  } else {
    firebaseApp = firebase.app();
  }

  const auth = firebase.auth();
  const messaging = firebase.messaging();

  return { firebase, auth, messaging };
};
