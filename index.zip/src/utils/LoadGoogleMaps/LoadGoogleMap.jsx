let googleMapsPromise = null;

export const loadGoogleMaps = (apiKey) => {
    if (googleMapsPromise) {
        return googleMapsPromise;
    }

    googleMapsPromise = new Promise((resolve, reject) => {
        if (window.google && window.google.maps) {
            console.log('Google Maps API already loaded');
            resolve();
            return;
        }

        const existingScript = document.querySelector(
            `script[src*="maps.googleapis.com/maps/api/js"]`
        );

        if (existingScript) {
            console.log('Google Maps script already exists, waiting for load');
            existingScript.onload = () => {
                console.log('Existing Google Maps script loaded');
                resolve();
            };
            existingScript.onerror = () => {
                console.error('Failed to load existing Google Maps script');
                reject(new Error('Failed to load Google Maps API'));
            };
            return;
        }

        const script = document.createElement('script');
        script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places`;
        script.async = true;
        script.defer = true;

        script.onload = () => {
            if (window.google && window.google.maps) {
                console.log('Google Maps API loaded successfully');
                resolve();
            } else {
                console.error('Google Maps API failed to initialize');
                reject(new Error('Google Maps API failed to load'));
            }
        };

        script.onerror = () => {
            console.error('Google Maps API script failed to load');
            reject(new Error('Failed to load Google Maps API'));
        };

        console.log('Appending Google Maps script to document');
        document.head.appendChild(script);
    });

    return googleMapsPromise;
};

export const isGoogleMapsLoaded = () => {
    return !!(window.google && window.google.maps);
};