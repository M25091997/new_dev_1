const constants = {
    GOOGLE_MAP_API_KEY: import.meta.env.VITE_APP_MAP_API,
    API_URL: import.meta.env.VITE_APP_API_URL,
    API_SUBURL: import.meta.env.VITE_APP_API_SUBURL
}

export default constants