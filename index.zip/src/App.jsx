import { MantineProvider } from "@mantine/core";
import '@mantine/core/styles.css';
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Route, BrowserRouter as Router, Routes, useLocation } from "react-router-dom";

// Pages and Components
import CategoryPage from './Components/Category/CategoryPage';
import SellerCategory from "./Components/Category/SellerCategory";
import SellerCategoryChild from "./Components/Category/SellerCategoryChild";
import SellerSubCategoryProducts from "./Components/Category/SellerSubCategoryProducts";
import AllSellers from './Components/Home/AllSellers';
import DesktopCategoryCarousel from './Components/Home/DeskTopCategoryCarousel';
import CartPage from "./Pages/CartPage";
import Home from "./Pages/Home";
import MobileLoggin from "./Pages/MobileLoggin";
import PageNotFound from "./Pages/PageNotFound";
import Product from "./Pages/Product";
import ProductDetails from "./Pages/ProductDetails";
import SellerWithProducts from "./Pages/sellerWithProducts/SellerWithProducts";
import Deals from "./Pages/Deals/Deals";
import api from "./api/api";

import AboutUsPage from './Components/FooterComponents/CompanyComponents/AboutUsPage';
import CancellationPolicyPage from './Components/FooterComponents/CompanyComponents/CancellationPolicyPage';
import ContactUsPage from './Components/FooterComponents/CompanyComponents/ContactUsPage';
import FaqsPage from './Components/FooterComponents/CompanyComponents/FaqsPage';
import PrivacyPolicyPage from './Components/FooterComponents/CompanyComponents/PrivacyPolicyPage';
import ReturnPolicyPage from './Components/FooterComponents/CompanyComponents/ReturnPolicyPage';
import ShippingPolicyPage from './Components/FooterComponents/CompanyComponents/ShippingPolicyPage';
import TermsAndConditionsPage from './Components/FooterComponents/CompanyComponents/TermsAndConditionsPage';

// Navbar and Footer
import DeskTopNavbar from "./Components/Navbar/DeskTopNavbar";
import MobileTopNavbar from "./Components/Navbar/MobileTopNavbar";

// Reducer Imports
import { logoutAuth, setCurrentUser } from "./model/reducer/authReducer";
import { clearCart, setIsGuest } from "./model/reducer/cartReducer";
import { setFavouriteLength, setFavouriteProducts } from "./model/reducer/favouriteReducer";
import { setLanguage } from "./model/reducer/languageReducer";
import { setSetting } from "./model/reducer/settingReducer";
import { setShop } from "./model/reducer/shopReducer";

// JSON
import CategoryDetail from "./Components/Category/CategoryDetail";
import Footer from "./Components/Footer";
import MobileFooterNavigation from "./Components/MobileFooterNavigation";
import DesktopDetails from "./Components/ProductDetails/DesktopDetails";
import MobileDetails from "./Components/ProductDetails/MobileDetails";
import MyAccount from "./Pages/MyAccount";
import WishlistPage from "./Pages/WishlistPage";
import CheckoutPage from "./Pages/checkout/Checkout";
import OrderConfirmation from "./Pages/orderConfirmationPage/OrderConfirmationPage";
import jsonFile from "./utils/en.json";

//react toastify
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import NewUserRegisterModal from "./Components/Register/NewUserRegisterModal";

// users dropdown section 
import EditProfile from './Components/user-dropdown/EditProfile';
import MyAddresses from './Components/user-dropdown/MyAddresses';
import Notifications from './Components/user-dropdown/Notifications';
import Transaction from './Components/user-dropdown/Transactions';
import WalletBalance from './Components/user-dropdown/WalletBalance';
import MyOrders from './Components/user-dropdown/orders/MyOrders';
import OrderDetails from "./Components/user-dropdown/orders/OrderDetails";

// Layout Wrapper
const LayoutWrapper = ({ children, isMobile }) => {
  const location = useLocation();
  const isAuthPage = location.pathname === '/login' || location.pathname === '/register';

  return (
    <>
      {!isAuthPage && (isMobile ? <MobileTopNavbar /> : <DeskTopNavbar />)}
      <main style={{ paddingBottom: isMobile && !isAuthPage ? '60px' : '0' }}>
        {children}
      </main>
      {!isAuthPage && (isMobile ? <MobileFooterNavigation /> : <Footer />)}
    </>
  );
};

function App() {
  const dispatch = useDispatch();
  const setting = useSelector((state) => state.setting);
  const city = useSelector((state) => state.city);
  const { user, status, jwtToken } = useSelector((state) => state.user);
  const language = useSelector((state) => state.language);

  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    const debounce = (func, delay) => {
      let timer;
      return () => {
        clearTimeout(timer);
        timer = setTimeout(func, delay);
      };
    };

    const debouncedResize = debounce(handleResize, 200);
    window.addEventListener("resize", debouncedResize);
    return () => window.removeEventListener("resize", debouncedResize);
  }, []);

  useEffect(() => {
    const handleAuthStateChange = async () => {
      if (jwtToken) {
        dispatch(setIsGuest(false));
        await getCurrentUser(jwtToken);
      } else {
        dispatch(setIsGuest(true));
        dispatch(clearCart());
      }
    };
    handleAuthStateChange();
  }, [jwtToken, dispatch]);

  useEffect(() => {
    getSetting();
  }, [jwtToken]);

  useEffect(() => {
    api.getSystemLanguage(0, 1)
      .then(response => response.json())
      .then(result => {
        document.documentElement.dir = result?.data?.type;
        if (result.status === 1) {
          if (result.data !== undefined) {
            dispatch(setLanguage({ data: result.data }));
          } else {
            dispatch(setLanguage({
              data: {
                id: 15, name: "English", code: "en", type: "LTR",
                system_type: 3, is_default: 1, json_data: jsonFile,
                display_name: "English", system_type_name: "Website"
              }
            }));
          }
        }
      });
  }, []);

  const getCurrentUser = (token) => {
    api.getUser(token)
      .then(response => response.json())
      .then(result => {
        if (result.status === 1) {
          dispatch(setCurrentUser({ data: { ...result.user, jwtToken: token } }));
        } else if (result.message === "Unauthenticated.") {
          dispatch(logoutAuth());
          dispatch(clearCart());
        }
      })
      .catch(() => {
        dispatch(logoutAuth());
        dispatch(clearCart());
      });
  };

  const getSetting = async () => {
    await api.getSettings(user ? 1 : 0, jwtToken || null)
      .then(response => response.json())
      .then(result => {
        if (result.status === 1) {
          dispatch(setFavouriteLength({ data: result?.data?.favorite_product_ids?.length }));
          dispatch(setFavouriteProducts({ data: result?.data?.favorite_product_ids }));
          dispatch(setSetting({ data: result?.data }));
        }
      });
  };

  useEffect(() => {
    const fetchShop = (latitude, longitude) => {
      api.getShop(latitude, longitude, jwtToken)
        .then(response => response.json())
        .then(result => {
          if (result.status === 1) {
            dispatch(setShop({ data: result.data }));
          }
        });
    };

    if (city.city !== null) {
      fetchShop(city.city.latitude, city.city.longitude);
    }
  }, [city]);

  useEffect(() => {
    document.title = setting.setting ? setting.setting.web_settings.site_title : "Loading...";
    const link = document.querySelector("link[rel~='icon']") || document.createElement('link');
    link.rel = 'icon';
    document.head.appendChild(link);
    link.href = setting.setting && setting.setting.web_settings.favicon;
  });

  return (
    <MantineProvider>
      <Router>
        <LayoutWrapper isMobile={isMobile}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<MobileLoggin />} />
            <Route path="/products" element={<Product />} />
            <Route path="/product/:name/:id" element={<ProductDetails />} />
            <Route path="/desktop-category-carousel" element={<DesktopCategoryCarousel />} />
            <Route
              path="/product/:slug"
              element={isMobile ? <MobileDetails /> : <DesktopDetails />}
            />
            <Route
              path="/product/:slug/:id"
              element={isMobile ? <MobileDetails /> : <DesktopDetails />}
            />
            <Route path="/cart" element={<CartPage />} />
            <Route path='/category/:slug' element={<CategoryPage />} />
            <Route path="/category/:slug/:subSlug" element={<CategoryDetail />} />
            <Route path='/seller/:slug' element={<SellerCategory />} />
            <Route path="/seller-products/:sellerName" element={<SellerWithProducts />} />
            <Route path='/seller/:slug/:categorySlug' element={<SellerCategoryChild />} />
            <Route path='/myAccount' element={<MyAccount />} />
            <Route path="/wishlist" element={<WishlistPage />} />
            <Route path="/checkout" element={<CheckoutPage />} />
            <Route path="/order-confirmation" element={<OrderConfirmation />} />
            <Route path='/seller/:slug/:categorySlug/subcategory/:subCategorySlug' element={<SellerSubCategoryProducts />} />
            <Route path='/allSellers' element={<AllSellers />} />
            <Route path="/deals" element={<Deals />} />

            {/* company routes  */}
            <Route path="/about-us" element={<AboutUsPage />} />
            <Route path="/faqs" element={<FaqsPage />} />
            <Route path="/contact-us" element={<ContactUsPage />} />
            <Route path="/terms-and-conditions" element={<TermsAndConditionsPage />} />
            <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
            <Route path="/return-policy" element={<ReturnPolicyPage />} />
            <Route path="/shipping-policy" element={<ShippingPolicyPage />} />
            <Route path="/cancellation-policy" element={<CancellationPolicyPage />} />

            {/* user dropdown section  */}
            <Route path="/edit-profile" element={<EditProfile />} />
            <Route path="/my-orders" element={<MyOrders />} />
            <Route path="/my-orders/details/:id" element={<OrderDetails />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/my-addresses" element={<MyAddresses />} />
            <Route path="/wallet-balance" element={<WalletBalance />} />
            <Route path="/transactions" element={<Transaction />} />

            <Route path="/register" element={<NewUserRegisterModal />} />
            <Route path="*" element={<PageNotFound />} />
          </Routes>
        </LayoutWrapper>
      </Router>

      <ToastContainer
        position="bottom-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
    </MantineProvider>
  );
}

export default App;
