import { useState, useEffect } from "react"
import { useLocation, useNavigate } from "react-router-dom"
import { Heart, ShoppingBag, Star, Truck, Wallet, Shield, Share2, ChevronDown, Check, ExternalLink, CalendarIcon as CalendarSync, Plus, Minus, Award, Clock, Package, ShoppingCart, Info, Zap, Gift } from 'lucide-react'
import { FaFacebook, FaWhatsapp } from "react-icons/fa"
import NotReturnable from "../../utils/Icons/NotReturnable.svg"
import VerticalSlider from "./VerticalSlider"
import Breadcrumbs from "../Breadcrumbs"
import { addtoGuestCart, setCart, setCartProducts, setCartSubTotal } from "../../model/reducer/cartReducer"
import { useDispatch, useSelector } from "react-redux"
import { addFavoriteProduct, removeFavoriteProduct } from "../../model/reducer/favouriteReducer"
import api from "../../api/api"
import { toast } from "react-toastify"
import { slugify } from "../../utils/Slugify"
import RelatedProductsPage from "../../Pages/RelatedProducts"

// Enhanced Toast component with better styling
const Toast = ({ message, type = "success" }) => {
  const bgColor = type === "success" ? "bg-gradient-to-r from-emerald-500 to-emerald-600" : "bg-gradient-to-r from-red-500 to-red-600"
  const position = type === "success" ? "right-4" : "left-4"
  return (
    <div
      className={`fixed top-4 ${position} ${bgColor} text-white px-6 py-3 rounded-xl shadow-2xl z-50 animate-slide-in-fade flex items-center gap-3 text-sm backdrop-blur-sm border border-white/20`}
    >
      {type === "success" ? (
        <div className="w-5 h-5 bg-white/20 rounded-full flex items-center justify-center">
          <Check className="w-3 h-3" />
        </div>
      ) : (
        <div className="w-5 h-5 bg-white/20 rounded-full flex items-center justify-center">
          <Info className="w-3 h-3" />
        </div>
      )}
      <span className="font-medium">{message}</span>
    </div>
  )
}

const DesktopDetails = () => {
  const [cartCount, setCartCount] = useState(1)
  const [activeTab, setActiveTab] = useState("details")
  const [showFullDescription, setShowFullDescription] = useState(false)
  const [selectedVariant, setSelectedVariant] = useState(null)
  const [showShareModal, setShowShareModal] = useState(false)
  const location = useLocation()
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { product: initialProduct = {}, breadcrumbs } = location.state || {}
  const { favouriteProductIds = [] } = useSelector((state) => state.favourite)
  const { user, status, jwtToken } = useSelector((state) => state.user)
  const { city } = useSelector((state) => state.city)
  const { isGuest, cartProducts } = useSelector((state) => state.cart)
  const isLoggedIn = status === "fulfill" && jwtToken
  const [showAddToCartFeedback, setShowAddToCartFeedback] = useState(false)
  const [showWishlistToast, setShowWishlistToast] = useState(false)
  const [wishlistToastMessage, setWishlistToastMessage] = useState("")
  const [wishlistToastType, setWishlistToastType] = useState("success")
  const [showLoginCartToast, setShowLoginCartToast] = useState(false)
  const [isAddingToCart, setIsAddingToCart] = useState(false)
  const [isInCart, setIsInCart] = useState(false)
  const [currentCartQuantity, setCurrentCartQuantity] = useState(0)
  const [isWishlistLoading, setIsWishlistLoading] = useState(false)
  const [product, setProduct] = useState(() => {
    const productData = location.state?.product || {};
    console.log("productData", productData)
    const allImages = productData.image_url
      ? [productData.image_url, ...(productData.images || []).filter(img => img !== productData.image_url)]
      : productData.images || ['https://via.placeholder.com/500'];
    return {
      ...productData,
      id: productData.id || '',
      name: productData?.name || 'Unnamed Product',
      seller_name: productData.seller?.name || productData.seller_name || "",
      seller_image_url: productData.seller?.image_url || "",
      variants: productData.variants || [],
      images: allImages,
      image_url: productData?.image_url || allImages[0] || "",
      price: productData.price || 0,
      discounted_price: productData.discounted_price || productData.price || 0,
      slug: productData.slug || `product-${productData.id || 'unknown'}`
    };
  });
  const [images, setImages] = useState(() => {
    const initialProduct = location.state?.product || {};
    const imagesArray = [];
    if (initialProduct?.image_url) {
      imagesArray.push(initialProduct?.image_url);
    }
    if (initialProduct?.images && initialProduct?.images.length > 0) {
      const uniqueImages = initialProduct?.images.filter(img => img !== initialProduct?.image_url);
      imagesArray.push(...uniqueImages);
    }
    return imagesArray.length > 0 ? imagesArray : ["https://via.placeholder.com/500"];
  });

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [product?.id]);

  useEffect(() => {
    if (initialProduct) {
      const processedProduct = {
        ...initialProduct,
        variants: initialProduct?.variants || [],
      }
      const productImages = []
      if (initialProduct?.image_url) {
        productImages.push(initialProduct?.image_url)
      }
      if (initialProduct?.images && initialProduct?.images.length > 0) {
        const uniqueImages = initialProduct?.images.filter((img) => img !== initialProduct?.image_url)
        productImages.push(...uniqueImages)
      }
      if (productImages.length === 0) {
        productImages.push("https://via.placeholder.com/500")
      }
      setImages(productImages)
      setProduct((prev) => ({
        ...processedProduct,
        images: productImages,
        seller_name: processedProduct?.seller?.name || "",
        seller_image_url: processedProduct?.seller?.image_url || "",
      }))
      // Auto-select the first variant if variants exist
      if (processedProduct?.variants && processedProduct?.variants.length > 0) {
        // Find the first in-stock variant or fall back to the first variant
        const firstInStockVariant = processedProduct?.variants.find(v =>
          product?.is_unlimited_stock === 1 || v.stock > 0
        ) || processedProduct?.variants[0]
        setSelectedVariant(firstInStockVariant)
      }
    }
  }, [initialProduct])

  useEffect(() => {
    if (!product) return
    const productId = product?.id
    const variantId = selectedVariant?.id || null
    if (isLoggedIn) {
      const cartItem = cartProducts?.find(
        (item) => item.product_id === productId && item.product_variant_id === variantId,
      )
      if (cartItem) {
        setIsInCart(true)
        setCurrentCartQuantity(cartItem.quantity)
        setCartCount(cartItem.quantity)
      } else {
        setIsInCart(false)
        setCurrentCartQuantity(0)
        setCartCount(1)
      }
    } else if (isGuest) {
      // Guest cart logic here
    }
  }, [product, selectedVariant, cartProducts, isLoggedIn, isGuest])

  useEffect(() => {
    if (!selectedVariant) return
    if (selectedVariant.images && selectedVariant.images.length > 0) {
      setImages(selectedVariant.images)
    } else {
      const productImages = []
      if (product?.image_url) {
        productImages.push(product?.image_url)
      }
      if (product?.images && product?.images.length > 0) {
        const uniqueImages = product?.images.filter((img) => img !== product?.image_url)
        productImages.push(...uniqueImages)
      }
      if (productImages?.length === 0) {
        productImages.push("https://via.placeholder.com/500")
      }
      setImages(productImages)
    }
  }, [selectedVariant, product])

  const isFavorite = product?.id ? favouriteProductIds.includes(product?.id) : false

  const handleVariantSelect = (variant) => {
    setSelectedVariant(variant)
    setCartCount(1)
  }

  const getCurrentPrice = () => {
    if (selectedVariant) {
      return {
        price: selectedVariant.price,
        discountedPrice: selectedVariant.discounted_price,
        discountPercentage: Math.round(
          ((selectedVariant.price - selectedVariant.discounted_price) / selectedVariant.price) * 100,
        ),
      }
    }
    return {
      price: product?.price || 0,
      discountedPrice: product?.discounted_price || product?.price || 0,
      discountPercentage: product?.cal_discount_percentage || 0,
    }
  }

  const { price, discountedPrice, discountPercentage } = getCurrentPrice()

  const fetchCartData = async () => {
    try {
      const response = await api.getCart(jwtToken, city?.city?.latitude || 28.6139, city?.city?.longitude || 77.209)
      const result = await response.json()
      if (result.status === 1) {
        const productsData = result?.data?.cart?.map((product) => ({
          id: product?.id,
          product_id: product?.product_id,
          product_variant_id: product?.product_variant_id,
          quantity: product?.qty,
          price: product?.price,
          discounted_price: product?.discounted_price,
          name: product?.name,
          image: product?.image_url,
          measurement: product?.measurement,
          unit_code: product?.unit_code,
          stock: product?.stock,
          is_unlimited_stock: product?.is_unlimited_stock,
          total_allowed_quantity: product?.total_allowed_quantity,
          slug: product?.slug,
          status: product?.status === 1,
        }))
        dispatch(setCart({ data: result }))
        dispatch(setCartSubTotal({ data: result?.data?.sub_total || 0 }))
        dispatch(setCartProducts({ data: productsData }))
      }
    } catch (err) {
      console.error("Failed to fetch cart:", err)
    }
  }

  useEffect(() => {
    const fetchProductDetails = async () => {
      if (!initialProduct) return
      try {
        const response = await api.getProductbyId(
          city?.city?.latitude || 28.6139,
          city?.city?.longitude || 77.209,
          initialProduct?.id,
          jwtToken,
          initialProduct?.slug,
        )
        const result = await response.json()
        if (result.status === 1) {
          const allImages = result?.data?.image_url
            ? [result?.data?.image_url, ...(result?.data?.images || []).filter((img) => img !== result?.data?.image_url)]
            : result.data.images || ["https://via.placeholder.com/500"]
          const productData = {
            ...result.data,
            seller_name: result.data.seller?.name || "",
            seller_image_url: result.data.seller?.image_url || "",
            variants: result.data.variants || [],
            images: allImages,
          }
          setProduct(productData)
          setImages(allImages)
        }
      } catch (error) {
        console.error("Failed to fetch product details:", error)
      }
    }
    fetchProductDetails()
  }, [initialProduct, jwtToken, city])

  useEffect(() => {
    const fetchProductFromUrl = async () => {
      if (!initialProduct) {
        const searchParams = new URLSearchParams(window.location.search)
        const productId = searchParams.get("id")
        if (productId) {
          try {
            const response = await api.getProductbyId(
              city?.city?.latitude || 28.6139,
              city?.city?.longitude || 77.209,
              productId,
              jwtToken,
              location.pathname.split("/").pop(),
            )
            const result = await response.json()
            if (result.status === 1) {
              const allImages = result?.data?.image_url
                ? [result.data.image_url, ...(result.data.images || []).filter((img) => img !== result.data.image_url)]
                : result.data.images || ["https://via.placeholder.com/500"]
              const productData = {
                ...result.data,
                seller_name: result.data.seller?.name || "",
                seller_image_url: result.data.seller?.image_url || "",
                variants: result.data.variants || [],
                images: allImages,
                price: result.data.price,
                discounted_price: result.data.discounted_price,
                cal_discount_percentage: result.data.cal_discount_percentage,
              }
              setProduct(productData)
              setImages(allImages)
            }
          } catch (error) {
            console.error("Failed to fetch product from URL:", error)
          }
        }
      }
    }
    fetchProductFromUrl()
  }, [initialProduct, jwtToken, city, location.pathname])

  useEffect(() => {
    if (product) {
      const updateMetaTag = (name, content) => {
        let tag = document.querySelector(`meta[property="${name}"]`)
        if (!tag) {
          tag = document.createElement("meta")
          tag.setAttribute("property", name)
          document.head.appendChild(tag)
        }
        tag.setAttribute("content", content)
      }
      updateMetaTag("og:title", product?.name)
      updateMetaTag("og:description", product?.description || product?.name)
      updateMetaTag("og:image", product?.image_url || product?.images?.[0] || "")
      updateMetaTag("og:url", window.location.href)
      updateMetaTag("og:type", "product")
      updateMetaTag("twitter:card", "summary_large_image")
      updateMetaTag("twitter:title", product?.name)
      updateMetaTag("twitter:description", product?.description || product?.name)
      updateMetaTag("twitter:image", product?.image_url || product?.images?.[0] || "")
    }
  }, [product])

  const handleAddToCart = async (quantity) => {
    if (!product) return
    const currentProduct = selectedVariant || product
    const productId = product?.id
    const variantId = selectedVariant?.id || null
    if (!isLoggedIn && !isGuest) {
      setShowLoginCartToast(true)
      setTimeout(() => setShowLoginCartToast(false), 3000)
      return
    }
    setIsAddingToCart(true)
    try {
      if (isLoggedIn) {
        const response = await api.addToCart(jwtToken, productId, variantId, quantity)
        const result = await response.json()
        if (result.status === 1) {
          setShowAddToCartFeedback(true)
          setTimeout(() => setShowAddToCartFeedback(false), 3000)
          await fetchCartData()
          toast.success(`${quantity} item(s) ${isInCart ? "updated in" : "added to"} cart`)
        } else {
          toast.error(result.message || "Failed to update cart")
        }
      } else {
        const cartItem = {
          id: `${productId}_${variantId || "base"}`,
          product_id: productId,
          product_variant_id: variantId,
          name: product?.name,
          price: price,
          discounted_price: discountedPrice,
          image: images[0],
          quantity: quantity,
          measurement: currentProduct?.measurement || "1",
          unit_code: currentProduct?.stock_unit_name || "PC",
          stock: currentProduct?.stock || 0,
          total_allowed_quantity: currentProduct?.total_allowed_quantity || 10000,
          slug: product?.slug,
          status: product?.status || 1,
        }
        dispatch(addtoGuestCart({ data: cartItem }))
        setShowAddToCartFeedback(true)
        setTimeout(() => setShowAddToCartFeedback(false), 3000)
        toast.success(`${quantity} item(s) ${isInCart ? "updated in" : "added to"} cart`)
      }
    } catch (error) {
      console.error("Add to cart error:", error)
      toast.error(error.message || "Failed to update cart")
    } finally {
      setIsAddingToCart(false)
    }
  }

  const handleIncreaseQuantity = () => {
    const maxQuantity =
      product?.is_unlimited_stock === 1
        ? product?.total_allowed_quantity || 10000
        : selectedVariant?.stock || product?.stock || 0
    if (cartCount < maxQuantity) {
      const newQuantity = cartCount + 1
      setCartCount(newQuantity)
      handleAddToCart(newQuantity)
    }
  }

  const handleDecreaseQuantity = () => {
    const newQuantity = Math.max(1, cartCount - 1)
    setCartCount(newQuantity)
    handleAddToCart(newQuantity)
  }

  const handleWishlistToggle = async () => {
    if (!product) return
    if (!isLoggedIn) {
      setWishlistToastMessage("Please login to add to wishlist")
      setWishlistToastType("error")
      setShowWishlistToast(true)
      setTimeout(() => setShowWishlistToast(false), 3000)
      return
    }
    setIsWishlistLoading(true)
    try {
      if (isFavorite) {
        const response = await api.removeFromFavorite(jwtToken, product?.id)
        const result = await response.json()
        if (result.status === 1) {
          dispatch(removeFavoriteProduct({ data: product?.id }))
          setWishlistToastMessage("Removed from wishlist")
          setWishlistToastType("success")
        } else {
          throw new Error(result.message || "Failed to remove from favorites")
        }
      } else {
        const response = await api.addToFavotite(jwtToken, product?.id)
        const result = await response.json()
        if (result.status === 1) {
          dispatch(addFavoriteProduct({ data: product?.id }))
          setWishlistToastMessage("Added to wishlist")
          setWishlistToastType("success")
        } else {
          throw new Error(result.message || "Failed to add to favorites")
        }
      }
      setShowWishlistToast(true)
      setTimeout(() => setShowWishlistToast(false), 3000)
    } catch (error) {
      console.error("Wishlist error:", error)
      toast.error(error.message || "Failed to update wishlist")
    } finally {
      setIsWishlistLoading(false)
    }
  }

  const formatPrice = (price) => {
    if (typeof price === "number") {
      return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0,
      })
        .format(price)
        .replace("₹", "₹ ")
    }
    return price
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="text-center bg-white p-12 rounded-2xl shadow-xl border border-gray-200 max-w-md mx-4">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Package className="w-8 h-8 text-gray-400" />
          </div>
          <div className="text-xl font-bold text-gray-900 mb-3">Product not found</div>
          <p className="text-gray-600 mb-6 leading-relaxed">
            The product you're looking for doesn't exist or has been removed from our catalog.
          </p>
          <button
            onClick={() => navigate(-1)}
            className="px-8 py-3 bg-gradient-to-r from-[#fc2e6b] to-[#fc2e6b]/90 text-white rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-200"
          >
            Go Back
          </button>
        </div>
      </div>
    )
  }

  const ShareModal = ({ product, onClose }) => {
    const [isCopied, setIsCopied] = useState(false)
    const productUrl = `${window.location.origin}/product/${product?.slug}?id=${product?.id}`
    const shareText = `Check out ${product?.name} on our store!`
    const handleCopyLink = async () => {
      try {
        await navigator.clipboard.writeText(productUrl)
        setIsCopied(true)
        setTimeout(() => setIsCopied(false), 2000)
      } catch (err) {
        console.error("Failed to copy:", err)
      }
    }
    const handleFacebookShare = () => {
      const facebookShareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
        productUrl,
      )}&quote=${encodeURIComponent(shareText)}`
      window.open(facebookShareUrl, "_blank", "width=600,height=400")
    }
    const handleWhatsAppShare = () => {
      const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(`${shareText}\n${productUrl}`)}`
      window.open(whatsappUrl, "_blank", "width=600,height=400")
    }
    return (
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 transform animate-modal-in">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold text-gray-900">Share this product</h3>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-700 transition-colors"
            >
              ×
            </button>
          </div>
          <div className="space-y-6">
            <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl border">
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center shadow-sm">
                <Gift className="w-6 h-6 text-[#fc2e6b]" />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-gray-900 line-clamp-2 text-sm">{product?.name}</h4>
                <div className="flex items-center mt-1">
                  <span className="text-lg font-bold text-[#fc2e6b]">
                    {formatPrice(product?.discounted_price || product?.price)}
                  </span>
                  {product?.cal_discount_percentage > 0 && (
                    <span className="ml-2 text-sm line-through text-gray-500">
                      {formatPrice(product?.price)}
                    </span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border">
              <div className="truncate text-sm text-gray-700 flex-1 mr-3 font-mono bg-white px-3 py-2 rounded-lg">
                {productUrl}
              </div>
              <button
                onClick={handleCopyLink}
                className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all ${isCopied
                  ? "bg-green-100 text-green-800 border border-green-200"
                  : "bg-[#fc2e6b] text-white hover:bg-[#fc2e6b]/90 shadow-md hover:shadow-lg"
                  }`}
              >
                {isCopied ? "Copied!" : "Copy"}
              </button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={handleFacebookShare}
                className="flex items-center justify-center gap-3 bg-[#1877F2] text-white py-4 px-4 rounded-xl hover:bg-[#166FE5] transition-all duration-200 font-semibold shadow-md hover:shadow-lg transform hover:scale-105"
              >
                <FaFacebook className="w-5 h-5" />
                Facebook
              </button>
              <button
                onClick={handleWhatsAppShare}
                className="flex items-center justify-center gap-3 bg-[#25D366] text-white py-4 px-4 rounded-xl hover:bg-[#1DA851] transition-all duration-200 font-semibold shadow-md hover:shadow-lg transform hover:scale-105"
              >
                <FaWhatsapp className="w-5 h-5" />
                WhatsApp
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const calculateTimeDifference = (createdAt) => {
    if (!createdAt) return "Recently joined"
    const createdDate = new Date(createdAt)
    const currentDate = new Date()
    if (isNaN(createdDate.getTime())) return "Recently joined"
    let years = currentDate.getFullYear() - createdDate.getFullYear()
    let months = currentDate.getMonth() - createdDate.getMonth()
    let days = currentDate.getDate() - createdDate.getDate()
    if (days < 0) {
      months--
      const tempDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0)
      days += tempDate.getDate()
    }
    if (months < 0) {
      years--
      months += 12
    }
    const parts = []
    if (years > 0) parts.push(`${years}y`)
    if (months > 0) parts.push(`${months} month`)
    if (days > 0 || parts.length === 0) parts.push(`${days} days`)
    return parts.join(" ")
  }

  const stockStatus =
    product?.is_unlimited_stock === 1
      ? "In Stock"
      : selectedVariant?.stock
        ? selectedVariant.stock < 5
          ? `Only ${selectedVariant.stock} left`
          : "In Stock"
        : product?.stock
          ? product?.stock < 5
            ? `Only ${product?.stock} left`
            : "In Stock"
          : "Out of Stock"

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Enhanced Breadcrumbs */}
        <div className="mb-8">
          <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <Breadcrumbs
              paths={
                breadcrumbs || [
                  { name: "Home", path: "/" },
                  { name: product?.category?.name || "Category", path: "#" },
                  { name: product?.name, path: null },
                ]
              }
            />
          </div>
        </div>

        <div className="grid grid-cols-12 gap-8">
          {/* Left Column - Images */}
          <div className="col-span-5">
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
              <VerticalSlider key={selectedVariant?.id || product?.id} images={images} />
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 mt-8">
              {showAddToCartFeedback ? (
                <button className="flex-1 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-2xl py-4 font-bold flex items-center justify-center gap-3 text-base shadow-lg">
                  <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center">
                    <Check className="w-4 h-4" />
                  </div>
                  {isInCart ? "Updated in Cart" : "Added to Cart"}
                </button>
              ) : isInCart ? (
                <button className="flex-1 bg-gradient-to-r from-emerald-50 to-emerald-100 text-emerald-700 border-2 border-emerald-200 rounded-2xl py-4 font-bold flex items-center justify-center gap-3 text-base">
                  <Check className="w-5 h-5" />
                  In Cart ({currentCartQuantity})
                </button>
              ) : (
                <>
                  <button
                    onClick={() => handleAddToCart(cartCount)}
                    disabled={isAddingToCart || (product?.is_unlimited_stock !== 1 && stockStatus === "Out of Stock")}
                    className="flex-1 bg-gradient-to-r from-[#fc2e6b] to-[#fc2e6b]/90 hover:from-[#fc2e6b]/90 hover:to-[#fc2e6b] text-white rounded-2xl py-4 font-bold flex items-center justify-center gap-3 transition-all duration-300 disabled:opacity-50 text-base shadow-lg hover:shadow-xl transform hover:scale-[1.02]"
                  >
                    {isAddingToCart ? (
                      <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <>
                        <ShoppingCart className="w-5 h-5" />
                        Add to Cart
                      </>
                    )}
                  </button>
                  <button
                    onClick={async () => {
                      await handleAddToCart(cartCount)
                      navigate("/cart")
                    }}
                    disabled={isAddingToCart || (product?.is_unlimited_stock !== 1 && stockStatus === "Out of Stock")}
                    className="flex-1 bg-white hover:bg-gray-50 text-[#fc2e6b] rounded-2xl py-4 font-bold flex items-center justify-center gap-3 transition-all duration-300 disabled:opacity-50 text-base border-2 border-[#fc2e6b] shadow-lg hover:shadow-xl transform hover:scale-[1.02]"
                  >
                    <Zap className="w-5 h-5" />
                    Buy Now
                  </button>
                </>
              )}

              <button
                onClick={handleWishlistToggle}
                disabled={isWishlistLoading}
                className={`w-16 h-16 border-2 rounded-2xl flex items-center justify-center transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 ${isFavorite
                  ? "border-red-300 bg-gradient-to-br from-red-50 to-red-100 text-red-500"
                  : "border-gray-200 bg-white text-gray-500 hover:bg-gray-50"
                  } disabled:opacity-50`}
              >
                {isWishlistLoading ? (
                  <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <Heart className={`w-6 h-6 ${isFavorite ? "fill-red-500" : ""}`} />
                )}
              </button>

              <button
                onClick={() => setShowShareModal(true)}
                className="w-16 h-16 border-2 border-gray-200 rounded-2xl flex items-center justify-center bg-white hover:bg-gray-50 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                <Share2 className="w-6 h-6 text-gray-500" />
              </button>
            </div>
          </div>

          {/* Right Column - Product Details */}
          <div className="col-span-7">
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100">
              <div className="p-8">
                {/* Product Header */}
                <div className="mb-8">
                  <h1 className="text-3xl font-bold text-gray-900 mb-4 leading-tight">{product?.name}</h1>
                  <div className="flex items-center gap-6 mb-6">
                    <div className="flex items-center bg-gradient-to-r from-yellow-50 to-amber-50 px-4 py-2 rounded-xl border border-yellow-200">
                      <div className="flex mr-3">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${i < Math.floor(product?.rating || 4) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                              }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm font-bold text-yellow-700">{product?.rating || 4.5}</span>
                      <span className="text-yellow-600 ml-2 text-sm">({product?.rating_count || 0} reviews)</span>
                    </div>
                    {product?.sku &&
                      product?.sku !== null &&
                      product?.sku !== "" &&
                      product?.sku !== "null" && (
                        <div className="bg-gradient-to-r from-gray-50 to-gray-100 px-4 py-2 rounded-xl border border-gray-200">
                          <span className="text-sm text-gray-600">SKU: </span>
                          <span className="text-sm font-bold text-gray-800">{product?.sku}</span>
                        </div>
                      )}
                  </div>
                  {product?.manufacturer &&
                    product?.manufacturer !== null &&
                    product?.manufacturer !== "" &&
                    product?.manufacturer !== "null" && (
                      <div className="mb-6 bg-gradient-to-r from-blue-50 to-indigo-50 px-4 py-2 rounded-xl border border-blue-200 inline-block">
                        <span className="text-sm text-blue-600">Manufacturer: </span>
                        <span className="text-sm font-bold text-blue-800">{product?.manufacturer}</span>
                      </div>
                    )}
                </div>

                {/* Pricing */}
                <div className="bg-gradient-to-r from-[#fc2e6b]/5 to-[#fc2e6b]/10 rounded-2xl p-6 mb-8 border border-[#fc2e6b]/20">
                  <div className="flex items-baseline gap-4 mb-3">
                    <span className="text-3xl font-black text-gray-900">
                      {discountedPrice ? formatPrice(discountedPrice) : formatPrice(price)}
                    </span>
                    {discountPercentage > 0 && (
                      <>
                        <span className="text-gray-500 line-through text-xl">{formatPrice(price)}</span>
                        <span className="text-white font-bold bg-gradient-to-r from-emerald-500 to-emerald-600 px-3 py-1 rounded-full text-sm shadow-md">
                          {discountPercentage}% OFF
                        </span>
                      </>
                    )}
                  </div>
                  {discountPercentage > 0 && (
                    <div className="text-emerald-600 font-bold text-base flex items-center gap-2">
                      <Gift className="w-4 h-4" />
                      You save: {formatPrice(price - discountedPrice)}
                    </div>
                  )}
                </div>

                {/* Quantity Selector */}
                <div className="flex items-center justify-between mb-8 bg-gradient-to-r from-gray-50 to-gray-100 p-6 rounded-2xl border border-gray-200">
                  <div>
                    <span className="text-base font-bold text-gray-800">Quantity</span>
                    <span className="text-sm text-gray-600 ml-3">
                      ({selectedVariant?.stock_unit_name || product?.stock_unit_name || "PC"})
                    </span>
                  </div>
                  <div className="flex items-center gap-0 bg-white border-2 border-gray-200 rounded-xl overflow-hidden shadow-sm">
                    <button
                      onClick={handleDecreaseQuantity}
                      disabled={isAddingToCart}
                      className="w-12 h-12 flex items-center justify-center text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50 font-bold"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="text-base font-bold w-16 text-center bg-gray-50 h-12 flex items-center justify-center border-x-2 border-gray-200">
                      {cartCount}
                    </span>
                    <button
                      onClick={handleIncreaseQuantity}
                      disabled={
                        isAddingToCart ||
                        (product?.is_unlimited_stock === 1
                          ? false
                          : (selectedVariant?.stock && cartCount >= selectedVariant.stock) ||
                          (!selectedVariant?.size && product?.stock && cartCount >= product?.stock))
                      }
                      className="w-12 h-12 flex items-center justify-center text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50 font-bold"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Variants */}
                <div className="space-y-6 mb-8">
                  {product?.variants.some((v) => v.size) && (
                    <div>
                      <h4 className="text-base font-bold text-gray-800 mb-4">Size</h4>
                      <div className="flex flex-wrap gap-3">
                        {[...new Set(product?.variants.map((variant) => variant.size))].map((size) => {
                          const variantWithSize = product?.variants.find((v) => v.size === size)
                          const isInStock = product?.is_unlimited_stock === 1 || (variantWithSize?.stock > 0)
                          const isSelected = selectedVariant?.size === size
                          return (
                            <button
                              key={size}
                              onClick={() => variantWithSize && handleVariantSelect(variantWithSize)}
                              disabled={!isInStock}
                              className={`px-6 py-3 text-sm font-bold rounded-xl border-2 transition-all duration-200 ${isSelected
                                ? "bg-gradient-to-r from-[#fc2e6b] to-[#fc2e6b]/90 text-white border-[#fc2e6b] shadow-lg"
                                : isInStock
                                  ? "bg-white text-gray-700 border-gray-300 hover:border-[#fc2e6b] hover:bg-gray-50"
                                  : "bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed"
                                }`}
                              title={!isInStock ? "Out of stock" : ""}
                            >
                              {size}
                              {!isInStock && product?.is_unlimited_stock !== 1 && (
                                <span className="text-xs text-red-500 ml-2">(X)</span>
                              )}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  )}

                  {console.log("product", product)}
                  {product?.variants.some((v) => v.color) && (
                    <div>
                      <h4 className="text-base font-bold text-gray-800 mb-4">Color</h4>
                      <div className="flex flex-wrap gap-6">
                        {[
                          ...new Set(
                            product?.variants
                              .filter((v) => {
                                if (!selectedVariant?.size) return true;
                                return v.size === selectedVariant.size;
                              })
                              .map((v) => ({ color: v.color, color_name: v.color_name }))
                              .filter((v) => v.color)
                          ),
                        ].map((colorObj) => {
                          const variantWithColor = product?.variants.find(
                            (v) =>
                              v.color === colorObj.color &&
                              (selectedVariant?.size === v.size || !selectedVariant?.size)
                          );
                          const isInStock =
                            product?.is_unlimited_stock === 1 || variantWithColor?.stock > 0;
                          const isSelected = selectedVariant?.color === colorObj.color;
                          return (
                            <div key={colorObj.color} className="flex flex-col items-center gap-2">
                              <button
                                onClick={() =>
                                  variantWithColor && handleVariantSelect(variantWithColor)
                                }
                                disabled={!isInStock}
                                className={`w-12 h-12 rounded-full border-4 flex items-center justify-center transition-all duration-200 relative shadow-lg ${isSelected
                                  ? "border-[#fc2e6b] ring-4 ring-[#fc2e6b]/30 scale-110"
                                  : isInStock
                                    ? "border-gray-300 hover:border-[#fc2e6b] hover:scale-105"
                                    : "border-gray-200 opacity-50 cursor-not-allowed"
                                  }`}
                                style={{ backgroundColor: colorObj.color }}
                                title={
                                  colorObj.color_name
                                    ? `${colorObj.color_name}${!isInStock ? " (Out of stock)" : ""}`
                                    : colorObj.color + (!isInStock ? " (Out of stock)" : "")
                                }
                              >
                                {isSelected && (
                                  <Check className="w-4 h-4 text-white drop-shadow-lg" />
                                )}
                                {!isInStock && product?.is_unlimited_stock !== 1 && (
                                  <div className="absolute inset-0 flex items-center justify-center">
                                    <div className="w-8 h-px bg-gray-400 transform rotate-45"></div>
                                  </div>
                                )}
                              </button>
                              {colorObj.color_name && (
                                <span className="text-xs text-gray-600 text-center font-medium max-w-16 break-words">
                                  {colorObj.color_name}
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                {/* Key Features */}
                <div className="mb-8">
                  <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Zap className="w-5 h-5 text-[#fc2e6b]" />
                    Key Features
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {product?.product_specification
                      ?.filter(spec =>
                        spec.value &&
                        spec.value !== "null" &&
                        String(spec.value).trim() !== "" &&
                        [
                          "Display Type",
                          "Operating System",
                          "Processor",
                          "Rear Camera",
                          "Front Camera",
                          "Battery",
                          "Network Type",
                          "SIM Type"
                        ].includes(spec.name)
                      )
                      .map((spec, index) => (
                        <div key={index} className="flex items-start gap-3 p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl border border-gray-200 hover:shadow-md transition-shadow">

                          <div>
                            <h4 className="text-sm font-bold text-gray-800">{spec.name}</h4>
                            <p className="text-sm text-gray-600">{spec.value}</p>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>

                {/* Stock Status */}
                <div
                  className={`rounded-xl p-4 mb-8 flex items-center border-2 ${stockStatus.includes("Only") || stockStatus === "Out of Stock"
                    ? "bg-gradient-to-r from-red-50 to-red-100 border-red-200 text-red-700"
                    : "bg-gradient-to-r from-emerald-50 to-emerald-100 border-emerald-200 text-emerald-700"
                    }`}
                >
                  <Package
                    className={`w-5 h-5 mr-3 ${stockStatus.includes("Only") || stockStatus === "Out of Stock"
                      ? "text-red-500"
                      : "text-emerald-500"
                      }`}
                  />
                  <span className="font-bold">{stockStatus}</span>
                </div>

                {/* Product Policies */}
                <div className="space-y-4 mb-8">
                  {product?.cancelable_status === 1 && (
                    <div className="flex items-start gap-4 bg-gradient-to-r from-emerald-50 to-emerald-100 p-4 rounded-xl border border-emerald-200">
                      <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <Check className="w-4 h-4 text-white" />
                      </div>
                      <p className="text-sm text-emerald-700 font-medium">This product can be cancelled until it is processed.</p>
                    </div>
                  )}
                  {product?.return_status === 1 ? (
                    <div className="flex items-start gap-4 bg-gradient-to-r from-blue-50 to-blue-100 p-4 rounded-xl border border-blue-200">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <Shield className="w-4 h-4 text-white" />
                      </div>
                      <p className="text-sm text-blue-700 font-medium">
                        This product is returnable within {product?.return_days || 7} days of delivery.
                      </p>
                    </div>
                  ) : (
                    <div className="flex items-start gap-4 bg-gradient-to-r from-red-50 to-red-100 p-4 rounded-xl border border-red-200">
                      <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <img src={NotReturnable || "/placeholder.svg"} alt="Not Returnable" className="w-4 h-4" />
                      </div>
                      <p className="text-sm text-red-700 font-bold">This product is not returnable.</p>
                    </div>
                  )}
                </div>

                {/* Service Features */}
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="flex items-center gap-4 p-4 rounded-xl border border-blue-200 bg-gradient-to-r from-blue-50 to-blue-100 hover:shadow-md transition-shadow">
                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
                      <Truck className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-blue-900">
                        {product?.free_delivery ? "Free Delivery" : "Delivery Available"}
                      </div>
                      <div className="text-xs text-blue-700">Fast & Reliable</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 rounded-xl border border-yellow-200 bg-gradient-to-r from-yellow-50 to-yellow-100 hover:shadow-md transition-shadow">
                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
                      <Award className="w-6 h-6 text-yellow-600" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-yellow-900">Top Rated</div>
                      <div className="text-xs text-yellow-700">Premium Quality</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 rounded-xl border border-emerald-200 bg-gradient-to-r from-emerald-50 to-emerald-100 hover:shadow-md transition-shadow">
                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
                      <Wallet className="w-6 h-6 text-emerald-600" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-emerald-900">Secure Payment</div>
                      <div className="text-xs text-emerald-700">100% Protected</div>
                    </div>
                  </div>
                  <div
                    className={`flex items-center gap-4 p-4 rounded-xl border hover:shadow-md transition-shadow ${product?.return_status
                      ? "border-purple-200 bg-gradient-to-r from-purple-50 to-purple-100"
                      : "border-red-200 bg-gradient-to-r from-red-50 to-red-100"
                      }`}
                  >
                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
                      <Shield className={`w-6 h-6 ${product?.return_status ? "text-purple-600" : "text-red-600"}`} />
                    </div>
                    <div>
                      <div
                        className={`text-sm font-bold ${product?.return_status ? "text-purple-900" : "text-red-900"}`}
                      >
                        {product?.return_status ? "Easy Returns" : "No Returns"}
                      </div>
                      <div className={`text-xs ${product?.return_status ? "text-purple-700" : "text-red-700"}`}>
                        {product?.return_status ? `${product?.return_days || 7} Days` : "Final Sale"}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Enhanced Tabs */}
                <div className="border-b border-gray-200 mb-8">
                  <div className="flex bg-gray-50 rounded-xl p-1">
                    {["details", "reviews", "shipping"].map((tab) => (
                      <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`flex-1 px-6 py-3 text-sm font-bold capitalize transition-all duration-200 rounded-lg ${activeTab === tab
                          ? "bg-white text-[#fc2e6b] shadow-md"
                          : "text-gray-600 hover:text-[#fc2e6b]"
                          }`}
                      >
                        {tab}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Tab Content */}
                <div className="pb-8">
                  {activeTab === "details" && (
                    <div className="space-y-8">
                      <div className="product-description">
                        <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                          <Info className="w-5 h-5 text-[#fc2e6b]" />
                          Product Description
                        </h3>
                        <div
                          className={`text-sm text-gray-600 leading-relaxed bg-gradient-to-r from-gray-50 to-gray-100 p-6 rounded-xl border border-gray-200 ${!showFullDescription && "line-clamp-4"
                            }`}
                          dangerouslySetInnerHTML={{
                            __html:
                              product?.description ||
                              `<p style="font-size: 0.875rem; color: #4B5563;">The <strong>${product?.name}</strong> is a high-quality product crafted to meet your needs. Made with durable materials and excellent craftsmanship, it ensures long-lasting performance. Ideal for daily use, it blends style and functionality seamlessly.</p>`,
                          }}
                        />
                        <button
                          onClick={() => setShowFullDescription(!showFullDescription)}
                          className="mt-4 text-[#fc2e6b] text-sm font-bold flex items-center hover:text-[#fc2e6b]/80 transition-colors"
                        >
                          {showFullDescription ? "Show less" : "Read more"}
                          <ChevronDown
                            size={16}
                            className={`ml-2 transition-transform ${showFullDescription ? "rotate-180" : ""}`}
                          />
                        </button>
                      </div>

                      <div className="specifications">
                        <h3 className="text-2xl font-semibold text-gray-900 mb-6 border-b pb-2">
                          Full Specifications
                        </h3>

                        <div className="bg-white rounded-xl overflow-hidden border border-gray-200 shadow-sm divide-y divide-gray-200">
                          {/* Dynamic specifications */}
                          {product?.product_specification
                            ?.filter(
                              (spec) =>
                                spec.value &&
                                spec.value !== "null" &&
                                String(spec.value).trim() !== "" &&
                                ![
                                  "Display",
                                  "Operating System",
                                  "Processor",
                                  "Rear Camera",
                                  "Front Camera",
                                  "Battery",
                                  "Network Type",
                                  "SIM Type",
                                ].includes(spec.name)
                            )
                            .map((spec, index) => (
                              <div
                                key={`dyn-${index}`}
                                className="flex justify-between items-center px-6 py-4 text-sm bg-white hover:bg-gray-50 transition"
                              >
                                <span className="text-[#1e3a8a] font-semibold w-1/2">{spec.name}</span>
                                <span className="text-right font-medium text-gray-900 w-1/2">
                                  {spec.value}
                                </span>
                              </div>
                            ))}

                          {/* Static/common specifications */}
                          {[
                            { label: "Brand", value: product?.brand?.name },
                            { label: "Manufacturer", value: product?.manufacturer },
                            { label: "Category", value: product?.category?.name },
                            {
                              label: "No. of Pieces",
                              value: selectedVariant?.no_of_pics || product?.variants?.[0]?.no_of_pics,
                            },
                            {
                              label: "Capacity",
                              value: selectedVariant?.capacity || product?.variants?.[0]?.capacity,
                            },
                            {
                              label: "Weight",
                              value: (() => {
                                const weight =
                                  product?.weight_in_grams ||
                                  selectedVariant?.weight_in_grams ||
                                  product?.variants?.[0]?.weight_in_grams;
                                const weightNumber = parseInt(weight);
                                if (!isNaN(weightNumber) && weightNumber > 0) {
                                  return weightNumber >= 1000
                                    ? `${(weightNumber / 1000).toFixed(2)} kg`
                                    : `${weightNumber} g`;
                                }
                                return null;
                              })(),
                            },
                            {
                              label: "Pattern",
                              value: selectedVariant?.pattern || product?.variants?.[0]?.pattern,
                            },
                            {
                              label: "Material",
                              value: selectedVariant?.material || product?.variants?.[0]?.material,
                            },
                            {
                              label: "Dimensions",
                              value: selectedVariant?.dimensions || product?.variants?.[0]?.dimensions,
                            },
                            {
                              label: "Stock Unit",
                              value: selectedVariant?.stock_unit_name || product?.stock_unit_name,
                            },
                            { label: "Type", value: product?.type },
                            {
                              label: "Made In",
                              value:
                                typeof product?.made_in === "object"
                                  ? product?.made_in?.name
                                  : product?.made_in,
                            },
                            {
                              label: "Warranty",
                              value:
                                product?.warranty_id &&
                                  product?.warranty_id !== "null"
                                  ? product?.warranty_id
                                    .replace(/_/g, " ")
                                    .replace(/\b\w/g, (c) => c.toUpperCase())
                                  : null,
                            },
                            {
                              label: "Accessories Warranty",
                              value:
                                product?.accessories_warranty_id &&
                                  product?.accessories_warranty_id !== "null"
                                  ? product?.accessories_warranty_id
                                    .replace(/_/g, " ")
                                    .replace(/\b\w/g, (c) => c.toUpperCase())
                                  : null,
                            },
                          ]
                            .filter(
                              (spec) =>
                                spec.value &&
                                spec.value !== "null" &&
                                spec.value !== "0" &&
                                String(spec.value).trim().toLowerCase() !== "null" &&
                                String(spec.value).trim().toLowerCase() !== "0"
                            )
                            .map((spec, index) => (
                              <div
                                key={`static-${index}`}
                                className="flex justify-between items-center px-6 py-4 text-sm bg-white hover:bg-gray-50 transition"
                              >
                                <span className="text-[#1e3a8a] font-semibold w-1/2">{spec.label}</span>
                                <span className="text-right font-medium text-gray-900 w-1/2">
                                  {spec.value}
                                </span>
                              </div>
                            ))}
                        </div>
                      </div>



                      {/* Additional Details Section */}
                      <div className="mt-8">
                        <h3 className="text-xl font-bold text-gray-900 mb-6">Additional Details</h3>
                        <div className="bg-white rounded-xl overflow-hidden border border-gray-200 shadow-sm">
                          {product?.fssai_lic_no && (
                            <div className="flex justify-between py-4 px-6 bg-white border-b border-gray-200 text-sm">
                              <span className="text-gray-600 font-medium">FSSAI License No.</span>
                              <span className="font-bold text-gray-800">{product?.fssai_lic_no}</span>
                            </div>
                          )}
                          <div className="flex justify-between py-4 px-6 bg-gray-50 border-b border-gray-200 text-sm">
                            <span className="text-gray-600 font-medium">Supplier Information:</span>
                            <span className="font-bold text-gray-800">{product?.seller?.name || product?.seller_name || "N/A"} c/o Bringmart</span>
                          </div>
                          <div className="p-6 text-sm text-gray-600 bg-gradient-to-r from-gray-50 to-gray-100">
                            <h4 className="font-bold text-gray-800 mb-3">Legal Disclaimer</h4>
                            <p className="leading-relaxed">
                              Product images are for illustrative purposes only. Actual product may vary slightly in
                              appearance due to natural variations. We recommend reading the product description
                              carefully before purchase. Manufacturer's warranty (if applicable) does not cover
                              damages caused by misuse or improper handling.
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Enhanced Seller Info */}
                      <div className="seller-info">
                        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-2xl p-8 shadow-lg">
                          <h3 className="text-xl font-bold text-blue-600 mb-6 flex items-center gap-2">
                            <Award className="w-6 h-6" />
                            Supplier Information
                          </h3>
                          <div className="flex items-start justify-between mb-6">
                            <div className="flex items-center gap-4">
                              <div className="w-16 h-16 bg-white rounded-2xl p-3 shadow-md">
                                <img
                                  src={product?.seller?.image_url || "/placeholder.png"}
                                  alt={product?.seller?.name || "Supplier Image"}
                                  className="w-full h-full object-contain"
                                />
                              </div>
                              <div>
                                <h4 className="text-lg font-bold text-blue-800">
                                  {typeof product?.seller === "object"
                                    ? product?.seller?.name
                                    : product?.seller_name || "N/A"}
                                </h4>
                                <div className="flex items-center mt-3 bg-gradient-to-r from-yellow-50 to-amber-50 px-3 py-2 rounded-xl border border-yellow-200">
                                  <div className="flex mr-2">
                                    {[...Array(5)].map((_, i) => (
                                      <Star
                                        key={i}
                                        className={`w-3 h-3 ${i < 4 ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                                          }`}
                                      />
                                    ))}
                                  </div>
                                  <span className="text-yellow-700 font-bold text-sm">4.0 (121)</span>
                                </div>
                              </div>
                            </div>
                            <button
                              onClick={() =>
                                navigate(
                                  `/seller-products/p${slugify(product?.seller?.name)}?seller_id=${product?.seller?.id}`,
                                )
                              }
                              className="flex items-center gap-2 bg-gradient-to-r from-[#fc2e6b] to-[#fc2e6b]/90 text-white px-6 py-3 rounded-xl font-bold hover:shadow-lg transform hover:scale-105 transition-all duration-200"
                            >
                              View Shop
                              <ExternalLink className="w-4 h-4" />
                            </button>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                            <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-300 rounded-2xl p-6 text-center shadow-md hover:shadow-lg transition-shadow">
                              <div className="text-3xl font-black text-emerald-700 mb-1">98%</div>
                              <div className="text-sm font-bold text-emerald-800">Positive Feedback</div>
                            </div>
                            <div
                              className="bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-300 rounded-2xl p-6 text-center cursor-pointer shadow-md hover:shadow-lg transition-all transform hover:scale-105"
                              onClick={() =>
                                navigate(
                                  `/seller-products/p${slugify(product?.seller?.name)}?seller_id=${product?.seller?.id}`,
                                )
                              }
                            >
                              <div className="text-3xl font-black text-blue-700 mb-1">
                                {product?.seller?.total_products}
                              </div>
                              <div className="text-sm font-bold text-blue-800">Total Products</div>
                            </div>
                            <div className="bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-300 rounded-2xl p-6 text-center shadow-md hover:shadow-lg transition-shadow">
                              <div className="text-sm font-bold text-purple-700 mb-1">
                                {calculateTimeDifference(product?.seller?.created_at)}
                              </div>
                              <div className="text-sm font-bold text-purple-800">Supplier Since</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === "reviews" && (
                    <div className="space-y-8">
                      <div className="flex items-center justify-between">
                        <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                          <Star className="w-5 h-5 text-[#fc2e6b]" />
                          Customer Reviews
                        </h3>
                        <div className="flex items-center bg-gradient-to-r from-yellow-50 to-amber-50 px-4 py-3 rounded-xl border border-yellow-200">
                          <Star className="w-5 h-5 text-yellow-400 fill-yellow-400 mr-2" />
                          <span className="text-base font-bold text-yellow-600">{product?.rating || 4.5}</span>
                          <span className="ml-3 text-sm text-yellow-600 font-medium">({product?.rating_count || 0} reviews)</span>
                        </div>
                      </div>
                      <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 rounded-2xl border border-gray-200 shadow-sm">
                        <div className="flex items-start gap-6">
                          <div className="w-12 h-12 bg-gradient-to-br from-[#fc2e6b] to-[#fc2e6b]/80 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-md">
                            JS
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-4">
                              <h4 className="text-base font-bold text-gray-900">Jane Smith</h4>
                              <div className="flex bg-gradient-to-r from-yellow-50 to-amber-50 px-3 py-2 rounded-xl border border-yellow-200">
                                <div className="flex items-center">
                                  {[...Array(5)].map((_, i) => (
                                    <Star
                                      key={i}
                                      className="w-4 h-4 text-yellow-400 fill-yellow-400"
                                    />
                                  ))}
                                </div>
                              </div>
                            </div>
                            <p className="text-sm text-gray-600 leading-relaxed mb-3">
                              Excellent product quality and fast delivery. The packaging was secure, and the item
                              exceeded my expectations. Definitely a recommended buy!
                            </p>
                            <div className="flex items-center text-xs text-gray-500 font-medium">
                              <Clock className="w-3 h-3 mr-2" />
                              1 week ago
                            </div>
                          </div>
                        </div>
                      </div>
                      <button className="w-full py-4 border-2 border-[#fc2e6b] rounded-2xl text-base font-bold text-[#fc2e6b] hover:bg-[#fc2e6b] hover:text-white transition-all duration-200 shadow-md hover:shadow-lg">
                        View All Reviews
                      </button>
                    </div>
                  )}

                  {activeTab === "shipping" && (
                    <div className="space-y-6">
                      <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                        <Truck className="w-5 h-5 text-[#fc2e6b]" />
                        Shipping Information
                      </h3>
                      <div className="space-y-6">
                        <div className="flex items-start gap-6 bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-2xl border border-blue-200 shadow-sm">
                          <div className="w-12 h-12 bg-blue-500 rounded-2xl flex items-center justify-center shadow-md">
                            <Truck className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h4 className="text-base font-bold text-blue-800 mb-2">
                              {product?.free_delivery ? "Free Delivery" : "Delivery Available"}
                            </h4>
                            <p className="text-sm text-blue-600 leading-relaxed">
                              Estimated delivery within 3-5 business days.
                              {product?.free_delivery ? " Free shipping on this order." : " Shipping charges may apply."}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start gap-6 bg-gradient-to-r from-emerald-50 to-emerald-100 p-6 rounded-2xl border border-emerald-200 shadow-sm">
                          <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center shadow-md">
                            <Wallet className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h4 className="text-base font-bold text-emerald-700 mb-2">Payment Options</h4>
                            <p className="text-sm text-emerald-600 leading-relaxed">
                              {product?.cod_allowed === 1
                                ? "Cash on Delivery available. "
                                : "Cash on Delivery not available. "}
                              We accept all major credit/debit cards, UPI, and net banking.
                            </p>
                          </div>
                        </div>
                        <div
                          className={`flex items-start gap-6 p-6 rounded-2xl border shadow-sm ${product?.return_status === 1
                            ? "bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200"
                            : "bg-gradient-to-r from-red-50 to-red-100 border-red-200"
                            }`}
                        >
                          <div
                            className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-md ${product?.return_status === 1 ? "bg-purple-500" : "bg-red-500"
                              }`}
                          >
                            <Shield className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h4
                              className={`text-base font-bold mb-2 ${product?.return_status === 1 ? "text-purple-800" : "text-red-800"
                                }`}
                            >
                              Return Policy
                            </h4>
                            <p
                              className={`text-sm leading-relaxed ${product?.return_status === 1 ? "text-purple-600" : "text-red-600"
                                }`}
                            >
                              {product?.return_status === 1
                                ? `Returnable within ${product?.return_days || 7} days of delivery. Items must be unused and in original packaging with tags intact.`
                                : "This product is non-returnable."}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              {showWishlistToast && <Toast message={wishlistToastMessage} type={wishlistToastType} />}
              {showLoginCartToast && <Toast message="Please log in to add product to cart!" type="error" />}
              {showShareModal && product && <ShareModal product={product} onClose={() => setShowShareModal(false)} />}
            </div>
          </div>
        </div>
      </div>
      <RelatedProductsPage product={product} key={product?.id} />

      <style jsx>{`
        .line-clamp-4 {
          display: -webkit-box;
          -webkit-line-clamp: 4;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .animate-slide-in-fade {
          animation: slideInFade 0.4s ease-out;
        }
        .animate-modal-in {
          animation: modalIn 0.3s ease-out;
        }
        @keyframes slideInFade {
          0% {
            opacity: 0;
            transform: translateX(100%) translateY(-10px);
          }
          100% {
            opacity: 1;
            transform: translateX(0) translateY(0);
          }
        }
        @keyframes modalIn {
          0% {
            opacity: 0;
            transform: scale(0.9) translateY(-20px);
          }
          100% {
            opacity: 1;
            transform: scale(1) translateY(0);
          }
        }
      `}</style>
    </div>
  )
}

export default DesktopDetails
