import React, { useState, useRef } from 'react';
import { ChevronUp, ChevronDown, ImageOff } from 'lucide-react';

const VerticalSlider = ({ images = [] }) => {
  const [selectedImage, setSelectedImage] = useState(0);
  const [startIndex, setStartIndex] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [zoomPosition, setZoomPosition] = useState({ x: 0, y: 0 });
  const imageRef = useRef(null);

  const thumbnailsToShow = 4;

  if (!images || images.length === 0) {
    return (
      <div className="flex items-center justify-center w-full h-[300px] bg-gray-100 rounded-lg">
        <ImageOff className="w-12 h-12 text-gray-400" />
        <p className="text-gray-500">No Images Available</p>
      </div>
    );
  }

  const handleMouseMove = (e) => {
    if (!imageRef.current) return;

    const { left, top, width, height } = imageRef.current.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;

    setZoomPosition({ x, y });
  };

  const nextThumbnails = () => {
    if (startIndex + thumbnailsToShow < images.length) {
      setStartIndex(startIndex + 1);
    }
  };

  const previousThumbnails = () => {
    if (startIndex > 0) {
      setStartIndex(startIndex - 1);
    }
  };

  return (
    <div className="flex gap-4 max-w-2xl mx-auto p-4">
      {/* Thumbnails column */}
      <div className="flex flex-col items-center gap-2">
        <button
          onClick={previousThumbnails}
          className="p-1 hover:bg-gray-100 rounded-full disabled:opacity-50 transition-colors"
          disabled={startIndex === 0}
        >
          <ChevronUp className="w-5 h-5" />
        </button>

        <div className="flex flex-col gap-2 transition-transform duration-300 ease-in-out">
          {images
            .slice(startIndex, startIndex + thumbnailsToShow)
            .map((img, index) => (
              <button
                key={`${startIndex + index}-${img}`} // Ensure unique keys
                onClick={() => setSelectedImage(startIndex + index)}
                className={`w-16 h-16 border-2 rounded-lg overflow-hidden transform transition-all duration-300 ease-in-out hover:scale-105 cursor-pointer
                  ${selectedImage === startIndex + index ? 'border-blue-500 scale-105' : 'border-gray-200'}`}
              >
                <img
                  src={img || "https://via.placeholder.com/150"} 
                  alt={`Thumbnail ${startIndex + index + 1}`}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
        </div>

        <button
          onClick={nextThumbnails}
          className="p-1 hover:bg-gray-100 rounded-full disabled:opacity-50 transition-colors"
          disabled={startIndex + thumbnailsToShow >= images.length}
        >
          <ChevronDown className="w-5 h-5" />
        </button>
      </div>

      {/* Main image with zoom */}
      <div className="flex-1">
        <div
          ref={imageRef}
          className="aspect-square rounded-2xl overflow-hidden bg-gray-50 relative cursor-zoom-in"
          onMouseEnter={() => setIsZoomed(true)}
          onMouseLeave={() => setIsZoomed(false)}
          onMouseMove={handleMouseMove}
        >
          <img
            src={images[selectedImage] || "https://via.placeholder.com/300"}
            alt={`Product ${selectedImage + 1}`}
            className={`w-full h-full object-cover transition-all duration-500 ease-in-out
              ${isZoomed ? 'scale-150' : 'scale-100'}`}
            style={{ transformOrigin: `${zoomPosition.x}% ${zoomPosition.y}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default VerticalSlider;
