import { useState } from "react";

const MobileFooterCart = () => {
    const [cartCount, setCartCount] = useState(1);
    return (
        <>
        <div className="fixed z-10 left-0 bottom-[60px] right-0 w-full flex justify-between items-center px-4 bg-white p-2 gap-3 border-t border-gray-200">
        <div>
                <input
                  type="number"
                  className="p-2 rounded-sm bg-[#fff] w-[80px] outline-none border border-gray-200"
                  min={1}
                  max={50}
                  value={cartCount}
                  onInput={(e) => setCartCount(e.target.value)}
                />
              </div>
              <div className="w-full">
                <button className="bg-[#fc2e6bed] hover:bg-[#fc462ef3] text-white p-2 rounded-sm w-full cursor-pointer">
                  Add To Cart
                </button>
              </div>
        </div>
        </>
    );
};

export default MobileFooterCart;