import {
  ArrowLeft,
  Check,
  ChevronDown,
  ChevronRight,
  Heart,
  Share2,
  Shield,
  ShoppingBag,
  Star,
  Truck,
  Wallet,
  X,
  Store,
  ExternalLink,
  CalendarSync,
  Zap
} from 'lucide-react';
import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { addtoGuestCart, setCart, setCartProducts, setCartSubTotal } from '../../model/reducer/cartReducer';
import { addFavoriteProduct, removeFavoriteProduct } from '../../model/reducer/favouriteReducer';
import api from '../../api/api';
import { toast } from 'react-toastify';
import { slugify } from "../../utils/Slugify";
import RelatedProductsPage from '../../Pages/RelatedProducts';
import { useParams } from 'react-router-dom';
import { FaFacebook, FaWhatsapp } from 'react-icons/fa';

const Toast = ({ message, type = 'success' }) => {
  const bgColor = type === 'success' ? 'bg-green-500' : 'bg-rose-500';
  const position = type === 'success' ? 'right-2' : 'left-2';

  return (
    <div className={`fixed top-4 ${position} ${bgColor} text-white px-4 py-2 rounded-lg shadow-lg z-50 animate-fade-in-out flex items-center gap-2`}>
      {type === 'success' ? <Check className="w-4 h-4" /> : null}
      <span className="text-sm font-medium">{message}</span>
    </div>
  );
};

const MobileDetails = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();
  const { id } = useParams();
  const { product: initialProduct, breadcrumbs } = location.state || {};
  const { favouriteProductIds = [] } = useSelector((state) => state.favourite);
  const { user, status, jwtToken } = useSelector((state) => state.user);
  const { city } = useSelector((state) => state.city);
  const { isGuest, cartProducts } = useSelector((state) => state.cart);
  const isLoggedIn = status === "fulfill" && jwtToken;

  const [cartCount, setCartCount] = useState(1);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [touchStart, setTouchStart] = useState(null);
  const [touchEnd, setTouchEnd] = useState(null);
  const [isZoomed, setIsZoomed] = useState(false);
  const [slideDirection, setSlideDirection] = useState('right');
  const [activeTab, setActiveTab] = useState('details');
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showAddToCartFeedback, setShowAddToCartFeedback] = useState(false);
  const [showWishlistToast, setShowWishlistToast] = useState(false);
  const [wishlistToastMessage, setWishlistToastMessage] = useState('');
  const [wishlistToastType, setWishlistToastType] = useState('success');
  const [showLoginCartToast, setShowLoginCartToast] = useState(false);
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [isAddingToCart, setIsAddingToCart] = useState(false);
  const [isWishlistLoading, setIsWishlistLoading] = useState(false);
  const [isInCart, setIsInCart] = useState(false);
  const [currentCartQuantity, setCurrentCartQuantity] = useState(0);
  const [product, setProduct] = useState(() => {
    const productData = location.state?.product || {};

    const allImages = productData.image_url
      ? [productData.image_url, ...(productData.images || []).filter(img => img !== productData.image_url)]
      : productData.images || ['https://via.placeholder.com/500'];

    return {
      ...productData,
      id: productData.id || '',
      name: productData.name || 'Unnamed Product',
      seller_name: productData.seller?.name || productData.seller_name || "",
      seller_image_url: productData.seller?.image_url || "",
      variants: productData.variants || [],
      images: allImages,
      image_url: productData.image_url || allImages[0] || "",
      price: productData.price || 0,
      discounted_price: productData.discounted_price || productData.price || 0,
      slug: productData.slug || `product-${productData.id || 'unknown'}`
    };
  });
  const [showShareModal, setShowShareModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [images, setImages] = useState(() => {
    const initialProduct = location.state?.product || {};
    const imagesArray = [];

    if (initialProduct?.image_url) {
      imagesArray.push(initialProduct?.image_url);
    }

    if (initialProduct?.images && initialProduct?.images.length > 0) {
      const uniqueImages = initialProduct?.images.filter(img => img !== initialProduct?.image_url);
      imagesArray.push(...uniqueImages);
    }

    return imagesArray.length > 0 ? imagesArray : ["https://via.placeholder.com/500"];
  });

  const scrollRef = useRef();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    let isMounted = true; // Flag to track component mount status

    const loadProduct = async () => {
      try {
        setIsLoading(true);

        // Case 1: Product data is passed via location state (internal navigation)
        if (location.state?.product) {
          const initialProduct = location.state.product;
          const processedProduct = {
            ...initialProduct,
            variants: initialProduct.variants || [],
            images: initialProduct.image_url
              ? [initialProduct.image_url, ...(initialProduct.images || []).filter(img => img !== initialProduct.image_url)]
              : initialProduct.images || ['https://via.placeholder.com/500'],
            seller_name: initialProduct.seller?.name || initialProduct.seller_name || '',
            seller_image_url: initialProduct.seller?.image_url || ''
          };

          if (isMounted) {
            setProduct(processedProduct);
            if (processedProduct?.variants?.length > 0) {
              const inStockVariant = processedProduct.variants.find(v => v.stock > 0) ||
                processedProduct.variants[0];
              setSelectedVariant(inStockVariant);
            }
          }
          return;
        }

        // Case 2: No product data, but we have an ID (direct URL access)
        if (id) {
          const response = await api.getProductbyId(
            city?.city?.latitude || 28.6139,
            city?.city?.longitude || 77.2090,
            id,
            jwtToken,
            location.pathname.split('/').pop()
          );

          const result = await response.json();

          if (result.status === 1 && isMounted) {
            const allImages = result.data.image_url
              ? [result.data.image_url, ...(result.data.images || []).filter(img => img !== result.data.image_url)]
              : result.data.images || ['https://via.placeholder.com/500'];

            const productData = {
              ...result.data,
              seller_name: result.data.seller?.name || '',
              seller_image_url: result.data.seller?.image_url || '',
              variants: result.data.variants || [],
              images: allImages
            };

            setProduct(productData);

            if (productData?.variants?.length > 0) {
              const inStockVariant = productData.variants.find(v => v.stock > 0) ||
                productData.variants[0];
              setSelectedVariant(inStockVariant);
            }

            // Generate breadcrumbs for direct URL access
            const newBreadcrumbs = [
              { name: 'Home', path: '/' },
              {
                name: result.data.category?.name || 'Products',
                path: `/products?category=${result.data.category?.id || ''}`
              },
              { name: result.data.name }
            ];

            // Update the location state to maintain consistency
            navigate(location.pathname, {
              state: { product: productData, breadcrumbs: newBreadcrumbs },
              replace: true
            });
          } else if (isMounted) {
            navigate('/404');
          }
        }
      } catch (error) {
        console.error('Failed to fetch product details:', error);
        if (isMounted) {
          navigate('/404');
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    loadProduct();

    return () => {
      isMounted = false; // Cleanup function to prevent state updates after unmount
    };
  }, [id, jwtToken, city, navigate, location]);

  // Check if current product is in cart and get quantity
  useEffect(() => {
    if (!product) return;

    const productId = product.id;
    const variantId = selectedVariant?.id || null;

    if (isLoggedIn) {
      const cartItem = cartProducts?.find(item =>
        item.product_id === productId &&
        item.product_variant_id === variantId
      );

      if (cartItem) {
        setIsInCart(true);
        setCurrentCartQuantity(cartItem.quantity);
        setCartCount(cartItem.quantity);
      } else {
        setIsInCart(false);
        setCurrentCartQuantity(0);
        setCartCount(1);
      }
    } else if (isGuest) {
      // For guest users, check guest cart implementation if needed
    }
  }, [product, selectedVariant, cartProducts, isLoggedIn, isGuest]);

  // Inside the MobileDetails component, add this useEffect:
  useEffect(() => {
    if (!selectedVariant) return;

    if (selectedVariant.images && selectedVariant.images.length > 0) {
      setImages(selectedVariant.images);
      setCurrentSlide(0); // Reset to first image when variant changes
    } else {
      const productImages = [];
      if (product?.image_url) {
        productImages.push(product.image_url);
      }
      if (product?.images && product.images.length > 0) {
        const uniqueImages = product.images.filter((img) => img !== product.image_url);
        productImages.push(...uniqueImages);
      }
      if (productImages.length === 0) {
        productImages.push("https://via.placeholder.com/500");
      }
      setImages(productImages);
      setCurrentSlide(0); // Reset to first image when variant changes
    }
  }, [selectedVariant, product]);

  useEffect(() => {
    if (!initialProduct && id) {
      const fetchProductFromUrl = async () => {
        try {
          const response = await api.getProductbyId(
            city?.city?.latitude || 28.6139,
            city?.city?.longitude || 77.2090,
            id,
            jwtToken,
            location.pathname.split('/').pop() // Get slug from URL
          );

          const result = await response.json();

          if (result.status === 1) {
            const allImages = result.data.image_url
              ? [result.data.image_url, ...(result.data.images || []).filter(img => img !== result.data.image_url)]
              : result.data.images || ['https://via.placeholder.com/500'];

            const productData = {
              ...result.data,
              seller_name: result.data.seller?.name || '',
              seller_image_url: result.data.seller?.image_url || '',
              variants: result.data.variants || [],
              images: allImages
            };

            setProduct(productData);

            // Generate basic breadcrumbs for direct URL access
            const newBreadcrumbs = [
              { name: 'Home', path: '/' },
              {
                name: result.data.category?.name || 'Products',
                path: `/products?category=${result.data.category?.id || ''}`
              },
              { name: result.data.name }
            ];

            // Update the location state to maintain consistency
            navigate(location.pathname, {
              state: { product: productData, breadcrumbs: newBreadcrumbs },
              replace: true
            });
          }
        } catch (error) {
          console.error('Failed to fetch product details:', error);
          navigate('/404');
        }
      };

      fetchProductFromUrl();
    }
  }, [id, initialProduct, jwtToken, city, navigate, location]);

  // Check if current product is in wishlist
  const isFavorite = product?.id ? favouriteProductIds.includes(product.id) : false;

  // Fetch cart data for logged in users
  const fetchCartData = async () => {
    try {
      const response = await api.getCart(
        jwtToken,
        city?.city?.latitude || 28.6139,
        city?.city?.longitude || 77.2090
      );
      const result = await response.json();

      if (result.status === 1) {
        const productsData = result?.data?.cart?.map((product) => ({
          id: product?.id,
          product_id: product?.product_id,
          product_variant_id: product?.product_variant_id,
          quantity: product?.qty,
          price: product?.price,
          discounted_price: product?.discounted_price,
          name: product?.name,
          image: product?.image_url,
          measurement: product?.measurement,
          unit_code: product?.unit_code,
          stock: product?.stock,
          is_unlimited_stock: product?.is_unlimited_stock,
          total_allowed_quantity: product?.total_allowed_quantity,
          slug: product?.slug,
          status: product?.status === 1
        }));

        dispatch(setCart({ data: result }));
        dispatch(setCartSubTotal({ data: result?.data?.sub_total || 0 }));
        dispatch(setCartProducts({ data: productsData }));
      }
    } catch (err) {
      console.error('Failed to fetch cart:', err);
    }
  };

  useEffect(() => {
    const fetchProductDetails = async () => {
      if (!initialProduct) return;

      try {
        const response = await api.getProductbyId(
          city?.city?.latitude || 28.6139,
          city?.city?.longitude || 77.2090,
          initialProduct.id,
          jwtToken,
          initialProduct.slug
        );

        const result = await response.json();

        if (result.status === 1) {
          const allImages = result.data.image_url
            ? [result.data.image_url, ...(result.data.images || []).filter(img => img !== result.data.image_url)]
            : result.data.images || ['https://via.placeholder.com/500'];

          const productData = {
            ...result.data,
            seller_name: result.data.seller?.name || '',
            seller_image_url: result.data.seller?.image_url || '',
            variants: result.data.variants || [],
            images: allImages
          };

          setProduct(productData);
        }
      } catch (error) {
        console.error('Failed to fetch product details:', error);
      }
    };

    fetchProductDetails();
  }, [initialProduct, jwtToken, city]);

  // Detect scroll for header styling
  useEffect(() => {
    const handleScroll = () => {
      if (scrollRef.current) {
        setScrolled(scrollRef.current.scrollTop > 120);
      }
    };

    const currentRef = scrollRef.current;
    if (currentRef) {
      currentRef.addEventListener('scroll', handleScroll);
    }

    return () => {
      if (currentRef) {
        currentRef.removeEventListener('scroll', handleScroll);
      }
    };
  }, []);

  const handleTouchStart = (e) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;

    const distance = touchStart - touchEnd;
    const minSwipeDistance = 50;

    if (Math.abs(distance) < minSwipeDistance) return;

    if (distance > 0) {
      setSlideDirection('left');
      setCurrentSlide((prev) => (prev + 1) % product.images.length);
    } else {
      setSlideDirection('right');
      setCurrentSlide((prev) => (prev - 1 + product.images.length) % product.images.length);
    }

    setTouchStart(null);
    setTouchEnd(null);
  };

  const handleDotClick = (index) => {
    setSlideDirection(index > currentSlide ? 'left' : 'right');
    setCurrentSlide(index);
  };

  // Handle variant selection
  const handleVariantSelect = (variant) => {
    setSelectedVariant(variant);
  };

  const goBack = () => navigate(-1);

  // Handle add to cart with proper variant and quantity management
  const handleAddToCart = async (quantity) => {
    if (!product) return;

    const currentProduct = selectedVariant || product;
    const productId = product.id;
    const variantId = selectedVariant?.id || null;

    if (!isLoggedIn && !isGuest) {
      setShowLoginCartToast(true);
      setTimeout(() => setShowLoginCartToast(false), 3000);
      return;
    }

    setIsAddingToCart(true);

    try {
      if (isLoggedIn) {
        // For logged in users - call API
        const response = await api.addToCart(
          jwtToken,
          productId,
          variantId,
          quantity
        );

        const result = await response.json();

        if (result.status === 1) {
          setShowAddToCartFeedback(true);
          setTimeout(() => setShowAddToCartFeedback(false), 3000);
          await fetchCartData(); // Refresh cart data
          toast.success(`${quantity} item(s) ${isInCart ? 'updated in' : 'added to'} cart`);
        } else {
          toast.error(result.message || 'Failed to update cart');
        }
      } else {
        // For guest users - add to redux store
        const cartItem = {
          id: `${productId}_${variantId || 'base'}`,
          product_id: productId,
          product_variant_id: variantId,
          name: product.name,
          price: price,
          discounted_price: discountedPrice,
          image: product.images[0], // Use first image
          quantity: quantity,
          measurement: currentProduct.measurement || '1',
          unit_code: currentProduct.stock_unit_name || 'PC',
          stock: currentProduct.stock || 0,
          total_allowed_quantity: currentProduct.total_allowed_quantity || 10000,
          slug: product.slug,
          status: product.status || 1
        };

        dispatch(addtoGuestCart({ data: cartItem }));
        setShowAddToCartFeedback(true);
        setTimeout(() => setShowAddToCartFeedback(false), 3000);
        toast.success(`${quantity} item(s) ${isInCart ? 'updated in' : 'added to'} cart`);
      }
    } catch (error) {
      console.error('Add to cart error:', error);
      toast.error(error.message || 'Failed to update cart');
    } finally {
      setIsAddingToCart(false);
    }
  };

  // Handle quantity increase
  const handleIncreaseQuantity = () => {
    const newQuantity = cartCount + 1;
    setCartCount(newQuantity);
    handleAddToCart(newQuantity);
  };

  // Handle quantity decrease
  const handleDecreaseQuantity = () => {
    const newQuantity = Math.max(1, cartCount - 1);
    setCartCount(newQuantity);
    handleAddToCart(newQuantity);
  };

  const handleWishlistToggle = async () => {
    if (!product) return;
    if (!isLoggedIn) {
      setWishlistToastMessage('Please login to add to wishlist');
      setWishlistToastType('error');
      setShowWishlistToast(true);
      setTimeout(() => setShowWishlistToast(false), 3000);
      return;
    }

    setIsWishlistLoading(true);

    try {
      if (isFavorite) {
        // Remove from favorites
        const response = await api.removeFromFavorite(jwtToken, product.id);
        const result = await response.json();

        if (result.status === 1) {
          dispatch(removeFavoriteProduct({ data: product.id }));
          setWishlistToastMessage('Removed from wishlist');
          setWishlistToastType('success');
        } else {
          throw new Error(result.message || 'Failed to remove from favorites');
        }
      } else {
        // Add to favorites
        const response = await api.addToFavotite(jwtToken, product.id);
        const result = await response.json();

        if (result.status === 1) {
          dispatch(addFavoriteProduct({ data: product.id }));
          setWishlistToastMessage('Added to wishlist');
          setWishlistToastType('success');
        } else {
          throw new Error(result.message || 'Failed to add to favorites');
        }
      }
      setShowWishlistToast(true);
      setTimeout(() => setShowWishlistToast(false), 3000);
    } catch (error) {
      console.error('Wishlist error:', error);
      toast.error(error.message || 'Failed to update wishlist');
    } finally {
      setIsWishlistLoading(false);
    }
  };

  // Get current price and discounted price based on selected variant
  const getCurrentPrice = () => {
    if (selectedVariant) {
      return {
        price: selectedVariant.price,
        discountedPrice: selectedVariant.discounted_price,
        discountPercentage: Math.round(((selectedVariant.price - selectedVariant.discounted_price) / selectedVariant.price) * 100)
      };
    }
    return {
      price: product?.price || 0,
      discountedPrice: product?.discounted_price || product?.price || 0,
      discountPercentage: product?.cal_discount_percentage || 0
    };
  };

  const { price, discountedPrice, discountPercentage } = getCurrentPrice();

  const badges = [
    { icon: <Truck className="w-5 h-5" />, title: product?.free_delivery ? "Free Delivery" : "Delivery Available" },
    { icon: <Star className="w-5 h-5" />, title: "Top Rated" },
    { icon: <Wallet className="w-5 h-5" />, title: "Secure Payment" },
    { icon: <Shield className="w-5 h-5" />, title: product?.return_status ? "Easy Returns" : "No Returns" }
  ];

  // Helper function to format price
  const formatPrice = (price) => {
    if (typeof price === 'number') {
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
      }).format(price).replace('₹', '₹ ');
    }
    return price;
  };

  const ShareModal = ({ product, onClose }) => {
    const [isCopied, setIsCopied] = useState(false);
    const productUrl = `${window.location.origin}/product/${product.slug || 'p' + product.id}?id=${product.id}`;
    const shareText = `Check out ${product.name} on our store!`;

    const handleCopyLink = async () => {
      try {
        await navigator.clipboard.writeText(productUrl);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
      } catch (err) {
        console.error('Failed to copy:', err);
      }
    };

    const handleFacebookShare = () => {
      const facebookShareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(productUrl)}&quote=${encodeURIComponent(shareText)}`;
      window.open(facebookShareUrl, '_blank', 'width=600,height=400');
    };

    const handleWhatsAppShare = () => {
      const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(`${shareText}\n${productUrl}`)}`;
      window.open(whatsappUrl, '_blank', 'width=600,height=400');
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-sm p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Share this product</h3>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-4 mb-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
              <img
                src={product.images?.[0] || 'https://via.placeholder.com/500'}
                alt={product.name}
                className="w-12 h-12 object-cover rounded-md"
              />
              <div>
                <h4 className="text-sm font-medium text-gray-900 line-clamp-2">{product.name}</h4>
                <div className="flex items-center mt-1">
                  <span className="text-sm font-bold text-gray-900">{formatPrice(product.discounted_price || product.price)}</span>
                  {product.cal_discount_percentage > 0 && (
                    <span className="ml-2 text-xs line-through text-gray-500">
                      {formatPrice(product.price)}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Copy Link */}
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
              <div className="truncate text-sm text-gray-700 flex-1 mr-2">{productUrl}</div>
              <button
                onClick={handleCopyLink}
                className={`px-3 py-1.5 text-sm font-medium rounded-md ${isCopied ? 'bg-green-100 text-green-800' : 'bg-[#fc2e6bed] text-white hover:bg-gray-800'}`}
              >
                {isCopied ? 'Copied!' : 'Copy'}
              </button>
            </div>

            {/* Social Share Buttons */}
            <div className="flex gap-3">
              <button
                onClick={handleFacebookShare}
                className="flex-1 flex items-center justify-center gap-2 bg-[#1877F2] text-white py-2.5 px-4 rounded-md hover:bg-[#166FE5] transition-colors"
              >
                <FaFacebook />
                Facebook
              </button>

              <button
                onClick={handleWhatsAppShare}
                className="flex-1 flex items-center justify-center gap-2 bg-[#25D366] text-white py-2.5 px-4 rounded-md hover:bg-[#1DA851] transition-colors"
              >
                <FaWhatsapp />
                WhatsApp
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const calculateTimeDifference = (createdAt) => {
    if (!createdAt) return 'Recently joined';

    const createdDate = new Date(createdAt);
    const currentDate = new Date();

    if (isNaN(createdDate.getTime())) return 'Recently joined';

    let years = currentDate.getFullYear() - createdDate.getFullYear();
    let months = currentDate.getMonth() - createdDate.getMonth();
    let days = currentDate.getDate() - createdDate.getDate();

    // Adjust for negative months/days
    if (days < 0) {
      months--;
      // Get the last day of the previous month
      const tempDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0);
      days += tempDate.getDate();
    }

    if (months < 0) {
      years--;
      months += 12;
    }

    const parts = [];
    if (years > 0) parts.push(`${years} year${years > 1 ? 's' : ''}`);
    if (months > 0) parts.push(`${months} month${months > 1 ? 's' : ''}`);
    if (days > 0 || parts.length === 0) parts.push(`${days} day${days !== 1 ? 's' : ''}`);

    return parts.join(' ');
  };

  // Stock status message
  const stockStatus = product?.is_unlimited_stock === 1
    ? "In Stock"
    : selectedVariant?.stock
      ? selectedVariant.stock < 5
        ? `Only ${selectedVariant.stock} left`
        : "In Stock"
      : product?.stock
        ? product?.stock < 5
          ? `Only ${product?.stock} left`
          : "In Stock"
        : "Out of Stock";

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-rose-500 mb-4"></div>
        <p className="text-gray-600">Loading product details...</p>
        <button
          onClick={() => navigate('/')}
          className="mt-4 px-4 py-2 text-sm text-rose-500 hover:text-rose-700"
        >
          Go to Home
        </button>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center p-6 bg-white rounded-lg shadow-md">
          <div className="text-rose-500 mb-4">
            <ShoppingBag className="w-12 h-12 mx-auto" />
          </div>
          <div className="text-lg font-semibold mb-2">Product not found</div>
          <p className="text-gray-500 mb-4">The product you're looking for is not available</p>
          <button
            onClick={goBack}
            className="px-4 py-2 bg-rose-500 text-white rounded-full font-medium hover:bg-rose-600 transition-colors"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Toast Notifications */}
      {showWishlistToast && (
        <Toast message={wishlistToastMessage} type={wishlistToastType} />
      )}
      {showLoginCartToast && (
        <Toast message="🛑 Please login to add product to cart!" type="error" />
      )}

      {/* Fixed Header Bar */}
      <div className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled
        ? "bg-white shadow-md py-2"
        : "bg-transparent py-4"
        }`}>
        <div className="container mx-auto px-4 flex items-center justify-between">
          <button onClick={goBack} className="p-1">
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className={`font-medium transition-opacity duration-300 ${scrolled ? "opacity-100" : "opacity-0"
            } text-sm truncate max-w-[200px]`}>
            {product.name}
          </div>

          <div className="w-5"></div> {/* Spacer for balance */}
        </div>
      </div>

      {/* Scrollable Content */}
      <div
        className="flex-1 overflow-y-auto pb-20"
        ref={scrollRef}
      >
        {/* Breadcrumbs */}
        {breadcrumbs && (
          <div className="px-4 py-2 flex items-center overflow-x-auto text-xs text-gray-500 whitespace-nowrap">
            {breadcrumbs.map((crumb, index) => (
              <div key={index} className="flex items-center">
                {index > 0 && <ChevronRight size={12} className="mx-1" />}
                {crumb.path ? (
                  <button
                    onClick={() => navigate(crumb.path)}
                    className="hover:text-rose-500"
                  >
                    {crumb.name}
                  </button>
                ) : (
                  <span className="text-rose-500">{crumb.name}</span>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Image Carousel */}
        <div className="relative bg-white">
          <div
            className="relative h-[70vh] overflow-hidden"
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            <div className="relative h-full">
              <img
                src={product?.images?.[currentSlide] || 'https://via.placeholder.com/500'}
                alt={`Product ${currentSlide + 1}`}
                className={`w-full h-full object-contain cursor-zoom-in transform transition-transform duration-500 
                  ${slideDirection === 'left' ? 'animate-slideLeft' : 'animate-slideRight'}
                `}
                onClick={() => setIsZoomed(true)}
              />

              {/* Stock Status */}
              <div className="absolute top-4 left-4">
                <div className={`px-3 py-1 rounded-full text-xs font-medium flex items-center ${stockStatus.includes('Only') || stockStatus === 'Out of Stock'
                  ? 'bg-rose-500 text-white'
                  : 'bg-green-500 text-white'
                  }`}>
                  <ShoppingBag className="w-3 h-3 mr-1" />
                  {stockStatus}
                </div>
              </div>

              {/* Discount Badge */}
              {discountPercentage > 0 && (
                <div className="absolute top-4 right-4">
                  <div className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-medium">
                    {discountPercentage}% OFF
                  </div>
                </div>
              )}

              {/* Vertical Icons on right side */}
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col space-y-3">
                <button
                  onClick={handleWishlistToggle}
                  disabled={isWishlistLoading}
                  className={`p-2 rounded-full shadow-md hover:bg-white transition-colors ${isFavorite
                    ? 'bg-rose-100 text-rose-500'
                    : 'bg-white/80 text-gray-700'
                    }`}
                >
                  {isWishlistLoading ? (
                    <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></span>
                  ) : (
                    <Heart className={`w-5 h-5 ${isFavorite ? 'fill-rose-500' : ''}`} />
                  )}
                </button>
                <button
                  onClick={() => setShowShareModal(true)}
                  className="p-2 rounded-full bg-white/80 shadow-md hover:bg-white transition-colors"
                >
                  <Share2 className="w-5 h-5 text-gray-700" />
                </button>

              </div>
            </div>
          </div>

          {/* Dots Indicator */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
            {product.images.map((_, index) => (
              <button
                key={index}
                onClick={() => handleDotClick(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${currentSlide === index ? 'bg-rose-500 w-6' : 'bg-gray-300'
                  }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Product Info Card */}
        <div className="bg-white -mt-6 rounded-t-3xl shadow-lg px-5 pt-6 pb-4 relative z-10">
          {/* Seller Info */}
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs text-gray-600">Sold by:</span>
            <span className="text-xs font-medium text-gray-800">{product.seller_name || 'BringMart'}</span>
          </div>

          {/* Product Name */}
          <h1 className="text-xl font-bold text-gray-900">{product.name}</h1>

          {/* Rating & Model */}
          <div className="flex items-center gap-2 mt-1 text-xs text-gray-600">
            <div className="flex items-center">
              <Star className="w-3 h-3 text-yellow-400 inline fill-yellow-400" />
              <span className="ml-1">{product.rating || 4.5}</span>
              <span className="ml-1">({product.rating_count || 0} reviews)</span>
            </div>
            <span className="mx-1">•</span>
            <span>SKU: {(product.sku && product.sku !== "null" && product.sku.trim() !== "") ? product.sku : product.id}</span>

          </div>

          {/* Manufacturer */}
          {product.manufacturer &&
            product.manufacturer !== "null" &&
            product.manufacturer.trim() !== "" && (
              <div className="mt-2">
                <span className="text-xs text-gray-600">Manufacturer: </span>
                <span className="text-xs font-medium text-gray-800">
                  {product.manufacturer}
                </span>
              </div>
            )}

          {/* Variants */}
          {product?.variants?.length > 0 && (
            <div className="mt-4">
              {product.variants.some(v => v.size) && (
                <div className="mb-3">
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Size</h3>
                  <div className="flex flex-wrap gap-2">
                    {[...new Set(product.variants.map(variant => variant.size))].map((size) => {
                      const variantWithSize = product.variants.find(v => v.size === size);
                      const isInStock = product?.is_unlimited_stock === 1 || (variantWithSize?.stock > 0);
                      const isSelected = selectedVariant?.size === size;

                      return (
                        <button
                          key={size}
                          onClick={() => {
                            if (variantWithSize) {
                              handleVariantSelect(variantWithSize);
                              // Find first available color variant with this size
                              const colorVariant = product.variants.find(v =>
                                v.size === size &&
                                (product?.is_unlimited_stock === 1 || v.stock > 0)
                              );
                              if (colorVariant) {
                                setSelectedVariant(colorVariant);
                              }
                            }
                          }}
                          disabled={!isInStock}
                          className={`px-3 py-1.5 text-xs rounded-lg border ${isSelected
                            ? 'bg-indigo-50 border-indigo-500 text-indigo-700 font-medium'
                            : isInStock
                              ? 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                              : 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed'
                            }`}
                          title={!isInStock ? "Out of stock" : ""}
                        >
                          {size}
                          {!isInStock && product?.is_unlimited_stock !== 1 && (
                            <span className="text-xs text-red-500 ml-1">(X)</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {product.variants.some(v => v.color) && (
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Color</h3>
                  <div className="flex flex-wrap gap-2">
                    {[...new Set(
                      product.variants
                        .filter((v) => {
                          if (!selectedVariant?.size) return true;
                          return v.size === selectedVariant.size;
                        })
                        .map((v) => v.color)
                        .filter(Boolean),
                    )].map((color) => {
                      const variantWithColor = product.variants.find(
                        (v) => v.color === color &&
                          (selectedVariant?.size ? v.size === selectedVariant.size : true)
                      );
                      const isInStock = product?.is_unlimited_stock === 1 || (variantWithColor?.stock > 0);
                      const isSelected = selectedVariant?.color === color;

                      return (
                        <button
                          key={color}
                          onClick={() => variantWithColor && handleVariantSelect(variantWithColor)}
                          disabled={!isInStock}
                          className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${isSelected
                            ? "border-indigo-500 ring-2 ring-indigo-200"
                            : isInStock
                              ? "border-gray-300 hover:border-gray-400"
                              : "border-gray-200 opacity-50 cursor-not-allowed"
                            }`}
                          style={{ backgroundColor: color }}
                          title={color + (!isInStock ? " (Out of stock)" : "")}
                        >
                          {isSelected && <Check className="w-3 h-3 text-white" />}
                          {!isInStock && product?.is_unlimited_stock !== 1 && (
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="w-6 h-px bg-gray-400 transform rotate-45"></div>
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* {product.variants.some(v => v.measurement) && (
                <div className="mt-3">
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Select Quantity</h3>
                  <div className="flex flex-wrap gap-2">
                    {[...new Set(product.variants.map(v => v.measurement))].map(measurement => (
                      <button
                        key={measurement}
                        onClick={() => {
                          const variantWithMeasurement = product.variants.find(v => v.measurement === measurement);
                          if (variantWithMeasurement) handleVariantSelect(variantWithMeasurement);
                        }}
                        className={`px-3 py-1.5 text-xs rounded-lg border ${selectedVariant?.measurement === measurement
                          ? 'bg-indigo-50 border-indigo-500 text-indigo-700 font-medium'
                          : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                          }`}
                      >
                        {measurement} {selectedVariant?.stock_unit_name || product.stock_unit_name || 'PC'}
                      </button>
                    ))}
                  </div>
                </div>
              )} */}
            </div>
          )}

          {/* Quantity Selector */}
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-medium text-gray-700">Quantity ({selectedVariant?.stock_unit_name || product.stock_unit_name || 'PC'})</span>
            <div className="flex items-center gap-2 border border-gray-200 rounded-lg overflow-hidden">
              <button
                onClick={handleDecreaseQuantity}
                disabled={isAddingToCart}
                className="w-8 h-8 flex items-center justify-center bg-gray-50 text-gray-700 hover:bg-gray-100 transition-colors disabled:opacity-50"
              >
                -
              </button>
              <span className="font-medium text-sm w-8 text-center">{cartCount}</span>
              <button
                onClick={handleIncreaseQuantity}
                disabled={
                  isAddingToCart ||
                  (product?.is_unlimited_stock === 1
                    ? false
                    : (selectedVariant?.stock && cartCount >= selectedVariant.stock) ||
                    (!selectedVariant && product?.stock && cartCount >= product?.stock))
                }
                className="w-8 h-8 flex items-center justify-center bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors disabled:opacity-50"
              >
                +
              </button>
            </div>
          </div>

          {/* Price Information */}
          <div className="bg-gray-50 rounded-xl p-4 mt-4 mb-4">
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-bold text-gray-900">{formatPrice(discountedPrice)}</span>
              {discountPercentage > 0 && (
                <>
                  <span className="text-gray-500 line-through text-sm">{formatPrice(price)}</span>
                  <span className="text-green-600 font-medium bg-green-100 px-2 py-1 rounded-lg text-xs">
                    {discountPercentage}% OFF
                  </span>
                </>
              )}
            </div>
            {discountPercentage > 0 && (
              <div className="text-xs text-green-600 font-medium mt-1">
                You save: {formatPrice(price - discountedPrice)}
              </div>
            )}
          </div>


          {/* Sticky Bottom Bar */}
          <div className="bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3 flex items-center z-40">
            <button
              onClick={handleWishlistToggle}
              disabled={isWishlistLoading}
              className={`w-12 h-12 rounded-full flex items-center justify-center mr-3 transition-colors ${isFavorite
                ? 'bg-rose-100 text-rose-500'
                : 'border border-gray-200 text-gray-500 hover:bg-gray-50'
                }`}
            >
              {isWishlistLoading ? (
                <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></span>
              ) : (
                <Heart className={`w-6 h-6 ${isFavorite ? 'fill-rose-500' : ''}`} />
              )}
            </button>

            {showAddToCartFeedback ? (
              <button className="flex-1 bg-green-500 text-white rounded-full py-3 font-medium text-sm flex items-center justify-center gap-2">
                <Check className="w-5 h-5" />
                {isInCart ? 'Updated in Cart' : 'Added to Cart'}
              </button>
            ) : isInCart ? (
              <button className="flex-1 bg-green-100 text-green-800 rounded-full py-3 font-medium text-sm flex items-center justify-center gap-2">
                <Check className="w-5 h-5" />
                In Cart ({currentCartQuantity})
              </button>
            ) : (
              <button
                onClick={() => handleAddToCart(cartCount)}
                disabled={isAddingToCart}
                className={`flex-1 rounded-full py-3 font-medium text-sm ${isAddingToCart
                  ? 'bg-gray-300 text-gray-600'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                  }`}
              >
                {isAddingToCart ? (
                  <span className="inline-block w-5 h-5 border-2 border-gray-600 border-t-transparent rounded-full animate-spin mx-auto"></span>
                ) : (
                  'Add to Cart'
                )}
              </button>
            )}

            <button
              onClick={() => {
                handleAddToCart(cartCount);
                navigate('/cart');
              }}
              disabled={isAddingToCart}
              className={`flex-1 bg-rose-500 hover:bg-rose-600 text-white rounded-full py-3 font-medium text-sm ml-3 ${isAddingToCart ? 'opacity-70' : ''
                }`}
            >
              Buy Now
            </button>
          </div>

          {/* Key Features Section */}
          <div className="mt-4">
            <h3 className="font-medium text-gray-900 mb-2 flex items-center gap-1">
              <Zap className="w-4 h-4 text-rose-500" />
              Key Features
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {product?.product_specification
                ?.filter(
                  (spec) =>
                    spec.value &&
                    spec.value !== "null" &&
                    String(spec.value).trim() !== "" &&
                    [
                      "Display Type",
                      "Operating System",
                      "Processor",
                      "Rear Camera",
                      "Front Camera",
                      "Battery",
                      "Network Type",
                      "SIM Type",
                    ].includes(spec.name)
                )
                .map((spec, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-2 p-2 bg-gray-50 rounded-lg border border-gray-200"
                  >
                    <div>
                      <h4 className="text-xs font-medium text-gray-800">{spec.name}</h4>
                      <p className="text-xs text-gray-600">{spec.value}</p>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          {/* Cancellation & Return Info */}
          <div className="space-y-2 mb-4 mt-2">
            {product.cancelable_status === 1 && (
              <div className="flex items-start gap-2">
                <div className="w-4 h-4 text-green-500 mt-0.5">
                  <Check className="w-full h-full" />
                </div>
                <p className="text-xs text-gray-600">
                  This product can be cancelled till it is processed.
                </p>
              </div>
            )}

            {product.return_status === 1 ? (
              <div className="flex items-start gap-2">
                <div className="w-4 h-4 text-green-500 mt-0.5">
                  <Check className="w-full h-full" />
                </div>
                <p className="text-xs text-gray-600">
                  This product is returnable within {product.return_days || 7} days of delivery.
                </p>
              </div>
            ) : (
              <div className="flex items-start gap-2">
                <div className="w-4 h-4 text-gray-500 mt-0.5">
                  <CalendarSync className="w-full h-full text-red-500" />
                </div>
                <p className="text-xs text-red-500 font-semibold">
                  This product is not returnable.
                </p>
              </div>
            )}
          </div>

          {/* Badges Section */}
          <div className="grid grid-cols-4 gap-2 mb-4">
            {badges.map((badge, index) => (
              <div key={index} className="flex flex-col items-center justify-center text-center p-2 bg-white border border-gray-100 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <div className="p-1 mb-1 bg-rose-50 rounded-full text-rose-500">
                  {badge.icon}
                </div>
                <span className="text-xs text-gray-700">
                  {badge.title}
                </span>
              </div>
            ))}
          </div>

          {/* Tabs Section */}
          <div className="border-b border-gray-200 mb-4">
            <div className="flex">
              {['details', 'reviews', 'shipping'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 py-3 px-2 text-sm font-medium capitalize transition-colors ${activeTab === tab
                    ? 'text-rose-500 border-b-2 border-rose-500'
                    : 'text-gray-500'
                    }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Content */}
          <div className="pb-4">
            {activeTab === 'details' && (
              <div>
                <h3 className="font-medium text-gray-900 mb-2">Product Description</h3>
                <p className={`text-xs text-gray-600 leading-relaxed ${!showFullDescription && 'line-clamp-3'}`}>
                  <div
                    dangerouslySetInnerHTML={{
                      __html: product.description || `The <strong>${product.name}</strong> is a premium product designed to meet your needs. 
                      It features high-quality materials and excellent craftsmanship to ensure 
                      durability and performance. Perfect for everyday use, this product combines 
                      style and functionality in one package. With its sleek design and user-friendly 
                      features, it's a great addition to your collection.`,
                    }}
                  />
                </p>
                <button
                  onClick={() => setShowFullDescription(!showFullDescription)}
                  className="mt-1 text-rose-500 text-xs flex items-center"
                >
                  {showFullDescription ? 'Show less' : 'Read more'}
                  <ChevronDown size={14} className={`ml-1 transition-transform ${showFullDescription ? 'rotate-180' : ''}`} />
                </button>

                {/* Full Specifications - Mobile Only */}
                <div className="specifications md:hidden mt-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4 border-b pb-2">Full Specifications</h3>

                  <div className="bg-white rounded-xl overflow-hidden border border-gray-200 shadow-sm divide-y divide-gray-100">
                    {/* Dynamic product specifications */}
                    {product?.product_specification
                      ?.filter(
                        (spec) =>
                          spec.value &&
                          spec.value !== "null" &&
                          String(spec.value).trim() !== "" &&
                          ![
                            "Display Type",
                            "Operating System",
                            "Processor",
                            "Rear Camera",
                            "Front Camera",
                            "Battery",
                            "Network Type",
                            "SIM Type",
                          ].includes(spec.name)
                      )
                      .map((spec, index) => (
                        <div
                          key={`dyn-${index}`}
                          className="flex justify-between items-start py-3 px-4 text-sm bg-white hover:bg-gray-50 transition"
                        >
                          <span className="text-[#1e3a8a] font-medium w-1/2">{spec.name}</span>
                          <span className="text-right font-medium text-gray-900 w-1/2 max-w-[60%]">{spec.value}</span>
                        </div>
                      ))}

                    {/* Static specifications */}
                    {[
                      { label: "Brand", value: product?.brand?.name },
                      { label: "Manufacturer", value: product?.manufacturer },
                      { label: "Category", value: product?.category?.name },
                      {
                        label: "No. of Pieces",
                        value: selectedVariant?.no_of_pics || product?.variants?.[0]?.no_of_pics,
                      },
                      {
                        label: "Capacity",
                        value: selectedVariant?.capacity || product?.variants?.[0]?.capacity,
                      },
                      {
                        label: "Weight",
                        value: (() => {
                          const weight =
                            product?.weight_in_grams ||
                            selectedVariant?.weight_in_grams ||
                            product?.variants?.[0]?.weight_in_grams;
                          const weightNumber = parseInt(weight);
                          if (!isNaN(weightNumber) && weightNumber > 0) {
                            return weightNumber >= 1000
                              ? `${(weightNumber / 1000).toFixed(2)} kg`
                              : `${weightNumber} g`;
                          }
                          return null;
                        })(),
                      },
                      {
                        label: "Pattern",
                        value: selectedVariant?.pattern || product?.variants?.[0]?.pattern,
                      },
                      {
                        label: "Material",
                        value: selectedVariant?.material || product?.variants?.[0]?.material,
                      },
                      {
                        label: "Dimensions",
                        value: selectedVariant?.dimensions || product?.variants?.[0]?.dimensions,
                      },
                      {
                        label: "Stock Unit",
                        value: selectedVariant?.stock_unit_name || product?.stock_unit_name,
                      },
                      { label: "Type", value: product?.type },
                      {
                        label: "Made In",
                        value: typeof product?.made_in === "object" ? product?.made_in?.name : product?.made_in,
                      },
                      {
                        label: "Warranty",
                        value:
                          product?.warranty_id && product?.warranty_id !== "null"
                            ? product?.warranty_id
                              .replace(/_/g, " ")
                              .replace(/\b\w/g, (c) => c.toUpperCase())
                            : null,
                      },
                    ]
                      .filter(
                        (spec) =>
                          spec.value &&
                          spec.value !== "null" &&
                          spec.value !== "0" &&
                          String(spec.value).trim().toLowerCase() !== "null" &&
                          String(spec.value).trim().toLowerCase() !== "0"
                      )
                      .map((spec, index) => (
                        <div
                          key={`static-${index}`}
                          className="flex justify-between items-start py-3 px-4 text-sm bg-white hover:bg-gray-50 transition"
                        >
                          <span className="text-[#1e3a8a] font-medium w-1/2">{spec.label}</span>
                          <span className="text-right font-medium text-gray-900 w-1/2 max-w-[60%]">{spec.value}</span>
                        </div>
                      ))}
                  </div>
                </div>

                {/* Additional Details Section */}
                <div className="mt-4">
                  <h3 className="font-medium text-gray-900 mb-2">Additional Details</h3>
                  <div className="space-y-2 bg-gray-50 rounded-lg overflow-hidden">
                    {product.fssai_lic_no && (
                      <div className="flex justify-between py-2 px-3 bg-white text-xs">
                        <span className="text-gray-500">FSSAI License No.</span>
                        <span className="font-medium text-gray-800">{product.fssai_lic_no}</span>
                      </div>
                    )}
                    {
                      <div className="flex justify-between py-2 px-3 bg-white text-xs">
                        <span className="text-gray-500">Supplier Information</span>
                        <span className="font-medium text-gray-800">{product?.seller?.name} c/o Bringmart</span>
                      </div>
                    }
                    <div className="p-3 text-xs text-gray-600">
                      <h4 className="font-medium text-gray-800 mb-1">Legal Disclaimer</h4>
                      <p>
                        Product images are for illustrative purposes only. Actual product may vary slightly in
                        appearance due to natural variations. We recommend reading the product description
                        carefully before purchase. Manufacturer's warranty (if applicable) does not cover
                        damages caused by misuse or improper handling.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Seller Information */}
                <div className="mt-4 bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
                  <h3 className="font-medium text-gray-900 mb-3">Seller Information</h3>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-rose-50 rounded-full text-rose-500">
                        {product.seller_image_url ? (
                          <img src={product.seller_image_url} alt="" className="w-5 h-5 rounded-full" />
                        ) : (
                          <Store className="w-5 h-5" />
                        )}
                      </div>
                      <div>
                        <h4 className="font-medium text-sm text-gray-900">
                          {typeof product.seller === 'object' ? product?.seller?.name : product.seller_name || 'NA'}
                        </h4>
                        <div className="flex items-center mt-1">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className={`w-3 h-3 ${i < 4 ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
                            ))}
                          </div>
                          <span className="ml-1 text-xs text-gray-600">
                            4.0 (121 ratings)
                          </span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => navigate(`/seller-products/p${slugify(product?.seller?.name)}?seller_id=${product?.seller?.id}`)}
                      className="flex items-center gap-1 text-xs text-rose-500 font-medium hover:text-rose-600 transition-colors"
                    >
                      View Shop
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                    <div className="border border-gray-100 rounded-lg p-2">
                      <div className="text-sm font-bold text-gray-900">98%</div>
                      <div className="text-xs text-gray-500">Positive Feedback</div>
                    </div>
                    <div
                      className="border border-gray-100 rounded-lg p-2 cursor-pointer"
                      onClick={() => navigate(`/seller-products/p${slugify(product?.seller?.name)}?seller_id=${product?.seller?.id}`)}
                    >
                      <div className="text-sm font-bold text-gray-900">{product.seller?.total_products || 'NA'}</div>
                      <div className="text-xs text-gray-500">Products</div>
                    </div>
                    <div className="border border-gray-100 rounded-lg p-2">
                      <div className="text-sm font-semibold text-gray-900">
                        {calculateTimeDifference(product.seller?.created_at)}
                      </div>
                      <div className="text-xs text-gray-500">On Platform</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'reviews' && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-medium text-gray-900">Customer Reviews</h3>
                  <div className="flex items-center">
                    <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    <span className="ml-1 text-sm font-medium">{product.rating || 4.5}</span>
                    <span className="ml-1 text-xs text-gray-500">({product.rating_count || 0} reviews)</span>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4 mb-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-rose-100 rounded-full flex items-center justify-center text-rose-600 font-medium">
                      J
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-medium text-gray-900">John D.</h4>
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                          ))}
                        </div>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">
                        Great product, very satisfied with the quality and performance.
                        The delivery was fast and the packaging was excellent.
                      </p>
                      <div className="text-2xs text-gray-500 mt-1">2 weeks ago</div>
                    </div>
                  </div>
                </div>

                <button className="w-full py-2 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">
                  View All Reviews
                </button>
              </div>
            )}

            {activeTab === 'shipping' && (
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Shipping Information</h3>

                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-rose-50 rounded-full">
                      <Truck className="w-5 h-5 text-rose-500" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">{product.free_delivery ? "Free Delivery" : "Delivery Available"}</h4>
                      <p className="text-xs text-gray-600 mt-1">
                        Estimated delivery within 3-5 business days.
                        {product.free_delivery ? " Free shipping on this product." : " Shipping charges may apply."}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-blue-50 rounded-full">
                      <Wallet className="w-5 h-5 text-blue-500" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Payment Options</h4>
                      <p className="text-xs text-gray-600 mt-1">
                        {product.cod_allowed ? "Cash on Delivery available for this product." : "Cash on Delivery not available."}
                        We also accept all major credit/debit cards, UPI, and net banking.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-green-50 rounded-full">
                      <Shield className="w-5 h-5 text-green-500" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Return Policy</h4>
                      <p className="text-xs text-gray-600 mt-1">
                        {product.return_status === 1
                          ? `Easy returns within ${product.return_days || 7} days of delivery. Products must be in original condition with all tags and packaging intact.`
                          : 'This product is not returnable.'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <RelatedProductsPage product={product} key={product?.id} />

          </div>

        </div>
      </div>

      {showShareModal && product && (
        <ShareModal
          product={product}
          onClose={() => setShowShareModal(false)}
        />
      )}

      {/* Zoom Modal */}
      {isZoomed && (
        <div className="fixed inset-0 bg-black bg-opacity-95 z-50 flex items-center justify-center p-4">
          <button
            onClick={() => setIsZoomed(false)}
            className="absolute top-4 right-4 text-white p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={product?.images?.[currentSlide] || 'https://via.placeholder.com/500'}
            alt={`Product ${currentSlide + 1} zoomed`}
            className="max-w-full max-h-[90vh] object-contain animate-zoomIn"
          />

          {/* Thumbnail navigation in zoom mode */}
          <div className="absolute bottom-8 left-0 right-0 flex justify-center gap-2 px-4">
            {product.images.map((img, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-12 h-12 rounded-md overflow-hidden border-2 transition-all ${currentSlide === index ? 'border-white' : 'border-transparent opacity-60'
                  }`}
              >
                <img
                  src={img}
                  alt={`Thumbnail ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* CSS Animations */}
      <style>{`
        @keyframes slideLeft {
          from { transform: translateX(100%); }
          to { transform: translateX(0); }
        }
        @keyframes slideRight {
          from { transform: translateX(-100%); }
          to { transform: translateX(0); }
        }
        @keyframes zoomIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        @keyframes fadeInOut {
          0% { opacity: 0; transform: translateY(-10px); }
          10% { opacity: 1; transform: translateY(0); }
          90% { opacity: 1; transform: translateY(0); }
          100% { opacity: 0; transform: translateY(-10px); }
        }
        .animate-slideLeft { animation: slideLeft 0.5s ease-out; }
        .animate-slideRight { animation: slideRight 0.5s ease-out; }
        .animate-zoomIn { animation: zoomIn 0.3s ease-out; }
        .animate-fade-in-out { animation: fadeInOut 3s ease-in-out; }
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>

    </div>
  );
};

export default MobileDetails;