import React, { useRef, useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import ProductCard from './ProductCard';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import * as newApi from ".././api/apiCollection";
import { setFilterBySeller, clearAllFilter } from '../model/reducer/productFilterReducer';
import { AiOutlineCloseCircle } from 'react-icons/ai';
import { Collapse, Slider, Checkbox } from "antd";
// import CategoryComponent from './Categories';
import { BsFillGrid3X3GapFill } from 'react-icons/bs';
import { FaThList } from 'react-icons/fa';
// import { useTranslation } from 'react-i18next';

const ProductList = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const location = useLocation();
    // const { t } = useTranslation();

    // State from Reduxz
    const filter = useSelector(state => state.productFilter);
    const city = useSelector(state => state.city);
    const setting = useSelector(state => state.setting);
    const category = useSelector(state => state.category?.category);

    // Local state
    const [isMobile, setIsMobile] = useState(false);
    const [isGridView, setIsGridView] = useState(true);
    const [products, setProducts] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [totalProducts, setTotalProducts] = useState(0);
    const [brands, setBrands] = useState(null);
    const [minPrice, setMinPrice] = useState(null);
    const [maxPrice, setMaxPrice] = useState(null);
    const [values, setValues] = useState([]);
    const [selectedCategories, setSelectedCategories] = useState([]);
    const scrollContainerRef = useRef(null);

    const total_products_per_page = 12;
    const [offset, setOffset] = useState(0);

    // Check if device is mobile
    useEffect(() => {
        const checkIfMobile = () => {
            setIsMobile(window.innerWidth < 768);
        };
        checkIfMobile();
        window.addEventListener('resize', checkIfMobile);
        return () => {
            window.removeEventListener('resize', checkIfMobile);
        };
    }, []);

    // Handle URL parameters (like ?seller=123)
    useEffect(() => {
        const searchParams = new URLSearchParams(location.search);
        const sellerId = searchParams.get('seller');

        if (sellerId) {
            // Clear all filters and set only the seller filter
            dispatch(clearAllFilter());
            dispatch(setFilterBySeller({ data: parseInt(sellerId) }));
        }
    }, [location.search, dispatch]);

    // Fetch products when filters change
    useEffect(() => {
        const fetchProducts = async () => {
            setIsLoading(true);
            try {
                const result = await newApi.productByFilter({
                    latitude: city?.city?.latitude,
                    longitude: city?.city?.longitude,
                    filters: {
                        min_price: filter.price_filter?.min_price,
                        max_price: filter.price_filter?.max_price,
                        category_ids: filter?.category_id,
                        brand_ids: filter?.brand_ids?.toString(),
                        sort: filter?.sort_filter,
                        search: filter?.search,
                        limit: total_products_per_page,
                        sizes: filter?.search_sizes?.filter(obj => obj.checked).map(obj => obj["size"]).join(","),
                        offset: offset,
                        unit_ids: filter?.search_sizes?.filter(obj => obj.checked).map(obj => obj["unit_id"]).join(","),
                        seller_id: filter?.seller_id,
                        country_id: filter?.country_id,
                        section_id: filter?.section_id
                    }
                });

                if (result.status === 1) {
                    // Handle prices if not set
                    if (minPrice == null && maxPrice == null && filter?.price_filter == null) {
                        setMinPrice(parseInt(result.total_min_price));
                        if (result.total_min_price === result.total_max_price) {
                            setMaxPrice(parseInt(result.total_max_price) + 100);
                            setValues([parseInt(result.total_min_price), parseInt(result.total_max_price) + 100]);
                        } else {
                            setMaxPrice(parseInt(result.total_max_price));
                            setValues([parseInt(result.total_min_price), parseInt(result.total_max_price)]);
                        }
                    }

                    if (offset === 0) {
                        setProducts(result.data);
                    } else {
                        setProducts(prev => [...prev, ...result.data]);
                    }
                    setTotalProducts(result.total);
                } else {
                    setProducts([]);
                    setTotalProducts(0);
                }
            } catch (error) {
                console.error("Error fetching products:", error);
                setProducts([]);
            } finally {
                setIsLoading(false);
            }
        };

        fetchProducts();
    }, [
        filter.search,
        filter.category_id,
        filter.brand_ids,
        filter.sort_filter,
        filter.search_sizes,
        filter.price_filter,
        filter.seller_id,
        offset,
        city?.city?.latitude,
        city?.city?.longitude
    ]);

    const scroll = (direction, ref) => {
        const container = ref.current;
        if (container) {
            const cardWidth = isMobile ?
                container.querySelector('.product-card-container').offsetWidth * 2 + 16 :
                300;
            container.scrollBy({
                left: direction === 'left' ? -cardWidth : cardWidth,
                behavior: 'smooth'
            });
        }
    };

    const Filter = () => (
        <div className='product-filter'>
            <div className='filter-header'>
                <div className='filter-sub-header '>
                    <h5>Filters</h5>
                    <p className='m-0' role='button'
                        onClick={() => {
                            setSelectedCategories([]);
                            setMinPrice(null);
                            setMaxPrice(null);
                            dispatch(clearAllFilter());
                            setOffset(0);
                            setProducts([]);
                        }}
                    >
                        Clear All
                    </p>
                </div>
            </div>
            <Collapse defaultActiveKey={['1', '2', '3']}>
                <Collapse.Panel header={t("product_category")} key="1">
                    <div className='filter-row'>
                        <CategoryComponent
                            data={category}
                            selectedCategories={selectedCategories}
                            setSelectedCategories={setSelectedCategories}
                            setProducts={setProducts}
                            setOffset={setOffset}
                        />
                    </div>
                </Collapse.Panel>
                <Collapse.Panel header={t("priceRange")} key="3">
                    <div>
                        <Slider
                            range
                            min={minPrice}
                            max={maxPrice}
                            step={0.01}
                            onChange={setValues}
                            value={values}
                        />
                        <div className='range-prices'>
                            <p>{setting?.setting?.currency}{values[0]}</p>
                            <p>{setting?.setting?.currency}{values[1]}</p>
                        </div>
                        <button className='price-filter-apply-btn' onClick={() => {
                            setOffset(0);
                            setProducts([]);
                            dispatch(setFilterMinMaxPrice({
                                data: {
                                    min_price: values[0],
                                    max_price: values[1]
                                }
                            }));
                        }}>
                            Apply
                        </button>
                    </div>
                </Collapse.Panel>
            </Collapse>
        </div>
    );

    const handleFetchMore = () => {
        setOffset(prev => prev + total_products_per_page);
    };

    return (
        <section className="max-w-7xl mx-auto px-4 mb-10">
            {/* Breadcrumb */}
            <div className='w-100 breadCrumbs mb-6'>
                <div className='container d-flex align-items-center gap-2'>
                    <div className='breadCrumbsItem'>
                        <Link to={"/"}>{t("home")}</Link>
                    </div>
                    <div className='breadCrumbsItem'>/</div>
                    <div className='breadCrumbsItem'>
                        <Link className={location.pathname === "/products" ? "breadCrumbActive" : ""} to={"/products"}>{t("products")}</Link>
                    </div>
                    {filter.seller_id && (
                        <>
                            <div className='breadCrumbsItem'>/</div>
                            <div className='breadCrumbsItem breadCrumbActive'>
                                Seller Products
                            </div>
                        </>
                    )}
                </div>
            </div>

            <div className="flex flex-col md:flex-row gap-6">
                {/* Filters - hidden on mobile by default, can add mobile toggle */}
                <div className="w-full md:w-1/4 lg:w-1/5">
                    <Filter />
                </div>

                {/* Products */}
                <div className="w-full md:w-3/4 lg:w-4/5">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-semibold">
                            {filter.seller_id ? "Seller Products" : "All Products"}
                            <span className="text-gray-600 ml-2 text-sm">
                                ({totalProducts} products)
                            </span>
                        </h2>

                        <div className="flex items-center gap-4">
                            <div className="flex items-center gap-2">
                                <span className="text-sm">Sort:</span>
                                <select
                                    className="border rounded p-1 text-sm"
                                    value={filter.sort_filter || ""}
                                    onChange={(e) => {
                                        setProducts([]);
                                        setOffset(0);
                                        dispatch(setFilterSort({ data: e.target.value }));
                                    }}
                                >
                                    <option value="">Default</option>
                                    <option value="new">Newest First</option>
                                    <option value="old">Oldest First</option>
                                    <option value="high">Price: High to Low</option>
                                    <option value="low">Price: Low to High</option>
                                    <option value="discount">Discount High to Low</option>
                                    <option value="popular">Popularity</option>
                                </select>
                            </div>

                            <div className="flex gap-2">
                                <button
                                    onClick={() => setIsGridView(true)}
                                    className={`p-2 rounded ${isGridView ? 'bg-gray-200' : 'bg-white'}`}
                                >
                                    <BsFillGrid3X3GapFill />
                                </button>
                                <button
                                    onClick={() => setIsGridView(false)}
                                    className={`p-2 rounded ${!isGridView ? 'bg-gray-200' : 'bg-white'}`}
                                >
                                    <FaThList />
                                </button>
                            </div>
                        </div>
                    </div>

                    {isLoading && offset === 0 ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                            {[...Array(12)].map((_, index) => (
                                <div key={index} className="bg-white rounded-lg shadow p-4 animate-pulse">
                                    <div className="bg-gray-200 h-48 rounded"></div>
                                    <div className="mt-4 space-y-2">
                                        <div className="bg-gray-200 h-4 rounded"></div>
                                        <div className="bg-gray-200 h-4 rounded w-3/4"></div>
                                        <div className="bg-gray-200 h-4 rounded w-1/2"></div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : products.length > 0 ? (
                        <>
                            <div className={isGridView ?
                                "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6" :
                                "space-y-6"}>
                                {products.map((product) => (
                                    isGridView ? (
                                        <ProductCard
                                            key={product.id}
                                            product={product}
                                            isMobile={isMobile}
                                        />
                                    ) : (
                                        <div key={product.id} className="bg-white rounded-lg shadow p-4">
                                            {/* List view implementation */}
                                            <div className="flex flex-col md:flex-row gap-4">
                                                <div className="w-full md:w-1/4">
                                                    <img
                                                        src={product.image_url || 'https://via.placeholder.com/300'}
                                                        alt={product.name}
                                                        className="w-full h-auto rounded"
                                                    />
                                                </div>
                                                <div className="w-full md:w-3/4">
                                                    <h3 className="text-lg font-semibold">{product.name}</h3>
                                                    <div className="flex items-center mt-2">
                                                        <span className="text-lg font-bold text-orange-500">
                                                            {setting?.setting?.currency}{product.price}
                                                        </span>
                                                        {product.old_price && (
                                                            <span className="ml-2 text-sm text-gray-500 line-through">
                                                                {setting?.setting?.currency}{product.old_price}
                                                            </span>
                                                        )}
                                                        {product.discount > 0 && (
                                                            <span className="ml-2 text-sm bg-red-100 text-red-800 px-2 py-1 rounded">
                                                                {product.discount}% OFF
                                                            </span>
                                                        )}
                                                    </div>
                                                    <p className="mt-2 text-gray-600">{product.short_description}</p>
                                                    <button className="mt-4 bg-orange-500 text-white px-4 py-2 rounded hover:bg-orange-600 transition">
                                                        Add to Cart
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    )
                                ))}
                            </div>

                            {totalProducts > products.length && (
                                <div className="mt-8 text-center">
                                    <button
                                        onClick={handleFetchMore}
                                        className="bg-gray-100 hover:bg-gray-200 px-6 py-2 rounded-full font-medium transition"
                                        disabled={isLoading}
                                    >
                                        {isLoading ? 'Loading...' : 'Load More'}
                                    </button>
                                </div>
                            )}
                        </>
                    ) : (
                        <div className="text-center py-12">
                            <div className="max-w-md mx-auto">
                                <img
                                    src="/no-products.svg"
                                    alt="No products found"
                                    className="w-full h-auto max-h-64 mb-6"
                                />
                                <h3 className="text-xl font-semibold mb-2">No Products Found</h3>
                                <p className="text-gray-600 mb-4">
                                    {filter.seller_id ?
                                        "This seller doesn't have any products available right now." :
                                        "We couldn't find any products matching your filters."}
                                </p>
                                <button
                                    onClick={() => {
                                        dispatch(clearAllFilter());
                                        setOffset(0);
                                        setSelectedCategories([]);
                                    }}
                                    className="bg-orange-500 text-white px-6 py-2 rounded hover:bg-orange-600 transition"
                                >
                                    Reset Filters
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </section>
    );
};

export default ProductList;