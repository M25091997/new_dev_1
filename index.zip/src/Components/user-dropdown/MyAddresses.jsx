import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { FiEdit, FiPlus, FiX } from 'react-icons/fi';
import { RiDeleteBinLine } from 'react-icons/ri';
import { toast } from 'react-toastify';
import { GoogleMap, MarkerF } from '@react-google-maps/api';
import { setAddress, setSelectedAddress } from '../../model/reducer/addressReducer';
import api from '../../api/api';
import ConfirmationDialog from '../../Components/Dialog/ConfirmationDialog';
import { BiCurrentLocation } from 'react-icons/bi';
import { loadGoogleMaps, isGoogleMapsLoaded } from '../../utils/LoadGoogleMaps/LoadGoogleMap'; // Import loadGoogleMaps

const MyAddresses = () => {
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user);
  const address = useSelector((state) => state.address);
  const city = useSelector((state) => state.city);
  const [addresses, setAddresses] = useState([]);
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [addressToDelete, setAddressToDelete] = useState(null);
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [loadingSaveAddress, setLoadingSaveAddress] = useState(false);
  const [errors, setErrors] = useState({});
  const [isGeocoding, setIsGeocoding] = useState(false);
  const [mapLoaded, setMapLoaded] = useState(isGoogleMapsLoaded()); // Initialize based on API load status
  const [mapsError, setMapsError] = useState(null); // Track loading errors
  const [locationPermission, setLocationPermission] = useState(null);
  const [typingTimeout, setTypingTimeout] = useState(null);
  const autocompleteRef = useRef(null);
  const autocomplete = useRef(null);

  const [newAddress, setNewAddress] = useState({
    id: null,
    name: '',
    mobile: '',
    alternate_mobile: '',
    address: '',
    landmark: '',
    area: '',
    city: '',
    state: '',
    country: '',
    pincode: '',
    type: 'Home',
    is_default: false,
    latitude: city.city ? city.city.latitude : 0,
    longitude: city.city ? city.city.longitude : 0,
    isManualInput: false, // Add this flag
  });

  const [mapPosition, setMapPosition] = useState({
    lat: parseFloat(city.city ? city.city.latitude : 0),
    lng: parseFloat(city.city ? city.city.longitude : 0),
  });

  // Load Google Maps API
  useEffect(() => {
    let mounted = true;

    const loadMaps = async () => {
      try {
        await loadGoogleMaps(import.meta.env.VITE_APP_MAP_API);
        if (mounted) {
          setMapLoaded(true);
        }
      } catch (error) {
        if (mounted) {
          setMapsError(error.message);
          toast.error('Failed to load Google Maps API');
          console.error('Google Maps loading error:', error);
        }
      }
    };

    if (!isGoogleMapsLoaded()) {
      loadMaps();
    } else {
      setMapLoaded(true);
    }

    return () => {
      mounted = false;
    };
  }, []);

  // Check location permission
  useEffect(() => {
    const checkLocationPermission = async () => {
      if (navigator.permissions) {
        try {
          const permissionStatus = await navigator.permissions.query({ name: 'geolocation' });
          setLocationPermission(permissionStatus.state);

          permissionStatus.onchange = () => {
            setLocationPermission(permissionStatus.state);
          };
        } catch (e) {
          console.error("Permission query failed:", e);
          setLocationPermission('prompt');
        }
      } else {
        setLocationPermission('prompt');
      }
    };

    checkLocationPermission();
  }, []);

  // Initialize Google Places Autocomplete
  useEffect(() => {
    if (mapLoaded && window.google && window.google.maps && autocompleteRef.current && !autocomplete.current) {
      autocomplete.current = new window.google.maps.places.Autocomplete(autocompleteRef.current, {
        types: ['geocode'],
        componentRestrictions: { country: 'IN' }, // Restrict to India
      });

      autocomplete.current.addListener('place_changed', () => {
        const place = autocomplete.current.getPlace();
        if (!place.geometry) {
          toast.error('No details available for this place');
          return;
        }

        // Clear any pending manual geocoding
        if (typingTimeout) {
          clearTimeout(typingTimeout);
          setTypingTimeout(null);
        }

        let address = '',
          city = '',
          state = '',
          pincode = '',
          country = '',
          area = '',
          landmark = '';

        place.address_components.forEach((component) => {
          if (component.types.includes('street_number') || component.types.includes('route')) {
            address = address ? `${component.long_name} ${address}` : component.long_name;
          }
          if (component.types.includes('locality')) {
            city = component.long_name;
          }
          if (component.types.includes('administrative_area_level_1')) {
            state = component.long_name;
          }
          if (component.types.includes('postal_code')) {
            pincode = component.long_name;
          }
          if (component.types.includes('country')) {
            country = component.long_name;
          }
          if (component.types.includes('sublocality') || component.types.includes('neighborhood')) {
            area = component.long_name;
          }
          if (component.types.includes('point_of_interest') || component.types.includes('establishment')) {
            landmark = component.long_name;
          }
        });

        const lat = place.geometry.location.lat();
        const lng = place.geometry.location.lng();

        setNewAddress((prev) => ({
          ...prev,
          address: address || place.formatted_address || prev.address,
          landmark: landmark || prev.landmark,
          area: area || prev.area,
          city: city || prev.city,
          state: state || prev.state,
          pincode: pincode || prev.pincode,
          country: country || prev.country,
          latitude: lat.toString(),
          longitude: lng.toString(),
        }));

        setMapPosition({ lat, lng });
      });
    }

    return () => {
      if (autocomplete.current && window.google?.maps) {
        window.google.maps.event.clearInstanceListeners(autocomplete.current);
      }
    };
  }, [mapLoaded]);

  // Fetch addresses when component mounts
  const fetchAddresses = async () => {
    try {
      const response = await api.getAddress(user?.jwtToken);
      const result = await response.json();

      if (result.status === 1) {
        setAddresses(result.data);
        dispatch(setAddress({ data: result.data }));
      }
    } catch (error) {
      console.error('Error fetching addresses:', error);
      toast.error('Failed to load addresses');
    }
  };

  useEffect(() => {
    if (user?.jwtToken) {
      fetchAddresses();
    }
  }, [user?.jwtToken]);

  const handleStreetChange = useCallback(
    (e) => {
      const { name, value } = e.target;

      // Update the address immediately for user feedback
      setNewAddress((prev) => ({
        ...prev,
        [name]: value,
        isManualInput: true, // Flag to indicate user is typing
      }));

      // Clear any existing timeout
      if (typingTimeout) {
        clearTimeout(typingTimeout);
      }

      // Skip geocoding if the input is empty or Google Maps is not loaded
      if (!value.trim() || !mapLoaded || !window.google || !window.google.maps) {
        return;
      }

      // Set a new timeout for geocoding
      setTypingTimeout(
        setTimeout(() => {
          const geocoder = new window.google.maps.Geocoder();
          const fullAddress = `${value}, ${newAddress.city || ''}, ${newAddress.state || ''}, ${newAddress.country || ''}`.trim();

          setIsGeocoding(true);
          geocoder.geocode({ address: fullAddress }, (results, status) => {
            setIsGeocoding(false);
            if (status === 'OK' && results[0]) {
              const location = results[0].geometry.location;
              const lat = location.lat();
              const lng = location.lng();

              // Update map position
              setMapPosition({ lat, lng });

              // Only update address components if user hasn't continued typing
              setNewAddress((prev) => {
                if (prev.isManualInput && prev.address !== value) {
                  // User has continued typing, don't overwrite
                  return {
                    ...prev,
                    isManualInput: false,
                    latitude: lat.toString(),
                    longitude: lng.toString(),
                  };
                }

                // Update address components from geocoding
                let city = prev.city,
                  state = prev.state,
                  country = prev.country,
                  pincode = prev.pincode,
                  area = prev.area,
                  landmark = prev.landmark;

                results[0].address_components.forEach((component) => {
                  if (component.types.includes('locality')) {
                    city = component.long_name;
                  }
                  if (component.types.includes('administrative_area_level_1')) {
                    state = component.long_name;
                  }
                  if (component.types.includes('country')) {
                    country = component.long_name;
                  }
                  if (component.types.includes('postal_code')) {
                    pincode = component.long_name;
                  }
                  if (component.types.includes('sublocality') || component.types.includes('neighborhood')) {
                    area = component.long_name;
                  }
                  if (component.types.includes('point_of_interest') || component.types.includes('establishment')) {
                    landmark = component.long_name;
                  }
                });

                return {
                  ...prev,
                  isManualInput: false,
                  city,
                  state,
                  country,
                  pincode,
                  area,
                  landmark,
                  latitude: lat.toString(),
                  longitude: lng.toString(),
                };
              });
            } else {
              // Handle geocoding errors
              toast.error(
                status === 'ZERO_RESULTS'
                  ? 'No location found for this address. Please refine your input.'
                  : 'Error geocoding address. Please try again.'
              );
            }
          });
        }, 1000) // 1 second delay after typing stops
      );
    },
    [newAddress.city, newAddress.state, newAddress.country, mapLoaded]
  );

  const handleCurrentLocation = () => {
    if (!mapLoaded || !window.google?.maps) {
      toast.error('Google Maps not loaded yet, please try again.');
      return;
    }

    if (!navigator.geolocation) {
      toast.error('Geolocation is not supported by your browser');
      return;
    }

    if (locationPermission === 'denied') {
      toast.error('Please enable location permissions in your browser settings');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const latLng = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };

        setMapPosition({
          lat: parseFloat(latLng.lat),
          lng: parseFloat(latLng.lng),
        });

        setNewAddress((prev) => ({
          ...prev,
          latitude: latLng.lat.toString(),
          longitude: latLng.lng.toString(),
        }));

        // Reverse geocode to get address details
        const geocoder = new window.google.maps.Geocoder();
        geocoder.geocode({ location: latLng }, (results, status) => {
          if (status === 'OK' && results[0]) {
            let address = '',
              country = '',
              pincode = '',
              landmark = '',
              area = '',
              state_ = '',
              city = '';

            results[0].address_components.forEach((res_add) => {
              if (res_add.types.includes('premise') || res_add.types.includes('plus_code') || res_add.types.includes('route')) {
                address = res_add.long_name;
              }
              if (res_add.types.includes('political')) {
                landmark = res_add.long_name;
              }
              if (
                res_add.types.includes('administrative_area_level_3') ||
                res_add.types.includes('administrative_area_level_2') ||
                res_add.types.includes('sublocality')
              ) {
                area = res_add.long_name;
              }
              if (res_add.types.includes('administrative_area_level_1')) {
                state_ = res_add.long_name;
              }
              if (res_add.types.includes('country')) {
                country = res_add.long_name;
              }
              if (res_add.types.includes('postal_code')) {
                pincode = res_add.long_name;
              }
              if (res_add.types.includes('locality')) {
                city = res_add.long_name;
              }
            });

            setNewAddress((prev) => ({
              ...prev,
              address: address || results[0].formatted_address || prev.address,
              landmark: landmark || prev.landmark,
              city: city || prev.city,
              area: area || prev.area,
              state: state_ || prev.state,
              pincode: pincode || prev.pincode,
              country: country || prev.country,
            }));
          }
        });
      },
      (error) => {
        console.log('Geolocation error:', error);
        if (error.code === error.PERMISSION_DENIED) {
          toast.error('Location access was denied. Please enable it to use this feature.');
        } else if (error.code === error.TIMEOUT) {
          toast.error('Location request timed out. Please try again or enter manually.');
        } else {
          toast.error('Error getting your location. Please try again or enter manually.');
        }
      }
    );
  };

  const onMarkerDragEnd = (e) => {
    if (!mapLoaded || !window.google?.maps) {
      toast.error('Google Maps not loaded yet, please try again.');
      return;
    }

    setIsGeocoding(true);
    const prev_latlng = {
      lat: mapPosition.lat,
      lng: mapPosition.lng,
    };

    const geocoder = new window.google.maps.Geocoder();

    geocoder.geocode(
      {
        location: {
          lat: e.latLng.lat(),
          lng: e.latLng.lng(),
        },
      },
      (response) => {
        if (response.results[0]) {
          setMapPosition({
            lat: parseFloat(e.latLng.lat()),
            lng: parseFloat(e.latLng.lng()),
          });

          let address = '',
            country = '',
            pincode = '',
            landmark = '',
            area = '',
            state_ = '',
            city = '';
          response.results[0].address_components.forEach((res_add) => {
            if (res_add / Hm.types.includes('premise') || res_add.types.includes('plus_code') || res_add.types.includes('route')) {
              address = res_add.long_name;
            }
            if (res_add.types.includes('political')) {
              landmark = res_add.long_name;
            }
            if (
              res_add.types.includes('administrative_area_level_3') ||
              res_add.types.includes('administrative_area_level_2') ||
              res_add.types.includes('sublocality')
            ) {
              area = res_add.long_name;
            }
            if (res_add.types.includes('administrative_area_level_1')) {
              state_ = res_add.long_name;
            }
            if (res_add.types.includes('country')) {
              country = res_add.long_name;
            }
            if (res_add.types.includes('postal_code')) {
              pincode = res_add.long_name;
            }
            if (res_add.types.includes('locality')) {
              city = res_add.long_name;
            }
          });

          if (address === '' || area === '') {
            setMapPosition({
              lat: prev_latlng.lat,
              lng: prev_latlng.lng,
            });
          } else {
            setNewAddress((prev) => ({
              ...prev,
              address: address,
              landmark: landmark,
              city: city,
              area: area,
              pincode: pincode,
              country: country,
              state: state_,
              latitude: e.latLng.lat().toString(),
              longitude: e.latLng.lng().toString(),
            }));
          }
          setIsGeocoding(false);
        }
      }
    );
  };

  const validateNewAddress = () => {
    const newErrors = {};
    if (!newAddress.name) newErrors.name = 'Name is required';
    if (!newAddress.mobile) newErrors.mobile = 'Mobile number is required';
    if (!newAddress.address) newErrors.address = 'Street address is required';
    if (!newAddress.city) newErrors.city = 'City is required';
    if (!newAddress.state) newErrors.state = 'State is required';
    if (!newAddress.pincode) newErrors.pincode = 'ZIP code is required';
    if (!newAddress.country) newErrors.country = 'Country is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;

    setNewAddress((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const saveNewAddress = async () => {
    if (!validateNewAddress()) {
      return;
    }

    setLoadingSaveAddress(true);

    try {
      // Prepare address data for API
      const addressData = {
        name: newAddress.name,
        mobile: newAddress.mobile.toString(), // Convert to string to avoid number issues
        alternate_mobile: newAddress.alternate_mobile ? newAddress.alternate_mobile.toString() : '',
        address: newAddress.address,
        landmark: newAddress.landmark || '',
        area: newAddress.area || '',
        city: newAddress.city,
        state: newAddress.state,
        country: newAddress.country,
        pincode: newAddress.pincode,
        type: newAddress.type,
        is_default: newAddress.is_default ? 1 : 0,
        latitude: newAddress.latitude || '0',
        longitude: newAddress.longitude || '0',
      };

      let result;
      if (newAddress.id) {
        // Update existing address
        const response = await api.updateAddress(
          user?.jwtToken,
          newAddress.id,
          addressData.name,
          addressData.mobile,
          addressData.type,
          addressData.address,
          addressData.landmark,
          addressData.area,
          addressData.pincode,
          addressData.city,
          addressData.state,
          addressData.country,
          addressData.alternate_mobile,
          addressData.latitude,
          addressData.longitude,
          addressData.is_default
        );
        result = await response.json();
      } else {
        // Create new address
        const response = await api.addAddress(
          user?.jwtToken,
          addressData.name,
          addressData.mobile,
          addressData.type,
          addressData.address,
          addressData.landmark,
          addressData.area,
          addressData.pincode,
          addressData.city,
          addressData.state,
          addressData.country,
          addressData.alternate_mobile,
          addressData.latitude,
          addressData.longitude,
          addressData.is_default
        );
        result = await response.json();
      }

      if (result.status !== 1) {
        toast.error(result.message || 'Failed to save address');
        return;
      }

      // Update local state with the new/updated address
      let updatedAddresses;
      if (newAddress.id) {
        // For update, replace the existing address
        updatedAddresses = addresses.map((addr) => (addr.id === newAddress.id ? result.data : addr));
      } else {
        // For create, add the new address
        updatedAddresses = [...addresses, result.data];
      }

      // If this address is set as default, remove default from others
      if (newAddress.is_default) {
        updatedAddresses = updatedAddresses.map((addr) => {
          if (addr.id !== result.data.id && addr.is_default === 1) {
            return { ...addr, is_default: 0 };
          }
          return addr;
        });
      }

      setAddresses(updatedAddresses);
      dispatch(setAddress({ data: updatedAddresses }));
      setShowAddressForm(false);

      // Reset form
      resetForm();

      toast.success(`Address ${newAddress.id ? 'updated' : 'saved'} successfully!`);
    } catch (error) {
      console.error('Error saving address:', error);
      toast.error(`Failed to ${newAddress.id ? 'update' : 'save'} address`);
    } finally {
      setLoadingSaveAddress(false);
    }
  };

  const handleEditAddress = (address) => {
    setNewAddress({
      id: address.id,
      name: address.name,
      mobile: address.mobile,
      alternate_mobile: address.alternate_mobile || '',
      address: address.address,
      landmark: address.landmark || '',
      area: address.area || '',
      city: address.city,
      state: address.state,
      pincode: address.pincode,
      country: address.country,
      type: address.type || 'Home',
      is_default: address.is_default === 1,
      latitude: address.latitude || (city.city ? city.city.latitude : 0),
      longitude: address.longitude || (city.city ? city.city.longitude : 0),
    });

    setMapPosition({
      lat: parseFloat(address.latitude || (city.city ? city.city.latitude : 0)),
      lng: parseFloat(address.longitude || (city.city ? city.city.longitude : 0)),
    });

    setShowAddressForm(true);
  };

  const handleDeleteAddress = (addressId) => {
    setAddressToDelete(addressId);
    setIsConfirmDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!addressToDelete) return;

    setIsDeleting(true);

    try {
      const response = await api.deleteAddress(user?.jwtToken, addressToDelete);
      const result = await response.json();

      if (result.status === 1) {
        const updatedAddresses = addresses.filter((addr) => addr.id !== addressToDelete);
        setAddresses(updatedAddresses);
        dispatch(setAddress({ data: updatedAddresses }));

        toast.success('Address deleted successfully');
      } else {
        toast.error(result.message || 'Failed to delete address');
      }
    } catch (error) {
      console.error('Error deleting address:', error);
      toast.error('Failed to delete address');
    } finally {
      setIsDeleting(false);
      setAddressToDelete(null);
      setIsConfirmDialogOpen(false);
    }
  };

  const handleAddressTypeChange = (type) => {
    setNewAddress((prev) => ({ ...prev, type }));
  };

  const mapContainerStyle = {
    width: '100%',
    height: '100%',
  };

  const MapComponent = React.memo(() => {
    if (!mapLoaded) {
      return (
        <div className="flex flex-col justify-center items-center h-full">
          <svg
            className="animate-spin h-8 w-8 text-pink-500"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            ></path>
          </svg>
          <p className="mt-2 text-gray-600">Loading map...</p>
        </div>
      );
    }

    return (
      <div className="h-full relative">
        <button
          onClick={handleCurrentLocation}
          className="absolute top-4 right-4 z-10 bg-white p-2 rounded-full shadow-md hover:bg-gray-100"
          disabled={locationPermission === 'denied' || isGeocoding}
        >
          <BiCurrentLocation size={20} />
        </button>
        {isGeocoding && (
          <div className="absolute top-4 left-4 z-10 bg-white p-2 rounded shadow-md text-gray-600">
            Updating location...
          </div>
        )}
        <GoogleMap
          zoom={15}
          center={mapPosition}
          mapContainerStyle={mapContainerStyle}
          options={{
            disableDefaultUI: true,
            zoomControl: true,
            fullscreenControl: true,
          }}
          onClick={(e) => {
            if (!isGeocoding) {
              const lat = e.latLng.lat();
              const lng = e.latLng.lng();
              setMapPosition({ lat, lng });
              setNewAddress((prev) => ({
                ...prev,
                latitude: lat.toString(),
                longitude: lng.toString(),
              }));
            }
          }}
        >
          <MarkerF position={mapPosition} draggable={true} onDragEnd={onMarkerDragEnd} />
        </GoogleMap>
      </div>
    );
  });

  const resetForm = () => {
    setNewAddress({
      id: null,
      name: '',
      mobile: '',
      alternate_mobile: '',
      address: '',
      landmark: '',
      area: '',
      city: '',
      state: '',
      country: '',
      pincode: '',
      type: 'Home',
      is_default: false,
      latitude: city.city ? city.city.latitude : 0,
      longitude: city.city ? city.city.longitude : 0,
    });
    setErrors({});
    setMapPosition({
      lat: parseFloat(city.city ? city.city.latitude : 0),
      lng: parseFloat(city.city ? city.city.longitude : 0),
    });
    setShowAddressForm(false);
  };

  if (mapsError) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8 text-center">
        <div className="text-red-500 mb-4">{mapsError}</div>
        <button
          onClick={() => window.location.reload()}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Retry
        </button>
      </div>
    );
  }

  useEffect(() => {
    return () => {
      if (typingTimeout) {
        clearTimeout(typingTimeout);
      }
    };
  }, [typingTimeout]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-800">My Addresses</h1>
        <button
          onClick={() => setShowAddressForm(true)}
          className="flex items-center bg-pink-500 hover:bg-pink-600 text-white px-4 py-2 rounded-lg font-medium shadow-md transition-all duration-300"
          disabled={!mapLoaded}
        >
          <FiPlus className="mr-2" />
          Add New Address
        </button>
      </div>

      <ConfirmationDialog
        isOpen={isConfirmDialogOpen}
        message="Do you really want to delete this address?"
        onClose={() => setIsConfirmDialogOpen(false)}
        onConfirm={handleConfirmDelete}
      />

      {addresses.length === 0 && !showAddressForm && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-16 w-16 mx-auto text-gray-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
            />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          <h3 className="text-lg font-medium text-gray-700 mt-4">No Saved Addresses</h3>
          <p className="text-gray-500 mt-2">You haven't saved any addresses yet.</p>
          <button
            onClick={() => setShowAddressForm(true)}
            className="mt-4 bg-pink-500 hover:bg-pink-600 text-white px-6 py-2 rounded-lg font-medium shadow-md transition-all duration-300"
            disabled={!mapLoaded}
          >
            Add Your First Address
          </button>
        </div>
      )}

      {addresses.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {addresses.map((address, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all duration-300"
            >
              <div className="p-5">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center">
                    <h4 className="font-semibold text-gray-800">{address.name}</h4>
                    {address.is_default && (
                      <span className="ml-2 text-xs px-2 py-1 rounded-full bg-green-100 text-green-700 font-medium">
                        Default
                      </span>
                    )}
                  </div>
                  <div className="flex items-center">
                    <span className="text-xs px-3 py-1 rounded-full bg-pink-100 text-pink-700 font-medium mr-2">
                      {address.type}
                    </span>
                    <button
                      onClick={() => handleEditAddress(address)}
                      className="text-blue-500 hover:text-blue-700 p-1 mr-2"
                    >
                      <FiEdit size={18} />
                    </button>
                    <button
                      onClick={() => handleDeleteAddress(address.id)}
                      className="text-red-500 hover:text-red-700 p-1"
                      disabled={isDeleting && addressToDelete === address.id}
                    >
                      {isDeleting && addressToDelete === address.id ? (
                        <svg
                          className="animate-spin h-5 w-5 text-red-500"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                        >
                          <circle
                            className="opacity-25"
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="4"
                          ></circle>
                          <path
                            className="opacity-75"
                            fill="currentColor"
                            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                          ></path>
                        </svg>
                      ) : (
                        <RiDeleteBinLine size={18} />
                      )}
                    </button>
                  </div>
                </div>

                <div className="space-y-1 text-gray-600">
                  <p className="text-sm">{address.address}</p>
                  {address.landmark && <p className="text-sm">Near: {address.landmark}</p>}
                  <p className="text-sm">
                    {address.city}, {address.state} {address.pincode}
                  </p>
                  <p className="text-sm">{address.country}</p>
                  <div className="pt-2 mt-2 border-t border-gray-100 flex items-center text-sm">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 mr-1 text-gray-500"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                      />
                    </svg>
                    {address.mobile}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal Overlay for Address Form */}
      {showAddressForm && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            {/* Background overlay */}
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75" onClick={resetForm}></div>
            </div>

            {/* Modal content */}
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-6xl sm:w-full">
              <div className="bg-white p-8">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-gray-800 flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6 mr-2 text-pink-500"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                      />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    {newAddress.id ? 'Edit Address' : 'Add New Address'}
                  </h3>
                  <button onClick={resetForm} className="text-gray-500 hover:text-gray-700">
                    <FiX size={24} />
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="h-[500px] rounded-lg overflow-hidden border border-gray-200">
                    <MapComponent />
                  </div>

                  <div className="space-y-5">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Full Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={newAddress.name}
                        onChange={handleInputChange}
                        placeholder="Enter your full name"
                        className={`block w-full px-4 py-3 rounded-lg border ${errors.name ? 'border-red-500 bg-red-50' : 'border-gray-300 focus:border-pink-500 focus:ring focus:ring-pink-200'
                          }`}
                        required
                      />
                      {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name}</p>}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Mobile Number <span className="text-red-500">*</span>
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-5 w-5 text-gray-400"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                              />
                            </svg>
                          </div>
                          <input
                            type="text"
                            name="mobile"
                            value={newAddress.mobile}
                            onChange={handleInputChange}
                            placeholder="Enter your mobile number"
                            className={`block w-full pl-10 pr-4 py-3 rounded-lg border ${errors.mobile ? 'border-red-500 bg-red-50' : 'border-gray-300 focus:border-pink-500 focus:ring focus:ring-pink-200'
                              }`}
                            required
                          />
                        </div>
                        {errors.mobile && <p className="mt-1 text-sm text-red-600">{errors.mobile}</p>}
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Alternate Mobile (Optional)</label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-5 w-5 text-gray-400"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                              />
                            </svg>
                          </div>
                          <input
                            type="text"
                            name="alternate_mobile"
                            value={newAddress.alternate_mobile}
                            onChange={handleInputChange}
                            placeholder="Enter alternate number (optional)"
                            className="block w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:border-pink-500 focus:ring focus:ring-pink-200"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Street Address <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 text-gray-400"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                            />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                          </svg>
                        </div>
                        <input
                          ref={autocompleteRef}
                          type="text"
                          name="address"
                          value={newAddress.address}
                          onChange={handleStreetChange}  // This is the special handler for street address
                          placeholder="Enter your street address"
                          className={`block w-full pl-10 pr-4 py-3 rounded-lg border ${errors.address ? 'border-red-500 bg-red-50' : 'border-gray-300 focus:border-pink-500 focus:ring focus:ring-pink-200'
                            }`}
                          required
                          disabled={!mapLoaded}
                        />
                      </div>
                      {errors.address && <p className="mt-1 text-sm text-red-600">{errors.address}</p>}
                      {newAddress.latitude && newAddress.longitude && (
                        <p className="text-xs text-gray-500 mt-1">
                          Coordinates: {parseFloat(newAddress.latitude).toFixed(6)}, {parseFloat(newAddress.longitude).toFixed(6)}
                        </p>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Landmark <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          name="landmark"
                          value={newAddress.landmark}
                          onChange={handleInputChange}
                          placeholder="Enter a nearby landmark"
                          className="block w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-pink-500 focus:ring focus:ring-pink-200"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Area <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          name="area"
                          value={newAddress.area}
                          onChange={handleInputChange}
                          placeholder="Enter your area/locality"
                          className="block w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-pink-500 focus:ring focus:ring-pink-200"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          City <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          name="city"
                          value={newAddress.city}
                          onChange={handleInputChange}
                          placeholder="Enter your city"
                          className={`block w-full px-4 py-3 rounded-lg border ${errors.city ? 'border-red-500 bg-red-50' : 'border-gray-300 focus:border-pink-500 focus:ring focus:ring-pink-200'
                            }`}
                          required
                        />
                        {errors.city && <p className="mt-1 text-sm text-red-600">{errors.city}</p>}
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          State <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          name="state"
                          value={newAddress.state}
                          onChange={handleInputChange}
                          placeholder="Enter your state"
                          className={`block w-full px-4 py-3 rounded-lg border ${errors.state ? 'border-red-500 bg-red-50' : 'border-gray-300 focus:border-pink-500 focus:ring focus:ring-pink-200'
                            }`}
                          required
                        />
                        {errors.state && <p className="mt-1 text-sm text-red-600">{errors.state}</p>}
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          ZIP Code <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="number"
                          name="pincode"
                          value={newAddress.pincode}
                          onChange={handleInputChange}
                          placeholder="Enter ZIP code"
                          className={`block w-full px-4 py-3 rounded-lg border ${errors.pincode ? 'border-red-500 bg-red-50' : 'border-gray-300 focus:border-pink-500 focus:ring focus:ring-pink-200'
                            }`}
                          required
                        />
                        {errors.pincode && <p className="mt-1 text-sm text-red-600">{errors.pincode}</p>}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Country <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        name="country"
                        value={newAddress.country}
                        onChange={handleInputChange}
                        placeholder="Enter your country"
                        className={`block w-full px-4 py-3 rounded-lg border ${errors.country ? 'border-red-500 bg-red-50' : 'border-gray-300 focus:border-pink-500 focus:ring focus:ring-pink-200'
                          }`}
                        required
                      />
                      {errors.country && <p className="mt-1 text-sm text-red-600">{errors.country}</p>}
                    </div>

                    <div className="pt-4">
                      <label className="block text-sm font-medium text-gray-700 mb-3">
                        Address Type <span className="text-red-500">*</span>
                      </label>
                      <div className="flex flex-wrap gap-3">
                        {['Home', 'Office', 'Other'].map((type) => (
                          <button
                            key={type}
                            type="button"
                            onClick={() => handleAddressTypeChange(type)}
                            className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-200 ${newAddress.type === type
                              ? 'bg-pink-500 text-white shadow-md'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                              }`}
                          >
                            {type}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 border-t border-gray-100">
                      <div className="flex items-center justify-between">
                        <label htmlFor="isDefault" className="flex items-center cursor-pointer">
                          <span className="text-sm font-medium text-gray-700 mr-3">Set as default address</span>
                          <div className="relative">
                            <input
                              type="checkbox"
                              id="isDefault"
                              name="is_default"
                              checked={newAddress.is_default}
                              onChange={handleInputChange}
                              className="sr-only"
                            />
                            <div
                              className={`block w-14 h-8 rounded-full transition-colors duration-200 ease-in-out ${newAddress.is_default ? 'bg-pink-500' : 'bg-gray-300'
                                }`}
                            ></div>
                            <div
                              className={`absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform duration-200 ease-in-out ${newAddress.is_default ? 'transform translate-x-6' : ''
                                }`}
                            ></div>
                          </div>
                        </label>
                      </div>
                    </div>

                    <div className="mt-8">
                      <button
                        onClick={saveNewAddress}
                        disabled={loadingSaveAddress || !mapLoaded}
                        className="w-full bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white py-3 px-4 rounded-lg font-medium shadow-md transition-all duration-300 flex items-center justify-center"
                      >
                        {loadingSaveAddress ? (
                          <>
                            <svg
                              className="animate-spin h-5 w-5 mr-2 text-white"
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                            >
                              <circle
                                className="opacity-25"
                                cx="12"
                                cy="12"
                                r="10"
                                stroke="currentColor"
                                strokeWidth="4"
                              ></circle>
                              <path
                                className="opacity-75"
                                fill="currentColor"
                                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                              ></path>
                            </svg>
                            Saving...
                          </>
                        ) : (
                          <>
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-5 w-5 mr-2"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                            Save Address
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MyAddresses;