import { useEffect, useRef, useState } from "react"
import { useSelector } from "react-redux"
import api from "../../../api/api"
import { useNavigate, useParams } from "react-router-dom"
import { toast } from "react-toastify"
import RateProductModal from "../../rate-product/RateProductModal"
import axios from "axios"
import RateProductStar from "../../../utils/stars.svg"
import { 
  Star, 
  Download, 
  Package, 
  MapPin, 
  CreditCard, 
  Calendar, 
  Clock, 
  Home, 
  ArrowLeft, 
  X, 
  Truck, 
  CheckCircle, 
  XCircle, 
  RotateCcw,
  WifiOff,
  AlertCircle
} from "lucide-react"
import UpdateRatingModal from "../../rate-product/UpdateRatingModal"
import { ValidateNoInternet } from "../../../utils/NoInternetValidator"

const OrderDetails = () => {
    const setting = useSelector((state) => state.setting)
    const user = useSelector((state) => state?.user?.user)
    const jwtToken = useSelector((state) => state.user?.jwtToken)
    const urlParams = useParams()

    const [orderData, setOrderData] = useState(null)
    const [orderStatus, setOrderStatus] = useState("Received")
    const [showPdtRatingModal, setShowPdtRatingModal] = useState(false)
    const [ratingProductId, setRatingProductId] = useState(0)
    const [editRatingId, setEditRatingId] = useState(0)
    const [showRatingEditModal, setShowRatingEditModal] = useState(false)
    const [isNetworkError, setIsNetworkError] = useState(false)
    const [showReturnModal, setShowReturnModal] = useState([])
    const [showCancelModal, setShowCancelModal] = useState([])
    const [isLoading, setIsLoading] = useState(true)

    const returnRef = useRef(null)
    const cancelRef = useRef(null)
    const navigate = useNavigate()

    useEffect(() => {
        setShowReturnModal(Array(orderData?.items?.length || 0).fill(false))
        setShowCancelModal(Array(orderData?.items?.length || 0).fill(false))

        const statusMap = {
            "6": "Delivered",
            "5": "Out for Delivery",
            "4": "Shipped",
            "3": "Processed",
            "7": "Cancelled",
            "8": "Returned",
        }

        if (orderData?.active_status) {
            setOrderStatus(statusMap[orderData.active_status] || "Received")
        }
    }, [orderData])

    const fetchOrderDetails = async () => {
        try {
            setIsLoading(true)
            const response = await api.getOrders(jwtToken, null, null, null, urlParams?.id)
            const result = await response.json()

            if (result.status) {
                setOrderData(result.data[0])
            } else {
                toast.error(result.message)
            }
        } catch (err) {
            if (ValidateNoInternet(err)) {
                setIsNetworkError(true)
            }
        } finally {
            setIsLoading(false)
        }
    }

    useEffect(() => {
        fetchOrderDetails()
    }, [urlParams?.id, editRatingId, showPdtRatingModal])

    const getInvoice = async (Oid) => {
        try {
            const postData = new FormData()
            postData.append("order_id", Oid)

            const response = await axios({
                url: `${import.meta.env.VITE_APP_API_URL}${import.meta.env.VITE_APP_API_SUBURL}/invoice_download`,
                method: "post",
                responseType: "blob",
                data: postData,
                headers: { Authorization: `Bearer ${jwtToken}` },
            })

            const fileURL = window.URL.createObjectURL(new Blob([response.data]))
            const fileLink = document.createElement("a")
            fileLink.href = fileURL
            fileLink.setAttribute("download", `Invoice-No:${Oid}.pdf`)
            document.body.appendChild(fileLink)
            fileLink.click()
        } catch (error) {
            toast.error(error?.request?.statusText || error.message || "Something went wrong!")
        }
    }

    const handleUpdateStatus = async (item_id, status, reason) => {
        try {
            const response = await api.updateOrderStatus(jwtToken, orderData?.id, item_id, status, reason)
            const result = await response.json()

            if (result.status) {
                fetchOrderDetails()
                toast.success(result.message)
            } else {
                toast.error(result.message || "Something went wrong!")
            }
        } catch (error) {
            console.error(error)
            toast.error("Failed to update order status")
        } finally {
            setShowCancelModal(Array(orderData?.items?.length || 0).fill(false))
            setShowReturnModal(Array(orderData?.items?.length || 0).fill(false))
        }
    }

    const convertToAMPM = (transactionDate) => {
        const dateTimeObj = new Date(transactionDate)
        const options = { hour: "numeric", minute: "numeric", second: "numeric", hour12: true }
        return dateTimeObj.toLocaleString("en-US", options)
    }

    const getStatusColor = (status) => {
        const colors = {
            "1": "bg-amber-50 text-amber-700 border-amber-200",
            "2": "bg-blue-50 text-blue-700 border-blue-200",
            "3": "bg-purple-50 text-purple-700 border-purple-200",
            "4": "bg-indigo-50 text-indigo-700 border-indigo-200",
            "5": "bg-orange-50 text-orange-700 border-orange-200",
            "6": "bg-emerald-50 text-emerald-700 border-emerald-200",
            "7": "bg-red-50 text-red-700 border-red-200",
            "8": "bg-gray-50 text-gray-700 border-gray-200",
        }
        return colors[status] || "bg-gray-50 text-gray-700 border-gray-200"
    }

    const getStatusIcon = (status) => {
        const icons = {
            "6": <CheckCircle className="w-5 h-5" />,
            "5": <Truck className="w-5 h-5" />,
            "4": <Package className="w-5 h-5" />,
            "7": <XCircle className="w-5 h-5" />,
            "8": <RotateCcw className="w-5 h-5" />,
        }
        return icons[status] || <Package className="w-5 h-5" />
    }

    if (isNetworkError) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex flex-col justify-center items-center p-4">
                <div className="text-center bg-white rounded-2xl shadow-lg p-8 max-w-md w-full">
                    <div className="bg-red-50 rounded-full p-4 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                        <WifiOff className="w-10 h-10 text-red-500" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-3">No Internet Connection</h3>
                    <p className="text-gray-600 leading-relaxed">You are not connected to the internet. Please check your connection and try again.</p>
                    <button 
                        onClick={() => window.location.reload()}
                        className="mt-6 px-6 py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 transition-all duration-200 transform hover:scale-105"
                    >
                        Try Again
                    </button>
                </div>
            </div>
        )
    }

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
                <div className="text-center">
                    <div className="relative">
                        <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-200 border-t-blue-600 mx-auto"></div>
                        <div className="absolute inset-0 rounded-full h-16 w-16 border-4 border-transparent border-t-blue-400 animate-ping"></div>
                    </div>
                    <p className="mt-4 text-gray-600 font-medium">Loading order details...</p>
                </div>
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
            {/* Enhanced Header */}
            <div className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40 backdrop-blur-sm bg-white/95">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-16">
                        <div className="flex items-center space-x-4">
                            <button
                                onClick={() => navigate(-1)}
                                className="p-2.5 hover:bg-gray-100 rounded-xl transition-all duration-200 group"
                            >
                                <ArrowLeft className="w-5 h-5 text-gray-600 group-hover:text-gray-900" />
                            </button>
                            <div>
                                <h1 className="text-xl font-bold text-gray-900">Order Details</h1>
                                <div className="flex items-center space-x-2 text-sm text-gray-500">
                                    <button 
                                        onClick={() => navigate("/")} 
                                        className="hover:text-blue-600 transition-colors duration-200 flex items-center"
                                    >
                                        <Home className="w-4 h-4" />
                                    </button>
                                    <span className="text-gray-300">/</span>
                                    <button 
                                        onClick={() => navigate("/my-orders")} 
                                        className="hover:text-blue-600 transition-colors duration-200"
                                    >
                                        Orders
                                    </button>
                                    <span className="text-gray-300">/</span>
                                    <span className="font-medium text-gray-700">#{orderData?.id}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Main Content */}
                    <div className="lg:col-span-2">
                        {/* Enhanced Order Items */}
                        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                            <div className="px-6 py-5 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50">
                                <div className="flex items-center space-x-3">
                                    <div className="bg-white p-3 rounded-xl shadow-sm">
                                        <Package className="w-6 h-6 text-blue-600" />
                                    </div>
                                    <div>
                                        <h2 className="text-xl font-bold text-gray-900">Order Items</h2>
                                        <p className="text-sm text-gray-600">
                                            {orderData?.items?.length} {orderData?.items?.length === 1 ? 'item' : 'items'} in this order
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div className="divide-y divide-gray-100">
                                {orderData?.items?.map((item, index) => (
                                    <div
                                        key={item?.id}
                                        className={`p-6 transition-all duration-200 ${
                                            Number(item?.active_status) > 6 ? "opacity-60 bg-gray-50" : "hover:bg-gray-50"
                                        }`}
                                    >
                                        <div className="flex flex-col lg:flex-row lg:items-start space-y-4 lg:space-y-0 lg:space-x-6">
                                            {/* Enhanced Product Info */}
                                            <div className="flex items-start space-x-4 flex-1">
                                                <div className="relative group">
                                                    <img
                                                        src={item.image_url || "/placeholder.svg?height=80&width=80"}
                                                        alt={item.name}
                                                        className="w-20 h-20 object-cover rounded-xl border border-gray-200 group-hover:shadow-lg transition-all duration-200"
                                                    />
                                                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 rounded-xl transition-all duration-200"></div>
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <h3 className="font-semibold text-gray-900 mb-2 leading-tight">{item.name}</h3>
                                                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                                                        <span className="bg-gray-100 px-3 py-1 rounded-full">
                                                            Qty: {item.quantity}
                                                        </span>
                                                        <span className="bg-gray-100 px-3 py-1 rounded-full">
                                                            {item.measurement} {item.unit}
                                                        </span>
                                                    </div>
                                                    <div className="flex items-center space-x-2">
                                                        <span className="text-2xl font-bold text-gray-900">
                                                            {setting.setting?.currency}{item.price}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>

                                            {/* Enhanced Actions */}
                                            <div className="flex flex-col space-y-3 lg:items-end lg:min-w-[200px]">
                                                {/* Enhanced Rating Section */}
                                                {Number(item?.active_status) === 6 && (
                                                    <div className="mb-2">
                                                        {item.item_rating?.find((rating) => rating.user.id === user.id) ? (
                                                            <button
                                                                onClick={() => {
                                                                    setRatingProductId(item.product_id)
                                                                    setShowRatingEditModal(true)
                                                                    setEditRatingId(item.item_rating.find((rating) => rating.user.id === user.id)?.id)
                                                                }}
                                                                className="flex items-center space-x-2 text-sm text-amber-600 hover:text-amber-700 bg-amber-50 px-3 py-2 rounded-lg transition-all duration-200 hover:bg-amber-100"
                                                            >
                                                                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                                                                <span>
                                                                    Rated {item?.item_rating?.find((rating) => rating?.user?.id === user?.id)?.rate}/5
                                                                </span>
                                                            </button>
                                                        ) : (
                                                            <button
                                                                onClick={() => {
                                                                    setRatingProductId(item.product_id)
                                                                    setShowPdtRatingModal(true)
                                                                }}
                                                                className="flex items-center space-x-2 text-sm text-blue-600 hover:text-blue-700 bg-blue-50 px-3 py-2 rounded-lg transition-all duration-200 hover:bg-blue-100"
                                                            >
                                                                <Star className="w-4 h-4" />
                                                                <span>Rate & Review</span>
                                                            </button>
                                                        )}
                                                    </div>
                                                )}

                                                {/* Enhanced Action Buttons */}
                                                <div className="flex flex-wrap gap-2">
                                                    {/* Return Button */}
                                                    {Number(item?.active_status) === 6 &&
                                                        item?.return_status === 1 &&
                                                        item?.return_requested === null && (
                                                            <button
                                                                onClick={() =>
                                                                    setShowReturnModal((prev) => {
                                                                        const newState = [...prev]
                                                                        newState[index] = true
                                                                        return newState
                                                                    })
                                                                }
                                                                className="inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg bg-orange-50 text-orange-700 hover:bg-orange-100 border border-orange-200 transition-all duration-200 hover:shadow-sm"
                                                            >
                                                                <RotateCcw className="w-4 h-4 mr-2" />
                                                                Return Item
                                                            </button>
                                                        )}

                                                    {/* Cancel Button */}
                                                    {Number(item?.active_status) <= 6 &&
                                                        item?.cancelable_status === 1 && (
                                                            <button
                                                                onClick={() =>
                                                                    setShowCancelModal((prev) => {
                                                                        const newState = [...prev]
                                                                        newState[index] = true
                                                                        return newState
                                                                    })
                                                                }
                                                                className="inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg bg-red-50 text-red-700 hover:bg-red-100 border border-red-200 transition-all duration-200 hover:shadow-sm"
                                                            >
                                                                <XCircle className="w-4 h-4 mr-2" />
                                                                Cancel Item
                                                            </button>
                                                        )}

                                                    {/* Status Badges */}
                                                    {Number(item?.active_status) === 7 && (
                                                        <span className="inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg bg-red-50 text-red-700 border border-red-200">
                                                            <XCircle className="w-4 h-4 mr-2" />
                                                            Cancelled
                                                        </span>
                                                    )}

                                                    {Number(item?.active_status) === 8 && (
                                                        <span className="inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg bg-gray-50 text-gray-700 border border-gray-200">
                                                            <RotateCcw className="w-4 h-4 mr-2" />
                                                            Returned
                                                        </span>
                                                    )}

                                                    {Number(item?.return_requested) === 1 && (
                                                        <span className="inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg bg-amber-50 text-amber-700 border border-amber-200">
                                                            <AlertCircle className="w-4 h-4 mr-2" />
                                                            Return Requested
                                                        </span>
                                                    )}

                                                    {Number(item?.return_requested) === 3 && (
                                                        <span className="inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg bg-red-50 text-red-700 border border-red-200">
                                                            <X className="w-4 h-4 mr-2" />
                                                            Return Rejected
                                                        </span>
                                                    )}
                                                </div>
                                            </div>
                                        </div>

                                        {/* Enhanced Modals */}
                                        {showCancelModal[index] && (
                                            <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                                                <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full transform transition-all duration-300 scale-100">
                                                    <div className="flex items-center justify-between p-6 border-b border-gray-100 bg-gradient-to-r from-red-50 to-pink-50">
                                                        <div className="flex items-center space-x-3">
                                                            <div className="bg-red-100 p-2 rounded-xl">
                                                                <XCircle className="w-5 h-5 text-red-600" />
                                                            </div>
                                                            <h3 className="text-lg font-bold text-gray-900">Cancel Order Item</h3>
                                                        </div>
                                                        <button
                                                            onClick={() =>
                                                                setShowCancelModal((prev) => {
                                                                    const newState = [...prev]
                                                                    newState[index] = false
                                                                    return newState
                                                                })
                                                            }
                                                            className="p-2 hover:bg-white rounded-xl transition-colors duration-200"
                                                        >
                                                            <X className="w-5 h-5 text-gray-500" />
                                                        </button>
                                                    </div>
                                                    <form
                                                        onSubmit={(e) => {
                                                            e.preventDefault()
                                                            if (cancelRef.current?.value.trim()) {
                                                                handleUpdateStatus(item?.id, 7, cancelRef.current.value)
                                                            } else {
                                                                toast.error("Please provide a cancel reason")
                                                            }
                                                        }}
                                                        className="p-6"
                                                    >
                                                        <div className="mb-6">
                                                            <label htmlFor="cancelReason" className="block text-sm font-semibold text-gray-700 mb-3">
                                                                Why are you cancelling this item?
                                                            </label>
                                                            <textarea
                                                                ref={cancelRef}
                                                                id="cancelReason"
                                                                rows={4}
                                                                placeholder="Please provide a reason for cancellation..."
                                                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none transition-all duration-200"
                                                                required
                                                            />
                                                        </div>
                                                        <div className="flex justify-end space-x-3">
                                                            <button
                                                                type="button"
                                                                onClick={() =>
                                                                    setShowCancelModal((prev) => {
                                                                        const newState = [...prev]
                                                                        newState[index] = false
                                                                        return newState
                                                                    })
                                                                }
                                                                className="px-6 py-3 text-sm font-medium text-gray-700 bg-gray-100 rounded-xl hover:bg-gray-200 transition-all duration-200"
                                                            >
                                                                Keep Item
                                                            </button>
                                                            <button
                                                                type="submit"
                                                                className="px-6 py-3 text-sm font-medium text-white bg-red-600 rounded-xl hover:bg-red-700 transition-all duration-200 transform hover:scale-105"
                                                            >
                                                                Cancel Item
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        )}

                                        {showReturnModal[index] && (
                                            <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                                                <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full transform transition-all duration-300 scale-100">
                                                    <div className="flex items-center justify-between p-6 border-b border-gray-100 bg-gradient-to-r from-orange-50 to-amber-50">
                                                        <div className="flex items-center space-x-3">
                                                            <div className="bg-orange-100 p-2 rounded-xl">
                                                                <RotateCcw className="w-5 h-5 text-orange-600" />
                                                            </div>
                                                            <h3 className="text-lg font-bold text-gray-900">Return Order Item</h3>
                                                        </div>
                                                        <button
                                                            onClick={() =>
                                                                setShowReturnModal((prev) => {
                                                                    const newState = [...prev]
                                                                    newState[index] = false
                                                                    return newState
                                                                })
                                                            }
                                                            className="p-2 hover:bg-white rounded-xl transition-colors duration-200"
                                                        >
                                                            <X className="w-5 h-5 text-gray-500" />
                                                        </button>
                                                    </div>
                                                    <form
                                                        onSubmit={(e) => {
                                                            e.preventDefault()
                                                            if (returnRef.current?.value.trim()) {
                                                                handleUpdateStatus(item?.id, 8, returnRef.current.value)
                                                            } else {
                                                                toast.error("Please provide a return reason")
                                                            }
                                                        }}
                                                        className="p-6"
                                                    >
                                                        <div className="mb-6">
                                                            <label htmlFor="returnReason" className="block text-sm font-semibold text-gray-700 mb-3">
                                                                Why are you returning this item?
                                                            </label>
                                                            <textarea
                                                                ref={returnRef}
                                                                id="returnReason"
                                                                rows={4}
                                                                placeholder="Please provide a reason for return..."
                                                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none transition-all duration-200"
                                                                required
                                                            />
                                                        </div>
                                                        <div className="flex justify-end space-x-3">
                                                            <button
                                                                type="button"
                                                                onClick={() =>
                                                                    setShowReturnModal((prev) => {
                                                                        const newState = [...prev]
                                                                        newState[index] = false
                                                                        return newState
                                                                    })
                                                                }
                                                                className="px-6 py-3 text-sm font-medium text-gray-700 bg-gray-100 rounded-xl hover:bg-gray-200 transition-all duration-200"
                                                            >
                                                                Keep Item
                                                            </button>
                                                            <button
                                                                type="submit"
                                                                className="px-6 py-3 text-sm font-medium text-white bg-orange-600 rounded-xl hover:bg-orange-700 transition-all duration-200 transform hover:scale-105"
                                                            >
                                                                Request Return
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Enhanced Sidebar */}
                    <div className="space-y-6">
                        {/* Enhanced Order Status */}
                        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                            <div className="px-6 py-5 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50">
                                <div className="flex items-center justify-between">
                                    <h3 className="text-lg font-bold text-gray-900">Order Status</h3>
                                    <div className="bg-white px-3 py-1 rounded-lg shadow-sm">
                                        <span className="text-lg font-bold text-blue-600">#{orderData?.id}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="p-6">
                                <div className={`flex items-center space-x-4 p-4 rounded-xl border-2 ${getStatusColor(orderData?.active_status)} mb-4`}>
                                    {getStatusIcon(orderData?.active_status)}
                                    <div>
                                        <p className="font-bold text-lg">{orderStatus}</p>
                                        <p className="text-sm opacity-75">Your order has been {orderStatus.toLowerCase()} successfully</p>
                                    </div>
                                </div>
                                {orderData?.status?.length > 0 && (
                                    <div className="flex items-center space-x-4 text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                                        <div className="flex items-center space-x-2">
                                            <Calendar className="w-4 h-4" />
                                            <span>{new Date(orderData?.status.reverse()[0].reverse()[0]).toLocaleDateString()}</span>
                                        </div>
                                        <div className="flex items-center space-x-2">
                                            <Clock className="w-4 h-4" />
                                            <span>{convertToAMPM(new Date(orderData?.status.reverse()[0].reverse()[0]))}</span>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Enhanced Order Note */}
                        {orderData?.order_note !== "" && (
                            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                                <div className="px-6 py-5 border-b border-gray-100 bg-gradient-to-r from-green-50 to-emerald-50">
                                    <h3 className="text-lg font-bold text-gray-900">Order Note</h3>
                                </div>
                                <div className="p-6">
                                    <p className="text-gray-700 leading-relaxed whitespace-pre-line bg-gray-50 p-4 rounded-lg">
                                        {orderData?.order_note}
                                    </p>
                                </div>
                            </div>
                        )}

                        {/* Enhanced Delivery Information */}
                        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                            <div className="px-6 py-5 border-b border-gray-100 bg-gradient-to-r from-green-50 to-emerald-50">
                                <div className="flex items-center space-x-3">
                                    <div className="bg-white p-3 rounded-xl shadow-sm">
                                        <MapPin className="w-6 h-6 text-green-600" />
                                    </div>
                                    <h3 className="text-lg font-bold text-gray-900">Delivery Information</h3>
                                </div>
                            </div>
                            <div className="p-6">
                                <div className="space-y-4">
                                    <div className="bg-gray-50 p-4 rounded-xl">
                                        <p className="text-sm font-semibold text-gray-700 mb-2">Delivery Address</p>
                                        <p className="text-gray-900 leading-relaxed">{orderData?.order_address}</p>
                                    </div>
                                    <div className="flex items-center justify-between text-sm">
                                        <span className="text-gray-600">Country:</span>
                                        <span className="font-medium text-gray-900">{orderData?.country}</span>
                                    </div>
                                    <div className="flex items-center justify-between text-sm">
                                        <span className="text-gray-600">Mobile:</span>
                                        <span className="font-medium text-gray-900">{orderData?.mobile}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Enhanced Billing Details */}
                        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                            <div className="px-6 py-5 border-b border-gray-100 bg-gradient-to-r from-purple-50 to-pink-50">
                                <div className="flex items-center space-x-3">
                                    <div className="bg-white p-3 rounded-xl shadow-sm">
                                        <CreditCard className="w-6 h-6 text-purple-600" />
                                    </div>
                                    <h3 className="text-lg font-bold text-gray-900">Billing Details</h3>
                                </div>
                            </div>
                            <div className="p-6">
                                <div className="space-y-4">
                                    <div className="flex justify-between items-center py-2">
                                        <span className="text-gray-600">Payment Method</span>
                                        <span className="font-semibold text-gray-900 bg-gray-50 px-3 py-1 rounded-lg">
                                            {orderData?.payment_method}
                                        </span>
                                    </div>
                                    <div className="flex justify-between items-center py-2">
                                        <span className="text-gray-600">Transaction ID</span>
                                        <span className="font-mono text-sm text-gray-900 bg-gray-50 px-3 py-1 rounded-lg">
                                            {orderData?.transaction_id}
                                        </span>
                                    </div>
                                    <div className="flex justify-between items-center py-2">
                                        <span className="text-gray-600">Delivery Charge</span>
                                        <span className="font-semibold text-gray-900">
                                            {setting.setting?.currency}{orderData?.delivery_charge}
                                        </span>
                                    </div>
                                    <div className="flex justify-between items-center py-2">
                                        <span className="text-gray-600">Sub Total</span>
                                        <span className="font-semibold text-gray-900">
                                            {setting.setting?.currency}{orderData?.total}
                                        </span>
                                    </div>
                                    {orderData?.promo_discount && (
                                        <div className="flex justify-between items-center py-2">
                                            <span className="text-gray-600">Promo Discount</span>
                                            <span className="font-semibold text-emerald-600">
                                                - {setting.setting?.currency}{orderData?.promo_discount}
                                            </span>
                                        </div>
                                    )}
                                    {orderData?.wallet_balance && (
                                        <div className="flex justify-between items-center py-2">
                                            <span className="text-gray-600">Wallet Balance Used</span>
                                            <span className="font-semibold text-emerald-600">
                                                - {setting.setting?.currency}{orderData?.wallet_balance}
                                            </span>
                                        </div>
                                    )}
                                    {orderData?.discount && (
                                        <div className="flex justify-between items-center py-2">
                                            <span className="text-gray-600">Discount</span>
                                            <span className="font-semibold text-emerald-600">
                                                - {setting.setting?.currency}{orderData?.discount}
                                            </span>
                                        </div>
                                    )}
                                    <div className="border-t border-gray-200 pt-4 mt-4">
                                        <div className="flex justify-between items-center py-2 bg-gradient-to-r from-blue-50 to-indigo-50 px-4 rounded-xl">
                                            <span className="text-xl font-bold text-gray-900">Total</span>
                                            <span className="text-2xl font-bold text-blue-600">
                                                {setting?.setting?.currency}{orderData?.final_total}
                                            </span>
                                        </div>
                                    </div>
                                    {orderData?.active_status === "6" && (
                                        <button
                                            onClick={() => getInvoice(orderData?.id)}
                                            className="w-full mt-6 flex items-center justify-center px-6 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
                                        >
                                            <Download className="w-5 h-5 mr-2" />
                                            Download Invoice
                                        </button>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <RateProductModal
                product_id={ratingProductId}
                showPdtRatingModal={showPdtRatingModal}
                setShowPdtRatingModal={setShowPdtRatingModal}
            />
            <UpdateRatingModal
                product_id={ratingProductId}
                showModal={showRatingEditModal}
                setShowModal={setShowRatingEditModal}
                ratingId={editRatingId}
                setRatingId={setEditRatingId}
            />
        </div>
    )
}

export default OrderDetails