import React from 'react'
import { Modal } from 'react-bootstrap'
import { useTranslation } from 'react-i18next'
import { useSelector } from 'react-redux'
import { formatDate, formatTime } from '../../../utils/formatDate'
import ReceivedSVG from "../../../utils/Icons/statusIcons/status_icon_received.svg";
import PendingPaymentSVG from "../../../utils/Icons/statusIcons/status_icon_awaiting_payment.svg";
import ProcessedSVG from "../../../utils/Icons/statusIcons/status_icon_process.svg";
import ShippedSVG from "../../../utils/Icons/statusIcons/status_icon_shipped.svg";
import OutforDeliverySVG from "../../../utils/Icons/statusIcons/status_icon_out_for_delivery.svg";
import DeliveredSVG from "../../../utils/Icons/statusIcons/status_icon_delivered.svg";
import CancelledSVG from "../../../utils/Icons/statusIcons/status_icon_cancel.svg";
import ReturnedSVG from "../../../utils/Icons/statusIcons/status_icon_returned.svg";
import { ProgressBar } from 'react-bootstrap';

const OrderTracker = ({ show, setShow, order }) => {
    const { t } = useTranslation();
    const setting = useSelector(state => state.setting);

    const getImageofOrderStatus = (status) => {
        const statusIcons = {
            1: PendingPaymentSVG,
            2: ReceivedSVG,
            3: ProcessedSVG,
            4: ShippedSVG,
            5: OutforDeliverySVG,
            6: DeliveredSVG,
            7: CancelledSVG,
            8: ReturnedSVG
        };
        return <img src={statusIcons[status]} className='p-3' alt={`status-${status}`} />;
    };

    const getStatusText = (status) => {
        const statusTexts = {
            1: t("paymentPending"),
            2: t("received"),
            3: t("processed"),
            4: t("shipped"),
            5: t("outForDelivery"),
            6: t("delivered"),
            7: t("cancelled"),
            8: t("returned")
        };
        return statusTexts[status] || '';
    };

    return (
        <Modal show={show} fullscreen onHide={() => setShow(false)} className='order-tracker' centered>
            <Modal.Header closeButton>
                <Modal.Title>{t("order_tracker")} - #{order?.order_id}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div className="tracker-container">
                    <div className="d-flex flex-column align-items-center">
                        {order?.status?.map((flag, index) => (
                            <div key={index} className="d-flex gap-5 align-items-center orderStatusContainer">
                                <div className="my-4 track-order-icon">
                                    {getImageofOrderStatus(Number(flag[0]))}
                                </div>
                                {(index < (order?.status?.length - 1)) && <ProgressBar className='orderProgressBar' now={100} />}
                                <span className='orderStatusText'>
                                    {t("your_order_has_been")} {getStatusText(Number(flag[0]))} {t("on")} {formatDate(flag[1])} {formatTime(flag[1])}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>
            </Modal.Body>
        </Modal>
    )
}

export default OrderTracker