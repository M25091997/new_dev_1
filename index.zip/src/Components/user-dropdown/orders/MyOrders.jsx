import { useEffect, useRef, useState } from "react"
import api from "../../../api/api"
import { FaRupeeSign, FaDownload, FaEye } from "react-icons/fa"
import { MdSignalWifiConnectedNoInternet0, MdLocalShipping, MdCheckCircle } from "react-icons/md"
import { BsClockHistory, BsBoxSeam } from "react-icons/bs"
import { IoMdClose } from "react-icons/io"
import {
    Package,
    Download,
    Eye,
    Truck,
    Calendar,
    Clock,
    CheckCircle,
    XCircle,
    RotateCcw,
    WifiOff,
    ShoppingBag,
    ArrowRight,
    ArrowLeft,
    Filter,
    Search
} from "lucide-react"
import Loader from "../../../Components/Loader/Loader"
import { toast } from "react-toastify"
import axios from "axios"
import { useSelector } from "react-redux"
import { useNavigate } from "react-router-dom"
import OrderTracker from "./OrderTracker"
import { formatDate, formatTime } from "../../../utils/formatDate"
import ReceivedSVG from "../../../utils/Icons/statusIcons/status_icon_received.svg"
import PendingPaymentSVG from "../../../utils/Icons/statusIcons/status_icon_awaiting_payment.svg"
import ProcessedSVG from "../../../utils/Icons/statusIcons/status_icon_process.svg"
import ShippedSVG from "../../../utils/Icons/statusIcons/status_icon_shipped.svg"
import OutforDeliverySVG from "../../../utils/Icons/statusIcons/status_icon_out_for_delivery.svg"
import DeliveredSVG from "../../../utils/Icons/statusIcons/status_icon_delivered.svg"
import CancelledSVG from "../../../utils/Icons/statusIcons/status_icon_cancel.svg"
import ReturnedSVG from "../../../utils/Icons/statusIcons/status_icon_returned.svg"
import { ValidateNoInternet } from "../../../utils/NoInternetValidator"
import LiveTrackingModal from "../../../Components/live-tracking-modal/LiveTrackingModal"

const MyOrders = () => {
    const [NoOrders, setNoOrders] = useState(false)
    const [totalActiveOrders, setTotalActiveOrders] = useState(null)
    const [totalPrevOrders, setTotalPrevOrders] = useState(null)
    const [ActiveOrders, setActiveOrders] = useState([])
    const [PrevOrders, setPrevOrders] = useState([])
    const [offset, setoffset] = useState(0)
    const [currPage, setcurrPage] = useState(1)
    const [isLoader, setisLoader] = useState(false)
    const [showTracker, setShowTracker] = useState(false)
    const [showLiveLocationModal, setShowLiveLocationModal] = useState(false)
    const [element, setElement] = useState({})
    const [selectedOrder, setSelectedOrder] = useState(null)
    const [activeTab, setActiveTab] = useState("active")
    const [showTrackModal, setShowTrackModal] = useState(false)

    const componentRef = useRef()
    const total_orders_per_page = 10

    const navigate = useNavigate()

    const setting = useSelector((state) => state.setting)
    const user = useSelector((state) => state.user)
    const [orderId, setOrderId] = useState(null)
    const [isNetworkError, setIsNetworkError] = useState(false)

    const fetchOrders = async () => {
        try {
            // Fetch active orders
            const activeResponse = await api.getOrders(user?.jwtToken, total_orders_per_page, offset)
            const activeResult = await activeResponse.json()

            if (activeResult.status === 1) {
                setActiveOrders(activeResult.data)
                setTotalActiveOrders(activeResult.total)
            } else if (activeResult.message === "No orders found") {
                setNoOrders(true)
            }

            // Fetch previous orders
            const prevResponse = await api.getOrders(user?.jwtToken, total_orders_per_page, offset, 0)
            const prevResult = await prevResponse.json()

            if (prevResult.status === 1) {
                setPrevOrders(prevResult.data)
                setTotalPrevOrders(prevResult.total)
            } else if (prevResult.message === "No orders found") {
                setNoOrders(true)
            }
        } catch (err) {
            const isNoInternet = ValidateNoInternet(err)
            if (isNoInternet) {
                setIsNetworkError(true)
            }
        } finally {
            setisLoader(false)
        }
    }

    useEffect(() => {
        setisLoader(true)
        fetchOrders()
    }, [offset])

    const handlePageChange = (pageNum) => {
        setcurrPage(pageNum)
        setoffset(pageNum * total_orders_per_page - total_orders_per_page)
    }

    const getInvoice = async (Oid) => {
        setisLoader(true)
        try {
            const postData = new FormData()
            postData.append("order_id", Oid)

            const response = await axios({
                url: `${import.meta.env.VITE_APP_API_URL}${import.meta.env.VITE_APP_API_SUBURL}/invoice_download`,
                method: "post",
                responseType: "blob",
                data: postData,
                headers: { Authorization: `Bearer ${user?.jwtToken}` },
            })

            const fileURL = window.URL.createObjectURL(new Blob([response.data]));
            const fileLink = document.createElement("a")
            fileLink.href = fileURL
            fileLink.setAttribute("download", `Invoice-No:${Oid}.pdf`)
            document.body.appendChild(fileLink)
            fileLink.click()
        } catch (error) {
            toast.error(error.request.statusText || error.message || "Something went wrong!")
        } finally {
            setisLoader(false)
        }
    }

    const convertToAMPM = (transactionDate) => {
        const dateTimeObj = new Date(transactionDate)
        const options = { hour: "numeric", minute: "numeric", second: "numeric", hour12: true }
        return dateTimeObj.toLocaleString("en-US", options)
    }

    const closeModalRef = useRef()
    const getOrderStatus = (pid) => {
        for (let i = 0; i < ActiveOrders.length; i++) {
            const element = ActiveOrders[i]
            closeModalRef.current.click()
        }
    }

    const setHtml = (ID, status = 0) => {
        const orders = status ? PrevOrders : ActiveOrders
        const foundOrder = orders.find((obj) => obj.id === Number(ID))
        if (foundOrder) setElement(foundOrder)
    }

    const getImageofOrderStatus = (status) => {
        const statusIcons = {
            1: PendingPaymentSVG,
            2: ReceivedSVG,
            3: ProcessedSVG,
            4: ShippedSVG,
            5: OutforDeliverySVG,
            6: DeliveredSVG,
            7: CancelledSVG,
            8: ReturnedSVG,
        }
        return <img src={statusIcons[status] || "/placeholder.svg"} className="w-12 h-12 p-2" alt={`status-${status}`} />
    }

    const getStatus = (flag) => {
        const statusTexts = {
            1: "Payment Pending",
            2: "Received",
            3: "Processed",
            4: "Shipped",
            5: "Out For Delivery",
            6: "Delivered",
            7: "Cancelled",
            8: "Returned",
        }
        return statusTexts[Number(flag[0])] || null
    }

    const getStatusColor = (status) => {
        const colors = {
            1: "bg-amber-50 text-amber-700 border-amber-200",
            2: "bg-blue-50 text-blue-700 border-blue-200",
            3: "bg-purple-50 text-purple-700 border-purple-200",
            4: "bg-indigo-50 text-indigo-700 border-indigo-200",
            5: "bg-orange-50 text-orange-700 border-orange-200",
            6: "bg-emerald-50 text-emerald-700 border-emerald-200",
            7: "bg-red-50 text-red-700 border-red-200",
            8: "bg-gray-50 text-gray-700 border-gray-200",
        }
        return colors[status] || "bg-gray-50 text-gray-700 border-gray-200"
    }

    const getStatusIcon = (status) => {
        const icons = {
            1: <Clock className="w-4 h-4" />,
            2: <Package className="w-4 h-4" />,
            3: <Package className="w-4 h-4" />,
            4: <Truck className="w-4 h-4" />,
            5: <Truck className="w-4 h-4" />,
            6: <CheckCircle className="w-4 h-4" />,
            7: <XCircle className="w-4 h-4" />,
            8: <RotateCcw className="w-4 h-4" />,
        }
        return icons[status] || <Package className="w-4 h-4" />
    }

    const handleLiveTrackOrder = (e, order) => {
        if (order?.active_status !== "5") {
            setHtml(e.target.value)
            setShowTrackModal(true)
            getOrderStatus(e.target.value)
        } else {
            setShowLiveLocationModal(true)
            setSelectedOrder(order)
        }
    }

    const renderPagination = (totalItems) => {
        const totalPages = Math.ceil(totalItems / total_orders_per_page)
        if (totalPages <= 1) return null

        const pages = []
        const maxVisiblePages = 5
        let startPage = Math.max(1, currPage - Math.floor(maxVisiblePages / 2))
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1)

        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1)
        }

        for (let i = startPage; i <= endPage; i++) {
            pages.push(
                <button
                    key={i}
                    onClick={() => handlePageChange(i)}
                    className={`relative inline-flex items-center px-4 py-2 text-sm font-semibold transition-all duration-200 ${currPage === i
                            ? "z-10 bg-blue-600 text-white focus:z-20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
                            : "text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
                        } ${i === startPage ? "rounded-l-lg" : ""} ${i === endPage ? "rounded-r-lg" : ""}`}
                >
                    {i}
                </button>
            )
        }

        return (
            <div className="flex items-center justify-between border-t border-gray-200 bg-white px-4 py-3 sm:px-6 rounded-b-2xl">
                <div className="flex flex-1 justify-between sm:hidden">
                    <button
                        onClick={() => handlePageChange(Math.max(1, currPage - 1))}
                        disabled={currPage === 1}
                        className="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Previous
                    </button>
                    <button
                        onClick={() => handlePageChange(Math.min(totalPages, currPage + 1))}
                        disabled={currPage === totalPages}
                        className="relative ml-3 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Next
                    </button>
                </div>
                <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
                    <div>
                        <p className="text-sm text-gray-700">
                            Showing <span className="font-medium">{(currPage - 1) * total_orders_per_page + 1}</span> to{" "}
                            <span className="font-medium">
                                {Math.min(currPage * total_orders_per_page, totalItems)}
                            </span>{" "}
                            of <span className="font-medium">{totalItems}</span> results
                        </p>
                    </div>
                    <div>
                        <nav className="isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
                            <button
                                onClick={() => handlePageChange(Math.max(1, currPage - 1))}
                                disabled={currPage === 1}
                                className="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                <span className="sr-only">Previous</span>
                                <ArrowLeft className="h-5 w-5" aria-hidden="true" />
                            </button>
                            {pages}
                            <button
                                onClick={() => handlePageChange(Math.min(totalPages, currPage + 1))}
                                disabled={currPage === totalPages}
                                className="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                <span className="sr-only">Next</span>
                                <ArrowRight className="h-5 w-5" aria-hidden="true" />
                            </button>
                        </nav>
                    </div>
                </div>
            </div>
        )
    }

    const renderOrderCard = (order, isActive = true) => (
        <div
            key={order.order_id}
            className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-300 group"
        >
            {/* Card Header */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 px-6 py-4 border-b border-gray-100">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center space-x-3 mb-2 sm:mb-0">
                        <div className="bg-white p-3 rounded-xl shadow-sm group-hover:shadow-md transition-shadow duration-300">
                            <Package className="w-6 h-6 text-blue-600" />
                        </div>
                        <div>
                            <h3 className="text-lg font-bold text-gray-900">Order #{order.order_id}</h3>
                            <div className="flex items-center space-x-4 text-sm text-gray-600">
                                <div className="flex items-center space-x-1">
                                    <Calendar className="w-4 h-4" />
                                    <span>{order.created_at.substring(0, 10)}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                    <Clock className="w-4 h-4" />
                                    <span>{convertToAMPM(order.created_at)}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-xl shadow-sm">
                        <FaRupeeSign className="w-4 h-4 text-gray-600" />
                        <span className="text-xl font-bold text-gray-900">{order.final_total}</span>
                    </div>
                </div>
            </div>

            {/* Card Body */}
            <div className="p-6">
                {/* Products Section */}
                <div className="mb-6">
                    <div className="flex items-center space-x-2 mb-3">
                        <ShoppingBag className="w-5 h-5 text-gray-600" />
                        <h4 className="text-sm font-semibold text-gray-700">
                            Products ({order.items.length} {order.items.length === 1 ? 'item' : 'items'})
                        </h4>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {order.items.slice(0, 4).map((item, ind) => (
                            <div
                                key={ind}
                                className="flex items-center space-x-2 bg-gray-50 px-3 py-2 rounded-lg"
                            >
                                <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0"></div>
                                <span className="text-sm text-gray-700 truncate">{item.product_name}</span>
                            </div>
                        ))}
                        {order.items.length > 4 && (
                            <div className="flex items-center space-x-2 bg-gray-100 px-3 py-2 rounded-lg">
                                <span className="text-sm text-gray-600">+{order.items.length - 4} more items</span>
                            </div>
                        )}
                    </div>
                </div>

                {/* Status Section */}
                {order.active_status && (
                    <div className="mb-6">
                        <div className={`inline-flex items-center space-x-2 px-4 py-2 rounded-xl border-2 ${getStatusColor(Number.parseInt(order.active_status))}`}>
                            {getStatusIcon(Number.parseInt(order.active_status))}
                            <span className="text-sm font-semibold">{getStatus([order.active_status])}</span>
                        </div>
                    </div>
                )}

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-3">
                    <button
                        onClick={(e) => {
                            e.target.value = order.id
                            handleLiveTrackOrder(e, order)
                        }}
                        className="flex items-center justify-center px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-sm font-semibold rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
                    >
                        <Truck className="w-4 h-4 mr-2" />
                        {order?.active_status === "5" ? "Live Track" : "Track Order"}
                    </button>
                    <button
                        onClick={() => navigate(`/my-orders/details/${order.order_id}`)}
                        className="flex items-center justify-center px-6 py-3 bg-gray-100 text-gray-700 text-sm font-semibold rounded-xl hover:bg-gray-200 transition-all duration-200 border border-gray-200 hover:border-gray-300"
                    >
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                    </button>
                    <button
                        onClick={() => getInvoice(order.order_id)}
                        className="flex items-center justify-center px-6 py-3 bg-emerald-50 text-emerald-700 text-sm font-semibold rounded-xl hover:bg-emerald-100 transition-all duration-200 border border-emerald-200 hover:border-emerald-300"
                    >
                        <Download className="w-4 h-4 mr-2" />
                        Download Invoice
                    </button>
                </div>
            </div>
        </div>
    )

    const renderEmptyState = () => (
        <div className="text-center py-16">
            <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-6">
                <Package className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">No orders found</h3>
            <p className="text-gray-600 leading-relaxed max-w-md mx-auto">
                {activeTab === "active"
                    ? "You don't have any active orders at the moment. Start shopping to see your orders here!"
                    : "You haven't completed any orders yet. Your order history will appear here once you make purchases."
                }
            </p>
            <button
                onClick={() => navigate("/")}
                className="mt-6 inline-flex items-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 transition-all duration-200 transform hover:scale-105"
            >
                <ShoppingBag className="w-5 h-5 mr-2" />
                Start Shopping
            </button>
        </div>
    )

    if (isNetworkError) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex flex-col justify-center items-center p-4">
                <div className="text-center bg-white rounded-2xl shadow-lg p-8 max-w-md w-full">
                    <div className="bg-red-50 rounded-full p-4 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                        <WifiOff className="w-10 h-10 text-red-500" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-3">No Internet Connection</h3>
                    <p className="text-gray-600 leading-relaxed">You are not connected to the internet. Please check your connection and try again.</p>
                    <button
                        onClick={() => window.location.reload()}
                        className="mt-6 px-6 py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 transition-all duration-200 transform hover:scale-105"
                    >
                        Try Again
                    </button>
                </div>
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Enhanced Header */}
                <div className="mb-8">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                        <div>
                            <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">My Orders</h1>
                            <p className="text-gray-600 text-lg">Manage and track all your orders in one place</p>
                        </div>
                        <div className="mt-4 sm:mt-0 flex items-center space-x-3">
                            <div className="bg-white px-4 py-2 rounded-xl shadow-sm border border-gray-200">
                                <div className="flex items-center space-x-2">
                                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                                    <span className="text-sm font-medium text-gray-700">
                                        {ActiveOrders.length} Active
                                    </span>
                                </div>
                            </div>
                            <div className="bg-white px-4 py-2 rounded-xl shadow-sm border border-gray-200">
                                <div className="flex items-center space-x-2">
                                    <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
                                    <span className="text-sm font-medium text-gray-700">
                                        {PrevOrders.length} Completed
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {isLoader ? (
                    <div className="flex justify-center items-center py-16">
                        <div className="text-center">
                            <div className="relative">
                                <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-200 border-t-blue-600 mx-auto"></div>
                                <div className="absolute inset-0 rounded-full h-16 w-16 border-4 border-transparent border-t-blue-400 animate-ping"></div>
                            </div>
                            <p className="mt-4 text-gray-600 font-medium">Loading your orders...</p>
                        </div>
                    </div>
                ) : (
                    <>
                        {/* Enhanced Tabs */}
                        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 mb-8 overflow-hidden">
                            <div className="border-b border-gray-200 bg-gradient-to-r from-gray-50 to-white">
                                <nav className="flex space-x-8 px-6" aria-label="Tabs">
                                    <button
                                        onClick={() => setActiveTab("active")}
                                        className={`py-6 px-1 border-b-3 font-semibold text-sm transition-all duration-200 ${activeTab === "active"
                                                ? "border-blue-500 text-blue-600"
                                                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                                            }`}
                                    >
                                        <div className="flex items-center space-x-3">
                                            <div className={`p-2 rounded-lg transition-colors duration-200 ${activeTab === "active" ? "bg-blue-50" : "bg-gray-100"
                                                }`}>
                                                <Clock className="w-5 h-5" />
                                            </div>
                                            <div className="text-left">
                                                <div className="font-semibold">Active Orders</div>
                                                <div className="text-xs text-gray-500">Currently processing</div>
                                            </div>
                                            {ActiveOrders.length > 0 && (
                                                <span className={`px-3 py-1 rounded-full text-xs font-bold ${activeTab === "active"
                                                        ? "bg-blue-100 text-blue-700"
                                                        : "bg-gray-100 text-gray-600"
                                                    }`}>
                                                    {ActiveOrders.length}
                                                </span>
                                            )}
                                        </div>
                                    </button>
                                    <button
                                        onClick={() => setActiveTab("previous")}
                                        className={`py-6 px-1 border-b-3 font-semibold text-sm transition-all duration-200 ${activeTab === "previous"
                                                ? "border-blue-500 text-blue-600"
                                                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                                            }`}
                                    >
                                        <div className="flex items-center space-x-3">
                                            <div className={`p-2 rounded-lg transition-colors duration-200 ${activeTab === "previous" ? "bg-blue-50" : "bg-gray-100"
                                                }`}>
                                                <CheckCircle className="w-5 h-5" />
                                            </div>
                                            <div className="text-left">
                                                <div className="font-semibold">Order History</div>
                                                <div className="text-xs text-gray-500">Completed orders</div>
                                            </div>
                                            {PrevOrders.length > 0 && (
                                                <span className={`px-3 py-1 rounded-full text-xs font-bold ${activeTab === "previous"
                                                        ? "bg-blue-100 text-blue-700"
                                                        : "bg-gray-100 text-gray-600"
                                                    }`}>
                                                    {PrevOrders.length}
                                                </span>
                                            )}
                                        </div>
                                    </button>
                                </nav>
                            </div>

                            <div className="p-6">
                                {activeTab === "active" ? (
                                    ActiveOrders.length === 0 ? (
                                        renderEmptyState()
                                    ) : (
                                        <>
                                            <div className="grid gap-6">
                                                {ActiveOrders.map((order) => renderOrderCard(order, true))}
                                            </div>
                                            {renderPagination(totalActiveOrders)}
                                        </>
                                    )
                                ) : PrevOrders.length === 0 ? (
                                    renderEmptyState()
                                ) : (
                                    <>
                                        <div className="grid gap-6">
                                            {PrevOrders.map((order) => renderOrderCard(order, false))}
                                        </div>
                                        {renderPagination(totalPrevOrders)}
                                    </>
                                )}
                            </div>
                        </div>
                    </>
                )}
            </div>

            {/* Enhanced Track Order Modal */}
            {showTrackModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                    <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto transform transition-all duration-300 scale-100">
                        <div className="flex items-center justify-between p-6 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50">
                            <div className="flex items-center space-x-4">
                                <div className="bg-white p-3 rounded-xl shadow-sm">
                                    <Truck className="w-6 h-6 text-blue-600" />
                                </div>
                                <div>
                                    <h2 className="text-xl font-bold text-gray-900">{setting.setting?.app_name}</h2>
                                    <p className="text-sm text-gray-600">Order Tracking • Mobile: {element && element.mobile}</p>
                                </div>
                            </div>
                            <button
                                onClick={() => setShowTrackModal(false)}
                                className="p-2 hover:bg-white rounded-xl transition-colors duration-200"
                            >
                                <IoMdClose className="w-6 h-6 text-gray-500" />
                            </button>
                        </div>

                        <div className="p-6">
                            <div className="space-y-6">
                                {element?.status?.map((flag, index) => (
                                    <div key={index} className="relative flex items-start space-x-4">
                                        <div className="flex-shrink-0 relative">
                                            <div className="bg-white rounded-xl shadow-sm p-2 border-2 border-gray-100">
                                                {getImageofOrderStatus(Number(flag[0]))}
                                            </div>
                                            {index < element?.status?.length - 1 && (
                                                <div className="absolute left-1/2 top-16 w-0.5 h-8 bg-gradient-to-b from-blue-200 to-gray-200 transform -translate-x-1/2"></div>
                                            )}
                                        </div>
                                        <div className="flex-1 min-w-0 pb-8">
                                            <div className="flex items-center space-x-3 mb-2">
                                                <span className={`inline-flex items-center space-x-2 px-4 py-2 rounded-xl border-2 text-sm font-semibold ${getStatusColor(Number(flag[0]))}`}>
                                                    {getStatusIcon(Number(flag[0]))}
                                                    <span>{getStatus(flag)}</span>
                                                </span>
                                            </div>
                                            <p className="text-gray-700 leading-relaxed">
                                                Your order has been <span className="font-semibold">{getStatus(flag)}</span> successfully
                                            </p>
                                            <div className="flex items-center space-x-4 mt-3 text-sm text-gray-500">
                                                <div className="flex items-center space-x-1">
                                                    <Calendar className="w-4 h-4" />
                                                    <span>{formatDate(flag[1])}</span>
                                                </div>
                                                <div className="flex items-center space-x-1">
                                                    <Clock className="w-4 h-4" />
                                                    <span>{formatTime(flag[1])}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <OrderTracker show={showTracker} setShow={setShowTracker} />
            {showLiveLocationModal && (
                <LiveTrackingModal
                    showLiveLocationModal={showLiveLocationModal}
                    setShowLiveLocationModal={setShowLiveLocationModal}
                    selectedOrder={selectedOrder}
                />
            )}
        </div>
    )
}

export default MyOrders