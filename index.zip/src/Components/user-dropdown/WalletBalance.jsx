import PaystackPop from "@paystack/inline-js"
import { CardElement, Elements, useElements, useStripe } from "@stripe/react-stripe-js"
import { loadStripe } from "@stripe/stripe-js"
import { useEffect, useState } from "react"
import { FaRupeeSign, FaTimes, FaPlus, FaHistory, FaWallet, FaChevronLeft, FaChevronRight, FaCreditCard, FaArrowUp, FaArrowDown, FaCalendarAlt, FaCheckCircle, FaClock, FaTimesCircle } from "react-icons/fa"
import { useDispatch, useSelector } from "react-redux"
import { toast } from "react-toastify"
import api from "../../api/api"
import { addUserBalance } from "../../model/reducer/authReducer"

// Payment method icons
import cashfree from "../../utils/ic_cashfree.svg"
import paytabs from "../../utils/Icons/ic_paytabs.svg"
import MidtransSVG from "../../utils/Icons/Midtrans.svg"
import PhonePeSVG from "../../utils/Icons/Phonepe.svg"
import PaypalSVG from "../../utils/Paypal.svg"
import PayStackSVG from "../../utils/Paystack.svg"
import RazorPaySVG from "../../utils/Razorpay.svg"
import StripeSVG from "../../utils/Stripe.svg"

const WalletBalance = () => {
  const dispatch = useDispatch()
  const setting = useSelector((state) => state.setting)
  const user = useSelector((state) => state.user)
  const [showModal, setShowModal] = useState(false)
  const [walletAmount, setWalletAmount] = useState(0)
  const [paymentMethod, setPaymentMethod] = useState("")
  const [stripeTransId, setStripeTransId] = useState(null)
  const [stripeClientSecret, setStripeClientSecret] = useState(null)
  const [stripeModalShow, setStripeModalShow] = useState(false)
  const [loader, setLoader] = useState(false)
  const [transactions, setTransactions] = useState([])
  const [totalTransactions, setTotalTransactions] = useState(0)
  const [offset, setOffset] = useState(0)
  const [currPage, setCurrPage] = useState(1)
  const total_transactions_per_page = 10

  const stripePromise = loadStripe(setting.payment_setting?.stripe_publishable_key)

  // Fetch wallet transactions
  const fetchTransactions = () => {
    api
      .getTransactions(user?.jwtToken, total_transactions_per_page, offset, "wallet")
      .then((response) => response.json())
      .then((result) => {
        if (result.status === 1) {
          setTransactions(result.data)
          setTotalTransactions(result.total)
        }
      })
  }

  useEffect(() => {
    fetchTransactions()
  }, [offset])

  const handleAmountChange = (e) => {
    const amt = Number.parseFloat(e.target.value)
    setWalletAmount(amt)
  }

  const handlePmtMethodChange = (value) => {
    setPaymentMethod(value)
  }

  const initializeRazorpay = () => {
    return new Promise((resolve) => {
      const script = document.createElement("script")
      script.src = "https://checkout.razorpay.com/v1/checkout.js"
      script.onload = () => resolve(true)
      script.onerror = () => resolve(false)
      document.body.appendChild(script)
    })
  }

  const handleRazorpayPayment = async (razorpay_transaction_id, amount) => {
    const res = await initializeRazorpay()
    if (!res) {
      toast.error("RazorPay SDK Load Failed")
      return
    }

    const key = setting.payment_setting?.razorpay_key
    const convertedAmount = Math.floor(amount * 100)
    const options = {
      key: key,
      amount: convertedAmount,
      currency: "INR",
      name: user.user?.name,
      description: setting.setting?.app_name,
      image: setting.setting?.web_settings?.web_logo,
      order_id: razorpay_transaction_id,
      handler: async (res) => {
        if (res.razorpay_payment_id) {
          await api
            .addTransaction(user?.jwtToken, null, razorpay_transaction_id, "Razorpay", "wallet", amount)
            .then((response) => response.json())
            .then((result) => {
              if (result.status === 1) {
                setShowModal(false)
                toast.success(result.message)
                dispatch(addUserBalance({ data: Number.parseInt(amount) }))
                fetchTransactions()
              } else {
                toast.error(result.message)
              }
            })
        }
      },
      modal: {
        confirm_close: true,
        ondismiss: async () => {
          setShowModal(false)
          setPaymentMethod("")
        },
      },
      prefill: {
        name: user.user?.name,
        email: user.user?.email,
        contact: user.user?.mobile,
      },
      theme: {
        color: setting.setting?.web_settings?.color,
      },
    }

    const rzpay = new window.Razorpay(options)
    rzpay.on("payment.cancel", () => toast.error("Payment cancelled"))
    rzpay.on("payment.failed", () => toast.error("Payment failed"))
    rzpay.open()
  }

  const handlePayStackPayment = (amount) => {
    const handler = PaystackPop.setup({
      key: setting.payment_setting?.paystack_public_key,
      email: user.user?.email,
      amount: Number.parseFloat(amount) * 100,
      currency: setting.payment_setting?.paystack_currency_code,
      ref: new Date().getTime().toString(),
      label: setting.setting?.support_email,
      callback: async (response) => {
        await api
          .addTransaction(user?.jwtToken, null, response.reference, "Paystack", "wallet", amount)
          .then((response) => response.json())
          .then((result) => {
            if (result.status === 1) {
              toast.success(result.message)
              dispatch(addUserBalance({ data: Number.parseInt(amount) }))
              setShowModal(false)
              fetchTransactions()
            } else {
              toast.error(result.message)
              setShowModal(false)
            }
          })
      },
    })
    handler.openIframe()
  }

  const handlePaypalPayment = (redirectUrl) => {
    window.open(redirectUrl, "_parent")
  }

  const handlePaymentWindow = (redirectUrl, successCallback) => {
    const windowWidth = 700
    const windowHeight = 700
    const windowLeft = window.screen.width / 2 - windowWidth / 2
    const windowTop = window.screen.height / 2 - windowHeight / 2
    const windowFeatures = `width=${windowWidth},height=${windowHeight},left=${windowLeft},top=${windowTop},resizable=yes,scrollbars=yes,status=yes`
    const paymentWindow = window.open(redirectUrl, "_blank", windowFeatures)

    const messageEventListener = (event) => {
      if (event.data === "Recharge Done") {
        paymentWindow.close()
        successCallback()
        window.removeEventListener("message", messageEventListener)
      }
    }

    window.addEventListener("message", messageEventListener)
    paymentWindow.onbeforeunload = () => {
      window.removeEventListener("message", messageEventListener)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (paymentMethod === "") {
      return toast.error("please_select_payment_method")
    }
    if (walletAmount <= 0) {
      return toast.error("amount_must_be_greater_than_zero")
    }

    try {
      setLoader(true)
      let response, result
      if (["paypal", "stripe", "razorpay", "midtrans", "phonepe", "cashfree", "paytabs"].includes(paymentMethod)) {
        response = await api.initiate_transaction(user?.jwtToken, null, paymentMethod, "wallet", walletAmount)
        result = await response.json()
      }

      if (!result || result.status !== 1) {
        toast.error(result?.message || "Payment initiation failed")
        setLoader(false)
        return
      }

      if (paymentMethod === "razorpay") {
        handleRazorpayPayment(result?.data?.transaction_id, walletAmount)
      } else if (paymentMethod === "paystack") {
        handlePayStackPayment(walletAmount)
      } else if (paymentMethod === "stripe") {
        setStripeTransId(result.data?.id)
        setStripeClientSecret(result.data?.client_secret)
        setStripeModalShow(true)
      } else if (paymentMethod === "paypal") {
        handlePaypalPayment(result?.data?.paypal_redirect_url)
      } else if (paymentMethod === "cashfree") {
        window.location.href = result?.data?.redirectUrl
      } else if (["midtrans", "phonepe", "paytabs"].includes(paymentMethod)) {
        handlePaymentWindow(result?.data?.redirectUrl || result?.data?.snapUrl, () => {
          dispatch(addUserBalance({ data: walletAmount }))
          toast.success("Wallet Recharge Successsful !!")
          setShowModal(false)
          fetchTransactions()
        })
      }
      setLoader(false)
    } catch (err) {
      setLoader(false)
      toast.error(err.message || "Payment processing failed")
    }
  }

  const convertToAMPM = (transactionDate) => {
    const dateTimeObj = new Date(transactionDate)
    const options = { hour: "numeric", minute: "numeric", second: "numeric", hour12: true }
    return dateTimeObj.toLocaleString("en-US", options)
  }

  const handlePageChange = (pageNum) => {
    setCurrPage(pageNum)
    setOffset(pageNum * total_transactions_per_page - total_transactions_per_page)
  }

  const StripeCheckoutForm = ({ clientSecret, transactionId, amount }) => {
    const stripe = useStripe()
    const elements = useElements()
    const [loading, setLoading] = useState(false)

    const handleSubmit = async (event) => {
      event.preventDefault()
      setLoading(true)

      if (!stripe || !elements) {
        setLoading(false)
        return
      }

      const { paymentIntent, error } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement),
          billing_details: {
            name: user.user?.name,
            address: {
              line1: "510 Townsend St",
              postal_code: "98140",
              city: "San Francisco",
              state: "CA",
              country: "US",
            },
          },
        },
      })

      if (error) {
        toast.error(error.message)
        setStripeModalShow(false)
        setShowModal(false)
      } else if (paymentIntent.status === "succeeded") {
        await api
          .addTransaction(user?.jwtToken, null, transactionId, "Stripe", "wallet", amount)
          .then((response) => response.json())
          .then((result) => {
            if (result.status === 1) {
              setLoading(false)
              setStripeModalShow(false)
              dispatch(addUserBalance({ data: amount }))
              setShowModal(false)
              toast.success(result.message)
              fetchTransactions()
            } else {
              setLoading(false)
              toast.error(result.message)
            }
          })
      } else {
        setLoading(false)
        toast.error("Payment failed")
        setStripeModalShow(false)
        setShowModal(false)
      }
    }

    return (
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="p-4 border border-gray-200 rounded-2xl bg-gray-50/50">
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: "16px",
                  color: "#1f2937",
                  fontFamily: "system-ui, -apple-system, sans-serif",
                  "::placeholder": {
                    color: "#9CA3AF",
                  },
                },
                invalid: {
                  color: "#EF4444",
                },
              },
            }}
          />
        </div>
        <button
          type="submit"
          disabled={!stripe || loading}
          className="w-full bg-[#fc2e6bed] hover:bg-[#fc2e6b] text-white py-4 px-6 rounded-2xl font-semibold transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          ) : (
            <>
              <FaCreditCard className="text-sm" />
              <span>
                Pay {setting?.setting?.currency}
                {amount}
              </span>
            </>
          )}
        </button>
      </form>
    )
  }

  const paymentMethods = [
    { key: "paypal", name: "PayPal", icon: PaypalSVG, setting: setting?.payment_setting?.paypal_payment_method },
    {
      key: "razorpay",
      name: "Razorpay",
      icon: RazorPaySVG,
      setting: setting?.payment_setting?.razorpay_payment_method,
    },
    {
      key: "paystack",
      name: "Paystack",
      icon: PayStackSVG,
      setting: setting?.payment_setting?.paystack_payment_method,
    },
    { key: "stripe", name: "Stripe", icon: StripeSVG, setting: setting?.payment_setting?.stripe_payment_method },
    {
      key: "midtrans",
      name: "Midtrans",
      icon: MidtransSVG,
      setting: setting?.payment_setting?.midtrans_payment_method,
    },
    { key: "phonepe", name: "PhonePe", icon: PhonePeSVG, setting: setting?.payment_setting?.phonepay_payment_method },
    { key: "cashfree", name: "Cashfree", icon: cashfree, setting: setting?.payment_setting?.cashfree_payment_method },
    { key: "paytabs", name: "Paytabs", icon: paytabs, setting: setting?.payment_setting?.paytabs_payment_method },
  ]

  const totalPages = Math.ceil(totalTransactions / total_transactions_per_page)

  const getStatusIcon = (status) => {
    switch (status) {
      case "success":
        return <FaCheckCircle className="text-green-500" />
      case "pending":
        return <FaClock className="text-yellow-500" />
      default:
        return <FaTimesCircle className="text-red-500" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile App Header */}
      <div className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#fc2e6bed] to-[#fc2e6b] rounded-2xl flex items-center justify-center shadow-lg">
                <FaWallet className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">My Wallet</h1>
                <p className="text-sm text-gray-500 hidden sm:block">Manage your balance</p>
              </div>
            </div>
            <button
              onClick={() => {
                setShowModal(true)
                setWalletAmount(0)
                setPaymentMethod("")
              }}
              className="bg-[#fc2e6bed] hover:bg-[#fc2e6b] text-white px-4 py-2 rounded-xl font-medium transition-all duration-300 flex items-center space-x-2 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              <FaPlus className="text-sm" />
              <span className="hidden sm:inline">Add Money</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Balance Card */}
        <div className="bg-gradient-to-br from-[#fc2e6bed] to-[#fc2e6b] rounded-3xl p-6 sm:p-8 text-white shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
            <div className="space-y-2">
              <p className="text-white/80 text-sm font-medium">Available Balance</p>
              <div className="flex items-baseline space-x-2">
                <span className="text-4xl sm:text-5xl font-bold">
                  {setting?.setting?.currency}
                  {Number.parseFloat(user?.user?.balance || 0).toFixed(setting?.setting?.decimal_point || 2)}
                </span>
              </div>
              <p className="text-white/70 text-sm">Last updated just now</p>
            </div>
            <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
              <button
                onClick={() => {
                  setShowModal(true)
                  setWalletAmount(0)
                  setPaymentMethod("")
                }}
                className="bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white px-6 py-3 rounded-2xl font-semibold transition-all duration-300 flex items-center justify-center space-x-2 border border-white/20"
              >
                <FaArrowUp className="text-sm" />
                <span>Add Money</span>
              </button>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
                <FaArrowUp className="text-green-600 text-sm" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Total Added</p>
                <p className="text-lg font-bold text-gray-900">
                  {setting?.setting?.currency}
                  {transactions
                    .filter(t => t.status === "success" && parseFloat(t.amount) > 0)
                    .reduce((sum, t) => sum + parseFloat(t.amount), 0)
                    .toFixed(2)}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                <FaHistory className="text-blue-600 text-sm" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Transactions</p>
                <p className="text-lg font-bold text-gray-900">{totalTransactions}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-yellow-100 rounded-xl flex items-center justify-center">
                <FaClock className="text-yellow-600 text-sm" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Pending</p>
                <p className="text-lg font-bold text-gray-900">
                  {transactions.filter(t => t.status === "pending").length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
                <FaCheckCircle className="text-green-600 text-sm" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Completed</p>
                <p className="text-lg font-bold text-gray-900">
                  {transactions.filter(t => t.status === "success").length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Transaction History */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
                  <FaHistory className="text-gray-600 text-lg" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">Transaction History</h2>
                  <p className="text-sm text-gray-500">Your recent wallet activities</p>
                </div>
              </div>
            </div>
          </div>

          {transactions.length === 0 ? (
            <div className="p-12 text-center">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <FaHistory className="text-gray-400 text-2xl" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No Transactions Yet</h3>
              <p className="text-gray-500 mb-6">Start by adding money to your wallet</p>
              <button
                onClick={() => {
                  setShowModal(true)
                  setWalletAmount(0)
                  setPaymentMethod("")
                }}
                className="bg-[#fc2e6bed] hover:bg-[#fc2e6b] text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300"
              >
                Add Money Now
              </button>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden lg:block overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50/50">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Transaction</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Description</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Date & Time</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Amount</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {transactions.map((transaction, index) => (
                      <tr key={index} className="hover:bg-gray-50/50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
                              {getStatusIcon(transaction.status)}
                            </div>
                            <div>
                              <p className="font-semibold text-gray-900">#{transaction.id}</p>
                              <p className="text-sm text-gray-500">Wallet Transaction</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <p className="text-sm text-gray-900 max-w-xs">
                            {transaction.order_id
                              ? `${transaction.message} - Order ID: ${transaction.order_id}`
                              : transaction.message}
                          </p>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-2 text-sm text-gray-600">
                            <FaCalendarAlt className="text-xs" />
                            <div>
                              <div>{new Date(transaction.created_at).toLocaleDateString()}</div>
                              <div className="text-xs text-gray-400">{convertToAMPM(transaction.created_at)}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-1">
                            <FaRupeeSign className="text-sm text-gray-600" />
                            <span className="font-semibold text-gray-900">{transaction.amount}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span
                            className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold ${transaction.status === "success"
                                ? "bg-green-100 text-green-800"
                                : transaction.status === "pending"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-red-100 text-red-800"
                              }`}
                          >
                            {transaction.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Cards */}
              <div className="lg:hidden space-y-4 p-4">
                {transactions.map((transaction, index) => (
                  <div key={index} className="bg-gray-50/50 rounded-2xl p-4 space-y-3 border border-gray-100">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                          {getStatusIcon(transaction.status)}
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900">#{transaction.id}</p>
                          <p className="text-sm text-gray-500">Wallet Transaction</p>
                        </div>
                      </div>
                      <span
                        className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold ${transaction.status === "success"
                            ? "bg-green-100 text-green-800"
                            : transaction.status === "pending"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-red-100 text-red-800"
                          }`}
                      >
                        {transaction.status}
                      </span>
                    </div>

                    <p className="text-sm text-gray-600">
                      {transaction.order_id
                        ? `${transaction.message} - Order ID: ${transaction.order_id}`
                        : transaction.message}
                    </p>

                    <div className="flex justify-between items-center pt-2 border-t border-gray-200">
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <FaCalendarAlt className="text-xs" />
                        <span>{new Date(transaction.created_at).toLocaleDateString()}</span>
                        <span>{convertToAMPM(transaction.created_at)}</span>
                      </div>
                      <div className="flex items-center space-x-1 text-lg font-bold text-gray-900">
                        <FaRupeeSign className="text-sm" />
                        <span>{transaction.amount}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="p-6 border-t border-gray-100 bg-gray-50/30">
                  <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
                    <p className="text-sm text-gray-700">
                      Showing {offset + 1} to {Math.min(offset + total_transactions_per_page, totalTransactions)} of{" "}
                      {totalTransactions} results
                    </p>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handlePageChange(currPage - 1)}
                        disabled={currPage === 1}
                        className="p-2 rounded-xl border border-gray-200 text-gray-500 hover:bg-white hover:shadow-sm disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                      >
                        <FaChevronLeft className="text-sm" />
                      </button>

                      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                        const pageNum = Math.max(1, Math.min(currPage - 2 + i, totalPages - 4 + i))
                        return (
                          <button
                            key={pageNum}
                            onClick={() => handlePageChange(pageNum)}
                            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${currPage === pageNum
                                ? "bg-[#fc2e6bed] text-white shadow-lg"
                                : "text-gray-700 hover:bg-white hover:shadow-sm"
                              }`}
                          >
                            {pageNum}
                          </button>
                        )
                      })}

                      <button
                        onClick={() => handlePageChange(currPage + 1)}
                        disabled={currPage === totalPages}
                        className="p-2 rounded-xl border border-gray-200 text-gray-500 hover:bg-white hover:shadow-sm disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                      >
                        <FaChevronRight className="text-sm" />
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Add Money Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-[#fc2e6bed] rounded-2xl flex items-center justify-center">
                    <FaPlus className="text-white text-sm" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">Add Money</h3>
                    <p className="text-sm text-gray-500">Choose amount and payment method</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setShowModal(false)
                    setPaymentMethod("")
                    setWalletAmount(0)
                  }}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <FaTimes className="text-gray-500" />
                </button>
              </div>
            </div>

            <div className="p-6">
              {loader ? (
                <div className="flex flex-col items-center justify-center py-12 space-y-4">
                  <div className="w-12 h-12 border-4 border-[#fc2e6bed] border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-gray-600 font-medium">Processing your payment...</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Amount Input */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-4">Enter Amount</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 font-semibold text-lg">
                        {setting?.setting?.currency}
                      </span>
                      <input
                        type="number"
                        className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-2xl focus:ring-2 focus:ring-[#fc2e6bed] focus:border-transparent text-xl font-bold bg-gray-50/50 transition-all"
                        placeholder="0.00"
                        min="1"
                        step="0.01"
                        value={walletAmount || ""}
                        onChange={handleAmountChange}
                        required
                      />
                    </div>

                    {/* Quick Amount Buttons */}
                    <div className="grid grid-cols-4 gap-2 mt-4">
                      {[100, 500, 1000, 2000].map((amount) => (
                        <button
                          key={amount}
                          type="button"
                          onClick={() => setWalletAmount(amount)}
                          className="py-2 px-3 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors"
                        >
                          {setting?.setting?.currency}{amount}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Payment Methods */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-4">
                      Select Payment Method
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {paymentMethods.map(
                        (method) =>
                          method.setting === "1" && (
                            <div
                              key={method.key}
                              className={`relative p-4 border-2 rounded-2xl cursor-pointer transition-all duration-200 ${paymentMethod === method.key
                                  ? "border-[#fc2e6bed] bg-[#fc2e6bed]/5 shadow-lg"
                                  : "border-gray-200 hover:border-gray-300 hover:bg-gray-50/50"
                                }`}
                              onClick={() => handlePmtMethodChange(method.key)}
                            >
                              <div className="flex items-center space-x-3">
                                <input
                                  type="radio"
                                  id={method.key}
                                  name="paymentMethod"
                                  checked={paymentMethod === method.key}
                                  onChange={() => handlePmtMethodChange(method.key)}
                                  className="w-4 h-4 text-[#fc2e6bed] focus:ring-[#fc2e6bed]"
                                />
                                <img
                                  src={method.icon || "/placeholder.svg"}
                                  alt={method.name}
                                  className="w-8 h-8 object-contain"
                                />
                                <label htmlFor={method.key} className="font-medium text-gray-900 cursor-pointer capitalize">
                                  {method.name}
                                </label>
                              </div>
                            </div>
                          ),
                      )}
                    </div>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="w-full bg-[#fc2e6bed] hover:bg-[#fc2e6b] text-white py-4 px-6 rounded-2xl font-semibold text-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 flex items-center justify-center space-x-2"
                    disabled={!paymentMethod || walletAmount <= 0}
                  >
                    <FaPlus className="text-sm" />
                    <span>
                      Add Money {walletAmount > 0 && `• ${setting?.setting?.currency}${walletAmount}`}
                    </span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Stripe Modal */}
      {stripeModalShow && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg">
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center">
                    <FaCreditCard className="text-white text-sm" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">Stripe Payment</h3>
                    <p className="text-sm text-gray-500">Secure card payment</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setStripeModalShow(false)
                    setShowModal(false)
                  }}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <FaTimes className="text-gray-500" />
                </button>
              </div>
            </div>
            <div className="p-6">
              {stripeClientSecret && stripeTransId && (
                <Elements stripe={stripePromise} options={{ clientSecret: stripeClientSecret }}>
                  <StripeCheckoutForm
                    clientSecret={stripeClientSecret}
                    transactionId={stripeTransId}
                    amount={walletAmount}
                  />
                </Elements>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default WalletBalance
