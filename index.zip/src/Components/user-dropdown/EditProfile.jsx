import { useEffect, useState } from "react"
import { Edit3, User, Mail, Phone, Camera, Check, Upload } from "lucide-react"
import { useDispatch, useSelector } from "react-redux"
import { toast } from "react-toastify"
import api from "../../api/api"
import { setCurrentUser } from "../../model/reducer/authReducer"

const EditProfile = () => {
  const dispatch = useDispatch()
  const user = useSelector((state) => state.user)
  const setting = useSelector((state) => state.setting)

  const [username, setUsername] = useState(user.user?.name || "")
  const [useremail, setUseremail] = useState(user.user?.email || "")
  const [phoneNumber, setPhoneNumber] = useState(user.user?.mobile || "")
  const [selectedFile, setSelectedFile] = useState(null)
  const [isUpdating, setIsUpdating] = useState(false)
  const [isChanged, setIsChanged] = useState(false)

  // Store original values
  const [originalUsername, setOriginalUsername] = useState(user.user?.name || "")
  const [originalEmail, setOriginalEmail] = useState(user.user?.email || "")
  const [originalPhone, setOriginalPhone] = useState(user.user?.mobile || "")

  // Check if any field has been changed
  const checkIfChanged = () => {
    const changed =
      username !== originalUsername ||
      useremail !== originalEmail ||
      phoneNumber !== originalPhone ||
      selectedFile !== null
    setIsChanged(changed)
  }

  useEffect(() => {
    checkIfChanged()
  }, [username, useremail, phoneNumber, selectedFile])

  const getCurrentUser = async () => {
    try {
      const response = await api.getUser(user?.jwtToken)
      const result = await response.json()
      if (result.status === 1) {
        dispatch(setCurrentUser({ data: result.user }))
        // Reset original values after successful update
        setOriginalUsername(result.user.name)
        setOriginalEmail(result.user.email)
        setOriginalPhone(result.user.mobile)
      }
    } catch (error) {
      console.error("Error fetching user:", error)
      toast.error("error_fetching_user")
    }
  }

  const handleUpdateUser = async (e) => {
    e.preventDefault()

    if (!isChanged) {
      toast.info("no_changes_detected")
      return
    }

    setIsUpdating(true)

    try {
      let response
      if (selectedFile) {
        // Validate file type if a file is selected
        if (!["image/png", "image/jpg", "image/jpeg"].includes(selectedFile.type)) {
          toast.error("file_type_not_allowed")
          setIsUpdating(false)
          return
        }

        response = await api.edit_profile(username, useremail, phoneNumber, selectedFile, user?.jwtToken)
      } else {
        response = await api.edit_profile(username, useremail, phoneNumber, null, user?.jwtToken)
      }

      const result = await response.json()

      if (result.status === 1) {
        toast.success(result?.message || "profile_updated_successfully")
        await getCurrentUser()
        setSelectedFile(null) // Reset file selection after successful update
      } else {
        toast.error(result.message || "update_failed")
      }
    } catch (error) {
      console.error("Update error:", error)
      toast.error("update_error")
    } finally {
      setIsUpdating(false)
    }
  }

  const placeHolderImage = (e) => {
    e.target.src = setting.setting?.web_logo
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Mobile Header */}
      <div className="lg:hidden bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="px-4 py-4">
          <h1 className="text-xl font-semibold text-gray-900 text-center">Edit Profile</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6 lg:py-12">
        {/* Desktop Header */}
        <div className="hidden lg:block text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Edit Profile</h1>
          <p className="text-gray-600">Update your personal information</p>
        </div>

        <div className="bg-white lg:border lg:border-gray-200 lg:rounded-2xl lg:shadow-sm overflow-hidden">
          {/* Profile Section */}
          <div className="bg-gray-50 lg:bg-white px-6 py-8 lg:py-6 border-b border-gray-100">
            <div className="flex flex-col lg:flex-row lg:items-center lg:space-x-6">
              {/* Profile Image */}
              <div className="relative mx-auto lg:mx-0 mb-6 lg:mb-0">
                <div className="w-24 h-24 lg:w-20 lg:h-20 rounded-full overflow-hidden bg-gray-100 border-4 border-white shadow-sm">
                  {selectedFile ? (
                    <img
                      src={URL?.createObjectURL(selectedFile) || "/placeholder.svg"}
                      alt="userProfileImage"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <img
                      onError={placeHolderImage}
                      src={user.user?.profile || "/placeholder.svg"}
                      alt="profile"
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
                <label htmlFor="profile-image" className="absolute -bottom-1 -right-1 cursor-pointer">
                  <div className="w-8 h-8 bg-[#fc2e6bed] hover:bg-[#ff437bed] rounded-full flex items-center justify-center shadow-lg transition-colors">
                    <Camera className="w-4 h-4 text-white" />
                  </div>
                  <input
                    type="file"
                    id="profile-image"
                    onChange={(e) => setSelectedFile(e.target.files[0])}
                    className="hidden"
                    accept="image/png, image/jpeg, image/jpg"
                  />
                </label>
              </div>

              {/* Profile Info */}
              <div className="text-center lg:text-left flex-1">
                <h2 className="text-xl lg:text-lg font-semibold text-gray-900 mb-1">{user.user?.name}</h2>
                <p className="text-gray-600 text-sm mb-4 lg:mb-2">{user.user?.email}</p>

                {selectedFile && (
                  <div className="inline-flex items-center px-3 py-1 bg-green-50 border border-green-200 rounded-full text-sm text-green-700">
                    <Check className="w-4 h-4 mr-1" />
                    New image selected
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Form Section */}
          <div className="p-6 lg:p-8">
            <form onSubmit={handleUpdateUser} className="space-y-6">
              {/* Username Field */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Enter your full name"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    disabled={user.authType === "google"}
                    required
                    className={`w-full pl-10 pr-4 py-3 border rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent ${user.authType === "google"
                        ? "bg-gray-50 border-gray-200 text-gray-500 cursor-not-allowed"
                        : "border-gray-300 hover:border-gray-400 focus:border-gray-900 bg-white"
                      }`}
                  />
                </div>
                {user.authType === "google" && (
                  <p className="text-xs text-gray-500">Name cannot be changed for Google accounts</p>
                )}
              </div>

              {/* Email Field */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    placeholder="Enter your email address"
                    value={useremail}
                    onChange={(e) => setUseremail(e.target.value)}
                    disabled={user.authType === "google"}
                    required
                    className={`w-full pl-10 pr-4 py-3 border rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent ${user.authType === "google"
                        ? "bg-gray-50 border-gray-200 text-gray-500 cursor-not-allowed"
                        : "border-gray-300 hover:border-gray-400 focus:border-gray-900 bg-white"
                      }`}
                  />
                </div>
                {user.authType === "google" && (
                  <p className="text-xs text-gray-500">Email cannot be changed for Google accounts</p>
                )}
              </div>

              {/* Phone Field */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Phone Number</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="tel"
                    placeholder="Enter your phone number"
                    value={phoneNumber}
                    required
                    disabled={user.authType === "phone"}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className={`w-full pl-10 pr-4 py-3 border rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent ${user.authType === "phone"
                        ? "bg-gray-50 border-gray-200 text-gray-500 cursor-not-allowed"
                        : "border-gray-300 hover:border-gray-400 focus:border-gray-900 bg-white"
                      }`}
                  />
                </div>
                {user.authType === "phone" && (
                  <p className="text-xs text-gray-500">Phone number cannot be changed for phone-verified accounts</p>
                )}
              </div>

              {/* File Upload */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Profile Picture</label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors">
                  <label htmlFor="file-upload" className="cursor-pointer">
                    <div className="space-y-2">
                      <Upload className="w-8 h-8 text-gray-400 mx-auto" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {selectedFile ? "Change Profile Picture" : "Upload Profile Picture"}
                        </p>
                        <p className="text-xs text-gray-500">PNG, JPG or JPEG up to 10MB</p>
                      </div>
                    </div>
                    <input
                      id="file-upload"
                      type="file"
                      onChange={(e) => setSelectedFile(e.target.files[0])}
                      accept="image/png, image/jpeg, image/jpg"
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Update Button */}
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={!isChanged || isUpdating}
                  className={`w-full py-3 px-4 rounded-lg font-medium transition-all duration-200 ${!isChanged || isUpdating
                      ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                      : "bg-[#fc2e6bed] text-white hover:bg-[#ff487f] active:bg-[#fc2e6bed]"
                    }`}
                >
                  {isUpdating ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      Updating Profile...
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      <Edit3 className="w-5 h-5 mr-2" />
                      Update Profile
                    </div>
                  )}
                </button>

                {!isChanged && (
                  <p className="text-center text-sm text-gray-500 mt-3">Make changes to enable the update button</p>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}

export default EditProfile
