import React, { useEffect, useState } from 'react';
import api from '../../api/api';
import { FaRupeeSign, FaReceipt, FaWifi } from "react-icons/fa";
import { MdSignalWifiConnectedNoInternet0, MdFilterList } from 'react-icons/md';
import Loader from '../loader/Loader';
import Pagination from 'react-js-pagination';
import No_Transactions from '../../utils/zero-state-screens/No_Transaction.svg';
import { ValidateNoInternet } from '../../utils/NoInternetValidator';
import { useSelector } from 'react-redux';

const Transactions = () => {
  const total_transactions_per_page = 10;
  const type = 'transactions';

  const user = useSelector(state => state.user);

  const [transactions, setTransactions] = useState(null);
  const [totalTransactions, setTotalTransactions] = useState(null);
  const [offset, setOffset] = useState(0);
  const [currPage, setCurrPage] = useState(1);
  const [isLoader, setIsLoader] = useState(false);
  const [isNetworkError, setIsNetworkError] = useState(false);

  const fetchTransactions = () => {
    api.getTransactions(user?.jwtToken, total_transactions_per_page, offset, type)
      .then(response => response.json())
      .then(result => {
        if (result.status === 1) {
          setIsLoader(false);
          setTransactions(result.data);
          setTotalTransactions(result.total);
        }
        setIsLoader(false);
      })
      .catch(err => {
        const isNoInternet = ValidateNoInternet(err);
        if (isNoInternet) {
          setIsNetworkError(true);
        }
        setIsLoader(false);
      });
  };

  useEffect(() => {
    setIsLoader(true);
    fetchTransactions();
  }, [offset]);

  const handlePageChange = (pageNum) => {
    setCurrPage(pageNum);
    setOffset(pageNum * total_transactions_per_page - total_transactions_per_page);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const options = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    };
    return date.toLocaleDateString('en-US', options);
  };

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'success':
      case 'completed':
        return 'text-green-600 bg-green-50';
      case 'failed':
      case 'cancelled':
        return 'text-red-600 bg-red-50';
      case 'pending':
        return 'text-yellow-600 bg-yellow-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const getPaymentMethodIcon = (method) => {
    switch (method?.toLowerCase()) {
      case 'card':
      case 'credit card':
      case 'debit card':
        return '💳';
      case 'upi':
        return '📱';
      case 'wallet':
        return '👛';
      case 'bank transfer':
        return '🏦';
      default:
        return '💰';
    }
  };

  if (isNetworkError) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
        <div className="text-center bg-white rounded-xl shadow-lg p-8 max-w-md w-full">
          <MdSignalWifiConnectedNoInternet0 className="text-6xl text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-800 mb-2">No Internet Connection</h3>
          <p className="text-gray-600 mb-4">Please check your internet connection and try again.</p>
          <button
            onClick={() => window.location.reload()}
            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg transition-colors duration-200"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <FaReceipt className="text-2xl text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Transactions</h1>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              <button className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors duration-200">
                <MdFilterList />
                <span>Filter</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {transactions === null ? (
          <div className="flex justify-center items-center h-96">
            <Loader width="100%" height="350px" />
          </div>
        ) : (
          <>
            {isLoader ? (
              <div className="flex justify-center items-center h-96">
                <Loader width="100%" height="500px" />
              </div>
            ) : (
              <>
                {transactions.length === 0 ? (
                  <div className="text-center py-16">
                    <div className="bg-white rounded-xl shadow-sm p-8 max-w-md mx-auto">
                      <img
                        src={No_Transactions}
                        alt="No transactions"
                        className="w-32 h-32 mx-auto mb-4 opacity-50"
                      />
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">No Transactions Found</h3>
                      <p className="text-gray-600">You haven't made any transactions yet.</p>
                    </div>
                  </div>
                ) : (
                  <>
                    {/* Desktop Table View */}
                    <div className="hidden lg:block bg-white rounded-xl shadow-sm overflow-hidden">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                              Transaction ID
                            </th>
                            <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                              Payment Method
                            </th>
                            <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                              Date & Time
                            </th>
                            <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                              Amount
                            </th>
                            <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {transactions.map((transaction, index) => (
                            <tr
                              key={index}
                              className="hover:bg-gray-50 transition-colors duration-150"
                            >
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900">
                                {transaction?.txn_id}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <div className="flex items-center space-x-2">
                                  <span className="text-lg">{getPaymentMethodIcon(transaction.type)}</span>
                                  <span className="capitalize">{transaction.type}</span>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {formatDate(transaction.created_at)}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
                                <div className="flex items-center space-x-1">
                                  <FaRupeeSign className="text-blue-600" />
                                  <span>{transaction.amount?.toLocaleString()}</span>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className={`inline-flex px-3 py-1 rounded-full text-xs font-semibold capitalize ${getStatusColor(transaction.status)}`}>
                                  {transaction.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Mobile Card View */}
                    <div className="lg:hidden space-y-4">
                      {transactions.map((transaction, index) => (
                        <div
                          key={index}
                          className="bg-white rounded-lg shadow-sm border border-gray-200 p-4"
                        >
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-2">
                              <span className="text-lg">{getPaymentMethodIcon(transaction.type)}</span>
                              <span className="font-medium text-gray-900 capitalize">{transaction.type}</span>
                            </div>
                            <span className={`inline-flex px-2 py-1 rounded-full text-xs font-semibold capitalize ${getStatusColor(transaction.status)}`}>
                              {transaction.status}
                            </span>
                          </div>

                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">Transaction ID</span>
                              <span className="text-sm font-mono text-gray-900">{transaction?.txn_id}</span>
                            </div>

                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">Amount</span>
                              <div className="flex items-center space-x-1">
                                <FaRupeeSign className="text-blue-600 text-sm" />
                                <span className="font-semibold text-gray-900">{transaction.amount?.toLocaleString()}</span>
                              </div>
                            </div>

                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">Date & Time</span>
                              <span className="text-sm text-gray-900">{formatDate(transaction.created_at)}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </>
            )}

            {/* Pagination */}
            {transactions && transactions.length > 0 && (
              <div className="mt-8 flex justify-center">
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                  <Pagination
                    itemClass="page-item"
                    linkClass="page-link"
                    activePage={currPage}
                    itemsCountPerPage={total_transactions_per_page}
                    totalItemsCount={totalTransactions}
                    pageRangeDisplayed={window.innerWidth < 768 ? 3 : 5}
                    onChange={handlePageChange}
                    hideDisabled={true}
                    hideNavigation={window.innerWidth < 768}
                  />
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <style jsx>{`
                .page-item {
                    margin: 0 2px;
                }
                
                .page-link {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    width: 40px;
                    height: 40px;
                    border: 1px solid #e5e7eb;
                    color: #6b7280;
                    text-decoration: none;
                    border-radius: 8px;
                    transition: all 0.2s ease;
                    font-weight: 500;
                }
                
                .page-link:hover {
                    background-color: #f3f4f6;
                    border-color: #d1d5db;
                    color: #374151;
                }
                
                .page-item.active .page-link {
                    background-color: #3b82f6;
                    border-color: #3b82f6;
                    color: white;
                }
                
                .page-item.disabled .page-link {
                    opacity: 0.5;
                    cursor: not-allowed;
                }
                
                @media (max-width: 768px) {
                    .page-link {
                        width: 36px;
                        height: 36px;
                        font-size: 14px;
                    }
                }
            `}</style>
    </div>
  );
};

export default Transactions;