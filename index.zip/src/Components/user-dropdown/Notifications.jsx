import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { IoNotifications } from 'react-icons/io5';
import Pagination from 'react-js-pagination';
import api from '../../api/api';
import Loader from '../loader/Loader';
import coverImg from '../../utils/cover-img.jpg';
import No_Notification from '../../utils/zero-state-screens/No_Notification.svg';
import { Link } from 'react-router-dom';
import { setNotification } from '../../model/reducer/notificationReducer';
import { formatNotificationDate } from '../../utils/formatDate';
import { ValidateNoInternet } from '../../utils/NoInternetValidator';
import { MdSignalWifiConnectedNoInternet0 } from 'react-icons/md';

const Notifications = () => {
  const user = useSelector(state => state.user);
  const setting = useSelector(state => state.setting);
  const dispatch = useDispatch();

  const total_notification_per_page = 10;
  const [totalNotification, setTotalNotification] = useState(null);
  const [currPage, setCurrPage] = useState(1);
  const [notification, setNotifications] = useState(null);
  const [offset, setOffset] = useState(0);
  const [isLoader, setIsLoader] = useState(false);
  const [isNetworkError, setIsNetworkError] = useState(false);

  const fetchNotification = () => {
    api.getNotification(user?.jwtToken, total_notification_per_page, offset)
      .then(response => response.json())
      .then(result => {
        if (result.status === 1) {
          setIsLoader(false);
          dispatch(setNotification({ data: result.data }));
          setNotifications(result.data);
          setTotalNotification(result.total);
        }
      })
      .catch(error => {
        const isNoInternet = ValidateNoInternet(error);
        if (isNoInternet) {
          setIsNetworkError(isNoInternet);
        }
      });
  };

  useEffect(() => {
    setIsLoader(true);
    fetchNotification();
  }, [offset]);

  const handlePageChange = (pageNum) => {
    setCurrPage(pageNum);
    setOffset(pageNum * total_notification_per_page - total_notification_per_page);
  };

  const placeHolderImage = (e) => {
    e.target.src = setting.setting?.web_logo;
  };

  if (isNetworkError) {
    return (
      <div className="flex flex-col items-center justify-center h-screen">
        <MdSignalWifiConnectedNoInternet0 className="text-6xl text-gray-500" />
        <p className="mt-4 text-lg text-gray-600">No internet connection</p>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Cover Section */}
      <div className="relative">
        <img src={coverImg} className="w-full h-64 object-cover" alt="cover" />
        <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col justify-center items-center">
          <h3 className="text-3xl font-bold text-white">Notifications</h3>
          <div className="text-white mt-2">
            <Link to="/" className="hover:underline">Home / </Link>
            <span className="font-semibold">Notifications</span>
          </div>
        </div>
      </div>

      {/* Notification Content */}
      {notification === null ? (
        <div className="flex justify-center items-center py-20">
          <Loader width="100%" height="500px" background="bg-gray-100" />
        </div>
      ) : (
        <div className="container mx-auto px-4 py-8">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold">All Notifications</h2>
            </div>

            {notification.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12">
                <img src={No_Notification} className="w-64 h-64" alt="no-notification" />
                <p className="mt-4 text-gray-500">You have no notifications yet.</p>
              </div>
            ) : (
              <>
                {isLoader ? (
                  <div className="flex justify-center items-center py-20">
                    <Loader width="100%" height="300px" />
                  </div>
                ) : (
                  <div className="divide-y divide-gray-200">
                    {notification.map((ntf, index) => (
                      <div key={index} className="flex flex-col md:flex-row p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex-shrink-0 mb-4 md:mb-0 md:mr-4">
                          {ntf.image_url === "" ? (
                            <div className="flex items-center justify-center w-16 h-16 rounded-full bg-blue-500">
                              <IoNotifications className="text-white text-2xl" />
                            </div>
                          ) : (
                            <img 
                              onError={placeHolderImage} 
                              src={ntf.image_url} 
                              alt="notification" 
                              className="w-16 h-16 object-cover rounded"
                            />
                          )}
                        </div>
                        <div className="flex-grow">
                          <p className="font-semibold">{ntf.title}</p>
                          <p className="text-gray-600 mt-1">{ntf.message}</p>
                          <Link className="text-blue-500 hover:underline mt-2 inline-block">
                            Go to products
                          </Link>
                        </div>
                        <div className="flex-shrink-0 mt-4 md:mt-0 md:ml-4 text-right">
                          <div className="text-sm text-gray-500">
                            {formatNotificationDate(ntf.date_sent)}
                          </div>
                          <div className="text-sm text-gray-400">
                            {ntf.date_sent.split(" ")[1]}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {notification.length !== 0 && (
                  <div className="px-6 py-4 border-t border-gray-200">
                    <Pagination
                      innerClass="flex justify-center space-x-2"
                      itemClass="px-3 py-1 rounded-md border border-gray-300 hover:bg-gray-100"
                      activeClass="bg-blue-500 text-white border-blue-500"
                      disabledClass="opacity-50 cursor-not-allowed"
                      activePage={currPage}
                      itemsCountPerPage={total_notification_per_page}
                      totalItemsCount={totalNotification}
                      pageRangeDisplayed={5}
                      onChange={handlePageChange}
                    />
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Notifications;
