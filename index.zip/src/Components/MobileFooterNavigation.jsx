import { Home, Menu, ShoppingBag, User, ShoppingCart } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import React from 'react';

export default function MobileFooterNavigation() {
    const { user, status } = useSelector((state) => state.user);
    const location = useLocation();

    const cartCount = useSelector((state) => {
        if (state?.cart?.isGuest) {
            return state.cart?.guestCart?.length || 0;
        } else {
            return state.cart?.cartProducts?.length || 0;
        }
    });

    const navItems = [
        { icon: <Home size={24} />, label: 'Home', href: '/' },
        { icon: <Menu size={24} />, label: 'Categories', href: '/desktop-category-carousel' },
        { icon: <ShoppingBag size={24} />, label: 'Deals', href: '/deals' },
        {
            icon: <User size={24} />,
            label: 'Account',
            href: status === 'fulfill' && user ? '/myAccount' : '/login',
        },
        {
            icon: <ShoppingCart size={24} />,
            label: 'Cart',
            href: '/cart',
            badge: cartCount > 0 ? cartCount : null,
        },
    ];

    return (
        <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-lg">
            <div className="flex justify-between items-center px-4 py-3">
                {navItems.map((item, index) => {
                    const isActive = location.pathname === item.href;

                    return (
                        <Link
                            key={index}
                            to={item.href}
                            className={`flex flex-col items-center relative px-2 py-1 rounded-lg transition-colors ${isActive
                                    ? 'bg-[rgba(252,46,107,0.93)] text-white'
                                    : 'hover:bg-gray-50 text-gray-600'
                                }`}
                        >
                            <div className="relative">
                                {React.cloneElement(item.icon, {
                                    className: `w-6 h-6 ${isActive ? 'text-white' : 'text-gray-600'}`
                                })}
                                {item.badge && (
                                    <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                                        {item.badge}
                                    </span>
                                )}
                            </div>
                            <span className={`text-xs mt-1 ${isActive ? 'text-white' : 'text-gray-600'}`}>
                                {item.label}
                            </span>
                        </Link>
                    );
                })}
            </div>
        </nav>
    );
}
