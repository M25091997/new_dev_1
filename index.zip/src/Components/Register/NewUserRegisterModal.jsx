"use client"

import { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { toast } from "react-toastify"
import { setCurrentUser, setAuthType } from "../../model/reducer/authReducer"
import {
    clearCart,
    setIsGuest,
    setCart,
    setCartProducts,
    setCartSubTotal,
    setGuestCartTotal,
    addtoGuestCart,
} from "../../model/reducer/cartReducer"
import { setTokenThunk } from "../../model/thunk/loginThunk"
import * as newApi from "../../api/apiCollection"
import { setSetting } from "../../model/reducer/settingReducer"
import { setFavouriteLength, setFavouriteProducts } from "../../model/reducer/favouriteReducer"
import { useNavigate } from "react-router-dom"
import api from "../../api/api"
import { X, User, Mail, Phone, CheckCircle, AlertCircle, Sparkles } from "lucide-react"

function NewUserRegisterModal({
    show,
    onClose,
    mobileNumber,
    email,
    setEmail,
    name,
    setName,
    loading,
    authType,
    fcmToken,
}) {
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const city = useSelector((state) => state.city)
    const setting = useSelector((state) => state.setting)
    const cart = useSelector((state) => state.cart)
    const [error, setError] = useState("")

    useEffect(() => {
        console.log("Modal props:", {
            show,
            mobileNumber,
            email,
            name,
            loading,
            authType,
            fcmToken,
        })
    }, [show, mobileNumber, email, name, loading, authType, fcmToken])

    const fetchCart = async (latitude, longitude) => {
        try {
            const response = await newApi.getCart({ latitude, longitude })
            if (response.status === 1) {
                dispatch(setCart({ data: response.data }))
                const productsData = response.data.cart.map((product) => ({
                    product_id: product.product_id,
                    product_variant_id: product.product_variant_id,
                    qty: product.qty,
                }))
                dispatch(setCartProducts({ data: productsData }))
                dispatch(setCartSubTotal({ data: response.data.sub_total }))
            } else {
                dispatch(setCart({ data: null }))
            }
        } catch (error) {
            console.error("Error fetching cart:", error)
        }
    }

    const getCurrentUser = async () => {
        try {
            const response = await newApi.getUser()
            dispatch(setCurrentUser({ data: response.user }))
        } catch (error) {
            console.error("Error getting user:", error)
        }
    }

    const handleFetchSetting = async () => {
        try {
            const setting = await newApi.getSetting()
            dispatch(setSetting({ data: setting?.data }))
            dispatch(setFavouriteLength({ data: setting?.data?.favorite_product_ids?.length }))
            dispatch(setFavouriteProducts({ data: setting?.data?.favorite_product_ids }))
        } catch (error) {
            console.error("Error fetching settings:", error)
        }
    }

    const addToCartBulk = async (token) => {
        try {
            const variantIds = cart?.guestCart?.map((p) => p.product_variant_id)
            const quantities = cart?.guestCart?.map((p) => p.qty)
            const response = await api.bulkAddToCart(token, variantIds.join(","), quantities.join(","))
            const result = await response.json()

            if (result.status === 1) {
                dispatch(setGuestCartTotal({ data: 0 }))
                dispatch(addtoGuestCart({ data: [] }))
            }
        } catch (error) {
            console.error("Error adding bulk cart:", error)
        }
    }

    const handleRegister = async (e) => {
        e.preventDefault()
        try {
            if (!name) {
                setError("please_enter_name")
                return
            }

            const registerPayload = {
                name: name,
                email: email || "",
                mobile: mobileNumber,
                country_code: "+91",
                fcm: fcmToken || "",
                type: authType || "phone",
                platform: "web",
            }

            const res = await newApi.registerUser(registerPayload)
            const result = await res

            if (result.status === 1) {
                const tokenSet = await dispatch(setTokenThunk(result.data.access_token))
                await getCurrentUser()
                dispatch(setAuthType({ data: authType || "phone" }))

                dispatch(clearCart())
                dispatch(setIsGuest(false))

                const latitude = city?.city?.latitude || setting?.setting?.default_city?.latitude
                const longitude = city?.city?.longitude || setting?.setting?.default_city?.longitude
                await fetchCart(latitude, longitude)

                if (cart?.guestCart?.length > 0) {
                    await addToCartBulk(result.data.access_token)
                }

                await handleFetchSetting()
                toast.success("register_successfully")

                onClose()
                navigate("/")
            } else {
                setError(result.message || "registration_failed")
            }
        } catch (error) {
            console.error("Registration error:", error)
            setError("registration_failed")
        }
    }

    if (!show) return null

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-md">
            <div className="relative w-full max-w-lg mx-auto animate-in fade-in-0 zoom-in-95 duration-300 max-h-[90vh] overflow-y-auto rounded-3xl">
                {/* Modal Container */}
                <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-gray-100">
                    {/* Decorative Header Background */}
                    <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-br from-[#fc2e6bed] via-[#fc2e6bed] to-pink-400 opacity-10"></div>

                    {/* Close Button */}
                    <button
                        onClick={onClose}
                        className="absolute top-6 right-6 z-10 p-2 hover:bg-gray-100 rounded-full transition-all duration-200 group"
                    >
                        <X className="w-5 h-5 text-gray-500 group-hover:text-gray-700" />
                    </button>

                    {/* Header */}
                    <div className="relative px-8 pt-12 pb-8 text-center">
                        <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#fc2e6bed] to-pink-500 rounded-2xl mb-6 shadow-lg">
                            <Sparkles className="w-10 h-10 text-white" />
                        </div>
                        <h2 className="text-3xl font-bold text-gray-900 mb-3">Welcome Aboard!</h2>
                        <p className="text-gray-600 text-lg">Complete your registration to get started</p>
                    </div>

                    {/* Form Content */}
                    <div className="px-8 pb-8">
                        {error && (
                            <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl animate-in slide-in-from-top-2 duration-300">
                                <div className="flex items-center">
                                    <div className="flex-shrink-0">
                                        <AlertCircle className="w-5 h-5 text-red-500" />
                                    </div>
                                    <p className="ml-3 text-red-800 text-sm font-medium">{error}</p>
                                </div>
                            </div>
                        )}

                        <form onSubmit={handleRegister} className="space-y-6">
                            {/* Mobile Number Field */}
                            <div className="space-y-3">
                                <label className="flex items-center text-sm font-semibold text-gray-800">
                                    <div className="flex items-center justify-center w-5 h-5 bg-[#fc2e6bed] rounded-full mr-3">
                                        <Phone className="w-3 h-3 text-white" />
                                    </div>
                                    Mobile Number
                                </label>
                                <div className="relative">
                                    <input
                                        type="text"
                                        value={mobileNumber}
                                        readOnly
                                        className="w-full px-5 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl text-gray-700 font-medium focus:outline-none cursor-not-allowed text-lg"
                                    />
                                    <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                                        <div className="flex items-center justify-center w-6 h-6 bg-green-100 rounded-full">
                                            <CheckCircle className="w-4 h-4 text-green-600" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Full Name Field */}
                            <div className="space-y-3">
                                <label className="flex items-center text-sm font-semibold text-gray-800">
                                    <div className="flex items-center justify-center w-5 h-5 bg-[#fc2e6bed] rounded-full mr-3">
                                        <User className="w-3 h-3 text-white" />
                                    </div>
                                    Full Name
                                    <span className="text-[#fc2e6bed] ml-1 text-base">*</span>
                                </label>
                                <input
                                    type="text"
                                    value={name}
                                    onChange={(e) => {
                                        setError("")
                                        setName(e.target.value)
                                    }}
                                    placeholder="Enter your full name"
                                    className="w-full px-5 py-4 border-2 border-gray-200 rounded-2xl focus:outline-none focus:border-[#fc2e6bed] focus:ring-4 focus:ring-[#fc2e6bed]/10 transition-all duration-200 disabled:bg-gray-50 disabled:cursor-not-allowed text-lg placeholder:text-gray-400"
                                    required
                                    disabled={authType === "google"}
                                />
                            </div>

                            {/* Email Field */}
                            <div className="space-y-3">
                                <label className="flex items-center text-sm font-semibold text-gray-800">
                                    <div className="flex items-center justify-center w-5 h-5 bg-[#fc2e6bed] rounded-full mr-3">
                                        <Mail className="w-3 h-3 text-white" />
                                    </div>
                                    Email Address
                                    {authType === "google" && <span className="text-[#fc2e6bed] ml-1 text-base">*</span>}
                                    {authType !== "google" && (
                                        <span className="ml-2 px-2 py-1 bg-gray-100 text-gray-500 text-xs rounded-full">Optional</span>
                                    )}
                                </label>
                                <input
                                    type="email"
                                    value={email}
                                    onChange={(e) => {
                                        setError("")
                                        setEmail(e.target.value)
                                    }}
                                    placeholder="Enter your email address"
                                    className={`w-full px-5 py-4 border-2 border-gray-200 rounded-2xl focus:outline-none focus:border-[#fc2e6bed] focus:ring-4 focus:ring-[#fc2e6bed]/10 transition-all duration-200 text-lg placeholder:text-gray-400 ${authType === "google" ? "bg-gray-50 cursor-not-allowed" : ""
                                        }`}
                                    required={authType === "google"}
                                    disabled={authType === "google"}
                                />
                            </div>

                            {/* Submit Button */}
                            <div className="pt-4">
                                <button
                                    type="submit"
                                    disabled={!name || loading}
                                    className={`w-full py-5 px-6 rounded-2xl text-white font-bold text-lg transition-all duration-300 transform ${!name || loading
                                        ? "bg-gray-300 cursor-not-allowed"
                                        : "bg-gradient-to-r from-[#fc2e6bed] to-pink-500 hover:from-[#e8296a] hover:to-pink-600 hover:shadow-xl hover:shadow-[#fc2e6bed]/25 hover:scale-[1.02] active:scale-[0.98] shadow-lg"
                                        }`}
                                >
                                    {loading ? (
                                        <div className="flex items-center justify-center">
                                            <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin mr-3"></div>
                                            Creating Your Account...
                                        </div>
                                    ) : (
                                        <div className="flex items-center justify-center">
                                            <CheckCircle className="w-6 h-6 mr-3" />
                                            Complete Registration
                                        </div>
                                    )}
                                </button>
                            </div>
                        </form>

                        {/* Footer */}
                        <div className="mt-8 pt-6 border-t border-gray-100">
                            <p className="text-center text-sm text-gray-500 leading-relaxed">
                                By registering, you agree to our <span className="text-[#fc2e6bed] font-medium">Terms of Service</span>{" "}
                                and <span className="text-[#fc2e6bed] font-medium">Privacy Policy</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default NewUserRegisterModal
