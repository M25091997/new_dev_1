import { useEffect, useState } from 'react';
import { useDisclosure } from "@mantine/hooks";
import { Modal } from "@mantine/core";
import { useSelector } from 'react-redux';
import Location from "../Locations/Location";

function SetDeliveryLocations({
  children,
  isOpen = false,
  onClose = () => { },
  onSuccess = () => { },
  locationPermission = null,
  forceOpen = false,
  firstVisit = false
}) {
  const [opened, { open, close: closeModal }] = useDisclosure(false);
  const [isLocationPresent, setIsLocationPresent] = useState(false);

  useEffect(() => {
    if (isOpen || forceOpen) {
      open();
    } else {
      closeModal();
    }
  }, [isOpen, forceOpen, open, closeModal]);

  const handleClose = () => {
    if (!firstVisit) {
      closeModal();
      onClose();
    }
  };

 const handleSuccess = () => {
  setIsLocationPresent(true);
  onSuccess();
  // Only close if it's not forced open or first visit
  if (!forceOpen && !firstVisit) {
    closeModal();
  }
};

  return (
    <>
      <Modal
        opened={opened}
        onClose={handleClose}
        title={firstVisit ? "" : "Set Delivery Location"} // Hide title for first visit
        centered
        overlayProps={{
          backgroundOpacity: 0.55,
          blur: 3,
        }}
        closeOnClickOutside={!firstVisit}
        withCloseButton={!firstVisit} // Hide close button for first visit
        closeOnEscape={!firstVisit} // Disable escape for first visit
        size="lg"
      >
        <Location
          isLocationPresent={isLocationPresent}
          setIsLocationPresent={setIsLocationPresent}
          open={open}
          setLocModal={true}
          close={handleSuccess}
          locationPermission={locationPermission}
          forceOpen={forceOpen || firstVisit}
        />
      </Modal>
      {children && <div onClick={open}>{children}</div>}
    </>
  );
}

export default SetDeliveryLocations;