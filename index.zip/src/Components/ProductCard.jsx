import { useState } from "react"
import { Heart, ShoppingCart, Eye, Star, Package, Truck } from "lucide-react"
import { Link, useNavigate } from "react-router-dom"
import { useDispatch, useSelector } from "react-redux"
import {
  addtoGuestCart,
  setCart,
  setCartProducts,
  setCartSubTotal,
  updateGuestCartItemQuantity,
} from "../model/reducer/cartReducer"
import { addFavoriteProduct, removeFavoriteProduct } from "../model/reducer/favouriteReducer"
import { Toast } from "./Toast/Toast"
import api from "../api/api"
import { toast } from "react-toastify"

const ProductCard = ({ product, isMobile, gradient = "from-emerald-500 to-teal-600" }) => {
  const dispatch = useDispatch()
  const navigate = useNavigate()


  if (!product) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-4 text-center">
        <p className="text-gray-500">Product not available</p>
      </div>
    );
  }

  // State variables
  const [showCartToast, setShowCartToast] = useState(false)
  const [showWishlistToast, setShowWishlistToast] = useState(false)
  const [showLoginCartToast, setShowLoginCartToast] = useState(false)
  const [showLoginWishlistToast, setShowLoginWishlistToast] = useState(false)
  const [isAddingToCart, setIsAddingToCart] = useState(false)
  const [isFavoriteLoading, setIsFavoriteLoading] = useState(false)
  const [isHovered, setIsHovered] = useState(false)
  const [selectedVariantId, setSelectedVariantId] = useState(product.variants?.[0]?.id || null)
  const [isNavigating, setIsNavigating] = useState(false) // New state for navigation loading

  // Redux selectors
  const { favouriteProducts } = useSelector((state) => state.favourite)
  const { guestCart, isGuest, cartProducts } = useSelector((state) => state.cart)
  const { user, status, jwtToken } = useSelector((state) => state.user)
  const { city } = useSelector((state) => state.city)

  // Get IDs with proper fallbacks
  const product_id = product.product_id || product.id
  const variantId = selectedVariantId

  // Find the selected variant
  const selectedVariant = product.variants?.find((v) => v.id === variantId) || product

  const stock = selectedVariant?.stock || product.stock || 0
  const isUnlimitedStock = product.is_unlimited_stock || false
  const isOutOfStock = !isUnlimitedStock && stock <= 0

  const isFavorite = favouriteProducts?.some((p) => p.id === product_id)
  const isLoggedIn = status === "fulfill" && jwtToken

  // Get cart item count
  const cartItem = isLoggedIn
    ? cartProducts?.find((item) => item.product_variant_id === variantId && item.product_id === product_id)
    : guestCart?.find((item) => item.product_variant_id === variantId && item.product_id === product_id)

  const cartItemCount = cartItem?.quantity || 0

  const handleAddToCart = async (e) => {
    e.preventDefault()
    e.stopPropagation()

    if (!product_id || !variantId) {
      console.error("Product ID missing:", {
        product_id: product_id,
        product_variant_id: variantId,
        full_product: product,
      })
      toast.error("Please try again. Product information is loading...")
      return
    }

    // Use selected variant's price if available
    const price = selectedVariant?.price || product.price || 0
    const discounted_price = selectedVariant?.discounted_price || product.discounted_price || price

    // Handle logged-in user
    if (isLoggedIn) {
      setIsAddingToCart(true)
      try {
        const response = await api.addToCart(jwtToken, product_id, variantId, 1)

        const result = await response.json()

        if (result?.status === 1) {
          setShowCartToast(true)
          setTimeout(() => setShowCartToast(false), 3000)

          // Create updated cart item with new quantity
          const updatedCartItem = {
            id: `${product_id}_${variantId}`,
            product_id: product_id,
            product_variant_id: variantId,
            name: product.name,
            price: price,
            discounted_price: discounted_price,
            image: product.image || product.image_url,
            measurement: selectedVariant?.measurement || product.measurement || "1",
            unit_code: selectedVariant?.stock_unit_name || product.stock_unit_name || "PC",
            quantity: (cartItem?.quantity || 0) + 1,
            status: selectedVariant?.status || product.status || 1,
            stock: selectedVariant?.stock || product.stock || 0,
            is_unlimited_stock: product.is_unlimited_stock || 0,
            total_allowed_quantity: product.total_allowed_quantity || 10000,
            slug: product.slug || `product-${product_id}`,
          }

          // Update Redux state immediately
          const existingItemIndex =
            cartProducts?.findIndex(
              (item) => item.product_variant_id === variantId && item.product_id === product_id,
            ) || -1

          let updatedCart
          if (existingItemIndex >= 0) {
            updatedCart = [...cartProducts]
            updatedCart[existingItemIndex] = updatedCartItem
          } else {
            updatedCart = [...(cartProducts || []), updatedCartItem]
          }

          dispatch(setCartProducts({ data: updatedCart }))

          // Calculate new subtotal
          const newSubtotal = updatedCart.reduce((total, item) => {
            const itemPrice = item.discounted_price > 0 ? item.discounted_price : item.price
            return total + itemPrice * item.quantity
          }, 0)

          dispatch(setCartSubTotal({ data: newSubtotal }))

          // Fetch updated cart data from server
          const cartResponse = await api.getCart(
            jwtToken,
            city?.city?.latitude || 28.6139,
            city?.city?.longitude || 77.209,
          )
          const cartResult = await cartResponse.json()

          if (cartResult?.status === 1) {
            dispatch(setCart({ data: cartResult }))
          }
        } else {
          toast.error(result.message || "Failed to add to cart")
        }
      } catch (error) {
        console.error("Cart error:", error)
        toast.error(error.message || "Failed to add to cart")
      } finally {
        setIsAddingToCart(false)
      }
      return
    }

    // Handle guest user
    if (isGuest) {
      const cartItem = {
        id: `${product_id}_${variantId}`,
        product_id: product_id,
        product_variant_id: variantId,
        name: product.name,
        price: price,
        discounted_price: discounted_price,
        image: product.image || product.image_url,
        measurement: selectedVariant?.measurement || product.measurement || "1",
        unit_code: selectedVariant?.stock_unit_name || product.stock_unit_name || "PC",
        quantity: 1,
        status: selectedVariant?.status || product.status || 1,
        stock: selectedVariant?.stock || product.stock || 0,
        is_unlimited_stock: product.is_unlimited_stock || 0,
        total_allowed_quantity: product.total_allowed_quantity || 10000,
        slug: product.slug || `product-${product_id}`,
      }

      const existingItem = guestCart?.find(
        (item) => item.product_id === product_id && item.product_variant_id === variantId,
      )

      if (existingItem) {
        const newQuantity = existingItem.quantity + 1
        if (newQuantity > (existingItem.total_allowed_quantity || 10000)) {
          toast.error("Maximum quantity reached")
          return
        }

        dispatch(
          updateGuestCartItemQuantity({
            id: existingItem.id,
            quantity: newQuantity,
            price: existingItem.price,
            discounted_price: existingItem.discounted_price,
          }),
        )
      } else {
        dispatch(addtoGuestCart({ data: cartItem }))
      }

      setShowCartToast(true)
      setTimeout(() => setShowCartToast(false), 3000)
      return
    }

    // If not logged in and not guest
    setShowLoginCartToast(true)
    setTimeout(() => setShowLoginCartToast(false), 3000)
  }
  const handleWishlistAction = async (e) => {
    e.preventDefault()
    e.stopPropagation()

    if (!isLoggedIn) {
      setShowLoginWishlistToast(true)
      setTimeout(() => setShowLoginWishlistToast(false), 3000)
      return
    }

    setIsFavoriteLoading(true)
    try {
      if (isFavorite) {
        // Remove from favorites
        await api.removeFromFavorite(jwtToken, product_id)
        dispatch(removeFavoriteProduct({ data: product_id }))
        toast.success("Item Removed from Wishlist")
      } else {
        // Add to favorites
        const response = await api.addToFavotite(jwtToken, product_id)

        const result = await response.json()

        if (result?.status === 1) {
          dispatch(
            addFavoriteProduct({
              data: {
                ...product,
                id: product.id || product.product_id,
                image_url: product.image_url || product.image, // Ensure image_url is set
                slug: product.slug || `product-${product_id}`, // Ensure slug exists
              },
            }),
          )
          toast.success("Added to Wishlist ❤️")
          setTimeout(() => setShowWishlistToast(false), 3000)
        } else {
          toast.error(result.message || "Failed to add to favorites")
        }
      }
    } catch (error) {
      console.error("Favorite error:", error)
      toast.error("Failed to update favorites")
    } finally {
      setIsFavoriteLoading(false)
    }
  }

  const handleProductClick = async (e) => {
    e.preventDefault()
    setIsNavigating(true)

    try {
      const response = await api.getProductbyId(
        city?.city?.latitude || 28.6139,
        city?.city?.longitude || 77.209,
        product_id,
        jwtToken,
        product.slug,
      )

      const result = await response.json()

      const safeProductData = {
        ...(result.data || product), // Fallback to the original product if no API data
        id: product_id,
        name: product.name,
        slug: product.slug,
        // Ensure image properties exist
        image: product.image || product.image_url || "/placeholder.svg",
        image_url: product.image_url || product.image || "/placeholder.svg",
        images: product.images || [product.image || product.image_url || "/placeholder.svg"],
        // Ensure seller data exists
        seller: product.seller || null,
        seller_name: product.seller?.name || product.seller_name || "",
        seller_image_url: product.seller?.image_url || "",
        // Ensure variants exist
        variants: product.variants || [],
      }

      navigate(`/product/${product.slug}`, {
        state: {
          product: safeProductData,
          breadcrumbs: [
            { name: "Home", path: "/" },
            { name: result.data?.category?.name || product.category || "Category", path: "#" },
            { name: result.data?.name || product.name, path: null },
          ],
        },
      })
    } catch (error) {
      console.error("Failed to fetch product details:", error)
      // Fallback with safe data
      navigate(`/product/${product.slug}`, {
        state: {
          product: {
            id: product_id,
            name: product.name,
            slug: product.slug,
            image: product.image || product.image_url || "/placeholder.svg",
            image_url: product.image_url || product.image || "/placeholder.svg",
            price: product.price,
            discounted_price: product.discounted_price,
            seller_name: product.seller?.name || "",
            seller_image_url: product.seller?.image_url || "",
            variants: product.variants || [],
          },
          breadcrumbs: [
            { name: "Home", path: "/" },
            { name: product.category || "Category", path: "#" },
            { name: product.name, path: null },
          ],
        },
      })
    } finally {
      setIsNavigating(false)
    }
  }

  // Mobile Design - Enhanced App-like Experience
  if (isMobile) {
    return (
      <>
        {/* Navigation Loader */}
        {isNavigating && (
          <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
          </div>
        )}

        <div className="bg-white rounded-xl shadow-lg w-full max-w-[140px] relative overflow-hidden transform transition-transform duration-300 active:scale-95 touch-manipulation">
          {/* Toast Components */}
          {showCartToast && <Toast message="🛒 Added to cart!" type="success" duration={3000} position="top-right" />}
          {showLoginCartToast && (
            <Toast message="🛑 Please login to add product to cart!" type="error" duration={3000} position="top-right" />
          )}
          {showLoginWishlistToast && (
            <Toast
              message="🛑 Please login to add product to wishlist!"
              type="error"
              duration={3000}
              position="top-right"
            />
          )}

          {/* Product Image */}
          <div className="relative">
            <Link to={`/product/${product.slug}`} onClick={handleProductClick} state={{ product }} className="block">
              <div className="relative pt-[100%] overflow-hidden bg-gray-50 rounded-t-xl">
                {/* Out of Stock Badge */}
                {isOutOfStock && (
                  <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] flex items-center justify-center z-10">
                    <span className="bg-white text-red-600 text-[10px] font-bold px-2 py-1 rounded-full shadow-md">
                      Out of Stock
                    </span>
                  </div>
                )}
                <img
                  src={product.image || "/placeholder.svg"}
                  className="absolute top-0 left-0 w-full h-full object-cover transition-all duration-300 hover:scale-105"
                  alt={product.name}
                  onError={(e) => {
                    e.target.onerror = null
                    e.target.src = "/placeholder-product.png"
                  }}
                />

                {/* Discount Badge */}
                {product.discount > 0 && (
                  <div className="absolute top-1 left-1">
                    <div
                      className={`bg-gradient-to-r ${gradient} text-white px-1.5 py-0.5 text-[10px] font-bold rounded-full shadow-md`}
                    >
                      -{product.discount}%
                    </div>
                  </div>
                )}
              </div>
            </Link>

            {/* Heart Icon - Enhanced with animation */}
            <button
              onClick={handleWishlistAction}
              className="absolute top-1 right-1 bg-white/90 backdrop-blur-sm rounded-full p-1.5 shadow-md transform transition-transform active:scale-90"
              disabled={isFavoriteLoading}
              aria-label={isFavorite ? "Remove from wishlist" : "Add to wishlist"}
            >
              <Heart
                className={`w-3 h-3 ${isFavorite ? "text-rose-500 fill-rose-500" : "text-gray-400"
                  } ${isFavoriteLoading ? "opacity-50" : ""} transition-all duration-300`}
                strokeWidth={isFavorite ? 2.5 : 2}
              />
            </button>
          </div>

          {/* Product Info - Enhanced with better spacing and shadows */}
          <div className="p-2.5">
            {/* Product Name - Single Line with Ellipsis */}
            <Link to={`/product/${product.slug}`} onClick={handleProductClick} state={{ product }} className="block">
              <h3 className="text-gray-800 font-medium text-xs leading-tight mb-0.5 truncate" title={product.name}>
                {product.name}
              </h3>
            </Link>

            {/* Seller Info (Simplified) */}
            {product.seller && (
              <div className="text-[8px] text-gray-500 mb-1.5 flex items-center">
                <span className="inline-block w-1 h-1 rounded-full bg-green-500 mr-0.5"></span>
                <span className="truncate">{product.seller}</span>
              </div>
            )}

            {/* Price Section - Enhanced with better spacing */}
            <div className="flex items-center justify-between mt-1">
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-1">
                  <span className="font-bold text-gray-900 text-xs">
                    ₹{product.discounted_price > 0 ? product.discounted_price : product.price}
                  </span>
                  {product.discounted_price > 0 && product.discounted_price !== product.price && (
                    <span className="text-gray-400 line-through text-[8px]">₹{product.price}</span>
                  )}
                </div>
              </div>

              {/* Cart Button - Enhanced with better shadows and animations */}
              <button
                onClick={handleAddToCart}
                disabled={isAddingToCart || isOutOfStock}
                className={`ml-1 p-1.5 rounded-full relative transition-all duration-200 transform active:scale-90 flex-shrink-0
                  ${isOutOfStock
                    ? "bg-gray-100 cursor-not-allowed"
                    : cartItemCount > 0
                      ? "bg-emerald-100 text-emerald-600 shadow-md shadow-emerald-100"
                      : "bg-gray-50 hover:bg-gray-100 text-gray-600 border border-gray-200 shadow-md"
                  }`}
                aria-label="Add to cart"
              >
                {isAddingToCart ? (
                  <span className="inline-block w-3 h-3 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></span>
                ) : (
                  <>
                    <ShoppingCart
                      className={`w-3 h-3 ${isOutOfStock ? "text-gray-400" : cartItemCount > 0 ? "text-emerald-600" : "text-gray-600"
                        }`}
                    />
                    {cartItemCount > 0 && !isOutOfStock && (
                      <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[8px] font-medium rounded-full w-3.5 h-3.5 flex items-center justify-center shadow-sm">
                        {cartItemCount}
                      </span>
                    )}
                  </>
                )}
              </button>
            </div>

            {/* Delivery Badges - Enhanced with better shadows */}
            {(product.free_delivery || product.express) && (
              <div className="flex gap-1 mt-1.5">
                {product.free_delivery && (
                  <div className="flex items-center text-emerald-700 text-[8px] font-medium bg-emerald-50 px-1.5 py-0.5 rounded-full shadow-sm">
                    <Package className="w-2 h-2 mr-0.5" />
                    <span>Free</span>
                  </div>
                )}
                {product.express && (
                  <div className="flex items-center text-purple-700 text-[8px] font-medium bg-purple-50 px-1.5 py-0.5 rounded-full shadow-sm">
                    <Truck className="w-2 h-2 mr-0.5" />
                    <span>Express</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </>
    )
  }

  // Desktop Design - Enhanced with better shadows and animations
  return (
    <>
      {/* Navigation Loader */}
      {isNavigating && (
        <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
        </div>
      )}

      <div
        className="relative bg-white rounded-xl overflow-hidden h-full transition-all duration-300 hover:shadow-xl border border-gray-100 hover:border-gray-200 group"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Toast Notifications */}
        {showCartToast && toast.success("Added to cart 🛒")}
        {showLoginCartToast && toast.error("🛑 Please login to add product to cart!")}
        {showLoginWishlistToast && toast.error("🛑 Please login to add product to wishlist!")}

        <div className="flex flex-col h-full">
          {/* Product Image */}
          <div className="relative pt-[80%] overflow-hidden">
            <Link to={`/product/${product.slug}`} onClick={handleProductClick} state={{ product }} className="block">
              {/* Out of Stock Overlay */}
              {isOutOfStock && (
                <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] flex items-center justify-center z-10">
                  <span className="bg-white text-red-600 text-xs font-bold px-2.5 py-1 rounded-full shadow-md">
                    Out of Stock
                  </span>
                </div>
              )}

              <div
                className={`absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 transition-opacity duration-300 ${isHovered ? "opacity-100" : ""
                  }`}
              ></div>
              <img
                src={product.image || product.image_url || "/placeholder.svg"}
                className="absolute top-0 left-0 w-full h-full object-cover transition-transform duration-500"
                alt={product.name}
                onError={(e) => {
                  e.target.onerror = null
                  e.target.src = "/placeholder-product.png"
                }}
              />
            </Link>

            {/* Heart Icon - Enhanced with better animation and shadow */}
            <button
              onClick={handleWishlistAction}
              className={`absolute top-3 right-3 z-10 bg-white rounded-full p-2 shadow-md transition-all duration-200 transform ${isHovered ? "scale-110" : "scale-100"
                }`}
              disabled={isFavoriteLoading}
              aria-label={isFavorite ? "Remove from wishlist" : "Add to wishlist"}
            >
              <Heart
                className={`w-4 h-4 ${isFavorite ? "text-rose-500 fill-rose-500" : "text-gray-400"
                  } ${isFavoriteLoading ? "opacity-50" : ""} transition-all duration-300`}
                strokeWidth={isFavorite ? 2.5 : 2}
              />
            </button>

            {/* Discount Badge - Enhanced with better shadow */}
            {product.discount > 0 && (
              <div className="absolute top-3 left-3 z-10">
                <div
                  className={`bg-gradient-to-r ${gradient} text-white px-2.5 py-1 text-xs font-bold rounded-full shadow-md`}
                >
                  -{product.discount}%
                </div>
              </div>
            )}

            {/* Rating Badge - Enhanced with better shadow */}
            {product.rating && (
              <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-sm rounded-full px-2.5 py-1 flex items-center shadow-md">
                <Star className="w-3.5 h-3.5 text-yellow-500 mr-1" fill="#f59e0b" />
                <span className="text-gray-700 text-xs font-medium">{product.rating}</span>
              </div>
            )}
          </div>

          {/* Product Info - Enhanced with better spacing and shadows */}
          <div className="p-4 flex-grow flex flex-col">
            {/* Product Name */}
            <Link
              to={`/product/${product.slug}`}
              onClick={handleProductClick}
              state={{ product }}
              className="block hover:text-emerald-600 transition duration-200"
            >
              <h3
                className="text-gray-800 font-medium text-sm leading-tight mb-1.5 line-clamp-2 group-hover:text-emerald-600 transition-colors duration-200"
                title={product.name}
              >
                {product.name}
              </h3>
            </Link>

            {/* Seller Info */}
            {product.seller && (
              <div className="text-xs text-gray-500 mb-2 flex items-center">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-green-500 mr-1"></span>
                <span className="truncate">{product.seller}</span>
              </div>
            )}

            {/* Delivery Badges - Enhanced with better shadows */}
            {(product.free_delivery || product.express) && (
              <div className="flex flex-wrap gap-1.5 mb-3">
                {product.free_delivery && (
                  <div className="flex items-center text-emerald-700 text-[10px] font-medium bg-emerald-50 px-2 py-0.5 rounded-full shadow-sm">
                    <Package className="w-2.5 h-2.5 mr-1" />
                    <span>Free Delivery</span>
                  </div>
                )}
                {product.express && (
                  <div className="flex items-center text-purple-700 text-[10px] font-medium bg-purple-50 px-2 py-0.5 rounded-full shadow-sm">
                    <Truck className="w-2.5 h-2.5 mr-1" />
                    <span>Express</span>
                  </div>
                )}
              </div>
            )}

            {/* Price Section - Enhanced with better spacing and shadows */}
            <div className="mt-auto pt-2.5 border-t border-gray-100">
              <div className="flex justify-between items-center">
                <div>
                  <div className="flex items-baseline gap-1.5">
                    <span className="font-bold text-gray-900 text-sm">
                      ₹{product.discounted_price > 0 ? product.discounted_price : product.price}
                    </span>
                    {product.discounted_price > 0 && product.discounted_price !== product.price && (
                      <span className="text-gray-500 line-through text-xs">₹{product.price}</span>
                    )}
                  </div>
                </div>

                {/* Cart Button - Enhanced with better shadows and animations */}
                <button
                  onClick={handleAddToCart}
                  className={`p-2 rounded-full relative transition-all duration-200 transform hover:scale-105 active:scale-95
                    ${isOutOfStock
                      ? "bg-gray-100 cursor-not-allowed"
                      : cartItemCount > 0
                        ? "bg-emerald-100 hover:bg-emerald-200 shadow-md shadow-emerald-100/50"
                        : "bg-white hover:bg-gray-50 border border-gray-200 shadow-md hover:shadow-lg"
                    }`}
                  disabled={isAddingToCart || isOutOfStock}
                  aria-label="Add to cart"
                >
                  {isAddingToCart ? (
                    <span className="inline-block w-4 h-4 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></span>
                  ) : (
                    <>
                      <ShoppingCart
                        className={`w-4 h-4 ${isOutOfStock ? "text-gray-400" : cartItemCount > 0 ? "text-emerald-600" : "text-gray-700"
                          }`}
                      />
                      {cartItemCount > 0 && !isOutOfStock && (
                        <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[10px] font-medium rounded-full w-4.5 h-4.5 flex items-center justify-center shadow-sm">
                          {cartItemCount}
                        </span>
                      )}
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default ProductCard