import { Drawer } from '@mantine/core';
import { Trash2, ShoppingBag, Plus, Minus } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { RiCoupon2Fill } from 'react-icons/ri';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import api from '../api/api';
import {
  clearCartPromo,
  removeFromGuestCart,
  setCart,
  setCartCheckout,
  setCartProducts,
  setCartSubTotal,
  setGuestCartTotal,
  updateCartItemQuantity,
  updateGuestCartItemQuantity,
  removeCartItem
} from '../model/reducer/cartReducer';
import { setPromoCode } from '../model/reducer/promoReducer';

const DEFAULT_LOCATION = {
  latitude: 28.6139,
  longitude: 77.2090
};

function CartSliderModal({ children }) {
  const [opened, setOpened] = useState(false);
  const { cart, guestCart, guestCartTotal, isGuest, cartProducts, cartSubTotal, checkout, promo_code } = useSelector((state) => state.cart);
  const { user, status, jwtToken } = useSelector((state) => state.user);
  const { city, setting } = useSelector((state) => state);
  const isLoggedIn = status === "fulfill" && jwtToken;
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [showPromoOffcanvas, setShowPromoOffcanvas] = useState(false);
  const [showModal, setShowModal] = useState(false);

  const subtotal = isGuest ? guestCartTotal : cartSubTotal;
  const currentLocation = city?.city || DEFAULT_LOCATION;

  const currentCartItems = isGuest ? guestCart : cartProducts;
  const showViewAll = currentCartItems?.length > 3;
  const displayedItems = showViewAll ? currentCartItems : currentCartItems;

  const isOutOfStock = (item) => {
    // If status is false, item is out of stock regardless of stock quantity
    if (item.status === false) return true;

    // If is_unlimited_stock is true (1), item is never out of stock
    if (item.is_unlimited_stock === 1) return false;

    // Otherwise, check if stock is 0 or less
    return item.stock <= 0;
  };

  const fetchCartData = useCallback(async () => {
    if (!isLoggedIn) return;

    setIsLoading(true);
    try {
      const response = await api.getCart(
        jwtToken,
        currentLocation.latitude,
        currentLocation.longitude
      );
      const result = await response.json();

      if (result?.status === 1) {
        dispatch(setCart({ data: result.data }));

        // Update cart products structure
        const productsData = result.data.cart.map(product => ({
          id: `${product.product_id}_${product.product_variant_id}`,
          product_id: product.product_id,
          product_variant_id: product.product_variant_id,
          quantity: product.qty,
          price: product.price,
          discounted_price: product.discounted_price,
          name: product.name,
          image: product.image_url,
          measurement: product.measurement,
          unit_code: product.unit_code,
          stock: product.stock,
          is_unlimited_stock: product.is_unlimited_stock,
          total_allowed_quantity: product.total_allowed_quantity,
          slug: product.slug,
          status: product.status === 1
        }));

        dispatch(setCartProducts({ data: productsData }));
        dispatch(setCartSubTotal({ data: result.data.sub_total }));
      } else if (result.message === "No item's found in users cart") {
        dispatch(setCartProducts({ data: [] }));
        dispatch(setCartSubTotal({ data: 0 }));
        dispatch(setCartCheckout({ data: null }));
      } else {
        toast.error(result.message || 'Failed to fetch cart data');
      }
    } catch (error) {
      console.error('Cart fetch error:', error);
      toast.error('Failed to fetch cart data');
    } finally {
      setIsLoading(false);
    }
  }, [isLoggedIn, jwtToken, currentLocation, dispatch]);

  const fetchGuestCart = useCallback(async () => {
    if (isLoggedIn) return;

    setIsLoading(true);
    try {
      if (!currentLocation.latitude || !currentLocation.longitude) {
        throw new Error('Location data is not available');
      }

      const validGuestCart = guestCart.filter(item =>
        item.product_variant_id && item.quantity > 0
      );

      if (validGuestCart.length === 0) {
        dispatch(setGuestCartTotal({ data: 0 }));
        dispatch(setCartCheckout({ data: null }));
        return;
      }

      const variantIds = validGuestCart.map(p => p.product_variant_id);
      const quantities = validGuestCart.map(p => p.quantity);

      const response = await api.getGuestCart(
        currentLocation.latitude,
        currentLocation.longitude,
        variantIds.join(","),
        quantities.join(",")
      );

      if (!response.ok) {
        throw new Error('Failed to fetch guest cart');
      }

      const result = await response.json();

      if (result.status === 1) {
        // Update guest cart items with server data
        const updatedGuestCart = validGuestCart.map(item => {
          const serverItem = result.data.cart.find(
            si => si.product_variant_id === item.product_variant_id
          );

          return serverItem ? {
            ...item,
            id: `${item.product_id}_${item.product_variant_id}`,
            price: serverItem.price,
            discounted_price: serverItem.discounted_price,
            name: serverItem.name,
            image: serverItem.image_url,
            measurement: serverItem.measurement,
            unit_code: serverItem.unit_code,
            stock: serverItem.stock,
            is_unlimited_stock: serverItem.is_unlimited_stock,
            total_allowed_quantity: serverItem.total_allowed_quantity,
            slug: serverItem.slug,
            status: serverItem.status === 1
          } : item;
        });

        // Calculate subtotal
        const calculatedSubtotal = updatedGuestCart.reduce((total, item) => {
          const itemPrice = item.discounted_price > 0 ?
            item.discounted_price : item.price;
          return total + (itemPrice * item.quantity);
        }, 0);

        dispatch(setGuestCartTotal({ data: calculatedSubtotal }));
        dispatch(setCartCheckout({
          data: {
            ...result.data,
            product_variant_id: updatedGuestCart.map(p => p.product_variant_id),
            quantity: updatedGuestCart.map(p => p.quantity)
          }
        }));
      } else {
        throw new Error(result.message || 'Failed to fetch guest cart');
      }
    } catch (error) {
      console.error('Guest cart error:', error);
      if (guestCart?.length > 0) {
        toast.error('Failed to update guest cart. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [isLoggedIn, guestCart, currentLocation, dispatch]);

  useEffect(() => {
    if (opened) {
      if (isLoggedIn) {
        fetchCartData();
      } else if (guestCart?.length > 0) {
        fetchGuestCart();
      } else {
        // Reset guest cart totals if empty
        dispatch(setGuestCartTotal({ data: 0 }));
        dispatch(setCartCheckout({ data: null }));
      }
    }
  }, [opened, isLoggedIn, guestCart, fetchCartData, fetchGuestCart, dispatch]);

  const removeItem = async (id) => {
    try {
      if (isGuest) {
        dispatch(removeFromGuestCart(id));

        if (guestCart.length > 1) {
          await fetchGuestCart();
        } else {
          dispatch(setGuestCartTotal({ data: 0 }));
          dispatch(setCartCheckout({ data: null }));
        }
      } else {
        const item = cartProducts.find(item => item.id === id);
        if (item) {
          await handleRemoveCartItem(item.product_id, item.product_variant_id);
        }
      }
      toast.success('Item removed from cart');
    } catch (error) {
      console.error('Failed to remove item:', error);
      toast.error('Failed to remove item. Please try again.');
    }
  };

  const updateCartItem = async (product_id, product_variant_id, qty) => {
    try {
      const response = await api.addToCart(
        jwtToken,
        product_id,
        product_variant_id,
        qty
      );
      const result = await response.json();

      if (result.status === 1) {
        dispatch(updateCartItemQuantity({
          product_id,
          product_variant_id,
          quantity: qty
        }));
        await fetchCartData();
        toast.success('Quantity updated');
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      console.error("Error updating cart:", error);
      toast.error("Failed to update cart");
    }
  };

  const handleRemoveCartItem = async (product_id, product_variant_id) => {
    try {
      const response = await api.removeFromCart(
        jwtToken,
        product_id,
        product_variant_id
      );
      const result = await response.json();

      if (result.status === 1) {
        dispatch(removeCartItem({ product_id, product_variant_id }));
        dispatch(clearCartPromo());
        await fetchCartData();
        toast.success('Item removed from cart');
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      console.error("Error removing item:", error);
      toast.error("Failed to remove item");
    }
  };

  const updateItemQuantity = async (id, quantity) => {
    const item = guestCart.find(item => item.id === id);
    if (!item) return;

    dispatch(updateGuestCartItemQuantity({
      id,
      quantity,
      price: item.price,
      discounted_price: item.discounted_price
    }));

    try {
      await fetchGuestCart();
    } catch {
      toast.error('Failed to update cart total');
    }
  };

  const increaseQuantity = (id) => {
    const item = isGuest ?
      guestCart.find(item => item.id === id) :
      cartProducts.find(item => item.id === id);

    if (!item) return;

    // Check if product is out of stock
    if (isOutOfStock(item)) {
      toast.error(`${item.name} is out of stock`);
      return;
    }

    // Check if we're exceeding available stock (only if not unlimited stock)
    if (item.is_unlimited_stock !== 1 && item.quantity >= item.stock) {
      toast.error(`Only ${item.stock} ${item.name} available in stock`);
      return;
    }

    const newQuantity = item.quantity + 1;
    if (isGuest) {
      updateItemQuantity(id, newQuantity);
    } else {
      updateCartItem(item.product_id, item.product_variant_id, newQuantity);
    }
  };

  const decreaseQuantity = (id) => {
    const item = isGuest ?
      guestCart.find(item => item.id === id) :
      cartProducts.find(item => item.id === id);

    if (!item) return;

    // Check if product is out of stock
    if (isOutOfStock(item)) {
      toast.error(`${item.name} is out of stock`);
      return;
    }

    if (item.quantity > 1) {
      if (isGuest) {
        updateItemQuantity(id, item.quantity - 1);
      } else {
        updateCartItem(item.product_id, item.product_variant_id, item.quantity - 1);
      }
    } else {
      if (isGuest) {
        removeItem(id);
      } else {
        handleRemoveCartItem(item.product_id, item.product_variant_id);
      }
    }
  };

  const handleViewAll = () => {
    setOpened(false);
    navigate('/cart');
  };

  const handleCheckout = () => {
    if (!isLoggedIn) {
      navigate("/login")
      return;
    }

    const outOfStockItems = (isGuest ? guestCart : cartProducts).filter(
      item => isOutOfStock(item)
    );

    if (outOfStockItems.length > 0) {
      toast.error(
        <div>
          <p>{outOfStockItems.length} items in your cart are out of stock:</p>
          <ul className="list-disc pl-5 mt-1">
            {outOfStockItems.slice(0, 3).map(item => (
              <li key={item.id}>{item.name}</li>
            ))}
            {outOfStockItems.length > 3 && <li>...and {outOfStockItems.length - 3} more</li>}
          </ul>
          <p className="mt-1">Please remove them to proceed to checkout.</p>
        </div>,
        { autoClose: 5000 }
      );
      return;
    }

    setOpened(false);

    const cartItems = isGuest ? guestCart : cartProducts;
    const calculatedSubtotal = cartItems.reduce((total, item) => {
      const itemPrice = item.discounted_price > 0 ? item.discounted_price : item.price;
      return total + (itemPrice * item.quantity);
    }, 0);

    navigate('/checkout', {
      state: {
        subtotal: calculatedSubtotal,
        cartItems: cartItems.map(item => ({
          ...item,
          product_variant_id: item.product_variant_id,
          price: item.discounted_price > 0 ? item.discounted_price : item.price,
          qty: item.quantity
        })),
        isGuest: isGuest
      }
    });
  };

  const removeCoupon = () => {
    dispatch(clearCartPromo());
    toast.info("Coupon Removed");
  };

  const handleCloseCartSidebar = () => {
    dispatch(setPromoCode({
      code: null,
      discount: 0,
      isPromoCode: false
    }));
    setOpened(false);
  };

  const placeHolderImage = (e) => {
    e.target.src = setting?.setting?.web_logo;
  };

  return (
    <div>
      <div onClick={() => setOpened(true)}>{children}</div>

      <Drawer
        opened={opened}
        onClose={handleCloseCartSidebar}
        position="right"
        size="md"
        padding={0}
        withCloseButton={false}
        styles={{
          drawer: {
            height: '100vh',
            maxHeight: '100vh',
            overflow: 'hidden',
            background: 'linear-gradient(145deg, #f8fafc 0%, #ffffff 100%)',
          }
        }}
      >
        {/* Modern Header */}
        <div className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm border-b border-slate-200">
          <div className="flex items-center justify-between p-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br bg-[#fc2e6bed] rounded-xl flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-800">Shopping Cart</h2>
                <p className="text-sm text-slate-500">
                  {currentCartItems?.length || 0} {currentCartItems?.length === 1 ? 'item' : 'items'}
                </p>
              </div>
            </div>
            <button
              onClick={handleCloseCartSidebar}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center transition-colors"
            >
              <span className="text-slate-600 text-lg">×</span>
            </button>
          </div>
        </div>

        <div className="flex flex-col h-full">
          <div className="flex-grow overflow-y-auto px-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-500 border-t-transparent"></div>
                <span className="ml-3 text-slate-600">Loading your cart...</span>
              </div>
            ) : currentCartItems?.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                  <ShoppingBag className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-800 mb-2">Your cart is empty</h3>
                <p className="text-slate-500">Add some products to get started</p>
              </div>
            ) : (
              <div className="py-4 space-y-4">
                {displayedItems && Array.isArray(displayedItems) && displayedItems.map((item, index) => (
                  <div key={item.id} className="group bg-white rounded-2xl p-4 shadow-sm border border-slate-200 hover:shadow-md transition-all duration-200">
                    <div className="flex items-start space-x-4">
                      {/* Product Image */}
                      <div className="relative">
                        <div className="h-20 w-20 flex-shrink-0 overflow-hidden rounded-xl bg-slate-50">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="h-full w-full object-cover object-center group-hover:scale-105 transition-transform duration-200"
                            onError={placeHolderImage}
                          />
                        </div>
                      </div>

                      {/* Product Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="text-base font-semibold text-slate-800 line-clamp-2 leading-snug">
                            {item.name}
                          </h3>
                          <button
                            onClick={() => isGuest ?
                              removeItem(item.id) :
                              handleRemoveCartItem(item.product_id, item.product_variant_id)}
                            className="ml-2 p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>

                        {/* Price Display */}
                        <div className="flex items-center space-x-2 mb-3">
                          <span className="text-lg font-bold text-slate-800">
                            {setting?.setting?.currency}
                            {(Number(item.discounted_price) > 0 ?
                              (item.discounted_price * item.quantity) :
                              (item.price * item.quantity))
                              .toFixed(setting?.setting?.decimal_point || 2)}
                          </span>
                          {item.discounted_price > 0 && item.discounted_price !== item.price && (
                            <span className="text-sm text-slate-400 line-through">
                              {setting?.setting?.currency}
                              {(Number(item?.price || 0) * Number(item?.quantity || 0)).toFixed(setting?.setting?.decimal_point || 2)}
                            </span>
                          )}
                        </div>

                        {/* Quantity Controls */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center bg-slate-50 rounded-xl p-1">
                            <button
                              onClick={() => decreaseQuantity(item.id)}
                              disabled={isOutOfStock(item) || item.quantity <= 1}
                              className={`w-8 h-8 rounded-lg flex items-center justify-center ${isOutOfStock(item) || item.quantity <= 1
                                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                  : 'bg-white shadow-sm text-slate-600 hover:text-slate-800 hover:shadow'
                                }`}
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="mx-3 text-sm font-semibold text-slate-800 min-w-[24px] text-center">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => increaseQuantity(item.id)}
                              disabled={
                                isOutOfStock(item) ||
                                (item.is_unlimited_stock !== 1 && item.quantity >= item.stock)
                              }
                              className={`w-8 h-8 rounded-lg flex items-center justify-center ${isOutOfStock(item) || (item.is_unlimited_stock !== 1 && item.quantity >= item.stock)
                                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                  : 'bg-white shadow-sm text-slate-600 hover:text-slate-800 hover:shadow'
                                }`}
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <div className="text-xs text-slate-500">
                            {isOutOfStock(item) ? (
                              <span className="text-red-500">Out of stock</span>
                            ) : (
                              <>
                                {setting?.setting?.currency}
                                {(Number(item.discounted_price) > 0 ? item.discounted_price : item.price).toFixed(2)} each
                                {item.is_unlimited_stock !== 1 && (
                                  <span className="block text-green-600">
                                    {item.stock} available
                                  </span>
                                )}
                              </>
                            )}
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                ))}

                {showViewAll && (
                  <div className="text-center pt-4">
                    <button
                      onClick={handleViewAll}
                      className="text-blue-600 font-semibold hover:text-blue-700 text-sm bg-blue-50 hover:bg-blue-100 px-4 py-2 rounded-lg transition-colors"
                    >
                      View All {currentCartItems.length} Items →
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Enhanced Footer */}
          {currentCartItems?.length > 0 && (
            <div className="mt-auto bg-white border-t border-slate-200">
              {/* Promo Section */}
              {!isGuest && (
                <div className="px-6 py-4 bg-gradient-to-r from-blue-50 to-purple-50 border-b border-slate-200">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <RiCoupon2Fill className="text-blue-600 text-lg" />
                      <span className="text-sm font-medium text-slate-700">Promo Code</span>
                    </div>
                    <button
                      className="text-sm font-semibold text-blue-600 hover:text-blue-700 bg-white px-3 py-1.5 rounded-lg hover:bg-blue-50 transition-colors"
                      onClick={() => setShowPromoOffcanvas(true)}
                    >
                      Apply Coupon
                    </button>
                  </div>

                  {promo_code && (
                    <div className="flex justify-between items-center mt-3 p-3 bg-white rounded-lg border border-green-200">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm font-medium text-slate-700">{promo_code.promo_code}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className="text-sm font-semibold text-green-600">
                          -{setting?.setting?.currency} {promo_code.discount}
                        </span>
                        <button
                          onClick={removeCoupon}
                          className="text-xs text-slate-500 hover:text-red-500 transition-colors"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Subtotal & Actions */}
              <div className="px-6 py-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-lg font-semibold text-slate-800">Subtotal</span>
                  <span className="text-2xl font-bold text-slate-800">
                    {setting?.setting?.currency}
                    {subtotal?.toFixed(setting?.setting?.decimal_point || 2)}
                  </span>
                </div>
                <p className="text-sm text-slate-500 mb-6">Shipping and taxes calculated at checkout</p>

                <div className="space-y-3">
                  <button
                    onClick={handleViewAll}
                    className="w-full py-3 px-4 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl text-slate-700 font-semibold transition-colors"
                  >
                    View Full Cart
                  </button>
                  <button
                    onClick={handleCheckout}
                    className="w-full py-3 px-4 bg-gradient-to-r bg-[#fc2e6bed] hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5"
                  >
                    Proceed to Checkout
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </Drawer>
    </div>
  );
}

export default CartSliderModal;