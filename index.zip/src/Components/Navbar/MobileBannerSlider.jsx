import React, { useState, useRef, useEffect } from 'react';
import { useSelector } from 'react-redux';

export default function MobileBannerSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [touchStart, setTouchStart] = useState(null);
  const [touchEnd, setTouchEnd] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [imagesLoaded, setImagesLoaded] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  const slideRef = useRef(null);
  const sliderContainerRef = useRef(null);

  // Get images from Redux store
  const { shop } = useSelector((state) => state.shop);
  const slides = shop?.sliders || [];

  const minSwipeDistance = 50;

  // Preload images to ensure they load immediately
  useEffect(() => {
    if (slides.length > 0) {
      const imagePromises = slides.map((slide) => {
        const img = new Image();
        img.src = slide.image_url;
        return new Promise((resolve) => {
          img.onload = resolve;
          img.onerror = resolve;
        });
      });

      Promise.all(imagePromises).then(() => {
        setImagesLoaded(true);
        setIsLoading(false);
      });
    } else {
      setIsLoading(false);
    }
  }, [slides]);

  // Handle swipe interactions
  const onTouchStart = (e) => {
    setIsPaused(true);
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e) => {
    setTouchEnd(e.targetTouches[0].clientX);

    // Optional: Add visual feedback during swipe
    if (touchStart && slideRef.current && !isAnimating) {
      const distance = e.targetTouches[0].clientX - touchStart;
      const maxDistance = sliderContainerRef.current?.offsetWidth * 0.2 || 100;
      const clampedDistance = Math.max(Math.min(distance, maxDistance), -maxDistance);

      // Apply a subtle drag effect
      slideRef.current.style.transform = `translateX(calc(-${currentSlide * 100}% + ${clampedDistance}px))`;
    }
  };

  const onTouchEnd = () => {
    setIsPaused(false);

    // Reset the transform if we didn't swipe enough
    if (slideRef.current) {
      slideRef.current.style.transition = 'transform 300ms ease-out';  // Faster transition
    }

    if (!touchStart || !touchEnd) {
      if (slideRef.current) {
        slideRef.current.style.transform = `translateX(-${currentSlide * 100}%)`;
      }
      return;
    }

    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    if (isLeftSwipe) {
      nextSlide();
    } else if (isRightSwipe) {
      prevSlide();
    } else {
      if (slideRef.current) {
        slideRef.current.style.transform = `translateX(-${currentSlide * 100}%)`;
      }
    }

    // Reset transition after touch end
    setTimeout(() => {
      if (slideRef.current) {
        slideRef.current.style.transition = 'transform 300ms ease-in-out';  // Faster transition speed
      }
    }, 50);
  };

  const goToSlide = (index) => {
    if (isAnimating || index === currentSlide) return;

    setIsAnimating(true);
    setCurrentSlide(index);

    // Reset animation flag after transition completes
    setTimeout(() => {
      setIsAnimating(false);
    }, 300);  // Faster transition
  };

  const nextSlide = () => {
    if (isAnimating || slides.length <= 1) return;

    setIsAnimating(true);
    setCurrentSlide((prev) => (prev + 1) % slides.length);

    // Reset animation flag after transition completes
    setTimeout(() => {
      setIsAnimating(false);
    }, 300);  // Faster transition
  };

  const prevSlide = () => {
    if (isAnimating || slides.length <= 1) return;

    setIsAnimating(true);
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);

    // Reset animation flag after transition completes
    setTimeout(() => {
      setIsAnimating(false);
    }, 300);  // Faster transition
  };

  // Auto-advance slides every 4 seconds
  useEffect(() => {
    if (isPaused || slides.length <= 1) return;

    const timer = setInterval(nextSlide, 4000);
    return () => clearInterval(timer);
  }, [currentSlide, isPaused, slides.length]);

  return (
    <div
      className="relative w-full overflow-hidden mx-auto my-4 px-1"
      ref={sliderContainerRef}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Skeleton Loader */}
      {isLoading ? (
        <div className="w-full h-44 md:h-56 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 animate-shimmer rounded-xl overflow-hidden" style={{ backgroundSize: '200% 100%' }}></div>
      ) : (
        <div className="relative rounded-xl overflow-hidden shadow-md">
          {/* Main Slider */}
          <div
            ref={slideRef}
            className="relative flex transition-transform duration-300 ease-out h-44 md:h-56"  // Faster transition
            style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            onTouchStart={onTouchStart}
            onTouchMove={onTouchMove}
            onTouchEnd={onTouchEnd}
          >
            {imagesLoaded && slides.length > 0 ? (
              slides.map((slide, index) => (
                <div
                  key={index}
                  className="flex-shrink-0 w-full h-full"
                  style={{ width: '100%' }}
                >
                  <div className="relative h-full overflow-hidden">
                    {/* Image with gradient overlay */}
                    <img
                      src={slide.image_url}
                      alt={`Slide ${index + 1}`}
                      className="w-full h-full object-cover object-center"
                      draggable="false"
                      loading={index === 0 ? "eager" : "lazy"}
                    />

                    <div className="absolute inset-0 bg-gradient-to-b from-black/10 to-black/30 opacity-60"></div>

                    {/* Optional: Add slide content/caption */}
                    {slide.title && (
                      <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                        <h3 className="text-lg font-semibold">{slide.title}</h3>
                        {slide.description && (
                          <p className="text-sm mt-1 text-white/90">{slide.description}</p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="min-w-full h-full flex items-center justify-center bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl">
                <p className="text-gray-500">No slides available</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Navigation Dots */}
      {slides.length > 1 && (
        <div className="flex justify-center mt-3 gap-1.5">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`h-2 rounded-full transition-all duration-300 ${currentSlide === index ? 'bg-pink-500 w-5' : 'bg-gray-300 hover:bg-gray-400 w-2'}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
