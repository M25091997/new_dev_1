import React, { useRef, useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

const DeskTopScrollableNav = () => {
  const scrollContainerRef = useRef(null);
  const shop = useSelector((state) => state.shop?.shop || {}); // Ensure shop exists
  const [categories, setCategories] = useState(shop.categories || []);
  const [loading, setLoading] = useState(!shop.categories?.length);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(false);
  const navigate = useNavigate();

  // Ensure categories load instantly if available
  useEffect(() => {
    if (shop?.categories?.length) {
      setCategories(shop.categories);
      setLoading(false);
      checkScrollButtons();
    }
  }, [shop]);

  const checkScrollButtons = () => {
    const container = scrollContainerRef.current;
    if (container) {
      setShowLeftArrow(container.scrollLeft > 0);
      setShowRightArrow(container.scrollLeft < container.scrollWidth - container.clientWidth);
    }
  };

  const scroll = (direction) => {
    const container = scrollContainerRef.current;
    if (container) {
      container.scrollBy({
        left: direction === 'left' ? -200 : 200,
        behavior: 'smooth',
      });
    }
  };

  const handleCategoryClick = (slug) => {
    navigate(`/category/${slug}`);
  };

  return (
    <div className="relative bg-white z-10">
      {/* Left Navigation Arrow */}
      {showLeftArrow && !loading && (
        <button
          onClick={() => scroll('left')}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white shadow-lg rounded-r p-1 hover:bg-gray-100 transition-colors"
          aria-label="Scroll left"
        >
          <ChevronLeft className="w-5 h-5 text-gray-700" />
        </button>
      )}

      {/* Content Container */}
      <div
        ref={scrollContainerRef}
        className="overflow-x-auto scrollbar-none [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        onScroll={checkScrollButtons}
      >
        <ul className={`flex gap-6 px-4 py-2 min-w-max ${loading ? 'min-w-full' : ''}`}>
          {loading ? (
            Array.from({ length: 6 }).map((_, index) => (
              <li key={index} className="flex-1 h-10 bg-gray-300 rounded-md animate-pulse"></li>
            ))
          ) : (
            categories.map((item) => (
              <li key={item.id}>
                <div
                  onClick={() => handleCategoryClick(item.slug)}
                  className="text-gray-700 hover:text-gray-900 text-sm font-bold whitespace-nowrap transition-colors cursor-pointer"
                >
                  {item.name}
                </div>
              </li>
            ))
          )}
        </ul>
      </div>

      {/* Right Navigation Arrow */}
      {showRightArrow && !loading && (
        <button
          onClick={() => scroll('right')}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white shadow-lg rounded-l p-1 hover:bg-gray-100 transition-colors"
          aria-label="Scroll right"
        >
          <ChevronRight className="w-5 h-5 text-gray-700" />
        </button>
      )}
    </div>
  );
};

export default DeskTopScrollableNav;