// DeskTopNavbar.js
import { useEffect, useState, useRef, useCallback } from 'react';
import { ChevronDown, Sun, ShoppingCart, Heart, UserCircle, Search, MapPin, Menu, X, LogOut, UserRoundPen, Bell, MapPinned, Wallet, ReceiptIndianRupee, Sparkles } from 'lucide-react';
import DeskTopScrollableNav from './DeskTopScrollableNav';
import { Link, NavLink, useNavigate, useLocation } from 'react-router-dom';
import SetDeliveryLocations from '../Models/SetDeliveryLocations';
import CartSliderModal from '../CartSliderModal';
import { useDispatch, useSelector } from 'react-redux';
import { setCity, setFirstVisit } from '../../model/reducer/locationReducer';
import * as newApi from '../../api/apiCollection';
import api from '../../api/api';
import BringMartLogo from '../../assets/bringmart-logo.png';
import { logoutAuth } from '../../model/reducer/authReducer';
import { toast } from 'react-toastify';
import { clearCart } from '../../model/reducer/cartReducer';
import { clearAllFilter, setFilterSearch } from '../../model/reducer/productFilterReducer';

export default function DeskTopNavbar() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const location = useLocation();
    const userDropdownRef = useRef(null);
    const [scrolled, setScrolled] = useState(false);

    // Redux selectors with memoization
    const cartCount = useSelector(state => {
        if (state?.cart?.isGuest) {
            return state.cart?.guestCart?.length || 0;
        } else {
            return (state.cart?.cartProducts?.length || 0);
        }
    });
    const { favouriteProducts } = useSelector((state) => state.favourite);
    const city = useSelector(state => state.city);
    const setting = useSelector(state => state.setting);
    const { user, status, jwtToken } = useSelector((state) => state.user);

    // Local state
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [searchFocused, setSearchFocused] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [userDropdownOpen, setUserDropdownOpen] = useState(false);
    const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
    const [isLoggingOut, setIsLoggingOut] = useState(false);
    const [locationModalKey, setLocationModalKey] = useState(0);
    const [showLocationModal, setShowLocationModal] = useState(false);
    const [locationPermission, setLocationPermission] = useState(null);

    // Check if location is set
    const isLocationSet = useCallback(() => {
        return city?.status === 'fulfill';
    }, [city]);

    // Check location permission
    useEffect(() => {
        const checkLocationPermission = async () => {
            if (navigator.permissions) {
                try {
                    const permissionStatus = await navigator.permissions.query({ name: 'geolocation' });
                    setLocationPermission(permissionStatus.state);

                    permissionStatus.onchange = () => {
                        setLocationPermission(permissionStatus.state);
                    }
                } catch (e) {
                    console.error("Permission query failed:", e);
                    setLocationPermission('prompt');
                }
            } else {
                setLocationPermission('prompt');
            }
        };

        checkLocationPermission();
    }, []);

    // Show location modal if location isn't set
    // Modify the useEffect that controls the modal
    useEffect(() => {
        if (!isLocationSet() && !showLocationModal) {
            setShowLocationModal(true);
        }
    }, [isLocationSet, showLocationModal]);

    // Scroll handler for navbar color change
    const handleScroll = useCallback(() => {
        const scrollTop = window.scrollY;
        setScrolled(scrollTop > 50);
    }, []);

    useEffect(() => {
        window.addEventListener('scroll', handleScroll, { passive: true });
        return () => window.removeEventListener('scroll', handleScroll);
    }, [handleScroll]);

    // Close dropdown when clicking outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (userDropdownRef.current && !userDropdownRef.current.contains(event.target)) {
                setUserDropdownOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    // Reset location modal when city changes
    useEffect(() => {
        setLocationModalKey(prev => prev + 1);
    }, [city]);

    // Handle location success
    const handleLocationSuccess = useCallback(() => {
        setShowLocationModal(false);
        localStorage.setItem('locationSet', 'true');
        dispatch(setFirstVisit(false));
    }, [dispatch]);

    // Search functionality
    const handleSearch = useCallback(
        async (e) => {
            e.preventDefault();

            if (!searchQuery.trim()) {
                navigate("/products");
                return;
            }

            try {
                const latitude = city?.city?.latitude || setting.setting?.default_city?.latitude;
                const longitude = city?.city?.longitude || setting.setting?.default_city?.longitude;

                if (!latitude || !longitude) {
                    toast.warning("Please set your delivery location first");
                    setShowLocationModal(true);
                    return;
                }

                // Clear all filters and set search query in Redux
                dispatch(clearAllFilter());
                dispatch(setFilterSearch({ data: searchQuery.trim() }));

                // Navigate with search query
                navigate(`/products?search=${encodeURIComponent(searchQuery)}`, {
                    state: {
                        fromSearch: true,
                        searchQuery: searchQuery.trim(),
                        latitude: parseFloat(latitude),
                        longitude: parseFloat(longitude),
                    },
                });
            } catch (error) {
                console.error("Search error:", error);
                toast.error("An error occurred during search");
                navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
            }
        },
        [searchQuery, navigate, city, setting, dispatch]
    );

    // Sync search query with URL
    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const queryFromUrl = params.get('search');
        if (queryFromUrl) {
            setSearchQuery(queryFromUrl);
        }
    }, [location.search]);

    // Logout handlers
    const handleLogout = useCallback(() => {
        setShowLogoutConfirm(true);
    }, []);

    const confirmLogout = useCallback(async () => {
        try {
            setIsLoggingOut(true);

            if (status === 'fulfill' && user && jwtToken) {
                const response = await api.logout(jwtToken);
                const result = await response.json();

                if (response.ok && result?.status === 1) {
                    toast.success('Logged out successfully');
                } else {
                    toast.error(result?.message || 'Logout failed');
                }
            }

            dispatch(logoutAuth());
            dispatch(clearCart());
            navigate('/');
            setMobileMenuOpen(false);
            setUserDropdownOpen(false);
        } catch (error) {
            console.error('Logout error:', error);
            toast.error('An error occurred during logout');
        } finally {
            setShowLogoutConfirm(false);
            setIsLoggingOut(false);
        }
    }, [status, user, jwtToken, dispatch, navigate]);

    const cancelLogout = useCallback(() => {
        setShowLogoutConfirm(false);
        setUserDropdownOpen(false);
    }, []);

    // Toggle functions
    const toggleMobileMenu = useCallback(() => {
        setMobileMenuOpen(prev => !prev);
    }, []);

    const toggleUserDropdown = useCallback(() => {
        setUserDropdownOpen(prev => !prev);
    }, []);

    // Dynamic navbar classes with consistent color
    const navbarClasses = `
        fixed top-0 left-0 right-0 z-40 transition-all duration-500 ease-in-out
        ${scrolled
            ? 'shadow-xl border-b border-gray-200/20'
            : 'shadow-lg'
        }
    `;

    // Use consistent color for both states
    const navbarStyle = {
        backgroundColor: '#fc2e6bed'
    };

    const textColorClass = 'text-white';
    const iconColorClass = 'text-white';

    return (
        <>
            {/* Location Modal */}
            <SetDeliveryLocations
                key={locationModalKey}
                isOpen={showLocationModal}
                onClose={() => {
                    if (isLocationSet()) {
                        setShowLocationModal(false);
                    }
                }}
                onSuccess={handleLocationSuccess}
                locationPermission={locationPermission}
            />

            {/* Logout Confirmation Modal */}
            {showLogoutConfirm && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-300">
                    <div className="bg-white rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl transform animate-in zoom-in-95 duration-300">
                        <div className="text-center">
                            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: '#fc2e6bed' }}>
                                <LogOut className="w-8 h-8 text-white" />
                            </div>
                            <h3 className="text-xl font-semibold text-gray-900 mb-2">Confirm Logout</h3>
                            <p className="text-gray-600 mb-8">Are you sure you want to logout from your account?</p>
                            <div className="flex gap-3">
                                <button
                                    onClick={cancelLogout}
                                    className="flex-1 px-6 py-3 border-2 border-gray-200 rounded-xl text-gray-700 font-medium hover:bg-gray-50 transition-colors duration-200"
                                    disabled={isLoggingOut}
                                >
                                    Cancel
                                </button>
                                <button
                                    onClick={confirmLogout}
                                    className="flex-1 px-6 py-3 text-white font-medium rounded-xl hover:opacity-90 disabled:opacity-70 transition-all duration-200 shadow-lg"
                                    style={{ backgroundColor: '#fc2e6bed' }}
                                    disabled={isLoggingOut}
                                >
                                    {isLoggingOut ? (
                                        <div className="flex items-center justify-center gap-2">
                                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                            Logging out...
                                        </div>
                                    ) : (
                                        'Logout'
                                    )}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Spacer for fixed navbar */}
            <div className="h-20"></div>

            {/* Main Navbar */}
            <nav className={navbarClasses} style={navbarStyle}>
                <div className="max-w-7xl mx-auto py-3 px-4 md:px-6">
                    <div className="flex items-center justify-between gap-4">
                        {/* Left Section: Logo and Location */}
                        <div className="flex items-center gap-6">
                            {/* Mobile Menu Toggle */}
                            <button
                                className={`md:hidden ${iconColorClass} hover:scale-110 transition-all duration-200 p-1 hover:bg-white/10 rounded-lg`}
                                onClick={toggleMobileMenu}
                                aria-label="Toggle menu"
                            >
                                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                            </button>

                            {/* Logo */}
                            <Link to="/" className="flex-shrink-0 group">
                                <div className="relative">
                                    <img
                                        src={BringMartLogo}
                                        className="h-12 w-auto object-contain rounded-xl shadow-lg transition-all duration-300 group-hover:scale-105 bg-white/95 p-2"
                                        alt="BringMart"
                                    />
                                </div>
                            </Link>

                            {/* Location Selector */}
                            <SetDeliveryLocations
                                key={`nav-${locationModalKey}`}
                                onSuccess={handleLocationSuccess}
                                locationPermission={locationPermission}
                            >
                                <div className="hidden md:flex items-center gap-3 cursor-pointer rounded-xl py-2 px-4 transition-all duration-300 hover:scale-105 bg-white/15 backdrop-blur-md hover:bg-white/25 border border-white/20">
                                    <div className="p-2 rounded-full bg-white/20">
                                        <MapPin className="w-4 h-4 text-white" />
                                    </div>
                                    <div>
                                        <p className="text-xs font-medium flex items-center text-white/90">
                                            Deliver to <ChevronDown className="w-3 h-3 ml-1" />
                                        </p>
                                        <p className="font-semibold text-sm truncate max-w-[140px] text-white">
                                            {isLocationSet()
                                                ? city.city.formatted_address
                                                : 'Set Location'
                                            }
                                        </p>
                                    </div>
                                </div>
                            </SetDeliveryLocations>
                        </div>

                        {/* Center Section: Search Bar */}
                        <form onSubmit={handleSearch} className="flex-1 max-w-2xl mx-4">
                            <div className={`relative flex items-center rounded-xl overflow-hidden transition-all duration-300 ${searchFocused
                                ? 'ring-4 ring-white/30 shadow-2xl scale-105'
                                : 'shadow-lg hover:shadow-xl'
                                } bg-white border border-gray-100`}>
                                <input
                                    type="text"
                                    className="py-3.5 px-5 w-full bg-transparent outline-none text-gray-800 placeholder-gray-500 font-medium text-sm"
                                    placeholder="What are you looking for today?"
                                    onFocus={() => setSearchFocused(true)}
                                    onBlur={() => setSearchFocused(false)}
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    required
                                    minLength={2}
                                />
                                <button
                                    type="submit"
                                    className="p-3 mr-1.5 rounded-lg transition-all duration-200 hover:scale-110 shadow-md hover:shadow-lg"
                                    style={{ backgroundColor: '#fc2e6bed' }}
                                    disabled={!searchQuery.trim()}
                                >
                                    <Search className="w-5 h-5 text-white" />
                                </button>
                            </div>
                        </form>

                        {/* Right Section: Navigation Icons */}
                        <div className="flex items-center gap-1">
                            {/* Theme Toggle */}
                            <button className="relative group p-3 rounded-xl transition-all duration-200 hover:scale-110 hover:bg-white/10">
                                <Sun className="w-6 h-6 text-white group-hover:text-yellow-200 transition-colors duration-300" />
                            </button>

                            {/* User Section */}
                            {status === 'fulfill' && user ? (
                                <div className="relative" ref={userDropdownRef}>
                                    <button
                                        onClick={toggleUserDropdown}
                                        className="flex items-center gap-2 p-2 rounded-xl transition-all duration-200 hover:scale-105 hover:bg-white/10"
                                    >
                                        <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold shadow-lg" style={{ backgroundColor: '#fc2e6bed' }}>
                                            {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
                                        </div>
                                        <div className="hidden lg:block text-left">
                                            <p className="text-sm font-medium text-white">
                                                {user.name?.split(' ')[0] || 'User'}
                                            </p>
                                        </div>
                                        <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${userDropdownOpen ? 'rotate-180' : ''} text-white`} />
                                    </button>

                                    {/* Enhanced User Dropdown */}
                                    {userDropdownOpen && (
                                        <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden z-50 animate-in slide-in-from-top-2 duration-200">
                                            {/* User Header */}
                                            <div className="p-4 text-white" style={{ backgroundColor: '#fc2e6bed' }}>
                                                <div className="flex items-center gap-4">
                                                    <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-xl font-bold shadow-lg">
                                                        {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
                                                    </div>
                                                    <div className="flex-1">
                                                        <h3 className="font-bold text-lg">{user.name || 'User'}</h3>
                                                        <p className="text-white/80 text-sm truncate">{user.email}</p>
                                                    </div>
                                                </div>
                                            </div>

                                            {/* Menu Items */}
                                            <div className="p-1">
                                                {[
                                                    { icon: UserRoundPen, label: 'Edit Profile', path: '/edit-profile', color: 'text-blue-600' },
                                                    { icon: ShoppingCart, label: 'My Orders', path: '/my-orders', color: 'text-green-600' },
                                                    { icon: Heart, label: 'My Wishlist', path: '/wishlist', color: 'text-red-600' },
                                                    { icon: Bell, label: 'Notifications', path: '/notifications', color: 'text-yellow-600' },
                                                    { icon: MapPinned, label: 'My Addresses', path: '/my-addresses', color: 'text-purple-600' },
                                                    { icon: Wallet, label: 'Wallet Balance', path: '/wallet-balance', color: 'text-indigo-600' },
                                                    { icon: ReceiptIndianRupee, label: 'Transactions', path: '/transactions', color: 'text-pink-600' },
                                                ].map((item, index) => (
                                                    <Link
                                                        key={index}
                                                        to={item.path}
                                                        className="flex items-center gap-4  p-2 rounded-xl hover:bg-gray-50 transition-colors duration-200 group"
                                                        onClick={() => setUserDropdownOpen(false)}
                                                    >
                                                        <div className={`p-2 rounded-lg bg-gray-50 group-hover:bg-white transition-colors ${item.color}`}>
                                                            <item.icon className="w-4 h-4" />
                                                        </div>
                                                        <span className="font-medium text-gray-700 group-hover:text-gray-900">
                                                            {item.label}
                                                        </span>
                                                    </Link>
                                                ))}

                                                <div className="border-t border-gray-100 mt-2 pt-2">
                                                    <button
                                                        onClick={handleLogout}
                                                        className="flex items-center gap-4 p-3 rounded-xl hover:bg-red-50 transition-colors duration-200 w-full group"
                                                    >
                                                        <div className="p-2 rounded-lg bg-red-50 group-hover:bg-red-100 text-red-600">
                                                            <LogOut className="w-4 h-4" />
                                                        </div>
                                                        <span className="font-medium text-red-600">Logout</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            ) : (
                                <NavLink
                                    to="/login"
                                    className="flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all duration-200 hover:scale-105 bg-white/20 text-white hover:bg-white/30 backdrop-blur-sm border border-white/20"
                                >
                                    <UserCircle className="w-5 h-5" />
                                    <span className="hidden sm:inline">Login</span>
                                </NavLink>
                            )}

                            {/* Wishlist */}
                            <NavLink
                                to="/wishlist"
                                className="relative p-3 rounded-xl transition-all duration-200 hover:scale-110 group hover:bg-white/10"
                            >
                                <Heart className="w-6 h-6 text-white group-hover:text-red-200 transition-colors duration-300" />
                                {favouriteProducts?.length > 0 && (
                                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center shadow-lg animate-pulse">
                                        {favouriteProducts?.length}
                                    </span>
                                )}
                            </NavLink>

                            {/* Cart */}
                            <CartSliderModal>
                                <div className="relative p-3 rounded-xl transition-all duration-200 hover:scale-110 cursor-pointer group hover:bg-white/10">
                                    <ShoppingCart className="w-6 h-6 text-white group-hover:text-green-200 transition-colors duration-300" />
                                    {cartCount > 0 && (
                                        <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-500 text-white text-xs font-bold rounded-full flex items-center justify-center shadow-lg animate-bounce">
                                            {cartCount}
                                        </span>
                                    )}
                                </div>
                            </CartSliderModal>
                        </div>
                    </div>
                </div>

                {/* Enhanced Mobile Menu */}
                <div className={`${mobileMenuOpen ? 'max-h-screen opacity-100' : 'max-h-0 opacity-0'} overflow-hidden transition-all duration-500 ease-in-out md:hidden bg-white/95 backdrop-blur-lg`}>
                    <div className="p-4 space-y-3">
                        {/* Mobile Location */}
                        <SetDeliveryLocations
                            key={`mobile-${locationModalKey}`}
                            onSuccess={handleLocationSuccess}
                            locationPermission={locationPermission}
                        >
                            <div className="flex items-center p-4 rounded-xl bg-gray-50 border border-gray-100">
                                <MapPin className="w-5 h-5 mr-3" style={{ color: '#fc2e6bed' }} />
                                <div className="flex-1">
                                    <p className="text-sm font-medium text-gray-700">Deliver to</p>
                                    <p className="text-sm font-bold text-gray-900 truncate">
                                        {isLocationSet()
                                            ? city.city.formatted_address
                                            : 'Set Location'
                                        }
                                    </p>
                                </div>
                                <ChevronDown className="w-4 h-4 text-gray-500" />
                            </div>
                        </SetDeliveryLocations>

                        {/* Mobile User Section */}
                        {status === 'fulfill' && user ? (
                            <div className="space-y-3">
                                <div className="p-4 rounded-xl text-white" style={{ backgroundColor: '#fc2e6bed' }}>
                                    <div className="flex items-center gap-3">
                                        <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center font-bold">
                                            {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
                                        </div>
                                        <div>
                                            <p className="font-semibold">{user.name}</p>
                                            <p className="text-sm text-white/80">{user.email}</p>
                                        </div>
                                    </div>
                                </div>
                                <button
                                    onClick={handleLogout}
                                    className="flex items-center w-full p-4 rounded-xl bg-red-50 hover:bg-red-100 transition-colors"
                                    disabled={isLoggingOut}
                                >
                                    <LogOut className="w-5 h-5 text-red-600 mr-3" />
                                    <span className="font-medium text-red-600">
                                        {isLoggingOut ? 'Logging out...' : 'Logout'}
                                    </span>
                                </button>
                            </div>
                        ) : (
                            <NavLink
                                to="/login"
                                className="flex items-center p-4 rounded-xl text-white font-medium hover:opacity-90 transition-all"
                                style={{ backgroundColor: '#fc2e6bed' }}
                                onClick={toggleMobileMenu}
                            >
                                <UserCircle className="w-5 h-5 mr-3" />
                                Login or Sign Up
                            </NavLink>
                        )}

                        {/* Mobile Menu Items */}
                        <NavLink
                            to="/wishlist"
                            className="flex items-center p-4 rounded-xl hover:bg-red-50 transition-colors"
                            onClick={toggleMobileMenu}
                        >
                            <Heart className="w-5 h-5 text-red-600 mr-3" />
                            <span className="font-medium text-gray-900 flex-1">My Wishlist</span>
                            {favouriteProducts?.length > 0 && (
                                <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                                    {favouriteProducts?.length}
                                </span>
                            )}
                        </NavLink>

                        <button className="flex items-center w-full p-4 rounded-xl hover:bg-yellow-50 transition-colors">
                            <Sun className="w-5 h-5 text-yellow-600 mr-3" />
                            <span className="font-medium text-gray-900">Change Theme</span>
                        </button>
                    </div>
                </div>
            </nav>

            {/* Categories Navigation */}
            <div className="bg-white shadow-lg border-t border-gray-200 transition-all duration-300">
                <div className="max-w-7xl mx-auto">
                    <DeskTopScrollableNav />
                </div>
            </div>
        </>
    );
}