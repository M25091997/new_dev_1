import {
    ChevronDown,
    Heart,
    MapPin,
    Search,
    UserCircle,
    ShoppingCart,
    LogOut,
    UserRoundIcon as UserRoundPen,
    Bell,
    MapPinned,
    Wallet,
    ReceiptIndianRupee,
    Menu,
    X,
    Sun,
    Sparkles
} from "lucide-react"
import { useEffect, useState, useCallback, useRef } from "react"
import SetDeliveryLocations from "../Models/SetDeliveryLocations"
import { useDispatch, useSelector } from "react-redux"
import { setCity, setFirstVisit } from "../../model/reducer/locationReducer"
import * as newApi from "../../api/apiCollection"
import { useNavigate, useLocation, Link, NavLink } from "react-router-dom"
import { logoutAuth } from "../../model/reducer/authReducer"
import { toast } from "react-toastify"
import { clearCart } from "../../model/reducer/cartReducer"
import api from "../../api/api"
import { clearAllFilter, setFilterSearch } from "../../model/reducer/productFilterReducer"
import CartSliderModal from "../CartSliderModal"

export default function MobileTopNavbar() {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const location = useLocation()
    const userDropdownRef = useRef(null)

    // Redux selectors
    const { favouriteProducts } = useSelector((state) => state.favourite)
    const cartCount = useSelector((state) => {
        if (state?.cart?.isGuest) {
            return state.cart?.guestCart?.length || 0
        } else {
            return state.cart?.cartProducts?.length || 0
        }
    })
    const city = useSelector((state) => state.city)
    const setting = useSelector((state) => state.setting)
    const { user, status, jwtToken } = useSelector((state) => state.user)

    // Local state
    const [searchQuery, setSearchQuery] = useState("")
    const [showLogoutConfirm, setShowLogoutConfirm] = useState(false)
    const [userDropdownOpen, setUserDropdownOpen] = useState(false)
    const [isLoggingOut, setIsLoggingOut] = useState(false)
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
    const [searchFocused, setSearchFocused] = useState(false)
    const [locationModalKey, setLocationModalKey] = useState(0)
    const [showLocationModal, setShowLocationModal] = useState(false)
    const [locationPermission, setLocationPermission] = useState(null)

    // Check if current route is home page
    const isHomePage = location.pathname === '/';

    // Check if location is set
    const isLocationSet = useCallback(() => {
        return city?.status === 'fulfill'
    }, [city])

    // Check location permission
    useEffect(() => {
        const checkLocationPermission = async () => {
            if (navigator.permissions) {
                try {
                    const permissionStatus = await navigator.permissions.query({ name: 'geolocation' })
                    setLocationPermission(permissionStatus.state)

                    permissionStatus.onchange = () => {
                        setLocationPermission(permissionStatus.state)
                    }
                } catch (e) {
                    console.error("Permission query failed:", e)
                    setLocationPermission('prompt')
                }
            } else {
                setLocationPermission('prompt')
            }
        }

        checkLocationPermission()
    }, [])

    // Show location modal if location isn't set
    useEffect(() => {
        if (!isLocationSet()) {
            setShowLocationModal(true)
        }
    }, [isLocationSet])

    // Close dropdown when clicking outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (userDropdownRef.current && !userDropdownRef.current.contains(event.target)) {
                setUserDropdownOpen(false)
            }
        }
        document.addEventListener('mousedown', handleClickOutside)
        return () => document.removeEventListener('mousedown', handleClickOutside)
    }, [])

    // Reset location modal when city changes
    useEffect(() => {
        setLocationModalKey(prev => prev + 1)
    }, [city])

    // Handle location success
    const handleLocationSuccess = useCallback(() => {
        setShowLocationModal(false)
        localStorage.setItem('locationSet', 'true')
        dispatch(setFirstVisit(false))
    }, [dispatch])

    // Search functionality
    const handleSearch = useCallback(
        async (e) => {
            e.preventDefault()

            if (!searchQuery.trim()) {
                navigate("/products")
                return
            }

            try {
                const latitude = city?.city?.latitude || setting.setting?.default_city?.latitude
                const longitude = city?.city?.longitude || setting.setting?.default_city?.longitude

                if (!latitude || !longitude) {
                    toast.warning("Please set your delivery location first")
                    setShowLocationModal(true)
                    return
                }

                // Clear all filters and set search query in Redux
                dispatch(clearAllFilter())
                dispatch(setFilterSearch({ data: searchQuery.trim() }))

                // Navigate with search query and state
                navigate(`/products?search=${encodeURIComponent(searchQuery)}`, {
                    state: {
                        fromSearch: true,
                        searchQuery: searchQuery.trim(),
                        latitude: parseFloat(latitude),
                        longitude: parseFloat(longitude),
                    },
                })
            } catch (error) {
                console.error("Search error:", error)
                toast.error("An error occurred during search")
                navigate(`/products?search=${encodeURIComponent(searchQuery)}`)
            }
        },
        [searchQuery, navigate, city, setting, dispatch]
    )

    // Sync search query with URL
    useEffect(() => {
        const params = new URLSearchParams(location.search)
        const queryFromUrl = params.get("search")
        if (queryFromUrl) {
            setSearchQuery(queryFromUrl)
        }
    }, [location.search])

    // Logout handlers
    const handleLogout = useCallback(() => {
        setShowLogoutConfirm(true)
        setMobileMenuOpen(false)
    }, [])

    const confirmLogout = useCallback(async () => {
        try {
            setIsLoggingOut(true)

            if (status === "fulfill" && user && jwtToken) {
                const response = await api.logout(jwtToken)
                const result = await response.json()

                if (response.ok && result?.status === 1) {
                    toast.success("Logged out successfully")
                } else {
                    toast.error(result?.message || "Logout failed")
                }
            }

            dispatch(logoutAuth())
            dispatch(clearCart())
            navigate("/")
            setUserDropdownOpen(false)
        } catch (error) {
            console.error("Logout error:", error)
            toast.error("An error occurred during logout")
        } finally {
            setShowLogoutConfirm(false)
            setIsLoggingOut(false)
        }
    }, [status, user, jwtToken, dispatch, navigate])

    const cancelLogout = useCallback(() => {
        setShowLogoutConfirm(false)
    }, [])

    // Toggle mobile menu
    const toggleMobileMenu = useCallback(() => {
        setMobileMenuOpen((prev) => !prev)
    }, [])

    // Close mobile menu when clicking on links
    const closeMobileMenu = useCallback(() => {
        setMobileMenuOpen(false)
    }, [])

    return (
        <>
            {/* Location Modal */}
            <SetDeliveryLocations
                key={locationModalKey}
                isOpen={showLocationModal}
                onClose={() => {
                    if (isLocationSet()) {
                        setShowLocationModal(false);
                    }
                }}
                onSuccess={handleLocationSuccess}
                locationPermission={locationPermission}
            />
            {/* Logout Confirmation Modal */}
            {showLogoutConfirm && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-300">
                    <div className="bg-white rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl transform animate-in zoom-in-95 duration-300">
                        <div className="text-center">
                            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: '#fc2e6bed' }}>
                                <LogOut className="w-8 h-8 text-white" />
                            </div>
                            <h3 className="text-xl font-semibold text-gray-900 mb-2">Confirm Logout</h3>
                            <p className="text-gray-600 mb-8">Are you sure you want to logout from your account?</p>
                            <div className="flex gap-3">
                                <button
                                    onClick={cancelLogout}
                                    className="flex-1 px-6 py-3 border-2 border-gray-200 rounded-xl text-gray-700 font-medium hover:bg-gray-50 transition-colors duration-200"
                                    disabled={isLoggingOut}
                                >
                                    Cancel
                                </button>
                                <button
                                    onClick={confirmLogout}
                                    className="flex-1 px-6 py-3 text-white font-medium rounded-xl hover:opacity-90 disabled:opacity-70 transition-all duration-200 shadow-lg"
                                    style={{ backgroundColor: '#fc2e6bed' }}
                                    disabled={isLoggingOut}
                                >
                                    {isLoggingOut ? (
                                        <div className="flex items-center justify-center gap-2">
                                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                            Logging out...
                                        </div>
                                    ) : (
                                        'Logout'
                                    )}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Main Navigation Bar */}
            <nav className="sticky top-0 z-40 bg-white shadow-sm">
                <div className="px-4 py-3 flex items-center gap-3">
                    {/* Logo */}
                    <div className="flex-shrink-0">
                        <Link to="/" className="block">
                            <img
                                src={setting.setting?.web_settings?.web_logo || "/placeholder.svg?height=32&width=100"}
                                alt="BringMart"
                                className="h-12 object-contain"
                            />
                        </Link>
                    </div>

                    {/* Right Icons */}
                    <div className="flex items-center gap-1 ml-auto">
                        {/* Wishlist */}
                        <NavLink
                            to="/wishlist"
                            className="relative p-2 rounded-full transition-all duration-200 hover:bg-gray-100 group"
                        >
                            <Heart className="w-5 h-5 text-gray-700 group-hover:text-red-500 transition-colors duration-300" />
                            {favouriteProducts?.length > 0 && (
                                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-lg">
                                    {favouriteProducts?.length}
                                </span>
                            )}
                        </NavLink>

                        {/* Cart */}
                        {/* <CartSliderModal>
                            <div className="relative p-2 rounded-full transition-all duration-200 hover:bg-gray-100 cursor-pointer group">
                                <ShoppingCart className="w-5 h-5 text-gray-700 group-hover:text-blue-500 transition-colors duration-300" />
                                {cartCount > 0 && (
                                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-blue-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-lg animate-bounce">
                                        {cartCount}
                                    </span>
                                )}
                            </div>
                        </CartSliderModal> */}

                        {/* Menu Toggle - moved to right, smooth */}
                        <button
                            onClick={toggleMobileMenu}
                            className="text-gray-700 hover:text-gray-900 transition-all duration-300 ease-in-out p-2 rounded-full hover:bg-gray-100"
                            aria-label="Toggle menu"
                        >
                            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                        </button>
                    </div>
                </div>

                {/* Search Bar */}
                <form onSubmit={handleSearch} className="px-4 pb-3 -mt-3">
                    <div className={`relative flex items-center rounded-xl overflow-hidden transition-all duration-300 ${searchFocused
                        ? 'ring-2 ring-blue-500/30 shadow-md'
                        : 'shadow-sm hover:shadow-md'
                        } bg-gray-50 border border-gray-200`}>
                        <input
                            type="text"
                            className="py-2.5 px-4 w-full bg-transparent outline-none text-gray-800 placeholder-gray-500 font-medium text-sm"
                            placeholder="Search products..."
                            onFocus={() => setSearchFocused(true)}
                            onBlur={() => setSearchFocused(false)}
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            required
                            minLength={2}
                        />
                        <button
                            type="submit"
                            className="p-2 mr-1 rounded-lg transition-all duration-200 hover:scale-110"
                            style={{ backgroundColor: '#fc2e6bed' }}
                            disabled={!searchQuery.trim()}
                        >
                            <Search className="w-4 h-4 text-white" />
                        </button>
                    </div>
                </form>

                {/* Location Bar - Only shown on home page */}
                {isHomePage && (
                    <SetDeliveryLocations
                        key={`mobile-nav-${locationModalKey}`}
                        onSuccess={handleLocationSuccess}
                        locationPermission={locationPermission}

                    >
                        <div className="bg-gray-50 px-3 py-1 flex items-center justify-between gap-2 cursor-pointer hover:bg-gray-100 transition-colors border-t border-gray-100">
                            <div className="flex items-center gap-1 flex-wrap">
                                <MapPin className="w-3 h-3 text-red-600 shrink-0" />
                                <p className="text-xs font-medium text-gray-700 whitespace-nowrap">
                                    Deliver to:
                                </p>
                                <p className="text-xs font-semibold text-red-600 truncate max-w-[150px]">
                                    {isLocationSet()
                                        ? city.city.formatted_address
                                        : 'Set Location'}
                                </p>
                            </div>
                            <ChevronDown className="w-3 h-3 text-gray-500 shrink-0" />
                        </div>
                    </SetDeliveryLocations>
                )}
            </nav>

            {/* Mobile Menu Overlay */}
            {mobileMenuOpen && (
                <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40" onClick={closeMobileMenu}>
                    <div
                        className="absolute right-0 top-0 h-full w-80 bg-white shadow-xl transform transition-transform duration-300 ease-out"
                        onClick={(e) => e.stopPropagation()}
                    >
                        {/* Menu Header */}
                        <div className="bg-gradient-to-r from-red-500 to-red-600 p-4 text-white">
                            <div className="flex items-center justify-between mb-3">
                                <div className="flex-1">
                                    {status === "fulfill" && user ? (
                                        <div>
                                            <h3 className="font-semibold text-lg">Hi, {user.name}!</h3>
                                            <p className="text-red-100 text-sm truncate">{user.email}</p>
                                        </div>
                                    ) : (
                                        <div>
                                            <h3 className="font-semibold text-lg">Welcome!</h3>
                                            <p className="text-red-100 text-sm">Please login to continue</p>
                                        </div>
                                    )}
                                </div>
                                <button
                                    onClick={closeMobileMenu}
                                    className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
                                >
                                    <X className="w-5 h-5" />
                                </button>
                            </div>
                        </div>

                        {/* Menu Content */}
                        <div className="flex-1 overflow-y-auto p-3">
                            {status === "fulfill" && user ? (
                                <div className="space-y-1">
                                    {/* User Menu Items */}
                                    {[
                                        {
                                            icon: ShoppingCart,
                                            label: "My Orders",
                                            path: "/my-orders",
                                            color: "text-green-600",
                                            bgColor: "bg-green-50",
                                        },
                                        {
                                            icon: Heart,
                                            label: "My Wishlist",
                                            path: "/wishlist",
                                            color: "text-red-600",
                                            bgColor: "bg-red-50",
                                            badge: favouriteProducts?.length,
                                        },
                                        {
                                            icon: Bell,
                                            label: "Notifications",
                                            path: "/notifications",
                                            color: "text-yellow-600",
                                            bgColor: "bg-yellow-50",
                                        },
                                        {
                                            icon: MapPinned,
                                            label: "My Addresses",
                                            path: "/my-addresses",
                                            color: "text-purple-600",
                                            bgColor: "bg-purple-50",
                                        },
                                        {
                                            icon: Wallet,
                                            label: "Wallet Balance",
                                            path: "/wallet-balance",
                                            color: "text-indigo-600",
                                            bgColor: "bg-indigo-50",
                                        },
                                        {
                                            icon: ReceiptIndianRupee,
                                            label: "Transactions",
                                            path: "/transactions",
                                            color: "text-pink-600",
                                            bgColor: "bg-pink-50",
                                        },
                                    ].map((item, index) => (
                                        <Link
                                            key={index}
                                            to={item.path}
                                            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 transition-colors group border border-transparent hover:border-gray-100"
                                            onClick={closeMobileMenu}
                                        >
                                            <div className="flex items-center gap-3">
                                                <div className={`p-2 rounded-lg ${item.bgColor} ${item.color}`}>
                                                    <item.icon className="w-5 h-5" />
                                                </div>
                                                <span className="font-medium text-gray-700 group-hover:text-gray-900">{item.label}</span>
                                            </div>
                                            {item.badge && item.badge > 0 && (
                                                <span className="px-2 py-1 bg-red-500 text-white text-xs font-semibold rounded-full min-w-[20px] text-center">
                                                    {item.badge}
                                                </span>
                                            )}
                                        </Link>
                                    ))}

                                    {/* Logout Button */}
                                    <div className="border-t border-gray-100 mt-3 pt-3">
                                        <button
                                            onClick={handleLogout}
                                            className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-red-50 transition-colors group"
                                        >
                                            <div className="p-2 rounded-lg bg-red-50 text-red-600 group-hover:bg-red-100">
                                                <LogOut className="w-5 h-5" />
                                            </div>
                                            <span className="font-medium text-red-600">Logout</span>
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                <div className="space-y-3">
                                    <NavLink
                                        to="/login"
                                        className="w-full flex items-center gap-3 p-3 rounded-xl bg-red-50 hover:bg-red-100 transition-colors"
                                        onClick={closeMobileMenu}
                                    >
                                        <div className="p-2 rounded-lg bg-red-600 text-white">
                                            <UserCircle className="w-5 h-5" />
                                        </div>
                                        <span className="font-medium text-gray-700">Login / Sign Up</span>
                                    </NavLink>

                                    <NavLink
                                        to="/wishlist"
                                        className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 transition-colors"
                                        onClick={closeMobileMenu}
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 rounded-lg bg-red-50 text-red-600">
                                                <Heart className="w-5 h-5" />
                                            </div>
                                            <span className="font-medium text-gray-700">My Wishlist</span>
                                        </div>
                                        {favouriteProducts?.length > 0 && (
                                            <span className="px-2 py-1 bg-red-500 text-white text-xs font-semibold rounded-full min-w-[20px] text-center">
                                                {favouriteProducts?.length}
                                            </span>
                                        )}
                                    </NavLink>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </>
    )
}