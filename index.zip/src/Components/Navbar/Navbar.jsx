import { useState } from 'react';
import { ChevronDown, Sun, ShoppingCart, Heart, User } from 'lucide-react';
import ScrollableNav from './ScrollableNav';
import bringmartLogo from '../../assets/bringmart-logo.png';

export default function Navbar() {
    const [wishlistCount, setWishlistCount] = useState(0);
    const [cartCount, setCartCount] = useState(1);

    return (
        <>
            <nav className="bg-[#fc2e6bed] p-4 flex flex-wrap gap-6 items-center justify-between">
                <div className="left-container flex gap-4 items-center">
                    <div className="logo w-20 py-2">
                        <a href="/"><img src={bringmartLogo} alt="BringMart" /></a>
                    </div>
                    <div className="location-conatiner flex items-center gap-2 cursor-pointer hover:opacity-60 duration-100 ease-in-out font-sans">
                        <div className="location">
                            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/4/41/Flag_of_India.svg/30px-Flag_of_India.svg.png?20240827082344" className="rounded" alt="Location" />
                        </div>
                        <div className="location-text text-gray-600">
                            <p className='text-sm flex gap-4'>Deliver to <ChevronDown /></p>
                            <p className='font-bold text-sm'>Bistupur, Jamshedpur</p>
                        </div>
                    </div>
                </div>
                <div className="center-container w-full md:w-auto mt-4 md:mt-0">
                    <input type="text" className='p-1 rounded-sm bg-[#fff] outline-none border border-gray-50 w-full md:min-w-3xl text-gray-700' placeholder='What are Looking For ?' />
                </div>
                <div className="right-container w-full md:w-auto mt-4 md:mt-0">
                    <div className="flex gap-4 justify-between items-center">
                        <div className="theme-icon cursor-pointer hover:opacity-60 duration-100 ease-in-out flex gap-2 items-center">
                            <Sun className="w-6 h-6" />
                            <span> |</span>
                        </div>
                        <div className="login-icon cursor-pointer hover:opacity-60 duration-100 ease-in-out flex gap-2 items-center">
                            <p className='font-bold text-sm'>Log in</p>
                            <User className="w-6 h-6" /> <span> |</span>
                        </div>
                        <div className="wishlist-icon login-icon cursor-pointer hover:opacity-60 duration-100 ease-in-out flex gap-2 items-center relative">
                            <p className='font-bold text-sm'>Wishlist</p>
                            <Heart className="w-6 h-6" />
                            {wishlistCount > 0 && (
                                <span className='text-center bg-blue-700 text-white rounded-full p-1 text-sm absolute top-[-15px] right-[5px] w-[25px] h-[25px]'>{wishlistCount}</span>
                            )}
                            <span> |</span>
                        </div>
                        <div className="cart-icon login-icon cursor-pointer hover:opacity-60 duration-100 ease-in-out flex gap-2 items-center relative">
                            <p className='font-bold text-sm'>Cart</p>
                            {cartCount > 0 && (
                                <span className='text-center bg-blue-700 text-white rounded-full p-1 text-sm absolute top-[-15px] right-[-5px] w-[25px] h-[25px]'>{cartCount}</span>
                            )}
                            <ShoppingCart className="w-6 h-6" />
                        </div>
                    </div>
                </div>
            </nav>
            <div className="bottom-section-nav bg-white mt-4 md:mt-0">
                <ScrollableNav />
            </div>
        </>
    );
}