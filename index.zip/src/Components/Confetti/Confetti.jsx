// components/Confetti.js
import { useState, useEffect } from "react";
import { motion } from "framer-motion";

const Confetti = () => {
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    const newParticles = [];
    const colors = ["#8B5CF6", "#06B6D4", "#10B981", "#F59E0B", "#EF4444", "#EC4899"];
    const shapes = ["square", "circle", "diamond"];

    for (let i = 0; i < 60; i++) {
      newParticles.push({
        id: i,
        x: Math.random() * 100,
        y: -10 - Math.random() * 20,
        size: 3 + Math.random() * 8,
        color: colors[Math.floor(Math.random() * colors.length)],
        shape: shapes[Math.floor(Math.random() * shapes.length)],
        rotation: Math.random() * 360,
        velocity: {
          x: -2 + Math.random() * 4,
          y: 1 + Math.random() * 4,
        },
      });
    }

    setParticles(newParticles);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-10">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className={`absolute ${p.shape === "circle" ? "rounded-full" : p.shape === "diamond" ? "rotate-45 rounded-sm" : "rounded-sm"
            }`}
          initial={{
            x: `${p.x}%`,
            y: `${p.y}%`,
            rotate: 0,
            opacity: 0.9,
            scale: 1,
          }}
          animate={{
            x: `${p.x + p.velocity.x * 25}%`,
            y: `${120 + Math.random() * 15}%`,
            rotate: p.rotation + 180,
            opacity: 0,
            scale: 0.2,
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            ease: "easeOut",
          }}
          style={{
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            filter: "blur(0.5px)",
          }}
        />
      ))}
    </div>
  );
};

export default Confetti;