"use client"

import { useState, useEffect, useCallback } from "react"
import { useDispatch, useSelector } from "react-redux"
import { useNavigate } from "react-router-dom"
import { toast } from "react-toastify"
import { Trash2, ShoppingBag, Plus, Minus, ChevronLeft, ArrowRight, Check, X, Tag, Package } from "lucide-react"
import { RiCoupon2Fill } from "react-icons/ri"
import api from "../api/api"
import {
  clearCartPromo,
  removeFromGuestCart,
  setCart,
  setCartCheckout,
  setCartProducts,
  setCartSubTotal,
  setGuestCartTotal,
  updateCartItemQuantity,
  updateGuestCartItemQuantity,
  removeCartItem,
} from "../model/reducer/cartReducer"
import { setPromoCode } from "../model/reducer/promoReducer"

const DEFAULT_LOCATION = {
  latitude: 28.6139,
  longitude: 77.209,
}

function Cart() {
  const { cart, guestCart, guestCartTotal, isGuest, cartProducts, cartSubTotal, checkout, promo_code } = useSelector(
    (state) => state.cart,
  )
  const { user, status, jwtToken } = useSelector((state) => state.user)
  const { city, setting } = useSelector((state) => state)
  const isLoggedIn = status === "fulfill" && jwtToken
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const [isLoading, setIsLoading] = useState(true)
  const [showPromoModal, setShowPromoModal] = useState(false)
  const [promoCode, setPromoCodeInput] = useState("")

  const subtotal = isGuest ? guestCartTotal : cartSubTotal
  const currentLocation = city?.city || DEFAULT_LOCATION
  const currentCartItems = isGuest ? guestCart : cartProducts

  const fetchCartData = useCallback(async () => {
    if (!isLoggedIn) return
    setIsLoading(true)
    try {
      const response = await api.getCart(jwtToken, currentLocation.latitude, currentLocation.longitude)
      const result = await response.json()
      if (result?.status === 1) {
        dispatch(setCart({ data: result.data }))
        const productsData = result.data.cart.map((product) => ({
          id: `${product.product_id}_${product.product_variant_id}`,
          product_id: product.product_id,
          product_variant_id: product.product_variant_id,
          quantity: product.qty,
          price: product.price,
          discounted_price: product.discounted_price,
          name: product.name,
          image: product.image_url,
          measurement: product.measurement,
          unit_code: product.unit_code,
          stock: product.stock,
          is_unlimited_stock: product.is_unlimited_stock,
          total_allowed_quantity: product.total_allowed_quantity,
          slug: product.slug,
          status: product.status === 1,
        }))
        dispatch(setCartProducts({ data: productsData }))
        dispatch(setCartSubTotal({ data: result.data.sub_total }))
      } else if (result.message === "No item's found in users cart") {
        dispatch(setCartProducts({ data: [] }))
        dispatch(setCartSubTotal({ data: 0 }))
        dispatch(setCartCheckout({ data: null }))
      } else {
        toast.error(result.message || "Failed to fetch cart data")
      }
    } catch (error) {
      console.error("Cart fetch error:", error)
      toast.error("Failed to fetch cart data")
    } finally {
      setIsLoading(false)
    }
  }, [isLoggedIn, jwtToken, currentLocation, dispatch])

  const fetchGuestCart = useCallback(async () => {
    if (isLoggedIn) return
    setIsLoading(true)
    try {
      if (!currentLocation.latitude || !currentLocation.longitude) {
        throw new Error("Location data is not available")
      }
      const validGuestCart = guestCart.filter((item) => item.product_variant_id && item.quantity > 0)
      if (validGuestCart.length === 0) {
        dispatch(setGuestCartTotal({ data: 0 }))
        dispatch(setCartCheckout({ data: null }))
        return
      }
      const variantIds = validGuestCart.map((p) => p.product_variant_id)
      const quantities = validGuestCart.map((p) => p.quantity)
      const response = await api.getGuestCart(
        currentLocation.latitude,
        currentLocation.longitude,
        variantIds.join(","),
        quantities.join(","),
      )
      if (!response.ok) {
        throw new Error("Failed to fetch guest cart")
      }
      const result = await response.json()
      if (result.status === 1) {
        const updatedGuestCart = validGuestCart.map((item) => {
          const serverItem = result.data.cart.find((si) => si.product_variant_id === item.product_variant_id)
          return serverItem
            ? {
                ...item,
                id: `${item.product_id}_${item.product_variant_id}`,
                price: serverItem.price,
                discounted_price: serverItem.discounted_price,
                name: serverItem.name,
                image: serverItem.image_url,
                measurement: serverItem.measurement,
                unit_code: serverItem.unit_code,
                stock: serverItem.stock,
                is_unlimited_stock: serverItem.is_unlimited_stock,
                total_allowed_quantity: serverItem.total_allowed_quantity,
                slug: serverItem.slug,
                status: serverItem.status === 1,
              }
            : item
        })
        const calculatedSubtotal = updatedGuestCart.reduce((total, item) => {
          const itemPrice = item.discounted_price > 0 ? item.discounted_price : item.price
          return total + itemPrice * item.quantity
        }, 0)
        dispatch(setGuestCartTotal({ data: calculatedSubtotal }))
        dispatch(
          setCartCheckout({
            data: {
              ...result.data,
              product_variant_id: updatedGuestCart.map((p) => p.product_variant_id),
              quantity: updatedGuestCart.map((p) => p.quantity),
            },
          }),
        )
      } else {
        throw new Error(result.message || "Failed to fetch guest cart")
      }
    } catch (error) {
      console.error("Guest cart error:", error)
      if (guestCart?.length > 0) {
        toast.error("Failed to update guest cart. Please try again.")
      }
    } finally {
      setIsLoading(false)
    }
  }, [isLoggedIn, guestCart, currentLocation, dispatch])

  useEffect(() => {
    if (isLoggedIn) {
      fetchCartData()
    } else if (guestCart?.length > 0) {
      fetchGuestCart()
    } else {
      dispatch(setGuestCartTotal({ data: 0 }))
      dispatch(setCartCheckout({ data: null }))
    }
  }, [isLoggedIn, guestCart, fetchCartData, fetchGuestCart, dispatch])

  const removeItem = async (id) => {
    try {
      if (isGuest) {
        dispatch(removeFromGuestCart(id))
        if (guestCart.length > 1) {
          await fetchGuestCart()
        } else {
          dispatch(setGuestCartTotal({ data: 0 }))
          dispatch(setCartCheckout({ data: null }))
        }
      } else {
        const item = cartProducts.find((item) => item.id === id)
        if (item) {
          await handleRemoveCartItem(item.product_id, item.product_variant_id)
        }
      }
      toast.success("Item removed from cart")
    } catch (error) {
      console.error("Failed to remove item:", error)
      toast.error("Failed to remove item. Please try again.")
    }
  }

  const updateCartItem = async (product_id, product_variant_id, qty) => {
    try {
      const response = await api.addToCart(jwtToken, product_id, product_variant_id, qty)
      const result = await response.json()
      if (result.status === 1) {
        dispatch(
          updateCartItemQuantity({
            product_id,
            product_variant_id,
            quantity: qty,
          }),
        )
        await fetchCartData()
        toast.success("Quantity updated")
      } else {
        toast.error(result.message)
      }
    } catch (error) {
      console.error("Error updating cart:", error)
      toast.error("Failed to update cart")
    }
  }

  const handleRemoveCartItem = async (product_id, product_variant_id) => {
    try {
      const response = await api.removeFromCart(jwtToken, product_id, product_variant_id)
      const result = await response.json()
      if (result.status === 1) {
        dispatch(removeCartItem({ product_id, product_variant_id }))
        dispatch(clearCartPromo())
        await fetchCartData()
        toast.success("Item removed from cart")
      } else {
        toast.error(result.message)
      }
    } catch (error) {
      console.error("Error removing item:", error)
      toast.error("Failed to remove item")
    }
  }

  const updateItemQuantity = async (id, quantity) => {
    const item = guestCart.find((item) => item.id === id)
    if (!item) return
    dispatch(
      updateGuestCartItemQuantity({
        id,
        quantity,
        price: item.price,
        discounted_price: item.discounted_price,
      }),
    )
    try {
      await fetchGuestCart()
    } catch {
      toast.error("Failed to update cart total")
    }
  }

  const isOutOfStock = (item) => {
    if (item.status === false) return true
    if (item.is_unlimited_stock === 1) return false
    return item.stock <= 0
  }

  const increaseQuantity = (id) => {
    const item = isGuest ? guestCart.find((item) => item.id === id) : cartProducts.find((item) => item.id === id)
    if (!item) return
    if (isOutOfStock(item)) {
      toast.error(`${item.name} is out of stock`)
      return
    }
    if (item.is_unlimited_stock !== 1 && item.quantity >= item.stock) {
      toast.error(`Only ${item.stock} ${item.name} available in stock`)
      return
    }
    const newQuantity = item.quantity + 1
    if (isGuest) {
      updateItemQuantity(id, newQuantity)
    } else {
      updateCartItem(item.product_id, item.product_variant_id, newQuantity)
    }
  }

  const decreaseQuantity = (id) => {
    const item = isGuest ? guestCart.find((item) => item.id === id) : cartProducts.find((item) => item.id === id)
    if (!item) return
    if (isOutOfStock(item)) {
      toast.error(`${item.name} is out of stock`)
      return
    }
    if (item.quantity > 1) {
      if (isGuest) {
        updateItemQuantity(id, item.quantity - 1)
      } else {
        updateCartItem(item.product_id, item.product_variant_id, item.quantity - 1)
      }
    } else {
      if (isGuest) {
        removeItem(id)
      } else {
        handleRemoveCartItem(item.product_id, item.product_variant_id)
      }
    }
  }

  const handleCheckout = () => {
    if (!isLoggedIn) {
      navigate("/login", { state: { from: "/cart" } })
      return
    }
    const outOfStockItems = (isGuest ? guestCart : cartProducts).filter((item) => isOutOfStock(item))
    if (outOfStockItems.length > 0) {
      toast.error(
        <div>
          <p>{outOfStockItems.length} item(s) in your cart are out of stock:</p>
          <ul className="list-disc pl-5 mt-1">
            {outOfStockItems.slice(0, 3).map((item) => (
              <li key={item.id}>{item.name}</li>
            ))}
            {outOfStockItems.length > 3 && <li>...and {outOfStockItems.length - 3} more</li>}
          </ul>
          <p className="mt-1">Please remove them to proceed to checkout.</p>
        </div>,
        { autoClose: 5000 },
      )
      return
    }
    const cartItems = isGuest ? guestCart : cartProducts
    const calculatedSubtotal = cartItems.reduce((total, item) => {
      const itemPrice = item.discounted_price > 0 ? item.discounted_price : item.price
      return total + itemPrice * item.quantity
    }, 0)
    navigate("/checkout", {
      state: {
        subtotal: calculatedSubtotal,
        cartItems: cartItems.map((item) => ({
          ...item,
          product_variant_id: item.product_variant_id,
          price: item.discounted_price > 0 ? item.discounted_price : item.price,
          qty: item.quantity,
        })),
        isGuest: isGuest,
      },
    })
  }

  const removeCoupon = () => {
    dispatch(clearCartPromo())
    toast.info("Coupon Removed")
  }

  const applyPromoCode = async () => {
    if (!promoCode.trim()) {
      toast.error("Please enter a promo code")
      return
    }
    try {
      const response = await api.applyPromoCode(
        isGuest ? null : jwtToken,
        promoCode,
        isGuest ? guestCart.map((item) => item.product_variant_id).join(",") : null,
        isGuest ? guestCart.map((item) => item.quantity).join(",") : null,
      )
      const result = await response.json()
      if (result.status === 1) {
        dispatch(
          setPromoCode({
            code: promoCode,
            discount: result.data.discount,
            isPromoCode: true,
          }),
        )
        toast.success("Promo code applied successfully")
        setShowPromoModal(false)
      } else {
        toast.error(result.message || "Failed to apply promo code")
      }
    } catch (error) {
      console.error("Error applying promo code:", error)
      toast.error("Failed to apply promo code")
    }
  }

  const placeHolderImage = (e) => {
    e.target.src = setting?.setting?.web_logo
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white flex items-center justify-center">
        <div className="text-center">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-gray-200 border-t-[#fc2e6bed] rounded-full animate-spin mx-auto"></div>
            <ShoppingBag className="w-6 h-6 text-[#fc2e6bed] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
          </div>
          <p className="mt-4 text-gray-600 font-medium">Loading your cart...</p>
        </div>
      </div>
    )
  }

  if (currentCartItems?.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
        <div className="container mx-auto px-4 py-16">
          <div className="flex flex-col items-center justify-center text-center max-w-lg mx-auto">
            <div className="relative mb-8">
              <div className="w-40 h-40 bg-gradient-to-br from-[#fc2e6bed]/10 to-[#fc2e6bed]/5 rounded-full flex items-center justify-center">
                <div className="w-32 h-32 bg-white rounded-full shadow-lg flex items-center justify-center">
                  <ShoppingBag className="w-16 h-16 text-[#fc2e6bed]" />
                </div>
              </div>
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-[#fc2e6bed] rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-bold">0</span>
              </div>
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-3">Your cart is empty</h1>
            <p className="text-gray-600 text-lg mb-8 leading-relaxed">
              Discover amazing products and start adding them to your cart
            </p>
            <button
              onClick={() => navigate("/")}
              className="group px-8 py-4 bg-[#fc2e6bed] text-white rounded-xl font-semibold hover:bg-[#fc2e6bed]/90 transition-all duration-200 flex items-center gap-3 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              Start Shopping
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 bg-[#fc2e6bed] rounded-lg flex items-center justify-center">
              <ShoppingBag className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">Shopping Cart</h1>
          </div>
          <p className="text-gray-600">
            {currentCartItems?.length || 0} {currentCartItems?.length === 1 ? "item" : "items"} in your cart
          </p>
        </div>

        <div className="flex flex-col xl:flex-row gap-8">
          {/* Cart Items Section */}
          <div className="xl:w-2/3">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="divide-y divide-gray-100">
                {currentCartItems?.map((item, index) => (
                  <div key={item.id} className="p-6 hover:bg-gray-50/50 transition-colors">
                    <div className="flex flex-col lg:flex-row gap-6">
                      {/* Product Image */}
                      <div className="w-full lg:w-32 h-32 flex-shrink-0 rounded-xl overflow-hidden bg-gradient-to-br from-gray-100 to-gray-50 border border-gray-200 flex items-center justify-center group">
                        <img
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          className="max-w-full max-h-full object-contain p-2 group-hover:scale-105 transition-transform duration-200"
                          onError={placeHolderImage}
                        />
                      </div>

                      {/* Product Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex-1 min-w-0 pr-4">
                            <h3 className="text-xl font-semibold text-gray-900 mb-1 line-clamp-2">{item.name}</h3>
                            <div className="flex items-center gap-2 text-sm text-gray-500">
                              <Package className="w-4 h-4" />
                              <span>
                                {item.measurement} {item.unit_code}
                              </span>
                            </div>
                          </div>
                          <button
                            onClick={() =>
                              isGuest
                                ? removeItem(item.id)
                                : handleRemoveCartItem(item.product_id, item.product_variant_id)
                            }
                            className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all duration-200"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>

                        {/* Price */}
                        <div className="flex items-center gap-3 mb-3">
                          <span className="text-2xl font-bold text-gray-900">
                            {setting?.setting?.currency}
                            {(Number(item.discounted_price) > 0 ? item.discounted_price : item.price).toFixed(2)}
                          </span>
                          {item.discounted_price > 0 && (
                            <span className="text-lg text-gray-400 line-through">
                              {setting?.setting?.currency}
                              {Number(item.price).toFixed(2)}
                            </span>
                          )}
                        </div>

                        {/* Stock Status */}
                        <div className="mb-4">
                          {isOutOfStock(item) ? (
                            <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm font-medium">
                              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                              Out of stock
                            </div>
                          ) : item.is_unlimited_stock !== 1 ? (
                            <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                              {item.stock} available
                            </div>
                          ) : (
                            <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                              In stock
                            </div>
                          )}
                        </div>

                        {/* Quantity Controls and Total */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center bg-gray-100 rounded-xl overflow-hidden">
                            <button
                              onClick={() => decreaseQuantity(item.id)}
                              disabled={isOutOfStock(item) || item.quantity <= 1}
                              className={`w-12 h-12 flex items-center justify-center transition-colors ${
                                isOutOfStock(item) || item.quantity <= 1
                                  ? "text-gray-400 cursor-not-allowed"
                                  : "text-gray-700 hover:bg-gray-200 active:bg-gray-300"
                              }`}
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <div className="w-16 text-center font-semibold text-lg">{item.quantity}</div>
                            <button
                              onClick={() => increaseQuantity(item.id)}
                              disabled={
                                isOutOfStock(item) || (item.is_unlimited_stock !== 1 && item.quantity >= item.stock)
                              }
                              className={`w-12 h-12 flex items-center justify-center transition-colors ${
                                isOutOfStock(item) || (item.is_unlimited_stock !== 1 && item.quantity >= item.stock)
                                  ? "text-gray-400 cursor-not-allowed"
                                  : "text-gray-700 hover:bg-gray-200 active:bg-gray-300"
                              }`}
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>
                          <div className="text-right">
                            <div className="text-sm text-gray-500 mb-1">Total</div>
                            <div className="text-2xl font-bold text-[#fc2e6bed]">
                              {setting?.setting?.currency}
                              {(
                                (Number(item.discounted_price) > 0 ? item.discounted_price : item.price) * item.quantity
                              ).toFixed(2)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Continue Shopping */}
              <div className="p-6 bg-gray-50 border-t border-gray-100">
                <button
                  onClick={() => navigate("/")}
                  className="flex items-center gap-2 text-gray-600 hover:text-[#fc2e6bed] font-medium transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                  Continue Shopping
                </button>
              </div>
            </div>
          </div>

          {/* Order Summary Section */}
          <div className="xl:w-1/3">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 sticky top-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Order Summary</h2>

              {/* Promo Code Section */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Tag className="w-5 h-5 text-gray-500" />
                    <span className="font-medium text-gray-700">Promo Code</span>
                  </div>
                  {!promo_code ? (
                    <button
                      onClick={() => setShowPromoModal(true)}
                      className="text-[#fc2e6bed] font-semibold hover:text-[#fc2e6bed]/80 transition-colors"
                    >
                      Apply
                    </button>
                  ) : (
                    <button
                      onClick={removeCoupon}
                      className="text-red-500 hover:text-red-600 font-semibold transition-colors"
                    >
                      Remove
                    </button>
                  )}
                </div>
                {promo_code && (
                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-4">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <Check className="w-4 h-4 text-green-600" />
                        </div>
                        <div>
                          <div className="font-semibold text-green-800">{promo_code.code}</div>
                          <div className="text-sm text-green-600">Promo applied</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-green-700 text-lg">
                          -{setting?.setting?.currency}
                          {promo_code.discount}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Order Details */}
              <div className="space-y-4 mb-6">
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-semibold text-lg">
                    {setting?.setting?.currency}
                    {subtotal?.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600">Delivery</span>
                  <span className="font-medium text-gray-500">Calculated at checkout</span>
                </div>
                {promo_code && (
                  <div className="flex justify-between items-center py-2">
                    <span className="text-gray-600">Discount</span>
                    <span className="font-semibold text-green-600 text-lg">
                      -{setting?.setting?.currency}
                      {promo_code.discount}
                    </span>
                  </div>
                )}
              </div>

              {/* Total */}
              <div className="border-t border-gray-200 pt-6 mb-6">
                <div className="flex justify-between items-center">
                  <span className="text-xl font-bold text-gray-900">Total</span>
                  <span className="text-2xl font-bold text-[#fc2e6bed]">
                    {setting?.setting?.currency}
                    {(subtotal - (promo_code?.discount || 0)).toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={handleCheckout}
                className="w-full py-4 bg-[#fc2e6bed] text-white font-bold rounded-xl hover:bg-[#fc2e6bed]/90 transition-all duration-200 flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
              >
                Proceed to Checkout
                <ArrowRight className="w-5 h-5" />
              </button>

              {/* Security Badge */}
              <div className="mt-4 text-center">
                <div className="inline-flex items-center gap-2 text-sm text-gray-500">
                  <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                  Secure checkout guaranteed
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Promo Code Modal */}
      {showPromoModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl transform transition-all">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#fc2e6bed]/10 rounded-xl flex items-center justify-center">
                  <RiCoupon2Fill className="w-5 h-5 text-[#fc2e6bed]" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Apply Promo Code</h3>
              </div>
              <button
                onClick={() => setShowPromoModal(false)}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mb-6">
              <input
                type="text"
                value={promoCode}
                onChange={(e) => setPromoCodeInput(e.target.value)}
                placeholder="Enter your promo code"
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#fc2e6bed]/20 focus:border-[#fc2e6bed] transition-colors text-lg"
                autoFocus
              />
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowPromoModal(false)}
                className="flex-1 py-3 border border-gray-300 rounded-xl text-gray-700 font-semibold hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={applyPromoCode}
                className="flex-1 py-3 bg-[#fc2e6bed] text-white font-semibold rounded-xl hover:bg-[#fc2e6bed]/90 transition-colors"
              >
                Apply Code
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Cart
