import React, { useRef, useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { clearCategory, clearSelectedCategory, setCategory, setSelectedCategory } from '../../model/reducer/categoryReducer';
import { setFilterCategory } from '../../model/reducer/productFilterReducer';

const DeskTopCategoryCarousel = () => {
  const dispatch = useDispatch();
  const shop = useSelector((state) => state.shop?.shop);
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const scrollContainerRef = useRef(null);
  const navigate = useNavigate();

  // Check if device is mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Set categories from shop
  useEffect(() => {
    if (shop?.categories && shop?.categories.length > 0) {
      setCategories(shop?.categories);
      setIsLoading(false);
    }
  }, [shop]);

  const scroll = (direction) => {
    const container = scrollContainerRef.current;
    if (container) {
      const scrollAmount = 200;
      container.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  const handleCategoryClick = (category) => {
    if (!category || !category.id) {
      console.error('Invalid category object:', category);
      return;
    }

    if (category?.has_child) {
      // If category has children, navigate to category page
      navigate(`/category/${category?.slug}`);
      dispatch(setCategory(shop?.categories))
      dispatch(setSelectedCategory({
        ...category, // spread all category properties
        children: category?.cat_active_childs || []
      }));
    } else {
      // If no children, navigate directly to products with this category filter
      dispatch(setFilterCategory({ data: category?.id }));
      navigate('/products');
    }
  };

  // Mobile Loading Skeleton
  const MobileLoadingSkeleton = () => (
    <div className="space-y-3">
      {Array.from({ length: 8 }).map((_, index) => (
        <div key={index} className="flex items-center p-4 bg-white rounded-xl shadow-sm">
          <div className="w-12 h-12 bg-gray-200 rounded-full animate-pulse" />
          <div className="ml-4 flex-1">
            <div className="h-4 bg-gray-200 rounded animate-pulse w-3/4" />
            <div className="h-3 bg-gray-100 rounded animate-pulse w-1/2 mt-2" />
          </div>
          <div className="w-6 h-6 bg-gray-200 rounded animate-pulse" />
        </div>
      ))}
    </div>
  );

  // Desktop Loading Skeleton
  const DesktopLoadingSkeleton = () => (
    <div className="flex gap-4 w-full">
      {Array.from({ length: 6 }).map((_, index) => (
        <div key={index} className="flex flex-col items-center gap-2">
          <div className="w-28 h-28 bg-gray-200 animate-pulse rounded-full" />
          <div className="w-20 h-4 bg-gray-200 animate-pulse rounded" />
        </div>
      ))}
    </div>
  );

  // Mobile List View
  const MobileView = () => (
    <div className="px-4 py-2">
      <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-2xl p-4 mb-4">
        <h2 className="text-lg font-bold text-gray-800 mb-1">Shop by Categories</h2>
        <p className="text-sm text-gray-600">Discover our wide range of products</p>
      </div>

      {isLoading ? (
        <MobileLoadingSkeleton />
      ) : (
        <div className="space-y-2">
          {categories?.map((category, index) => (
            <div
              key={category.slug || index}
              className="group bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden border border-gray-100 hover:border-pink-200 active:scale-[0.98]"
              onClick={() => handleCategoryClick(category)}
            >
              <div className="flex items-center p-4">
                {/* Category Image */}
                <div className="relative w-12 h-12 rounded-full overflow-hidden bg-gradient-to-br from-pink-100 to-rose-100 flex-shrink-0">
                  {category.image_url ? (
                    <img
                      src={category.image_url}
                      alt={category.subtitle}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                      onError={(e) => {
                        e.target.style.display = 'none';
                        e.target.parentElement.classList.add('flex', 'items-center', 'justify-center');
                        e.target.parentElement.innerHTML = `<span class="text-pink-500 font-semibold text-sm">${category.name?.charAt(0) || ''}</span>`;
                      }}
                    />
                  ) : (
                    <span className="text-pink-500 font-semibold text-sm flex items-center justify-center w-full h-full">
                      {category.name?.charAt(0) || ''}
                    </span>
                  )}
                </div>

                {/* Category Info */}
                <div className="ml-4 flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-800 text-sm truncate group-hover:text-pink-600 transition-colors duration-200">
                    {category.name || 'Unnamed Category'}
                  </h3>
                  <p className="text-xs text-gray-500 mt-0.5 truncate">
                    Explore {category.name?.toLowerCase() || 'category'} collection
                  </p>
                </div>

                {/* Arrow Icon */}
                <div className="flex-shrink-0 ml-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-pink-500 to-rose-500 flex items-center justify-center group-hover:shadow-lg transition-all duration-200">
                    <ArrowRight className="w-4 h-4 text-white group-hover:translate-x-0.5 transition-transform duration-200" />
                  </div>
                </div>
              </div>

              {/* Subtle bottom border with gradient */}
              <div className="h-0.5 bg-gradient-to-r from-transparent via-pink-200 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
          ))}
        </div>
      )}

      {/* View All Categories Button */}
      {!isLoading && categories.length > 0 && (
        <div className="mt-6 pt-4">
          <button
            onClick={() => navigate('/category/all')}
            className="w-full mb-5 bg-gradient-to-r from-pink-500 to-rose-500 text-white py-3 px-4 rounded-xl font-semibold text-sm shadow-lg hover:shadow-xl active:scale-[0.98] transition-all duration-200"
          >
            View All Categories
          </button>
        </div>
      )}
    </div>
  );

  // Desktop Carousel View
  const DesktopView = () => (
    <div className="relative max-w-full px-4 py-6 z-10">
      {/* Left Navigation Arrow */}
      <button
        onClick={() => scroll('left')}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors cursor-pointer"
        aria-label="Scroll left"
      >
        <ChevronLeft className="w-5 h-5 text-gray-600" />
      </button>

      {/* Category Cards Container */}
      <div
        ref={scrollContainerRef}
        className="overflow-x-auto scrollbar-none [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        <div className="flex gap-4 min-w-full">
          {isLoading ? (
            <DesktopLoadingSkeleton />
          ) : (
            categories.map((category, index) => (
              <div
                key={category.slug || index}
                className="flex flex-col items-center gap-2 cursor-pointer group"
                onClick={() => handleCategoryClick(category)}
              >
                <div className="relative h-24 w-24 p-1 rounded-full bg-gradient-to-br from-pink-200 to-rose-200 group-hover:shadow-xl transition-all duration-300">
                  <div className="h-full w-full rounded-full overflow-hidden flex items-center justify-center bg-white">
                    {category.image_url ? (
                      <img
                        src={category.image_url}
                        alt={category.subtitle}
                        className="w-32 h-32 object-cover rounded-full group-hover:scale-110 transition-transform duration-300"
                        onError={(e) => {
                          e.target.style.display = 'none';
                          e.target.parentElement.classList.add('flex', 'items-center', 'justify-center');
                          e.target.parentElement.innerHTML = `<span class="text-pink-500 font-semibold">${category.name?.charAt(0) || ''}</span>`;
                        }}
                      />
                    ) : (
                      <span className="text-pink-500 font-semibold text-lg">
                        {category.name?.charAt(0) || ''}
                      </span>
                    )}
                  </div>
                </div>

                <span className="text-sm text-gray-700 text-center font-medium max-w-[112px] group-hover:text-pink-600 transition-colors duration-200">
                  {category.name || 'Unnamed Category'}
                </span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Right Navigation Arrow */}
      <button
        onClick={() => scroll('right')}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors cursor-pointer"
        aria-label="Scroll right"
      >
        <ChevronRight className="w-5 h-5 text-gray-600" />
      </button>
    </div>
  );

  return isMobile ? <MobileView /> : <DesktopView />;
};

export default DeskTopCategoryCarousel;