import { useEffect, useRef, useState } from "react"
import { useSelector } from "react-redux"
import ProductCard from "../ProductCard"
import { CircleChevronLeft, CircleChevronRight } from "lucide-react"
import { useNavigate } from "react-router-dom"

const RecommendedProducts = () => {
  const { shop } = useSelector((state) => state.shop)
  const recommendedProducts = shop?.recommended_products || []
  const scrollRef = useRef(null)
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768)

  const navigate = useNavigate()

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768)
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  // Add scrollbar hiding styles dynamically
  useEffect(() => {
    const styleElement = document.createElement('style');
    styleElement.innerHTML = `
      .scrollbar-hide::-webkit-scrollbar {
        display: none;
      }
      .scrollbar-hide {
        -ms-overflow-style: none;
        scrollbar-width: none;
      }
    `;
    document.head.appendChild(styleElement);

    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  if (!recommendedProducts.length) return null

  const scroll = (direction) => {
    if (scrollRef.current) {
      const scrollAmount = scrollRef.current.offsetWidth * 0.8
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
    }
  }

  const renderProductCard = (product, index) => {
    const variant = product.variants?.[0] || {}

    const discountPercentage =
      variant.price && variant.discounted_price && variant.price > variant.discounted_price
        ? Math.round(((variant.price - variant.discounted_price) / variant.price) * 100)
        : product.cal_discount_percentage || product.discount || 0

    return (
      <div
        key={`${product.id}-${variant?.id || index}`}
        className={`${isMobile ? "w-full" : "flex-shrink-0 w-[220px]"} relative`}
      >
        <div className="h-full">
          <ProductCard
            product={{
              ...product,
              image: product.image_url || product.image,
              discount: discountPercentage,
              seller: product.seller_name || "",
              rating: product.rating || 4.5,
              rating_count: product.rating_count || 0,
              price: variant.price || product.price || 0,
              discounted_price:
                variant.discounted_price || variant.price || product.discounted_price || product.price || 0,
              measurement: variant.measurement || product.measurement || "1",
              unit_code: variant.stock_unit_name || product.unit_code || "PC",
              stock: variant.stock || product.stock || 0,
              is_unlimited_stock: product.is_unlimited_stock || 0,
              total_allowed_quantity: product.total_allowed_quantity || 10000,
              slug: product.slug || `product-${product.id}`,
              product_variant_id: variant.id,
            }}
          />
        </div>
      </div>
    )
  }

  return (
    <div className="w-full py-3 px-4">
      <div className="py-3">
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold tracking-tight">
              <span className="text-slate-800">Recommended</span>
              <span className="text-[#fc2e6bed] ml-2">Products</span>
            </h2>
            <div className="w-16 sm:w-20 md:w-24 h-0.5 bg-[#fc2e6bed] mt-3 sm:mt-4 rounded-full"></div>
          </div>

          {/* Desktop Only: View All Products Button */}
          {!isMobile && (
            <button
              onClick={() => navigate("/products")}
              className="text-sm md:text-base text-white bg-[#fc2e6bed] hover:bg-[#4543caed] px-4 md:px-6 ease-in-out duration-300 py-2.5 rounded-lg font-semibold transition-colors shadow-sm hover:shadow-md"
            >
              View All Products
            </button>
          )}
        </div>
      </div>

      <div className="relative mt-2">
        {isMobile ? (
          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            {recommendedProducts.map((product, index) => renderProductCard(product, index))}
          </div>
        ) : (
          <>
            <button
              onClick={() => scroll("left")}
              className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 hover:bg-white rounded-full w-10 h-10 flex items-center justify-center shadow-md transition-all duration-200 hover:shadow-lg"
              aria-label="Previous products"
            >
              <CircleChevronLeft className="w-6 h-6 text-gray-600" />
            </button>

            <div
              ref={scrollRef}
              className="flex overflow-x-auto gap-4 px-12 pb-4 scrollbar-hide scroll-smooth"
              style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
            >
              {recommendedProducts.map((product, index) => renderProductCard(product, index))}
            </div>

            <button
              onClick={() => scroll("right")}
              className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 hover:bg-white rounded-full w-10 h-10 flex items-center justify-center shadow-md transition-all duration-200 hover:shadow-lg"
              aria-label="Next products"
            >
              <CircleChevronRight className="w-6 h-6 text-gray-600" />
            </button>
          </>
        )}

        {/* Mobile Only: Show More Button */}
        {isMobile && (
          <div className="flex justify-center mt-6">
            <button
              onClick={() => navigate("/products")}
              className="text-sm text-[#fc2e6bed] hover:text-[#4543caed] font-semibold border border-[#fc2e6bed] hover:border-[#4543caed] px-6 py-2.5 rounded-lg transition-colors duration-300"
            >
              Show More Products
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

export default RecommendedProducts