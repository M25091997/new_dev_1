"use client"

import { useState, useEffect } from "react"
import { useSelector } from "react-redux"
import { Sparkles, TrendingUp, Award } from "lucide-react"

const BrandSlider = () => {
    const { shop } = useSelector((state) => state.shop)
    const [currentIndex, setCurrentIndex] = useState(0)
    const [isMobile, setIsMobile] = useState(false)

    const brands = shop?.brands || []

    useEffect(() => {
        const handleResize = () => {
            setIsMobile(window.innerWidth <= 768)
        }

        handleResize()
        window.addEventListener("resize", handleResize)
        return () => window.removeEventListener("resize", handleResize)
    }, [])

    useEffect(() => {
        // Add scroll animations dynamically
        const styleElement = document.createElement('style');
        styleElement.innerHTML = `
            @keyframes scroll-rtl {
                0% {
                    transform: translateX(0);
                }
                100% {
                    transform: translateX(-33.333%);
                }
            }
            
            .animate-scroll-rtl {
                animation: scroll-rtl 30s linear infinite;
            }
            
            .hover\\:pause-animation:hover {
                animation-play-state: paused;
            }
            
            @keyframes float {
                0%, 100% {
                    transform: translateY(0px);
                }
                50% {
                    transform: translateY(-10px);
                }
            }
            
            .animate-float {
                animation: float 3s ease-in-out infinite;
            }
            
            @keyframes shimmer {
                0% {
                    background-position: -200px 0;
                }
                100% {
                    background-position: calc(200px + 100%) 0;
                }
            }
            
            .animate-shimmer {
                background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
                background-size: 200px 100%;
                animation: shimmer 2s infinite;
            }
        `;
        document.head.appendChild(styleElement);

        return () => {
            document.head.removeChild(styleElement);
        };
    }, []);

    useEffect(() => {
        if (brands.length > 0) {
            const interval = setInterval(() => {
                setCurrentIndex((prevIndex) => (prevIndex + 1) % brands.length)
            }, 3000)
            return () => clearInterval(interval)
        }
    }, [brands.length])

    // Duplicate brands array for seamless infinite scroll
    const duplicatedBrands = [...brands, ...brands, ...brands]

    return (
        <div className="relative bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 py-16 px-4 overflow-hidden">
            {/* Background Decorations */}
            <div className="absolute inset-0 overflow-hidden">
                <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-3xl"></div>
                <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-pink-400/20 to-orange-400/20 rounded-full blur-3xl"></div>
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-indigo-400/10 to-cyan-400/10 rounded-full blur-3xl"></div>
            </div>

            <div className="relative max-w-7xl mx-auto">
                {/* Enhanced Header Section */}
                <div className="text-center mb-12">
                    <div className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full border border-white/20 shadow-lg mb-6">
                        <Sparkles className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm font-medium text-gray-600">Premium Brands</span>
                        <Award className="w-4 h-4 text-blue-500" />
                    </div>

                    <div className="flex flex-col">
                        <h2 className={`${isMobile ? "text-2xl" : "text-4xl"} font-bold tracking-tight`}>
                            <span className="text-slate-800">Shop</span>
                            <span className="text-[#fc2e6bed] ml-2">By Brands</span>
                        </h2>
                        <div className={`${isMobile ? "w-20" : "w-24"} h-0.5 bg-[#fc2e6bed] mt-4 rounded-full`}></div>
                    </div>

                    <p className="text-gray-600 max-w-2xl mx-auto text-lg leading-relaxed">
                        Discover premium products from trusted brands that deliver quality and excellence
                    </p>

                    <div className="flex items-center justify-center gap-2 mt-6">
                        <div className="w-12 h-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"></div>
                        <div className="w-2 h-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"></div>
                        <div className="w-12 h-1 bg-gradient-to-r from-pink-500 to-orange-500 rounded-full"></div>
                    </div>
                </div>

                {/* Infinite Scrolling Brand Cards */}
                <div className="relative mb-12">
                    {/* Gradient Overlays for Fade Effect */}
                    <div className="absolute left-0 top-0 w-20 h-full bg-gradient-to-r from-slate-50 via-blue-50/80 to-transparent z-10 pointer-events-none"></div>
                    <div className="absolute right-0 top-0 w-20 h-full bg-gradient-to-l from-slate-50 via-blue-50/80 to-transparent z-10 pointer-events-none"></div>

                    {/* Scrolling Container */}
                    <div className="overflow-hidden">
                        <div className="flex animate-scroll-rtl gap-4 hover:pause-animation">
                            {duplicatedBrands.map((brand, index) => (
                                <div key={`brand-${index}`} className="group flex-shrink-0 relative">
                                    {/* Small Brand Card */}
                                    <div className="relative w-24 h-24 bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-110 hover:-translate-y-2 border border-white/50 overflow-hidden">
                                        {/* Gradient Background on Hover */}
                                        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                                        {/* Shimmer Effect */}
                                        <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"></div>

                                        {/* Brand Logo */}
                                        <div className="relative z-10 w-full h-full flex items-center justify-center p-3">
                                            <img
                                                src={brand.image_url || "/placeholder.svg"}
                                                alt={brand.name}
                                                className="max-w-full max-h-full object-contain filter drop-shadow-sm group-hover:drop-shadow-lg transition-all duration-300"
                                                loading="lazy"
                                            />
                                        </div>

                                        {/* Floating Badge */}
                                        <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                                            <TrendingUp className="w-2 h-2 text-white" />
                                        </div>
                                    </div>

                                    {/* Brand Name Tooltip */}
                                    <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none">
                                        <div className="bg-gray-900 text-white text-xs px-3 py-1 rounded-lg whitespace-nowrap shadow-lg">
                                            {brand.name}
                                            <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-gray-900 rotate-45"></div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Enhanced Stats Section */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-white/50 shadow-lg hover:shadow-xl transition-all duration-300">
                        <div className="flex items-center gap-3 mb-2">
                            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
                                <Award className="w-5 h-5 text-white" />
                            </div>
                            <div>
                                <div className="text-2xl font-bold text-gray-900">{brands.length}+</div>
                                <div className="text-sm text-gray-600">Premium Brands</div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-white/50 shadow-lg hover:shadow-xl transition-all duration-300">
                        <div className="flex items-center gap-3 mb-2">
                            <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
                                <TrendingUp className="w-5 h-5 text-white" />
                            </div>
                            <div>
                                <div className="text-2xl font-bold text-gray-900">100%</div>
                                <div className="text-sm text-gray-600">Quality Assured</div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-white/50 shadow-lg hover:shadow-xl transition-all duration-300">
                        <div className="flex items-center gap-3 mb-2">
                            <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-orange-500 rounded-xl flex items-center justify-center">
                                <Sparkles className="w-5 h-5 text-white" />
                            </div>
                            <div>
                                <div className="text-2xl font-bold text-gray-900">24/7</div>
                                <div className="text-sm text-gray-600">Support</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default BrandSlider