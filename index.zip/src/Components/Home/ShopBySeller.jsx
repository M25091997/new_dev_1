import { useState, useEffect } from "react"
import { useSelector } from "react-redux"
import { Store, ArrowRight, Star, Package } from "lucide-react"
import { useNavigate } from "react-router-dom"
import { slugify } from "../../utils/Slugify"
import homeShopBySeller from "../../assets/images/homeShopBySeller.png"
import homeShopBySellerMobile from "../../assets/images/homeShopBySellerMobile.png"


const ShopBySeller = () => {
    const { shop } = useSelector((state) => state.shop)
    const [localSellers, setLocalSellers] = useState([])
    const [isMobile, setIsMobile] = useState(window.innerWidth <= 768)
    const [isLoading, setIsLoading] = useState(true)
    const [hoveredCard, setHoveredCard] = useState(null)

    const navigate = useNavigate()

    useEffect(() => {
        setIsLoading(true)
        if (shop?.sellers) {
            setLocalSellers(shop?.sellers || [])
            setIsLoading(false)
        } else {
            setLocalSellers([])
            setIsLoading(false)
        }
    }, [shop])

    useEffect(() => {
        const handleResize = () => {
            setIsMobile(window.innerWidth <= 768)
        }

        window.addEventListener("resize", handleResize)
        return () => window.removeEventListener("resize", handleResize)
    }, [])

    const handleSellerClick = (seller) => {
        if (!seller?.store_name) return
        navigate(`/seller-products/${slugify(seller.store_name)}?seller_id=${seller.id}`)
    }

    const handleButtonClick = () => {
        navigate("/allSellers")
    }

    // Skeleton Card Component
    const SkeletonCard = () => (
        <div className="group relative bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden animate-pulse">
            <div className="absolute inset-0 bg-gradient-to-br from-gray-50 to-gray-100"></div>
            <div className="relative p-4 sm:p-6">
                <div className="flex items-center space-x-3 sm:space-x-4">
                    <div className="relative">
                        <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gray-300 rounded-2xl"></div>
                    </div>
                    <div className="flex-1 space-y-2">
                        <div className="h-4 sm:h-5 bg-gray-300 rounded-lg w-3/4"></div>
                        <div className="h-3 sm:h-4 bg-gray-200 rounded-lg w-1/2"></div>
                    </div>
                </div>
                <div className="mt-3 sm:mt-4 flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                        <div className="w-4 h-4 bg-gray-300 rounded"></div>
                        <div className="w-12 h-3 bg-gray-300 rounded"></div>
                    </div>
                    <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gray-300 rounded-full"></div>
                </div>
            </div>
        </div>
    )

    // Seller Card Component
    const SellerCard = ({ seller, index }) => (
        <div
            onClick={() => handleSellerClick(seller)}
            onMouseEnter={() => setHoveredCard(index)}
            onMouseLeave={() => setHoveredCard(null)}
            className="group relative bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden cursor-pointer transition-all duration-500 hover:shadow-xl hover:border-rose-200 hover:-translate-y-1"
        >
            {/* Gradient Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-rose-50 via-white to-orange-50 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

            {/* Floating Elements */}
            <div className="absolute top-3 right-3 sm:top-4 sm:right-4 opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-x-2 group-hover:translate-x-0">
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-rose-100 rounded-full flex items-center justify-center">
                    <ArrowRight size={isMobile ? 12 : 14} className="text-rose-500" />
                </div>
            </div>

            <div className="relative p-4 sm:p-6">
                <div className="flex items-center space-x-3 sm:space-x-4">
                    {/* Store Logo */}
                    <div className="relative group">
                        <div className="absolute inset-0 bg-gradient-to-br from-rose-400 to-orange-400 rounded-2xl opacity-0 group-hover:opacity-20 transition-opacity duration-500"></div>
                        <div className="relative w-12 h-12 sm:w-16 sm:h-16 bg-gray-100 rounded-2xl overflow-hidden border-2 border-white shadow-lg group-hover:shadow-xl transition-all duration-500">
                            {seller.logo_url ? (
                                <img
                                    src={seller.logo_url || "/placeholder.svg"}
                                    alt={seller.store_name}
                                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                                />
                            ) : (
                                <div className="w-full h-full bg-gradient-to-br from-rose-100 to-orange-100 flex items-center justify-center">
                                    <Store size={isMobile ? 20 : 24} className="text-rose-500" />
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Store Info */}
                    <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-gray-900 text-base sm:text-lg group-hover:text-rose-600 transition-colors duration-300 truncate">
                            {seller.store_name}
                        </h3>
                        <p className="text-xs sm:text-sm text-gray-500 mt-1 flex items-center">
                            <Package size={10} className="mr-1 sm:hidden" />
                            <Package size={12} className="mr-1 hidden sm:inline" />
                            {seller.total_products} product{seller.total_products !== 1 ? "s" : ""}
                        </p>
                    </div>
                </div>

                {/* Store Stats/Actions */}
                <div className="mt-3 sm:mt-4 flex items-center justify-between">
                    <div className="flex items-center space-x-2 sm:space-x-3">
                        {/* Rating */}
                        <div className="flex items-center space-x-1">
                            <Star size={isMobile ? 12 : 14} className="text-yellow-400 fill-current" />
                            <span className="text-xs sm:text-sm font-medium text-gray-700">{seller.rating || "4.5"}</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Shine Effect */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent -skew-x-12 transform translate-x-full group-hover:-translate-x-full transition-transform duration-1000"></div>
            </div>
        </div>
    )

    // Empty State Component
    const EmptyState = () => (
        <div className="text-center py-12 sm:py-20">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
                <Store size={isMobile ? 28 : 32} className="text-gray-400" />
            </div>
            <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2">No Sellers Available</h3>
            <p className="text-sm sm:text-base text-gray-500 max-w-md mx-auto px-4">
                We're working on bringing amazing sellers to our platform. Check back soon for exciting stores and products!
            </p>
        </div>
    )

    if (!isLoading && localSellers?.length === 0) {
        return (
            <section className="py-12 sm:py-16 bg-gradient-to-br from-gray-50 to-white">
                <div className="max-w-7xl mx-auto px-4">
                    {/* Header */}
                    <div className="text-center mb-8 sm:mb-12">
                        <h2 className="text-2xl sm:text-3xl lg:text-5xl font-bold mb-4">
                            <span className="bg-gradient-to-r from-rose-500 via-pink-500 to-orange-500 text-transparent bg-clip-text">
                                Shop
                            </span>
                            <span className="text-gray-800 ml-3">By Seller</span>
                        </h2>
                        <div className="w-16 sm:w-24 h-1 bg-gradient-to-r from-rose-500 to-orange-500 mx-auto rounded-full"></div>
                    </div>
                    <EmptyState />
                </div>
            </section>
        )
    }

    return (
        <section className="py-12 sm:py-16 bg-gradient-to-br from-gray-50 to-white">
            {/* Header */}
            <div className="text-center mb-8 sm:mb-14">
                {isMobile ? (
                    <img
                        src={homeShopBySellerMobile || "/placeholder.svg"}
                        alt="Shop by Seller Mobile"
                        className="rounded-2xl max-w-full h-auto"
                    />
                ) : (
                    <img
                        src={homeShopBySeller || "/placeholder.svg"}
                        alt="Shop by Seller Desktop"
                        className="rounded-2xl max-w-full h-auto"
                    />
                )}
            </div>

            <div className="max-w-7xl mx-auto px-4 -mt-6 sm:-mt-10">
                {isLoading ? (
                    <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-6">
                        {[...Array(8)].map((_, index) => (
                            <SkeletonCard key={index} />
                        ))}
                    </div>
                ) : (
                    <>
                        {/* Responsive Grid - 2 columns on mobile, more on larger screens */}
                        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-6">
                            {localSellers.map((seller, index) => (
                                <SellerCard key={index} seller={seller} index={index} />
                            ))}
                        </div>

                        {/* View All Button */}
                        {localSellers && (
                            <div className="text-center mt-8 sm:mt-12">
                                <button
                                    onClick={handleButtonClick}
                                    className="bg-gradient-to-r from-rose-500 to-orange-500 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-semibold hover:shadow-lg transform hover:-translate-y-1 transition-all duration-300 text-sm sm:text-base"
                                >
                                    View All Sellers
                                    <ArrowRight size={14} className="ml-2 inline" />
                                </button>
                            </div>
                        )}
                    </>
                )}
            </div>
        </section>
    )
}

export default ShopBySeller
