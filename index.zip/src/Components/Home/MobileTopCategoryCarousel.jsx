import React, { useEffect, useRef, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { setCategory, setSelectedCategory } from '../../model/reducer/categoryReducer';
import { setFilterCategory, clearAllFilter } from '../../model/reducer/productFilterReducer';

const MobileTopCategoryCarousel = () => {
  const { shop } = useSelector((state) => state.shop);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const scrollContainerRef = useRef(null);

  const [categories, setCategories] = useState(shop?.categories || []);
  const [isLoading, setIsLoading] = useState(!shop?.categories);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [maxScroll, setMaxScroll] = useState(0);

  useEffect(() => {
    if (shop?.categories && shop.categories.length > 0) {
      setCategories(shop.categories);
      setIsLoading(false);
    }
  }, [shop]);

  useEffect(() => {
    if (scrollContainerRef.current) {
      const calculateMaxScroll = () => {
        const container = scrollContainerRef.current;
        setMaxScroll(container.scrollWidth - container.clientWidth);
      };

      calculateMaxScroll();
      window.addEventListener('resize', calculateMaxScroll);
      return () => window.removeEventListener('resize', calculateMaxScroll);
    }
  }, [categories, isLoading]);

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (container) {
      const handleScroll = () => {
        setScrollPosition(container.scrollLeft);
      };

      container.addEventListener('scroll', handleScroll);
      return () => container.removeEventListener('scroll', handleScroll);
    }
  }, []);

  const scroll = (direction) => {
    const container = scrollContainerRef.current;
    if (container) {
      const scrollAmount = Math.min(container.clientWidth * 0.75, 200);
      container.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  const handleCategoryClick = (category) => {
    if (!category || !category.id) return;

    dispatch(clearAllFilter());

    if (category?.has_child) {
      navigate(`/category/${category?.slug}`);
      dispatch(setCategory(shop?.categories));
      dispatch(setSelectedCategory({
        category: category,
        children: category?.cat_active_childs || []
      }));
    } else {
      dispatch(setFilterCategory({ data: category?.id.toString() }));
      navigate('/products');
    }

    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 100);
  };

  const LoadingSkeleton = () => (
    <div className="flex gap-3 min-w-max px-4">
      {Array.from({ length: 8 }).map((_, index) => (
        <div key={index} className="snap-start flex flex-col items-center">
          <div className="w-20 h-20 bg-gray-200 animate-pulse rounded-lg"></div>
          <div className="mt-2 w-16 h-3 bg-gray-200 animate-pulse rounded"></div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="relative max-w-full py-4">
      <h2 className="text-base sm:text-lg md:text-xl lg:text-2xl font-semibold px-4 mb-3 text-gray-800">
        Shop by Category
      </h2>

      <div className="relative px-1">
        <div
          ref={scrollContainerRef}
          className="overflow-x-auto px-4 pb-2 scrollbar-none [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden snap-x snap-mandatory"
        >
          {isLoading ? (
            <LoadingSkeleton />
          ) : (
            <div className="flex gap-3 min-w-max">
              {categories.map((category) => (
                <div
                  key={category.slug}
                  className="snap-start flex flex-col items-center gap-1 cursor-pointer group"
                  onClick={() => handleCategoryClick(category)}
                >
                  <div className="relative w-20 h-20 overflow-hidden rounded-lg shadow-sm group">
                    <div className="absolute inset-0 bg-gradient-to-br from-pink-500/20 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>

                    {category.image_url ? (
                      <img
                        src={category.image_url}
                        alt={category.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        loading="lazy"
                        onError={(e) => {
                          e.target.style.display = 'none';
                          e.target.parentElement.classList.add('flex', 'items-center', 'justify-center', 'bg-gradient-to-br', 'from-gray-100', 'to-gray-200');
                          e.target.parentElement.innerHTML = `<span class="text-gray-500 font-medium text-lg">${category.name?.charAt(0) || ''}</span>`;
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200">
                        <span className="text-gray-500 font-medium text-lg">
                          {category.name?.charAt(0) || ''}
                        </span>
                      </div>
                    )}
                  </div>
                  <span className="text-xs font-medium text-gray-700 text-center line-clamp-1 max-w-20 group-hover:text-pink-600 transition-colors">
                    {category.name}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {!isLoading && categories.length > 0 && (
        <div className="flex justify-center mt-3 gap-1">
          {Array.from({ length: Math.ceil(maxScroll / 200) + 1 }).map((_, index) => {
            const dotPosition = index * 200;
            const isActive =
              scrollPosition >= dotPosition - 100 &&
              scrollPosition < dotPosition + 100;

            return (
              <div
                key={index}
                className={`h-1 rounded-full transition-all duration-300 ${isActive ? 'w-4 bg-pink-500' : 'w-1 bg-gray-300'}`}
              ></div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default MobileTopCategoryCarousel;
