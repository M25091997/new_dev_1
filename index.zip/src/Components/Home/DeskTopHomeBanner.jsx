import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useSelector } from 'react-redux';
import homeSideBanner from '../../assets/images/homesidebanner3.png';

export default function HomeBanner() {
    const shop = useSelector((state) => state.shop?.shop);
    const [slides, setSlides] = useState(shop?.sliders || []);
    const [currentSlide, setCurrentSlide] = useState(0);
    const [isLoading, setIsLoading] = useState(!shop?.sliders?.length);
    const [imagesLoaded, setImagesLoaded] = useState(false);

    // Ensure slides load instantly if available in Redux
    useEffect(() => {
        if (shop?.sliders?.length) {
            setSlides(shop.sliders);
            setIsLoading(false);
        }
    }, [shop]);

    // Preload images
    useEffect(() => {
        if (slides.length > 0) {
            const imagePromises = slides.map((slide) => {
                const img = new Image();
                img.src = slide.image_url;
                return new Promise((resolve) => {
                    img.onload = resolve;
                    img.onerror = resolve;
                });
            });

            Promise.all(imagePromises).then(() => {
                setImagesLoaded(true);
            });
        }
    }, [slides]);

    // Auto-slide every 5 seconds
    useEffect(() => {
        if (slides.length > 0) {
            const timer = setInterval(() => setCurrentSlide((prev) => (prev + 1) % slides.length), 5000);
            return () => clearInterval(timer);
        }
    }, [slides]);

    return (
        <div className="homeTopBannerContainer flex">
            {/* Left-side Banner */}
            <div className="left-content w-[60%]">
                <div className="relative overflow-hidden w-full z-10">
                    {/* Skeleton Loader */}
                    {isLoading ? (
                        <div className="flex h-[270px] animate-pulse">
                            <div className="w-full bg-gray-300"></div>
                        </div>
                    ) : (
                        <div
                            className="flex transition-transform duration-500 ease-out h-[270px]"
                            style={{ transform: `translateX(-${currentSlide * 100}%)` }}
                        >
                            {imagesLoaded && slides.length > 0 ? (
                                slides.map((slide, index) => (
                                    <div key={index} className="min-w-full relative z-10">
                                        <img
                                            src={slide.image_url}
                                            alt={`Slide ${index + 1}`}
                                            className="w-full h-full object-cover"
                                            loading="lazy"
                                        />
                                    </div>
                                ))
                            ) : (
                                <div className="min-w-full h-[270px] flex items-center justify-center bg-gray-200">
                                    <p className="text-gray-500">No slides available</p>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Navigation Arrows */}
                    {!isLoading && slides.length > 1 && (
                        <>
                            <button
                                onClick={() => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)}
                                className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white flex items-center justify-center shadow-lg transition-all"
                                aria-label="Previous slide"
                            >
                                <ChevronLeft className="w-6 h-6" />
                            </button>

                            <button
                                onClick={() => setCurrentSlide((prev) => (prev + 1) % slides.length)}
                                className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white flex items-center justify-center shadow-lg transition-all"
                                aria-label="Next slide"
                            >
                                <ChevronRight className="w-6 h-6" />
                            </button>
                        </>
                    )}

                    {/* Dots Navigation */}
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                        {slides.map((_, index) => (
                            <button
                                key={index}
                                onClick={() => setCurrentSlide(index)}
                                className={`h-2 rounded-full transition-all duration-300 ${currentSlide === index ? 'w-8 bg-yellow-400' : 'w-2 bg-white/60'
                                    }`}
                                aria-label={`Go to slide ${index + 1}`}
                            />
                        ))}
                    </div>
                </div>
            </div>

            {/* Right-side images */}
            <div className="right-content w-[40%]">
                <div className="img-container flex gap-4">
                    {/* Skeleton Loader */}
                    {isLoading ? (
                        <div className="flex gap-4 w-full">
                            <div className="w-1/2 h-[270px] bg-gray-300 animate-pulse"></div>
                            <div className="w-1/2 h-[270px] bg-gray-300 animate-pulse"></div>
                        </div>
                    ) : (
                        <img
                            src={homeSideBanner}
                            className="h-[270px] w-full object-cover transition-transform duration-300 ml-3"
                            alt="Right Image 1"
                            loading="lazy"
                        />
                    )}
                </div>
            </div>
        </div>
    );
}
