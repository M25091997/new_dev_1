import { useState, useEffect, useCallback, useRef } from "react"
import { Link, useLocation, useNavigate } from "react-router-dom"
import { useDispatch, useSelector } from "react-redux"
import * as newApi from "../api/apiCollection"
import NoProductImage from "../assets/NoProduct.png"
import {
  setFilterBySeller,
  clearAllFilter,
  setFilterBrands,
  setFilterCategory,
  setFilterMinMaxPrice,
  setFilterSort,
  setFilterProductSizes,
  setFilterSearch,
} from "../model/reducer/productFilterReducer"
import { slugify } from "../utils/Slugify"
import ProductCard from "./ProductCard"
import {
  List,
  ChevronDown,
  ChevronRight,
  X,
  ArrowRight,
  Loader,
  ArrowUpDown,
  Check,
  Grid3X3,
  SlidersHorizontal,
  Search,
  MapPin,
  Store,
  Tag,
  TrendingUp,
  Zap,
  RefreshCw,
} from "lucide-react"
import { setAllCategories } from "../model/reducer/categoryReducer"

// Custom Range Slider Component
const RangeSlider = ({ min, max, value, onChange, disabled }) => {
  const [isDragging, setIsDragging] = useState(false);
  const sliderRef = useRef(null);

  const handleMouseDown = (e, index) => {
    setIsDragging(index);
    e.preventDefault();
  };

  const handleMouseMove = useCallback(
    (e) => {
      if (isDragging !== false && sliderRef.current) {
        const rect = sliderRef.current.getBoundingClientRect();
        const percent = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        const newValue = min + percent * (max - min);

        const newValues = [...value];
        newValues[isDragging] = Math.round(newValue);

        // Ensure min doesn't exceed max and vice versa
        if (isDragging === 0 && newValues[0] > newValues[1]) {
          newValues[0] = newValues[1];
        } else if (isDragging === 1 && newValues[1] < newValues[0]) {
          newValues[1] = newValues[0];
        }

        onChange(newValues);
      }
    },
    [isDragging, min, max, value, onChange]
  );

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  useEffect(() => {
    if (isDragging !== false) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      return () => {
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);

  if (disabled || min === null || max === null || !value || value.length !== 2) {
    return (
      <div className="w-full h-2 bg-gray-200 rounded-full relative">
        <div className="absolute inset-0 flex items-center justify-center text-xs text-gray-400">
          Loading...
        </div>
      </div>
    );
  }

  const leftPercent = ((value[0] - min) / (max - min)) * 100;
  const rightPercent = ((value[1] - min) / (max - min)) * 100;

  return (
    <div className="w-full">
      <div ref={sliderRef} className="relative h-2 bg-gray-200 rounded-full cursor-pointer">
        <div
          className="absolute h-2 bg-gradient-to-r from-rose-500 to-pink-500 rounded-full"
          style={{
            left: `${leftPercent}%`,
            width: `${rightPercent - leftPercent}%`,
          }}
        />
        <div
          className="absolute w-5 h-5 bg-white border-2 border-rose-500 rounded-full cursor-grab active:cursor-grabbing shadow-lg transform -translate-y-1.5 hover:scale-110 transition-transform"
          style={{ left: `calc(${leftPercent}% - 10px)` }}
          onMouseDown={(e) => handleMouseDown(e, 0)}
        />
        <div
          className="absolute w-5 h-5 bg-white border-2 border-rose-500 rounded-full cursor-grab active:cursor-grabbing shadow-lg transform -translate-y-1.5 hover:scale-110 transition-transform"
          style={{ left: `calc(${rightPercent}% - 10px)` }}
          onMouseDown={(e) => handleMouseDown(e, 1)}
        />
      </div>
    </div>
  );
};

// Custom Checkbox Component
const CustomCheckbox = ({ checked, onChange, children, className = "" }) => {
  return (
    <label className={`flex items-center cursor-pointer group ${className}`}>
      <div className="relative">
        <input type="checkbox" checked={checked} onChange={onChange} className="sr-only" />
        <div
          className={`w-5 h-5 rounded border-2 transition-all duration-200 ${checked ? "bg-rose-500 border-rose-500" : "bg-white border-gray-300 group-hover:border-rose-300"
            }`}
        >
          {checked && <Check size={12} className="text-white absolute top-0.5 left-0.5" />}
        </div>
      </div>
      <span className="ml-3 text-sm text-gray-700 group-hover:text-gray-900 transition-colors">{children}</span>
    </label>
  )
}

// Collapsible Panel Component
const CollapsiblePanel = ({ title, children, defaultOpen = false, icon: Icon }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen)

  return (
    <div className="border-b border-gray-100 last:border-b-0">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between py-4 px-1 text-left hover:bg-gray-50 transition-colors rounded-lg"
      >
        <div className="flex items-center">
          {Icon && <Icon size={18} className="text-rose-500 mr-3" />}
          <span className="font-medium text-gray-900">{title}</span>
        </div>
        <ChevronDown
          size={18}
          className={`text-gray-400 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
        />
      </button>
      <div className={`overflow-hidden transition-all duration-300 ${isOpen ? "max-h-96 pb-4" : "max-h-0"}`}>
        <div className="px-1">{children}</div>
      </div>
    </div>
  )
}

const CategoryComponent = ({ data, selectedCategories, setSelectedCategories, setproductresult, setoffset }) => {
  const [categories, setCategories] = useState([]);
  const [expandedCategories, setExpandedCategories] = useState({});
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const { allCategories } = useSelector((state) => state.category);
  const categoriesLoaded = useRef(false);

  // Use allCategories if available, otherwise fetch
  useEffect(() => {
    if (allCategories && allCategories.length > 0) {
      setCategories(allCategories);
      categoriesLoaded.current = true;
      return;
    }

    if (categoriesLoaded.current) return;

    const fetchCategories = async () => {
      if (!data || data.length === 0) {
        setLoading(true);
        try {
          const result = await newApi.getCategory({ id: 0 });
          if (result.status === 1) {
            const cats = result.data.map((cat) => ({
              ...cat,
              subcategories: [],
              loaded: false,
            }));
            setCategories(cats);
            dispatch(setAllCategories(cats)); // Store all categories in Redux
          }
        } catch (error) {
          console.error("Error fetching categories:", error);
        } finally {
          setLoading(false);
          categoriesLoaded.current = true;
        }
      } else {
        const cats = data.map((cat) => ({
          ...cat,
          subcategories: [],
          loaded: false,
        }));
        setCategories(cats);
        dispatch(setAllCategories(cats)); // Store all categories in Redux
        categoriesLoaded.current = true;
      }
    };

    fetchCategories();
  }, [data, dispatch, allCategories]);

  // Toggle category expansion and load subcategories if not loaded
  const toggleCategory = async (categoryId) => {
    setExpandedCategories((prev) => ({
      ...prev,
      [categoryId]: !prev[categoryId],
    }));

    // Load subcategories if not already loaded
    const categoryIndex = categories.findIndex((c) => c.id === categoryId);
    if (categoryIndex !== -1 && !categories[categoryIndex].loaded) {
      try {
        const result = await newApi.getCategory({ id: categoryId });
        if (result.status === 1) {
          setCategories((prev) => {
            const newCategories = [...prev];
            newCategories[categoryIndex] = {
              ...newCategories[categoryIndex],
              subcategories: result.data,
              loaded: true,
            };
            return newCategories;
          });

          // Update allCategories in Redux as well
          dispatch(setAllCategories(categories.map(cat =>
            cat.id === categoryId ? {
              ...cat,
              subcategories: result.data,
              loaded: true
            } : cat
          )));
        }
      } catch (error) {
        console.error("Error fetching subcategories:", error);
      }
    }
  };

  // Handle category selection
  const handleCategorySelect = (categoryId) => {
    let newSelectedCategories;
    if (selectedCategories.includes(categoryId)) {
      newSelectedCategories = selectedCategories.filter((id) => id !== categoryId);
    } else {
      newSelectedCategories = [...selectedCategories, categoryId];
    }

    setSelectedCategories(newSelectedCategories);
    setoffset(0);
    dispatch(setFilterCategory({ data: newSelectedCategories.join(",") }));
  };

  // Recursive function to render categories and subcategories
  const renderCategories = (categoriesToRender, level = 0) => {
    return categoriesToRender.map((category) => (
      <div key={category.id} className={`${level > 0 ? "ml-6" : ""} mb-2`}>
        <div className="flex items-center py-2">
          {category.has_child && (
            <button
              onClick={() => toggleCategory(category.id)}
              className="mr-2 p-1 hover:bg-gray-100 rounded transition-colors"
            >
              {expandedCategories[category.id] ? (
                <ChevronDown size={14} className="text-gray-500" />
              ) : (
                <ChevronRight size={14} className="text-gray-500" />
              )}
            </button>
          )}
          <CustomCheckbox
            checked={selectedCategories.includes(category.id)}
            onChange={() => handleCategorySelect(category.id)}
          >
            <span className={selectedCategories.includes(category.id) ? "font-medium text-rose-600" : ""}>
              {category.name}
            </span>
          </CustomCheckbox>
        </div>
        {expandedCategories[category.id] && category.subcategories.length > 0 && (
          <div className="ml-4">{renderCategories(category.subcategories, level + 1)}</div>
        )}
      </div>
    ));
  };

  return (
    <div className="max-h-80 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
      {loading ? (
        <div className="flex justify-center items-center h-20">
          <div className="w-6 h-6 border-2 border-rose-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : categories?.length > 0 ? (
        renderCategories(categories)
      ) : (
        <div className="text-sm text-gray-500 italic py-4 text-center">No categories available</div>
      )}
    </div>
  );
};

const ProductListing = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const location = useLocation()

  // State from Redux
  const filter = useSelector((state) => state.productFilter)
  const city = useSelector((state) => state.city)
  const setting = useSelector((state) => state.setting)
  const category = useSelector((state) => state.category?.category)
  const shop = useSelector((state) => state.shop)
  const { selectedCategory } = useSelector((state) => state.category?.category);


  // Local state
  const [isMobile, setIsMobile] = useState(false)
  const [isGridView, setIsGridView] = useState(true)
  const [products, setProducts] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [totalProducts, setTotalProducts] = useState(0)
  const [minPrice, setMinPrice] = useState(null)
  const [maxPrice, setMaxPrice] = useState(null)
  const [values, setValues] = useState([])
  const [currentSeller, setCurrentSeller] = useState(null)
  const [brands, setBrands] = useState([])
  const [totalBrands, setTotalBrands] = useState(0)
  const [brandOffset, setBrandOffset] = useState(0)
  const [sizes, setSizes] = useState([])
  const [selectedCategories, setSelectedCategories] = useState(() => {
    if (!filter?.category_id) return []

    // Handle array case
    if (Array.isArray(filter.category_id)) {
      return filter.category_id
    }

    // Handle string case
    if (typeof filter.category_id === 'string') {
      return filter.category_id.split(',').map(Number).filter(n => !isNaN(n))
    }

    // Handle number case
    if (typeof filter.category_id === 'number') {
      return [filter.category_id]
    }

    // Fallback for other cases
    return []
  })
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false)
  // Add this near the top of your ProductListing component
  const [isFromSearch, setIsFromSearch] = useState(false);

  const PRODUCTS_PER_PAGE = 12
  const brandLimit = 10
  const [offset, setOffset] = useState(0)
  const [isFetchingMore, setIsFetchingMore] = useState(false)
  const [hasMoreProducts, setHasMoreProducts] = useState(true)
  const loadingRef = useRef(false)

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  // Check if device is mobile
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)
    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  // Add this useEffect to check if we're coming from a search
  useEffect(() => {
    if (location.state?.fromSearch) {
      setIsFromSearch(true);
      // Clear any category filters if coming from search
      setSelectedCategories([]);
    }
  }, [location.state]);

  // Fetch brands
  const fetchBrands = useCallback(
    async (offset = 0) => {
      try {
        const result = await newApi.getBrands({ limit: brandLimit, offset })
        if (result.status === 1) {
          setBrands((prev) => (offset === 0 ? result.data : [...prev, ...result.data]))
          setTotalBrands(result.total)
        }
      } catch (error) {
        console.error("Error fetching brands:", error)
      }
    },
    [brandLimit],
  )

  // Update the useEffect that handles URL parameters
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search)
    const sellerSlug = searchParams.get("seller")
    const searchQuery = searchParams.get("search");

    // If we have a search query, prioritize that over seller filter
    if (searchQuery) {
      dispatch(setFilterSearch({ data: searchQuery }));
      return;
    }
    // Clear existing filters when a seller is selected
    if (sellerSlug) {
      dispatch(clearAllFilter())

      const seller = shop?.sellers?.find((s) => slugify(s.store_name) === sellerSlug)
      if (seller) {
        setCurrentSeller(seller)
        dispatch(setFilterBySeller({ data: seller.id }))
      } else {
        // If seller not found by slug but we have ID from state
        const sellerIdFromState = location.state?.seller_id
        if (sellerIdFromState) {
          dispatch(setFilterBySeller({ data: sellerIdFromState }))
        }
      }
    } else {
      setCurrentSeller(null)
    }
  }, [location.search, location.state, shop?.sellers, dispatch])

  // Fetch products when filters change
  const fetchProducts = useCallback(
    async (reset = false, currentOffset = 0) => {
      // Prevent multiple simultaneous requests
      if (loadingRef.current) return
      loadingRef.current = true

      try {
        setIsLoading(reset);
        setIsFetchingMore(!reset);

        const result = await newApi.productByFilter({
          latitude: city?.city?.latitude,
          longitude: city?.city?.longitude,
          filters: {
            min_price: filter.price_filter?.min_price,
            max_price: filter.price_filter?.max_price,
            // Only apply category filter if not coming from search
            category_ids: isFromSearch ? '' : (
              Array.isArray(filter?.category_id)
                ? filter.category_id.join(',')
                : filter?.category_id?.toString() || ''
            ),
            brand_ids: filter?.brand_ids?.toString(),
            sort: filter?.sort_filter,
            search: filter?.search || location.state?.searchQuery,
            limit: PRODUCTS_PER_PAGE,
            sizes: filter?.search_sizes
              ?.filter((obj) => obj.checked)
              .map((obj) => obj.size)
              .join(","),
            offset: currentOffset,
            unit_ids: filter?.search_sizes
              ?.filter((obj) => obj.checked)
              .map((obj) => obj.unit_id)
              .join(","),
            seller_id: filter?.seller_id || location.state?.seller_id || "",
            country_id: filter?.country_id,
            section_id: filter?.section_id,
          },
        });

        if (result.status === 1) {
          // Initialize price range if not set (only on first load)
          if (reset && minPrice == null && maxPrice == null && filter?.price_filter == null) {
            const newMin = Number.parseInt(result.total_min_price) || 0;
            const newMax = Number.parseInt(result.total_max_price) || (Number.parseInt(result.total_min_price) || 0) + 100;

            setMinPrice(newMin);
            setMaxPrice(newMax);
            setValues([newMin, newMax]);
          }

          const processedProducts = result.data.map((product) => ({
            ...product,
            image_url: product.image_url || product.images?.[0]?.image_url || NoProductImage,
            price: product.price.toString() || "0",
          }))

          if (reset) {
            // Reset products and total count
            setProducts(processedProducts)
            setTotalProducts(result.total)
            setOffset(0)
          } else {
            // Append new products
            setProducts((prev) => [...prev, ...processedProducts])
          }

          // Update whether more products are available
          setHasMoreProducts(processedProducts.length === PRODUCTS_PER_PAGE)

          // Update sizes if they changed
          if (result.sizes) {
            setSizes(result.sizes)
          }
        } else {
          // No products found
          if (reset) {
            setProducts([])
            setTotalProducts(0)
          }
          setHasMoreProducts(false)
        }
      } catch (error) {
        console.error("Error fetching products:", error)
        if (reset) {
          setProducts([])
          setTotalProducts(0)
        }
        setHasMoreProducts(false)
      } finally {
        setIsLoading(false)
        setIsFetchingMore(false)
        loadingRef.current = false
      }
    },
    [
      filter,
      location.state?.seller_id,
      city?.city?.latitude,
      city?.city?.longitude,
      minPrice,
      maxPrice,
      PRODUCTS_PER_PAGE,
    ],
  )

  // Add this useEffect to clear the search flag after initial load
  useEffect(() => {
    if (isFromSearch) {
      // After the first render, we can clear the flag
      setIsFromSearch(false);
    }
  }, [isFromSearch]);

  // Reset products and fetch when filters change
  useEffect(() => {
    // This will automatically filter products when category is selected
    const fetchData = async () => {
      await fetchProducts(true);
    };
    fetchData();
  }, [filter, selectedCategory]); // Add selectedCategory to dependencies

  // Handle load more button click
  const handleLoadMore = async () => {
    const newOffset = offset + PRODUCTS_PER_PAGE
    setOffset(newOffset)
    await fetchProducts(false, newOffset)
  }

  // Handle brand selection
  const filterByBrand = (brandId) => {
    const brandIds = [...(filter.brand_ids || [])];
    const index = brandIds.indexOf(brandId);

    if (index === -1) {
      brandIds.push(brandId);
    } else {
      brandIds.splice(index, 1);
    }

    setOffset(0); // Reset pagination
    dispatch(setFilterBrands({ data: brandIds }));
  };


  // Handle size selection
  const filterBySize = (size, unitId) => {
    const currentSizes = [...(filter.search_sizes || [])];
    const existingIndex = currentSizes.findIndex((s) => s.size === size && s.unit_id === unitId);

    if (existingIndex === -1) {
      currentSizes.push({ size, unit_id: unitId, checked: true });
    } else {
      currentSizes[existingIndex].checked = !currentSizes[existingIndex].checked;
    }

    setOffset(0);
    dispatch(setFilterProductSizes({ data: currentSizes }));
  };

  // Handle price range change
  const handlePriceChange = (newValues) => {
    setValues(newValues)
  }

  // Apply price filter
  const applyPriceFilter = () => {
    setOffset(0)
    dispatch(
      setFilterMinMaxPrice({
        data: {
          min_price: values[0],
          max_price: values[1],
        },
      }),
    )
  }

  // Clear all filters
  const clearFilters = () => {
    setMinPrice(null);
    setMaxPrice(null);
    setValues([]);
    setSelectedCategories([]);
    setBrandOffset(0);
    dispatch(clearAllFilter());
    setOffset(0);
    if (currentSeller || location.search.includes("seller")) {
      navigate("/products");
      setCurrentSeller(null);
    }
  };

  // Load more brands
  const loadMoreBrands = () => {
    const newOffset = brandOffset + brandLimit
    setBrandOffset(newOffset)
    fetchBrands(newOffset)
  }

  // Get active filter count
  const getActiveFilterCount = () => {
    let count = 0

    // Handle category_id count
    if (filter.category_id) {
      if (Array.isArray(filter.category_id)) {
        count += filter.category_id.length
      } else if (typeof filter.category_id === 'string') {
        count += filter.category_id.split(',').length
      } else if (typeof filter.category_id === 'number') {
        count += 1
      }
    }

    if (filter.brand_ids) count += filter.brand_ids.length
    if (filter.search_sizes) count += filter.search_sizes.filter((s) => s.checked).length
    if (filter.price_filter) count += 1

    return count
  }

  const FilterSection = () => (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      {/* Filter Header */}
      <div className="bg-gradient-to-r from-rose-500 to-pink-500 p-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center mr-3">
              <SlidersHorizontal size={20} className="text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white text-lg">Filters</h3>
            </div>
          </div>
          <button
            onClick={clearFilters}
            className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors flex items-center"
          >
            <RefreshCw size={14} className="mr-2" />
            Clear All
          </button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Categories */}
        <CollapsiblePanel title="Categories" defaultOpen={true} icon={Tag}>
          <CategoryComponent
            data={category}
            selectedCategories={selectedCategories}
            setSelectedCategories={setSelectedCategories}
            setproductresult={setProducts}
            setoffset={setOffset}
          />
        </CollapsiblePanel>

        {/* Price Range */}
        <CollapsiblePanel title="Price Range" defaultOpen={true} icon={TrendingUp}>
          <div className="space-y-4">
            <RangeSlider
              min={minPrice}
              max={maxPrice}
              value={values}
              onChange={handlePriceChange}
              disabled={!minPrice || !maxPrice}
            />
            <div className="flex justify-between items-center">
              <div className="bg-gray-50 px-3 py-2 rounded-lg">
                <span className="text-sm font-medium text-gray-700">
                  {setting?.setting?.currency}
                  {values[0]?.toLocaleString() || 0}
                </span>
              </div>
              <div className="w-4 h-px bg-gray-300"></div>
              <div className="bg-gray-50 px-3 py-2 rounded-lg">
                <span className="text-sm font-medium text-gray-700">
                  {setting?.setting?.currency}
                  {values[1]?.toLocaleString() || 0}
                </span>
              </div>
            </div>
            <button
              onClick={applyPriceFilter}
              disabled={!minPrice || !maxPrice}
              className="w-full bg-gradient-to-r from-rose-500 to-pink-500 text-white py-3 rounded-xl hover:from-rose-600 hover:to-pink-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center font-medium"
            >
              Apply Price Filter
              <ArrowRight size={16} className="ml-2" />
            </button>
          </div>
        </CollapsiblePanel>

        {/* Brands */}
        {brands.length > 0 && (
          <CollapsiblePanel title="Brands" defaultOpen={false} icon={Zap}>
            <div className="space-y-3 max-h-60 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
              {brands.map((brand) => (
                <CustomCheckbox
                  key={brand.id}
                  checked={filter.brand_ids?.includes(brand.id) || false}
                  onChange={() => {
                    setOffset(0); // Reset pagination when brand filter changes
                    filterByBrand(brand.id);
                  }}
                  className="hover:bg-gray-50 p-2 rounded-lg transition-colors"
                >
                  <span className={filter.brand_ids?.includes(brand.id) ? "font-medium text-rose-600" : ""}>
                    {brand.name}
                  </span>
                </CustomCheckbox>
              ))}
              {brands.length < totalBrands && (
                <button
                  onClick={loadMoreBrands}
                  className="text-sm text-rose-500 hover:text-rose-600 mt-3 flex items-center font-medium w-full justify-center py-2 border border-rose-200 rounded-lg hover:bg-rose-50 transition-colors"
                >
                  Show More Brands
                  <ChevronDown size={16} className="ml-1" />
                </button>
              )}
            </div>
          </CollapsiblePanel>
        )}

        {/* Sizes */}
        {sizes.length > 0 && (
          <CollapsiblePanel title="Sizes" defaultOpen={false} icon={Grid3X3}>
            <div className="grid grid-cols-3 gap-2">
              {sizes.map((size) => (
                <button
                  key={`${size.size}-${size.unit_id}`}
                  onClick={() => filterBySize(size.size, size.unitId)}
                  className={`py-3 px-2 text-sm rounded-xl border-2 transition-all font-medium ${filter.search_sizes?.some((s) => s.size === size.size && s.unit_id === size.unit_id && s.checked)
                    ? "bg-gradient-to-r from-rose-500 to-pink-500 border-rose-500 text-white shadow-lg"
                    : "bg-gray-50 border-gray-200 hover:border-rose-300 hover:bg-rose-50 text-gray-700"
                    }`}
                >
                  {size.size} {size.unit}
                </button>
              ))}
            </div>
          </CollapsiblePanel>
        )}
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Mobile Header */}
      {isMobile && (
        <div className="sticky top-0 z-30 bg-white shadow-sm border-b border-gray-100">
          <div className="px-4 py-3">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="font-bold text-lg text-gray-900">
                  {currentSeller ? currentSeller.store_name : "Products"}
                </h1>
                <p className="text-sm text-gray-500">{totalProducts} items found</p>
              </div>
              <button
                onClick={() => setMobileFiltersOpen(true)}
                className="relative bg-gradient-to-r from-rose-500 to-pink-500 text-white p-3 rounded-xl shadow-lg"
              >
                <SlidersHorizontal size={20} />
                {getActiveFilterCount() > 0 && (
                  <span className="absolute -top-2 -right-2 bg-yellow-400 text-black text-xs rounded-full h-6 w-6 flex items-center justify-center font-bold">
                    {getActiveFilterCount()}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-full mx-auto">
        {/* Desktop Breadcrumb */}
        {!isMobile && (
          <div className="px-6 py-4 bg-white border-b border-gray-100">
            <div className="flex items-center gap-2 text-sm">
              <Link to="/" className="text-gray-600 hover:text-rose-500 transition-colors flex items-center">
                <MapPin size={16} className="mr-1" />
                Home
              </Link>
              <ChevronRight size={16} className="text-gray-400" />
              <Link
                to="/products"
                className={
                  location.pathname === "/products"
                    ? "text-rose-500 font-medium"
                    : "text-gray-600 hover:text-rose-500 transition-colors"
                }
              >
                Products
              </Link>
              {currentSeller && (
                <>
                  <ChevronRight size={16} className="text-gray-400" />
                  <span className="text-rose-500 font-medium flex items-center">
                    <Store size={16} className="mr-1" />
                    {currentSeller.store_name}
                  </span>
                </>
              )}
            </div>
          </div>
        )}

        <div className="flex">
          {/* Desktop Filters - Left Sidebar */}
          {!isMobile && (
            <div className="w-80 flex-shrink-0 p-6">
              <FilterSection />
            </div>
          )}

          {/* Mobile Filter Modal */}
          {isMobile && (
            <div
              className={`fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300 ${mobileFiltersOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
                }`}
            >
              <div
                className={`fixed bottom-0 left-0 right-0 max-h-[90vh] bg-white rounded-t-3xl shadow-2xl transform transition-transform duration-300 ease-out ${mobileFiltersOpen ? "translate-y-0" : "translate-y-full"
                  }`}
              >
                <div className="sticky top-0 bg-white p-4 border-b border-gray-100 rounded-t-3xl">
                  <div className="flex justify-between items-center">
                    <h3 className="font-bold text-xl text-gray-900">Filters</h3>
                    <button
                      onClick={() => setMobileFiltersOpen(false)}
                      className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
                    >
                      <X size={24} />
                    </button>
                  </div>
                  <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mt-2"></div>
                </div>
                <div className="overflow-y-auto max-h-[calc(90vh-80px)] p-4">
                  <FilterSection />
                </div>
              </div>
            </div>
          )}

          {/* Products - Main Content */}
          <div className="flex-1 p-4 md:p-6">
            {/* Desktop Header */}
            {!isMobile && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
                <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 flex items-center">
                      {currentSeller ? (
                        <>
                          <Store size={24} className="mr-3 text-rose-500" />
                          {currentSeller.store_name}
                        </>
                      ) : (
                        <>
                          <Grid3X3 size={24} className="mr-3 text-rose-500" />
                          All Products
                        </>
                      )}
                    </h2>
                    <p className="text-gray-600 mt-1">Discover amazing products just for you</p>
                  </div>

                  <div className="flex items-center gap-4">
                    {/* Sort Dropdown */}
                    <div className="flex items-center gap-2">
                      <ArrowUpDown size={18} className="text-gray-500" />
                      <select
                        className="border-2 border-gray-200 rounded-xl px-4 py-2 text-sm focus:border-rose-500 focus:outline-none bg-white min-w-[160px]"
                        value={filter.sort_filter || ""}
                        onChange={(e) => {
                          setProducts([])
                          setOffset(0)
                          dispatch(setFilterSort({ data: e.target.value }))
                        }}
                      >
                        <option value="">Default</option>
                        <option value="new">Newest First</option>
                        <option value="old">Oldest First</option>
                        <option value="high">Price: High to Low</option>
                        <option value="low">Price: Low to High</option>
                        <option value="discount">Discount High to Low</option>
                        <option value="popular">Popularity</option>
                      </select>
                    </div>

                    {/* View Toggle */}
                    <div className="flex bg-gray-100 rounded-xl p-1">
                      <button
                        onClick={() => setIsGridView(true)}
                        className={`p-2 rounded-lg transition-all ${isGridView ? "bg-white text-rose-500 shadow-sm" : "text-gray-500 hover:text-gray-700"
                          }`}
                      >
                        <Grid3X3 size={18} />
                      </button>
                      <button
                        onClick={() => setIsGridView(false)}
                        className={`p-2 rounded-lg transition-all ${!isGridView ? "bg-white text-rose-500 shadow-sm" : "text-gray-500 hover:text-gray-700"
                          }`}
                      >
                        <List size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Mobile Sort Bar */}
            {isMobile && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 mb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 flex-1">
                    <ArrowUpDown size={16} className="text-gray-500" />
                    <select
                      className="border-0 bg-transparent text-sm focus:outline-none flex-1"
                      value={filter.sort_filter || ""}
                      onChange={(e) => {
                        setProducts([])
                        setOffset(0)
                        dispatch(setFilterSort({ data: e.target.value }))
                      }}
                    >
                      <option value="">Default Sort</option>
                      <option value="new">Newest First</option>
                      <option value="old">Oldest First</option>
                      <option value="high">Price: High to Low</option>
                      <option value="low">Price: Low to High</option>
                      <option value="discount">Best Discount</option>
                      <option value="popular">Most Popular</option>
                    </select>
                  </div>
                  <div className="flex bg-gray-100 rounded-lg p-1">
                    <button
                      onClick={() => setIsGridView(true)}
                      className={`p-1.5 rounded transition-all ${isGridView ? "bg-white text-rose-500 shadow-sm" : "text-gray-500"
                        }`}
                    >
                      <Grid3X3 size={16} />
                    </button>
                    <button
                      onClick={() => setIsGridView(false)}
                      className={`p-1.5 rounded transition-all ${!isGridView ? "bg-white text-rose-500 shadow-sm" : "text-gray-500"
                        }`}
                    >
                      <List size={16} />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Product Grid */}
            {isLoading && offset === 0 ? (
              <div
                className={`grid gap-4 ${isMobile
                  ? isGridView
                    ? "grid-cols-2"
                    : "grid-cols-1"
                  : isGridView
                    ? "grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
                    : "grid-cols-1"
                  }`}
              >
                {[...Array(8)].map((_, index) => (
                  <div
                    key={index}
                    className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden animate-pulse"
                  >
                    <div className="bg-gray-200 aspect-square"></div>
                    <div className="p-4 space-y-3">
                      <div className="bg-gray-200 h-4 rounded-full w-3/4"></div>
                      <div className="bg-gray-200 h-4 rounded-full w-1/2"></div>
                      <div className="flex justify-between items-center pt-2">
                        <div className="bg-gray-200 h-6 rounded-full w-1/3"></div>
                        <div className="bg-gray-200 h-8 rounded-full w-8"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : products.length > 0 ? (
              <>
                <div
                  className={`${isMobile
                    ? isGridView
                      ? "grid-cols-2"
                      : "grid-cols-1"
                    : isGridView
                      ? "grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
                      : "grid-cols-1"
                    } ${isGridView ? "grid gap-4" : "space-y-4"}`}
                >
                  {products.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={{
                        id: product.id,
                        name: product.name || 'Unnamed Product',
                        price: product.price || 0,
                        discounted_price: product.discounted_price || product.price || 0,
                        image: product.image_url || product.images?.[0]?.image_url || "https://via.placeholder.com/300",
                        image_url: product.image_url || product.images?.[0]?.image_url || "https://via.placeholder.com/300",
                        variants: product.variants || [],
                        stock: product.stock || 0,
                        is_unlimited_stock: product.is_unlimited_stock || false,
                        slug: product.slug || `product-${product.id || 'unknown'}`,
                        seller: product.seller_name || product.seller?.name || '', // Use seller_name or seller.name
                        seller_image_url: product.seller?.image_url || ''
                      }}
                      isMobile={isMobile}
                    />
                  ))}
                </div>

                {/* Load More Button */}
                {hasMoreProducts && (
                  <div className="mt-8 text-center">
                    <button
                      onClick={handleLoadMore}
                      disabled={isFetchingMore}
                      className="bg-gradient-to-r from-rose-500 to-pink-500 text-white px-8 py-4 rounded-2xl hover:from-rose-600 hover:to-pink-600 transition-all disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center mx-auto font-medium shadow-lg hover:shadow-xl transform hover:scale-105"
                    >
                      {isFetchingMore ? (
                        <>
                          <Loader size={20} className="animate-spin mr-3" />
                          Loading more products...
                        </>
                      ) : (
                        <>
                          Load More Products
                          <ChevronDown size={20} className="ml-2" />
                        </>
                      )}
                    </button>
                  </div>
                )}

                {/* No more products message */}
                {!hasMoreProducts && products.length > 0 && (
                  <div className="mt-8 text-center">
                    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                      <div className="w-16 h-16 bg-gradient-to-r from-rose-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Check size={24} className="text-white" />
                      </div>
                      <p className="text-gray-600 font-medium">You've seen all products!</p>
                      <p className="text-gray-500 text-sm mt-1">Try adjusting your filters to see more</p>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-12">
                <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 max-w-md mx-auto">
                  <div className="w-24 h-24 bg-gradient-to-r from-rose-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Search size={32} className="text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">No Products Found</h3>
                  <p className="text-gray-600 mb-6">
                    {currentSeller
                      ? `${currentSeller.store_name} doesn't have any products available right now.`
                      : "We couldn't find any products matching your filters."}
                  </p>
                  <button
                    onClick={clearFilters}
                    className="bg-gradient-to-r from-rose-500 to-pink-500 text-white px-6 py-3 rounded-xl hover:from-rose-600 hover:to-pink-600 transition-all font-medium shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    {currentSeller ? "Browse All Products" : "Reset Filters"}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default ProductListing
