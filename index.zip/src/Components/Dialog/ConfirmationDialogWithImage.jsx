// components/ConfirmDialog.jsx
import React from 'react';
import { X } from 'lucide-react'; // Make sure you have lucide-react installed

const ConfirmationDialogWithImage = ({
    isOpen,
    title = 'Are you sure?',
    message = '',
    product,
    onClose,
    onConfirm,
}) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg max-w-md w-full p-6 shadow-xl transform transition-all">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold text-lg text-gray-900">{title}</h3>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
                        <X size={20} />
                    </button>
                </div>

                {product && (
                    <div className="flex items-center mb-4 p-2 bg-gray-50 rounded">
                        <img
                            src={product.image}
                            alt={product.name}
                            className="w-14 h-14 rounded object-cover mr-3"
                        />
                        <div>
                            <p className="font-medium text-gray-800 text-sm">{product.name}</p>
                            <p className="text-sm text-gray-500">₹{product.price}</p>
                        </div>
                    </div>
                )}

                <p className="text-gray-600 mb-6">{message}</p>

                <div className="flex space-x-3 justify-end">
                    <button
                        onClick={onClose}
                        className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 font-medium text-sm"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={onConfirm}
                        className="px-4 py-2 bg-red-500 rounded-md text-white hover:bg-red-600 font-medium text-sm"
                    >
                        Remove
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ConfirmationDialogWithImage;
