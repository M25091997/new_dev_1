import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { ChevronLeft, Search, Grid3X3, List, Star } from 'lucide-react';
import { slugify } from '../../utils/Slugify';

const SellerSubCategoryProducts = () => {
    const { slug, categorySlug, subCategorySlug } = useParams();
    const { shop } = useSelector((state) => state.shop);
    const [category, setCategory] = useState(null);
    const [subCategory, setSubCategory] = useState(null);
    const [seller, setSeller] = useState(null);
    const [loading, setLoading] = useState(true);
    const [viewMode, setViewMode] = useState('grid');
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        setLoading(true);
        if (shop && shop?.sellers) {
            const selectedSeller = shop?.sellers.find(seller =>
                slugify(seller.store_name) === slug
            );

            if (selectedSeller) {
                setSeller(selectedSeller);
                const selectedCategory = selectedSeller?.categories?.find(cat =>
                    cat.slug === categorySlug
                );
                
                if (selectedCategory) {
                    setCategory(selectedCategory);
                    const selectedSubCategory = selectedCategory?.cat_active_childs?.find(
                        subCat => subCat.slug === subCategorySlug
                    );
                    
                    if (selectedSubCategory) {
                        setSubCategory(selectedSubCategory);
                    }
                }
            }
            setTimeout(() => setLoading(false), 300);
        } else {
            setLoading(false);
        }
    }, [shop, slug, categorySlug, subCategorySlug]);

    const filteredProducts = subCategory?.products?.filter(product =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase())
    ) || [];

    if (loading) {
        return (
            <div className="bg-gray-50 min-h-screen p-4">
                <div className="max-w-7xl mx-auto">
                    <div className="h-8 w-64 bg-gray-200 rounded animate-pulse mb-6"></div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {[...Array(8)].map((_, i) => (
                            <div key={i} className="bg-white rounded-xl overflow-hidden shadow-sm">
                                <div className="h-40 bg-gray-200 animate-pulse"></div>
                                <div className="p-3">
                                    <div className="h-5 w-24 bg-gray-200 rounded animate-pulse"></div>
                                    <div className="h-4 w-16 bg-gray-200 rounded animate-pulse mt-2"></div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }

    if (!subCategory || !seller || !category) {
        return (
            <div className="flex flex-col h-screen items-center justify-center bg-gray-50 p-6">
                <div className="text-center p-8 bg-white rounded-xl shadow-sm max-w-md w-full">
                    <div className="w-16 h-16 bg-pink-50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-pink-500 text-2xl">!</span>
                    </div>
                    <h2 className="text-xl font-semibold text-gray-800">Subcategory Not Found</h2>
                    <p className="mt-2 text-gray-500">We couldn't find the subcategory you're looking for.</p>
                    <Link to={`/seller/${slug}`} className="mt-6 inline-block px-4 py-2 bg-pink-500 text-white rounded-lg font-medium hover:bg-pink-600 transition-colors">
                        Back to Store
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className="bg-gray-50 min-h-screen pb-20">
            {/* Header Section with Breadcrumb */}
            <div className="bg-white shadow-sm sticky top-0 z-10">
                <div className="max-w-7xl mx-auto px-4 py-3">
                    <div className="flex items-center">
                        <Link to={`/seller/${slug}/${categorySlug}`} className="text-gray-600 hover:text-pink-500 p-2 -ml-2">
                            <ChevronLeft size={20} />
                        </Link>
                        <div className="ml-2">
                            <div className="text-xs text-gray-500">
                                <Link to="/" className="hover:text-pink-500">Home</Link> {" › "}
                                <Link to={`/seller/${slug}`} className="hover:text-pink-500">{seller.store_name}</Link> {" › "}
                                <Link to={`/seller/${slug}/${categorySlug}`} className="hover:text-pink-500">{category.name}</Link> {" › "}
                                <span className="text-gray-700">{subCategory.name}</span>
                            </div>
                            <h1 className="text-xl font-bold text-gray-800">{subCategory.name}</h1>
                        </div>
                    </div>
                </div>
            </div>

            {/* Search and View Controls */}
            <div className="max-w-7xl mx-auto px-4 pt-4 pb-2">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                    <div className="relative flex-grow max-w-md">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Search size={16} className="text-gray-400" />
                        </div>
                        <input
                            type="text"
                            className="block w-full bg-white border border-gray-200 rounded-lg pl-10 pr-4 py-2 text-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                            placeholder="Search products..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-500">View:</span>
                        <button
                            onClick={() => setViewMode('grid')}
                            className={`p-2 rounded-md ${viewMode === 'grid' ? 'bg-pink-50 text-pink-500' : 'text-gray-500 hover:bg-gray-100'}`}
                        >
                            <Grid3X3 size={16} />
                        </button>
                        <button
                            onClick={() => setViewMode('list')}
                            className={`p-2 rounded-md ${viewMode === 'list' ? 'bg-pink-50 text-pink-500' : 'text-gray-500 hover:bg-gray-100'}`}
                        >
                            <List size={16} />
                        </button>
                    </div>
                </div>
            </div>

            {/* Products Section */}
            <div className="max-w-7xl mx-auto px-4 py-4">
                {filteredProducts.length === 0 ? (
                    <div className="bg-white rounded-xl p-6 text-center shadow-sm">
                        <p className="text-gray-500">
                            {searchTerm ? 
                                `No products found matching "${searchTerm}"` : 
                                'No products available in this subcategory'
                            }
                        </p>
                    </div>
                ) : viewMode === 'grid' ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                        {filteredProducts.map((product, index) => (
                            <Link
                                to={`/product/${slugify(product.name)}/${product.id}`}
                                key={index}
                                className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all transform hover:-translate-y-1 duration-200"
                            >
                                <div className="aspect-w-1 aspect-h-1 relative">
                                    {product.image_url ? (
                                        <img
                                            src={product.image_url}
                                            alt={product.name}
                                            className="w-full h-48 object-cover"
                                            loading="lazy"
                                        />
                                    ) : (
                                        <div className="w-full h-48 flex items-center justify-center bg-gradient-to-br from-pink-50 to-pink-100">
                                            <div className="text-pink-500 text-4xl font-light">{product.name.charAt(0)}</div>
                                        </div>
                                    )}
                                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent h-24 pointer-events-none"></div>
                                </div>
                                <div className="p-3">
                                    <h3 className="text-sm font-medium text-gray-800 line-clamp-2">{product.name}</h3>
                                    <div className="flex items-center mt-1">
                                        <Star size={14} className="text-yellow-400 fill-yellow-400" />
                                        <span className="text-xs text-gray-500 ml-1">{product.rating || '0'}</span>
                                    </div>
                                    <p className="text-sm font-semibold text-pink-500 mt-1">
                                        {product.price ? `$${product.price.toFixed(2)}` : 'Price not available'}
                                    </p>
                                </div>
                            </Link>
                        ))}
                    </div>
                ) : (
                    <div className="flex flex-col space-y-3">
                        {filteredProducts.map((product, index) => (
                            <Link
                                to={`/product/${slugify(product.name)}/${product.id}`}
                                key={index}
                                className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all flex items-center"
                            >
                                <div className="w-20 h-20 flex-shrink-0">
                                    {product.image_url ? (
                                        <img
                                            src={product.image_url}
                                            alt={product.name}
                                            className="w-full h-full object-cover"
                                            loading="lazy"
                                        />
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-pink-50 to-pink-100">
                                            <div className="text-pink-500 text-2xl font-light">{product.name.charAt(0)}</div>
                                        </div>
                                    )}
                                </div>
                                <div className="p-4 flex-grow">
                                    <h3 className="font-medium text-gray-800">{product.name}</h3>
                                    <div className="flex items-center mt-1">
                                        <Star size={14} className="text-yellow-400 fill-yellow-400" />
                                        <span className="text-xs text-gray-500 ml-1">{product.rating || '0'}</span>
                                    </div>
                                </div>
                                <div className="p-4 flex-shrink-0">
                                    <p className="text-sm font-semibold text-pink-500">
                                        {product.price ? `$${product.price.toFixed(2)}` : 'Price not available'}
                                    </p>
                                </div>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default SellerSubCategoryProducts;