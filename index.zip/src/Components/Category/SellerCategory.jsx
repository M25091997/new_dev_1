// src/Components/Category/SellerCategory.js
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { slugify } from '../../utils/Slugify';

const SellerCategory = () => {
    const { slug } = useParams(); // Changed from storeName to slug
    const { shop } = useSelector((state) => state.shop);
    const [seller, setSeller] = useState(null);
    const navigate = useNavigate();

    console.log(shop);

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    useEffect(() => {
        if (shop && shop?.sellers) {
            // Find the seller by comparing slugified store_name
            const selectedSeller = shop?.sellers.find(seller =>
                slugify(seller.store_name) === slug
            );
            setSeller(selectedSeller);
        }
    }, [shop, slug]);

    if (!seller) {
        return (
            <div className="flex h-screen items-center justify-center bg-white">
                <div className="text-center p-8 rounded-lg">
                    <div className="animate-pulse mb-4">
                        <div className="h-16 w-16 mx-auto rounded-full bg-gray-200"></div>
                    </div>
                    <h2 className="text-xl font-semibold text-gray-700">No seller found! br</h2>
                    <p className="mt-2 text-gray-500">Please check the store name and try again.</p>
                </div>
            </div>
        );
    }

    // Handle category click - use the slug instead of store_name
    const handleCategoryClick = (category) => {
        navigate(`/seller/${slug}/${category.slug}`);
    };

    return (
        <div className="flex flex-col min-h-screen bg-white">
            {/* Store Header with Background */}
            <div className="relative w-full h-48 sm:h-64 md:h-80">
                {/* Background Image with Overlay */}
                <div className="absolute inset-0 w-full h-full opacity-70">
                    {seller.logo_url ? (
                        <img
                            src={seller.logo_url}
                            alt={`${seller.store_name} banner`}
                            className="w-full h-full object-cover"
                        />
                    ) : (
                        <div className="w-full h-full bg-gray-300"></div>
                    )}
                </div>

                {/* Black Transparent Overlay */}
                <div className="absolute inset-0 w-full h-full bg-black opacity-30"></div>

                {/* Centered Content */}
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
                    {/* Store Name */}
                    <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white text-center mb-4 drop-shadow-lg">
                        {seller.store_name}
                    </h1>

                    {/* Categories Badge */}
                    <div className="bg-white text-rose-500 px-4 py-2 rounded-full text-sm md:text-base font-semibold shadow-md hover:bg-rose-100 transition cursor-pointer">
                        {seller.categories?.length || 0} {seller.categories?.length === 1 ? 'Category' : 'Categories'} Available
                    </div>
                </div>
            </div>

            {/* Categories Section */}
            <div className="flex-grow p-4 md:p-6">
                <div className="max-w-7xl mx-auto">
                    <div className="flex items-center justify-between mb-4">
                        <h2 className="text-xl md:text-2xl font-semibold text-gray-800">Categories</h2>
                    </div>

                    {/* Categories Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-6 cursor-pointer">
                        {seller.categories.map((category, index) => (
                            <div
                                key={index}
                                className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-all duration-300 border border-gray-100"
                                onClick={() => handleCategoryClick(category)}
                            >
                                <div className="aspect-w-1 aspect-h-1 bg-gray-100">
                                    {category.image_url ? (
                                        <img
                                            src={category.image_url}
                                            alt={category.name}
                                            className="h-40 w-72 object-cover"
                                        />
                                    ) : (
                                        <div className="h-full w-full flex items-center justify-center bg-pink-50">
                                            <div className="h-12 w-12 rounded-full bg-pink-100 flex items-center justify-center">
                                                <div className="text-pink-500 text-xl">{category.name.charAt(0)}</div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                                <div className="p-3 md:p-4">
                                    <h3 className="text-sm md:text-lg font-medium text-gray-800">{category.name}</h3>
                                    {category.product_count && (
                                        <p className="text-xs md:text-sm text-gray-500 mt-1">
                                            {category.product_count} Products
                                        </p>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SellerCategory;