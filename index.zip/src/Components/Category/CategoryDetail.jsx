import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useParams, useNavigate } from 'react-router-dom';
import { Search } from 'lucide-react';

const CategoryDetail = () => {
    const { slug, subSlug } = useParams();
    const navigate = useNavigate();
    const { shop } = useSelector((state) => state.shop);
    const categories = shop?.categories || [];
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
    const [searchTerm, setSearchTerm] = useState('');

    // Find the selected category by slug
    const selectedCategory = categories.find((category) => category.slug === slug);

    // Find the sub-category by subSlug
    const selectedSubCategory = selectedCategory?.cat_active_childs?.find(
        (subCategory) => subCategory.slug === subSlug
    );

    // Handle window resize
    useEffect(() => {
        const handleResize = () => setIsMobile(window.innerWidth < 768);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    // Filter products based on search term
    const filteredProducts = selectedSubCategory?.cat_active_childs?.filter(
        product => product.name.toLowerCase().includes(searchTerm.toLowerCase())
    ) || [];

    // Handle category click
    const handleCategoryClick = (slug) => {
        navigate(`/category/${slug}`);
    };

    if (!selectedCategory || !selectedSubCategory) {
        return <div>Category not found</div>;
    }

    return (
        <>
            <div className="bg-gray-50 min-h-screen pb-16">
                {/* Category Header */}
                <div className="bg-white px-4 py-5 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-[#fc2e6bed]/10 to-[#fc2e6bed]/5 transform rotate-6 -translate-x-10"></div>
                    <div className="max-w-7xl mx-auto relative z-10">
                        <h1 className="text-xl md:text-2xl font-bold mb-2 text-center text-[#fc2e6bed]">
                            {selectedSubCategory.name}
                        </h1>
                        <p className="text-sm text-gray-600 text-center font-semibold">
                            {filteredProducts.length} products available
                        </p>
                    </div>
                </div>

                {/* Search Bar */}
                <div className="sticky top-0 z-10 bg-white shadow-sm px-4 py-3">
                    <div className="max-w-7xl mx-auto flex items-center gap-2">
                        <div className="relative flex-grow">
                            <input
                                type="text"
                                placeholder="Search products..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="w-full pl-8 pr-3 py-2 bg-gray-100 border-0 rounded-full text-sm focus:ring-1 focus:ring-indigo-500 focus:bg-white"
                            />
                            <Search size={16} className="absolute left-2.5 top-2.5 text-gray-400" />
                        </div>
                    </div>
                </div>

                {/* Main Content */}
                <div className="max-w-7xl mx-auto px-2 sm:px-4 pt-4">
                    {/* Grid of Products */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
                        {filteredProducts.map((product) => (
                            <div
                                key={product.id}
                                className="relative group bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden cursor-pointer"
                            >
                                <div className="relative aspect-square overflow-hidden">
                                    <img
                                        src={product.image_url}
                                        alt={product.name}
                                        className="w-full h-full object-cover"
                                    />
                                </div>
                                <div className="p-1 text-center -mt-7">
                                    <h3 className="text-sm font-bold text-gray-800 truncate">{product.name}</h3>
                                    <div className="inline-block bg-gradient-to-r from-indigo-500 to-transparent h-0.5 w-8 rounded-full my-1"></div>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Empty State */}
                    {filteredProducts.length === 0 && (
                        <div className="flex flex-col items-center justify-center py-16">
                            <div className="bg-gray-100 rounded-full p-4 mb-4">
                                <Search size={24} className="text-gray-400" />
                            </div>
                            <h3 className="text-lg font-medium text-gray-600">No products found</h3>
                            <p className="text-gray-500 text-sm">Try a different search term</p>
                        </div>
                    )}
                </div>
            </div>
        </>
    );
};

export default CategoryDetail;