import { Search, ChevronRight, Home, ChevronLeft, Grid3X3, List, Tag } from "lucide-react"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { useParams, useNavigate } from "react-router-dom"
import api from "../../api/api"
import { setSelectedCategory } from "../../model/reducer/categoryReducer"
import { setFilterCategory, clearAllFilter } from "../../model/reducer/productFilterReducer"
import { ImageWithPlaceholder } from "../image-with-placeholder/ImageWithPlaceholder"
import { ValidateNoInternet } from "../../utils/NoInternetValidator"
import { MdSignalWifiConnectedNoInternet0 } from "react-icons/md"
import Skeleton from "react-loading-skeleton"
import beautyImage from "../../assets/images/beauty.png"

const total_products_per_page = 12

const Breadcrumbs = ({ paths }) => {
  return (
    <div className="hidden md:flex items-center overflow-x-auto pb-2 scrollbar-hide">
      <nav className="flex items-center text-sm whitespace-nowrap">
        {paths.map((path, index) => (
          <div key={index} className="flex items-center">
            {index === 0 ? (
              <Home className="w-4 h-4 text-slate-500" />
            ) : (
              <ChevronRight className="w-4 h-4 text-slate-400 mx-2" />
            )}
            <a
              href={path.path || "#"}
              className={`ml-1 font-medium transition-colors ${index === paths.length - 1 ? "text-indigo-600" : "text-slate-600 hover:text-indigo-500"
                }`}
            >
              {path.name}
            </a>
          </div>
        ))}
      </nav>
    </div>
  )
}

const CustomPagination = ({ currentPage, totalPages, onPageChange }) => {
  const getVisiblePages = () => {
    const delta = window.innerWidth < 768 ? 1 : 2
    const range = []
    const rangeWithDots = []

    for (let i = Math.max(2, currentPage - delta); i <= Math.min(totalPages - 1, currentPage + delta); i++) {
      range.push(i)
    }

    if (currentPage - delta > 2) {
      rangeWithDots.push(1, "...")
    } else {
      rangeWithDots.push(1)
    }

    rangeWithDots.push(...range)

    if (currentPage + delta < totalPages - 1) {
      rangeWithDots.push("...", totalPages)
    } else {
      rangeWithDots.push(totalPages)
    }

    return rangeWithDots
  }

  if (totalPages <= 1) return null

  const visiblePages = getVisiblePages()

  return (
    <div className="flex items-center justify-center space-x-2 mt-8 px-4">
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className={`flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-all duration-200 ${currentPage === 1
          ? "text-slate-400 cursor-not-allowed bg-slate-50"
          : "text-slate-700 hover:text-indigo-600 hover:bg-indigo-50 bg-white shadow-sm border border-slate-200"
          }`}
      >
        <ChevronLeft className="w-4 h-4 mr-1" />
        <span className="hidden sm:inline">Previous</span>
      </button>

      <div className="flex items-center space-x-1 mx-2">
        {visiblePages.map((page, index) => (
          <React.Fragment key={index}>
            {page === "..." ? (
              <span className="px-3 py-2 text-slate-400 text-sm">...</span>
            ) : (
              <button
                onClick={() => onPageChange(page)}
                className={`w-10 h-10 text-sm font-medium rounded-lg transition-all duration-200 ${currentPage === page
                  ? "bg-indigo-600 text-white shadow-md"
                  : "text-slate-700 hover:text-indigo-600 hover:bg-indigo-50 bg-white shadow-sm border border-slate-200"
                  }`}
              >
                {page}
              </button>
            )}
          </React.Fragment>
        ))}
      </div>

      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className={`flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-all duration-200 ${currentPage === totalPages
          ? "text-slate-400 cursor-not-allowed bg-slate-50"
          : "text-slate-700 hover:text-indigo-600 hover:bg-indigo-50 bg-white shadow-sm border border-slate-200"
          }`}
      >
        <span className="hidden sm:inline">Next</span>
        <ChevronRight className="w-4 h-4 ml-1" />
      </button>
    </div>
  )
}

const CategoryPage = () => {
  const { slug } = useParams()
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { shop } = useSelector((state) => state.shop)
  const setting = useSelector((state) => state.setting)
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768)
  const [searchTerm, setSearchTerm] = useState("")
  const [breadcrumbs, setBreadcrumbs] = useState([])
  const [loading, setLoading] = useState(false)
  const [isNetworkError, setIsNetworkError] = useState(false)
  const [viewMode, setViewMode] = useState("grid")
  const [offset, setOffset] = useState(0)
  const [currPage, setCurrPage] = useState(1)
  const [totalProducts, setTotalProducts] = useState(0)
  const [categoryData, setCategoryData] = useState(null)
  const [children, setChildren] = useState([])

  const totalPages = Math.ceil(totalProducts / total_products_per_page)
  const displayName = categoryData?.name || "Categories"

  console.log("slug:", slug)

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768)
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  useEffect(() => {
    window.scrollTo(0, 0)
  })

  useEffect(() => {
    const fetchCategory = async () => {
      const slug_id = slug === "all" ? "" : slug;
      console.log("Fetching category with slug:", slug_id);
      setLoading(true);

      try {
        const response = await api.getCategory({
          limit: total_products_per_page,
          offset: offset,
          slug: slug_id,
        });
        const result = await response.json();
        console.log("Category API Response:", result);

        if (result?.status === 1) {
          setTotalProducts(result?.total || 0);

          // Convert data to array whether it's an object or array
          const convertToArray = (data) => {
            if (Array.isArray(data)) return data;
            if (typeof data === 'object' && data !== null) {
              return Object.values(data);
            }
            return [];
          };

          const resultData = convertToArray(result.data);
          console.log("resultData:", resultData);

          if (slug === "all") {
            // For "all" categories page
            setCategoryData({
              name: "All Categories",
              children: resultData,
            });
            setChildren(resultData);
            setBreadcrumbs([
              { name: "Home", path: "/" },
              { name: "Categories", path: null },
            ]);
          } else {
            // For specific category page
            const foundCategory = resultData?.filter((cat) => cat.slug === slug);
            console.log("foundCategory:", foundCategory);

            if (foundCategory) {
              setCategoryData(foundCategory);
              setChildren(foundCategory.cat_active_childs || resultData);

              // Build breadcrumbs
              const parentCategories = [];
              let parentId = foundCategory.parent_id;
              
              // We need to fetch parent categories if available
              if (shop?.categories) {
                while (parentId) {
                  const parent = shop.categories.find((cat) => cat.id === parentId);
                  if (parent) {
                    parentCategories.unshift(parent);
                    parentId = parent.parent_id;
                  } else {
                    break;
                  }
                }
              }

              setBreadcrumbs([
                { name: "Home", path: "/" },
                { name: "Categories", path: "/category/all" },
                ...parentCategories.map((cat) => ({
                  name: cat.name,
                  path: `/category/${cat.slug}`,
                })),
                { name: foundCategory.name, path: null },
              ]);
            }
          }
        }
      } catch (error) {
        console.error("Error fetching categories:", error);
        const isNoInternet = ValidateNoInternet(error);
        if (isNoInternet) setIsNetworkError(isNoInternet);
      } finally {
        setLoading(false);
      }
    };

    fetchCategory();
  }, [slug, offset, shop?.categories]);

  const handleCategoryClick = (item) => {
    dispatch(clearAllFilter())

    if (item?.has_child === true) {
      navigate(`/category/${item.slug}`)
      // Don't set selected category in Redux - we'll fetch fresh data from API
      // Scroll to top after navigation
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: "smooth" })
      }, 100)
    } else {
      dispatch(setFilterCategory({ data: item.id.toString() }))
      navigate("/products")
      // Scroll to top after navigation
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: "smooth" })
      }, 100)
    }
  }

  const handlePageChange = (pageNum) => {
    setCurrPage(pageNum)
    setOffset(pageNum * total_products_per_page - total_products_per_page)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const filteredItems = children.filter((item) => item.name.toLowerCase().includes(searchTerm.toLowerCase()))

  if (isNetworkError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 px-4">
        <div className="text-center bg-white rounded-lg p-8 shadow-lg border border-slate-200">
          <MdSignalWifiConnectedNoInternet0 className="w-16 h-16 text-slate-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-slate-700 mb-2">No Internet Connection</h3>
          <p className="text-slate-500">Please check your connection and try again</p>
        </div>
      </div>
    )
  }

  console.log("categoryData:", categoryData)

  if (!categoryData && !loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50">
        <div className="text-center bg-white rounded-lg p-8 shadow-lg border border-slate-200">
          <h3 className="text-xl font-semibold text-slate-700">Category not found</h3>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Mobile Header */}
      <div className="md:hidden bg-white shadow-sm sticky top-0 z-50 border-b border-slate-200">
        <div className="flex items-center justify-between px-4 py-3">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-slate-700" />
          </button>
          <h1 className="text-lg font-semibold text-slate-900 truncate mx-4 flex-1 text-center">{displayName}</h1>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}
              className="p-2 rounded-lg hover:bg-slate-100 transition-colors"
            >
              {viewMode === "grid" ? (
                <List className="w-5 h-5 text-slate-700" />
              ) : (
                <Grid3X3 className="w-5 h-5 text-slate-700" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Desktop Header */}
      <div className="hidden md:block bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <Breadcrumbs paths={breadcrumbs} />
          <div className="flex items-center justify-between mt-4">
            <div>
              <h1 className="text-2xl font-bold text-slate-900 mb-1">{displayName}</h1>
              <div className="flex items-center space-x-2">
                <div className="flex items-center px-2 py-1 bg-slate-100 rounded-md">
                  <span className="text-sm font-medium text-slate-600">
                    {totalProducts} {totalProducts === 1 ? "item" : "items"}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}
                className="flex items-center px-4 py-2 text-sm font-medium text-slate-700 bg-white rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors"
              >
                {viewMode === "grid" ? (
                  <>
                    <List className="w-4 h-4 mr-2" />
                    List
                  </>
                ) : (
                  <>
                    <Grid3X3 className="w-4 h-4 mr-2" />
                    Grid
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* <div className="hidden md:block max-w-7xl mx-auto px-6 py-4">
        <img src={beautyImage} alt="" />
      </div> */}

      {/* Search Bar */}
      <div className="bg-white md:bg-transparent px-4 py-4">
        <div className="max-w-7xl mx-auto">
          <div className="relative">
            <input
              type="text"
              placeholder="Search categories..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-10 py-3 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all placeholder-slate-400"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm("")}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400 hover:text-slate-600 bg-slate-100 rounded-full flex items-center justify-center text-xs"
              >
                ×
              </button>
            )}
          </div>
          {searchTerm && (
            <div className="mt-2">
              <span className="text-sm text-slate-600">
                {filteredItems.length} result{filteredItems.length !== 1 ? "s" : ""} found
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Category Listing */}
      <div className="max-w-7xl mx-auto px-4 md:px-6 pb-8">
        {loading ? (
          <div
            className={`grid gap-4 ${viewMode === "grid"
              ? "grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6"
              : "grid-cols-1 max-w-2xl mx-auto"
              }`}
          >
            {Array.from({ length: 12 }).map((_, index) => (
              <div key={index} className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
                <Skeleton height={80} className="mb-3" />
                <Skeleton height={16} width="80%" />
                <Skeleton height={12} width="60%" className="mt-2" />
              </div>
            ))}
          </div>
        ) : (
          <>
            {filteredItems.length > 0 ? (
              <>
                <div
                  className={`grid gap-4 ${viewMode === "grid"
                    ? "grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6"
                    : "grid-cols-1 max-w-2xl mx-auto"
                    }`}
                >
                  {filteredItems.map((ctg, index) => (
                    <div
                      key={index}
                      className={`group bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer border border-slate-200 hover:border-indigo-200 ${viewMode === "list" ? "flex items-center p-3" : "p-2"
                        }`}
                      onClick={() => handleCategoryClick(ctg)}
                    >
                      {viewMode === "grid" ? (
                        <>
                          {/* Small Grid Card Design */}
                          <div className="relative">
                            <div className="w-full h-36 bg-slate-100 overflow-hidden mb-3">
                              <ImageWithPlaceholder
                                src={ctg.image_url || "/placeholder.svg?height=80&width=120"}
                                alt={ctg.name}
                                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                              />
                            </div>

                            {/* Category badge */}
                            <div className="absolute top-1 right-1">
                              {ctg.has_child ? (
                                <div className="px-2 py-1 bg-blue-100 rounded text-xs font-medium text-blue-600">
                                  <Tag className="w-3 h-3 inline" />
                                </div>
                              ) : (
                                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                              )}
                            </div>
                          </div>

                          <div className="text-center">
                            <h3 className="text-sm font-semibold text-slate-900 line-clamp-2 leading-tight mb-1 group-hover:text-indigo-600 transition-colors">
                              {ctg.name}
                            </h3>
                            <p className="text-xs text-slate-500">
                              {ctg.has_child ? "Category" : "Products"}
                            </p>
                          </div>
                        </>
                      ) : (
                        <>
                          {/* Simple List View */}
                          <div className="w-16 h-16 bg-slate-100 rounded-lg overflow-hidden flex-shrink-0 mr-4">
                            <ImageWithPlaceholder
                              src={ctg.image_url || "/placeholder.svg?height=64&width=64"}
                              alt={ctg.name}
                              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                            />
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <div className="flex-1 min-w-0">
                                <h3 className="text-base font-semibold text-slate-900 truncate group-hover:text-indigo-600 transition-colors mb-1">
                                  {ctg.name}
                                </h3>
                                <div className="flex items-center space-x-2">
                                  {ctg.has_child ? (
                                    <span className="inline-flex items-center px-2 py-1 bg-blue-100 rounded text-xs font-medium text-blue-600">
                                      <Tag className="w-3 h-3 mr-1" />
                                      Category
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center px-2 py-1 bg-green-100 rounded text-xs font-medium text-green-600">
                                      <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                                      Products
                                    </span>
                                  )}
                                </div>
                              </div>
                              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 flex-shrink-0 ml-2" />
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>

                {!searchTerm && (
                  <CustomPagination currentPage={currPage} totalPages={totalPages} onPageChange={handlePageChange} />
                )}
              </>
            ) : (
              <div className="text-center py-12">
                <div className="max-w-sm mx-auto bg-white rounded-lg p-6 shadow-sm border border-slate-200">
                  <div className="w-16 h-16 mx-auto mb-4 bg-slate-100 rounded-lg flex items-center justify-center">
                    <Search className="w-8 h-8 text-slate-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-700 mb-2">No items found</h3>
                  <p className="text-slate-500 mb-4 text-sm">
                    {searchTerm ? (
                      <>
                        No categories match "<span className="font-medium text-slate-700">{searchTerm}</span>".
                      </>
                    ) : (
                      "This category is currently empty."
                    )}
                  </p>
                  {searchTerm && (
                    <button
                      onClick={() => setSearchTerm("")}
                      className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
                    >
                      Clear search
                    </button>
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

export default CategoryPage