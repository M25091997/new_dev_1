import React, { useEffect, useRef, useState } from "react";
import constants from "../constants/constants";

let autoComplete;

const loadScript = (url, callback) => {
  let script = document.createElement("script");
  script.type = "text/javascript";

  if (script.readyState) {
    script.onreadystatechange = function () {
      if (script.readyState === "loaded" || script.readyState === "complete") {
        script.onreadystatechange = null;
        callback();
      }
    };
  } else {
    script.onload = () => callback();
  }

  script.src = url;
  document.getElementsByTagName("head")[0].appendChild(script);
};

const SearchLocationInput = ({ setSelectedLocation }) => {
  const [query, setQuery] = useState("");
  const autoCompleteRef = useRef(null);

  const handleScriptLoad = (updateQuery, autoCompleteRef) => {
    if (!window.google) return; // Ensure Google Maps is loaded

    autoComplete = new window.google.maps.places.Autocomplete(autoCompleteRef.current, {
      componentRestrictions: { country: "IN" }, // Restrict to India
    });

    // Listen for place changes
    autoComplete.addListener("place_changed", () => handlePlaceSelect(updateQuery));
  };

  const handlePlaceSelect = async (updateQuery) => {
    const place = autoComplete.getPlace();

    if (!place.geometry) {
      // Handle case where no geometry is returned
      console.error("No geometry found for place:", place);
      return;
    }

    const query = place.formatted_address;
    updateQuery(query);
    console.log({ query });

    const latLng = {
      lat: place.geometry.location.lat(),
      lng: place.geometry.location.lng(),
    };

    console.log({ latLng });
    setSelectedLocation(latLng); // Set the selected location
  };

  useEffect(() => {
    loadScript(
      `https://maps.googleapis.com/maps/api/js?key=${constants.GOOGLE_MAP_API_KEY}&libraries=places`,
      () => handleScriptLoad(setQuery, autoCompleteRef)
    );

    return () => {
      if (autoComplete) {
        window.google.maps.event.clearInstanceListeners(autoComplete); // Cleanup event listener
      }
    };
  }, []);

  return (
      <input
        ref={autoCompleteRef}
        className="focus:outline-0 text-sm w-full"
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Search Location"
        value={query}
      />
  );
};

export default SearchLocationInput;