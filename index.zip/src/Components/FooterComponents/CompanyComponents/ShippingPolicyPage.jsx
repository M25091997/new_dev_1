
import React, { useEffect, useState } from 'react';
import { Truck, Package, Clock, MapPin, Shield, CheckCircle, AlertTriangle, ChevronDown, ChevronUp, CreditCard, Globe, Calendar, Zap, Phone, Mail, HeadphonesIcon } from 'lucide-react';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const ShippingPolicyPage = () => {
  const { jwtToken } = useSelector(state => state.user)
  const [activeSection, setActiveSection] = useState(null);
  const navigate = useNavigate()

  const toggleSection = (sectionId) => {
    setActiveSection(activeSection === sectionId ? null : sectionId);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleTrackOrderClick = () => {
    if (jwtToken) {
      navigate("/my-orders")
    } else {
      toast.error("Please Login to track your order !!")
    }
  }
  const sections = [
    {
      id: 1,
      title: "Shipping Coverage & Zones",
      icon: <Globe className="w-6 h-6" />,
      content: [
        {
          subtitle: "Service Areas",
          items: [
            "We currently deliver to all major cities and towns across Jharkhand.",
            "Coverage includes cities like Ranchi, Jamshedpur, Dhanbad, Bokaro, Hazaribagh, and many more.",
            "Delivery availability may vary slightly depending on local logistics in certain remote areas.",
            "You can verify delivery to your location by entering your pincode during checkout.",
            "Special delivery arrangements may apply for hilly or hard-to-reach locations within Jharkhand."
          ]
        },
        {
          subtitle: "Delivery Zones",
          items: [
            "Zone A: Urban areas like Ranchi, Jamshedpur, Dhanbad with same-day or next-day delivery options.",
            "Zone B: Other cities and towns like Bokaro, Hazaribagh, Deoghar with 1–2 day standard delivery.",
            "Zone C: Smaller towns and semi-urban regions with 2–4 day delivery depending on accessibility.",
            "Zone D: Rural areas across Jharkhand with 3–5 day delivery, based on logistics availability.",
            "Special zones may apply for remote or hilly regions with customized delivery timelines."
          ]
        }
      ]
    },
    {
      id: 2,
      title: "Delivery Options & Timeframes",
      icon: <Clock className="w-6 h-6" />,
      content: [
        {
          subtitle: "Instant Delivery",
          items: [
           "Get your order delivered within 15 to 30 minutes, only available in serviceable pincodes.",
            "Available for selected products and areas within Jharkhand.",
            "Service availability may vary based on order time and local logistics.",
            "Check eligibility at checkout based on your location and product type.",
            "Ideal for urgent grocery and daily essential orders."
          ]
        },
        {
          subtitle: "Scheduled Delivery",
          items: [
            "All the orders will be delivedred within 5-7 business days.",
            "Select a preferred delivery date and time slot during checkout.",
            "Available delivery dates: Today and the next 5 calendar days.",
            "Time slots include: ☀️ 7 AM – 10 AM, 🌤️ 10 AM – 1 PM, ☀️ 1 PM – 4 PM, 🌆 4 PM – 7 PM, 🌙 7 PM – 10 PM.",
            "Scheduled delivery is available in all major cities of Jharkhand.",
            "Perfect for planning deliveries at your convenience."
          ]
        }
      ]
    },
    {
      id: 3,
      title: "Shipping Charges & Policies",
      icon: <CreditCard className="w-6 h-6" />,
      content: [
        {
          subtitle: "Delivery Charges",
          items: [
            "Free standard delivery on orders above ₹499 for most products and locations.",
            "Delivery charges range from ₹40-₹120 based on location, order value, and delivery speed.",
            "Bulk orders and heavy items may have additional handling charges clearly mentioned at checkout.",
            "Express and scheduled delivery services have premium charges varying by location and time slot.",
            "Delivery charges are calculated automatically during checkout based on your location and preferences."
          ]
        },
        {
          subtitle: "Order Processing",
          items: [
            "Orders are processed within 24 hours of confirmation and payment verification.",
            "Cut-off time for same-day processing is 6 PM for regular orders and 12 PM for express delivery.",
            "Weekends and public holidays may extend processing time by 1-2 additional business days.",
            "Order modifications or cancellations must be requested within 1 hour of order placement.",
            "Large or bulk orders may require additional processing time communicated at the time of purchase."
          ]
        }
      ]
    },
    {
      id: 4,
      title: "Special Products & Handling",
      icon: <Package className="w-6 h-6" />,
      content: [
        {
          subtitle: "Perishable Items",
          items: [
            "Fresh produce, dairy, and frozen items are delivered in temperature-controlled packaging.",
            "Perishable deliveries are prioritized and typically completed within 24-48 hours of order.",
            "Special handling fees may apply for items requiring refrigeration or freezing during transit.",
            "Delivery time slots are more strictly adhered to for perishable items to maintain quality.",
            "Quality guarantee applies with immediate replacement or refund for spoiled perishable items."
          ]
        },
        {
          subtitle: "Fragile & Electronic Items",
          items: [
            "Extra protective packaging used for fragile items, electronics, and valuable products.",
            "Insurance coverage available for high-value items with minimal additional cost.",
            "Signature confirmation required for delivery of electronics and items above ₹5,000.",
            "Special handling charges may apply for oversized or unusually shaped items.",
            "Installation services available for select appliances and electronics at additional cost."
          ]
        },
        {
          subtitle: "Bulk & Wholesale Orders",
          items: [
            "Bulk orders may have extended processing and delivery times based on quantity and availability.",
            "Special delivery arrangements can be made for large orders including multiple delivery dates.",
            "Wholesale customers may have access to dedicated delivery slots and priority processing.",
            "Custom packaging and labeling services available for business orders at additional cost.",
            "Volume discounts on delivery charges available for regular bulk order customers."
          ]
        }
      ]
    },
    {
      id: 5,
      title: "Delivery Process & Tracking",
      icon: <MapPin className="w-6 h-6" />,
      content: [
        {
          subtitle: "Order Tracking",
          items: [
            "Real-time tracking available through our website, app, and SMS notifications.",
            "Tracking ID provided within 24 hours of order dispatch with estimated delivery time.",
            "Live location tracking available for same-day and express deliveries in select cities.",
            "Email and SMS updates at key milestones: order confirmed, packed, dispatched, and delivered.",
            "Customer support available for tracking queries and delivery status updates."
          ]
        },
        {
          subtitle: "Delivery Procedure",
          items: [
            "Delivery partner will call/message 30 minutes before reaching your location.",
            "Valid ID proof may be required for high-value orders or age-restricted products.",
            "Contactless delivery available with prior request and suitable drop-off location.",
            "Quality check opportunity provided before accepting perishable and fragile items.",
            "Delivery confirmation via SMS and email with digital receipt and feedback request."
          ]
        }
      ]
    },
    {
      id: 6,
      title: "Delivery Policies & Restrictions",
      icon: <Shield className="w-6 h-6" />,
      content: [
        {
          subtitle: "Address & Contact Requirements",
          items: [
            "A complete and accurate delivery address with a nearby landmark and an active contact number is required.",
            "Address changes must be requested within 2 hours of placing the order and may incur additional delivery charges.",
            "You can save multiple delivery addresses in your BringMart account for faster checkout.",
            "For apartment complexes and gated communities, please ensure security access or delivery permissions are arranged in advance.",
            "Delivery to remote or hard-to-reach areas in Jharkhand may take longer or incur extra charges based on logistics availability."
          ]
        },
        {
          subtitle: "Delivery Attempts & Failed Deliveries",
          items: [
            "We make up to 2 delivery attempts for each order.",
            "You will be notified before each attempt via SMS or phone call.",
            "If the delivery fails due to unavailability or incorrect address, a redelivery fee may apply.",
            "Orders returned due to failed delivery are refundable, but delivery and handling fees may be deducted.",
            "Perishable items, especially groceries, may be canceled or discarded after failed attempts for safety reasons."
          ]
        },
        {
          subtitle: "Restricted Items & Locations",
          items: [
            "Certain products may not be deliverable to specific localities due to local restrictions or storage limitations.",
            "Age-restricted items require valid ID verification and cannot be left unattended at the doorstep.",
            "We currently do not deliver to PO Box addresses, military areas, or institutions with restricted entry.",
            "Items restricted by Jharkhand or Indian law will not be processed or shipped.",
            "Extreme weather or seasonal conditions may temporarily affect the availability of certain product deliveries."
          ]
        }
      ]
    }
  ];

  const quickStats = [
    { icon: <Zap className="w-8 h-8" />, number: "Same Day", label: "Express Delivery", description: "Available in select areas" },
    { icon: <Truck className="w-8 h-8" />, number: "₹499+", label: "Free Shipping", description: "On eligible orders" },
    { icon: <Globe className="w-8 h-8" />, number: "Pan State", label: "Coverage", description: "Across Jharkhand" },
    { icon: <Package className="w-8 h-8" />, number: "24/7", label: "Order Tracking", description: "Real-time updates" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Enhanced Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Breadcrumbs */}
          <div className="py-4 border-b border-gray-100">
            <nav className="flex" aria-label="Breadcrumb">
              <ol className="inline-flex items-center space-x-1 md:space-x-3">
                <li className="inline-flex items-center">
                  <a href="#" className="text-gray-500 hover:text-[#fc2e6b] transition-colors duration-200 text-sm font-medium">
                    Home
                  </a>
                </li>
                <li>
                  <div className="flex items-center">
                    <svg className="w-4 h-4 text-gray-400 mx-2" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-[#fc2e6b] font-semibold text-sm">Shipping Policy</span>
                  </div>
                </li>
              </ol>
            </nav>
          </div>

          {/* Hero Header */}
          <div className="py-12 text-center">
            <div className="max-w-3xl mx-auto">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-[#fc2e6b] to-[#e91e63] rounded-full mb-6">
                <Truck className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                Shipping <span className="text-[#fc2e6b]">Policy</span>
              </h1>
              <p className="text-lg text-gray-600 leading-relaxed max-w-2xl mx-auto">
                Comprehensive information about our delivery services, charges, and procedures to ensure transparent and reliable shipping across Jharkhand.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Professional Stats Section */}
      <div className="bg-gradient-to-r from-[#fc2e6b] via-[#e91e63] to-[#d81b60] py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-black bg-opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {quickStats.map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-2xl p-6 transition-all duration-300 group-hover:bg-opacity-30 group-hover:scale-105">
                  <div className="text-white mb-4 flex justify-center">
                    {stat.icon}
                  </div>
                  <div className="text-2xl lg:text-3xl font-bold text-white mb-2">
                    {stat.number}
                  </div>
                  <div className="text-white text-lg font-semibold mb-1">
                    {stat.label}
                  </div>
                  <div className="text-pink-100 text-sm">
                    {stat.description}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">

        {/* Professional Introduction */}
        <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12 border border-gray-200 mb-12 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-[#fc2e6b]/5 to-transparent rounded-full transform translate-x-32 -translate-y-32"></div>
          <div className="relative">
            <div className="flex items-start space-x-4 mb-6">
              <div className="bg-gradient-to-br from-[#fc2e6b] to-[#e91e63] p-3 rounded-xl shadow-lg">
                <AlertTriangle className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-2">Shipping Information</h2>
                <div className="w-16 h-1 bg-gradient-to-r from-[#fc2e6b] to-[#e91e63] rounded-full"></div>
              </div>
            </div>
            <p className="text-gray-700 text-lg leading-relaxed">
              At BringMart, we are committed to delivering your orders with precision, care, and reliability. Our comprehensive shipping policy outlines our delivery services, charges, timeframes, and procedures, ensuring complete transparency in our shipping process. We continuously strive to enhance our logistics network to serve you better across Jharkhand.
            </p>
          </div>
        </div>

        {/* Enhanced Sections */}
        <div className="space-y-8">
          {sections.map((section) => (
            <div key={section.id} className="bg-white rounded-3xl shadow-xl border border-gray-200 overflow-hidden transition-all duration-300 hover:shadow-2xl">
              <button
                onClick={() => toggleSection(section.id)}
                className="w-full flex items-center justify-between p-8 hover:bg-gray-50 transition-all duration-200 group"
              >
                <div className="flex items-center space-x-6">
                  <div className="bg-gradient-to-br from-[#fc2e6b]/10 to-[#e91e63]/10 p-4 rounded-2xl group-hover:from-[#fc2e6b]/20 group-hover:to-[#e91e63]/20 transition-all duration-200">
                    <div className="text-[#fc2e6b]">{section.icon}</div>
                  </div>
                  <div className="text-left">
                    <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 group-hover:text-[#fc2e6b] transition-colors duration-200">
                      {section.title}
                    </h2>
                    <div className="w-12 h-0.5 bg-gradient-to-r from-[#fc2e6b] to-[#e91e63] rounded-full mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
                  </div>
                </div>
                <div className="text-[#fc2e6b] group-hover:scale-110 transition-transform duration-200">
                  {activeSection === section.id ? <ChevronUp className="w-7 h-7" /> : <ChevronDown className="w-7 h-7" />}
                </div>
              </button>

              {activeSection === section.id && (
                <div className="px-8 pb-8 border-t border-gray-100 bg-gradient-to-b from-gray-50/50 to-white">
                  <div className="pt-8 space-y-8">
                    {section.content.map((contentBlock, index) => (
                      <div key={index} className="bg-white rounded-2xl p-6 shadow-md border border-gray-100">
                        {contentBlock.subtitle && (
                          <div className="mb-6">
                            <h3 className="text-xl font-bold text-gray-800 mb-2">
                              {contentBlock.subtitle}
                            </h3>
                            <div className="w-8 h-0.5 bg-gradient-to-r from-[#fc2e6b] to-[#e91e63] rounded-full"></div>
                          </div>
                        )}
                        <ul className="space-y-4">
                          {contentBlock.items.map((item, itemIndex) => (
                            <li key={itemIndex} className="flex items-start space-x-4 group">
                              <div className="flex-shrink-0 w-2 h-2 bg-gradient-to-r from-[#fc2e6b] to-[#e91e63] rounded-full mt-3 group-hover:scale-125 transition-transform duration-200"></div>
                              <p className="text-gray-700 leading-relaxed group-hover:text-gray-900 transition-colors duration-200">
                                {item}
                              </p>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Enhanced Support Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-16">
          {/* Customer Support */}
          <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-200 hover:shadow-2xl transition-all duration-300 group">
            <div className="flex items-center space-x-4 mb-6">
              <div className="bg-gradient-to-br from-[#fc2e6b] to-[#e91e63] p-3 rounded-xl shadow-lg group-hover:scale-110 transition-transform duration-200">
                <HeadphonesIcon className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900">Delivery Support</h3>
                <div className="w-12 h-0.5 bg-gradient-to-r from-[#fc2e6b] to-[#e91e63] rounded-full mt-1"></div>
              </div>
            </div>
            <p className="text-gray-600 leading-relaxed mb-6">
              Our dedicated logistics team is available to assist with tracking, scheduling, and delivery queries. Get instant support for all your shipping needs.
            </p>
            <div className="space-y-4">
              <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors duration-200">
                <Phone className="w-5 h-5 text-[#fc2e6b]" />
                <div>
                  <p className="text-sm font-medium text-gray-900">Phone Support</p>
                  <a href="tel:06574022692" className="text-[#fc2e6b] hover:text-[#e91e63] font-semibold transition-colors duration-200">
                    0657-4022692
                  </a>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors duration-200">
                <Mail className="w-5 h-5 text-[#fc2e6b]" />
                <div>
                  <p className="text-sm font-medium text-gray-900">Email Support</p>
                  <a href="mailto:support@bringmart.in" className="text-[#fc2e6b] hover:text-[#e91e63] font-semibold transition-colors duration-200">
                    support@bringmart.in
                  </a>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-xl">
                <Clock className="w-5 h-5 text-[#fc2e6b]" />
                <div>
                  <p className="text-sm font-medium text-gray-900">Business Hours</p>
                  <p className="text-gray-600 text-sm">10 AM - 6 PM (Mon-Sat)</p>
                </div>
              </div>
            </div>
          </div>

          {/* Emergency Delivery */}
          <div className="bg-gradient-to-br from-[#fc2e6b] to-[#e91e63] rounded-3xl shadow-xl p-8 text-white hover:shadow-2xl transition-all duration-300 group relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white bg-opacity-10 rounded-full transform translate-x-16 -translate-y-16"></div>
            <div className="relative">
              <div className="flex items-center space-x-4 mb-6">
                <div className="bg-white bg-opacity-20 p-3 rounded-xl backdrop-blur-sm group-hover:scale-110 transition-transform duration-200">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">Emergency Deliveries</h3>
                  <div className="w-12 h-0.5 bg-white bg-opacity-60 rounded-full mt-1"></div>
                </div>
              </div>
              <p className="text-white text-opacity-90 leading-relaxed mb-6">
                Special arrangements for urgent medical supplies, baby products, and essential items. Contact our emergency delivery team for priority processing during critical situations.
              </p>
              <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-xl p-4">
                <p className="text-white text-sm font-medium">
                  Available 24/7 for genuine emergencies
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Delivery Partners Section */}
        <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-3xl shadow-2xl p-12 text-white mt-16 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-[#fc2e6b]/10 to-[#e91e63]/10"></div>
          <div className="relative text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#fc2e6b] to-[#e91e63] rounded-full mb-8 shadow-2xl">
              <Package className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-3xl lg:text-4xl font-bold mb-6">Trusted Delivery Network</h3>
            <p className="text-gray-300 text-lg mb-8 max-w-4xl mx-auto leading-relaxed">
              We partner with leading logistics companies across India to ensure reliable and timely delivery.
              Our comprehensive network includes national courier services, local delivery partners, and specialized handlers for different product categories.
            </p>
            <div className="grid md:grid-cols-3 gap-6 mt-12">
              <div className="bg-white bg-opacity-5 backdrop-blur-sm rounded-2xl p-6 hover:bg-opacity-10 transition-all duration-300">
                <CheckCircle className="w-8 h-8 text-[#fc2e6b] mx-auto mb-4" />
                <h4 className="text-lg font-semibold mb-2">Verified Partners</h4>
                <p className="text-gray-400 text-sm">All delivery partners are verified and trained</p>
              </div>
              <div className="bg-white bg-opacity-5 backdrop-blur-sm rounded-2xl p-6 hover:bg-opacity-10 transition-all duration-300">
                <Shield className="w-8 h-8 text-[#fc2e6b] mx-auto mb-4" />
                <h4 className="text-lg font-semibold mb-2">Secure Handling</h4>
                <p className="text-gray-400 text-sm">Professional care for all product categories</p>
              </div>
              <div className="bg-white bg-opacity-5 backdrop-blur-sm rounded-2xl p-6 hover:bg-opacity-10 transition-all duration-300">
                <Globe className="w-8 h-8 text-[#fc2e6b] mx-auto mb-4" />
                <h4 className="text-lg font-semibold mb-2">Wide Coverage</h4>
                <p className="text-gray-400 text-sm">Extensive network across Jharkhand</p>
              </div>
            </div>
          </div>
        </div>

        {/* Policy Updates */}
        <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12 border border-gray-200 mt-12 relative overflow-hidden">
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-gradient-to-tr from-[#fc2e6b]/5 to-transparent rounded-full transform -translate-x-32 translate-y-32"></div>
          <div className="relative">
            <div className="flex items-start space-x-4 mb-6">
              <div className="bg-gradient-to-br from-[#fc2e6b] to-[#e91e63] p-3 rounded-xl shadow-lg">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-3xl font-bold text-gray-900 mb-2">Policy Updates & Seasonal Changes</h3>
                <div className="w-16 h-1 bg-gradient-to-r from-[#fc2e6b] to-[#e91e63] rounded-full"></div>
              </div>
            </div>
            <div className="space-y-4">
              <p className="text-gray-700 text-lg leading-relaxed">
                Shipping policies may be updated to reflect changes in logistics partnerships, service improvements, or seasonal variations.
                During festival seasons and peak periods, delivery times may be extended due to high order volumes.
              </p>
              <div className="bg-gradient-to-r from-[#fc2e6b]/5 to-[#e91e63]/5 rounded-2xl p-6 border border-[#fc2e6b]/10">
                <p className="text-gray-600 leading-relaxed">
                  Customers will be notified of significant policy changes through email, SMS, and website announcements.
                  Seasonal delivery schedules and special arrangements will be communicated in advance.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced CTA Section */}
        <div className="bg-gradient-to-r from-[#fc2e6b] via-[#e91e63] to-[#d81b60] rounded-3xl shadow-2xl p-12 text-white mt-16 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-black bg-opacity-10"></div>
          <div className="relative">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-white bg-opacity-20 backdrop-blur-sm rounded-full mb-8">
              <HeadphonesIcon className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-3xl lg:text-4xl font-bold mb-4">Questions About Shipping?</h3>
            <p className="text-white text-opacity-90 text-lg mb-10 max-w-2xl mx-auto">
              Our delivery team is ready to help you with shipping queries, tracking, and special delivery requests.
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center max-w-md mx-auto">
              <a
                href="mailto:support@bringmart.in"
                className="flex-1 bg-white text-[#fc2e6b] px-8 py-4 rounded-2xl font-bold hover:bg-gray-100 transition-all duration-300 shadow-xl hover:shadow-2xl transform hover:scale-105 flex items-center justify-center space-x-2"
              >
                <Mail className="w-5 h-5" />
                <span>Email Support</span>
              </a>
              <button
                onClick={handleTrackOrderClick}
                className="flex-1 bg-white bg-opacity-20 backdrop-blur-sm text-white border-2 border-white border-opacity-30 px-8 py-4 rounded-2xl font-bold hover:bg-opacity-30 transition-all duration-300 shadow-xl hover:shadow-2xl transform hover:scale-105 flex items-center justify-center space-x-2"
              >
                <Package className="w-5 h-5" />
                <span>Track Order</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShippingPolicyPage;
