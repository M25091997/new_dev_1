import React, { useEffect } from 'react';
import { Phone, Mail, MapPin, Clock, Facebook, Instagram, Twitter, MessageCircle, HelpCircle } from 'lucide-react';
import ContactUs from '../../../assets/ContactUs1.png'

const ContactUsPage = () => {

  useEffect(() => {
    window.scrollTo(0, {
      behavior: "smooth"
    })
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumbs */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <a href="#" className="text-gray-600 hover:text-[#fc2e6b] transition-colors">
                  Home
                </a>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <span className="text-[#fc2e6b] font-medium">Contact Us</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Hero Section */}
      {/* <div className="bg-gradient-to-r from-[#fc2e6b] to-[#e91e63] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Contact Us</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            At bringmart.in, we value our customers and are here to assist you with any questions, feedback, or concerns.
          </p>
        </div>
      </div> */}
      <div>
        <img src={ContactUs} alt="" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

          {/* Contact Information Cards */}
          <div className="lg:col-span-2 space-y-6">

            {/* Customer Support Hours */}
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 hover:shadow-xl transition-all duration-300">
              <div className="flex items-center mb-6">
                <div className="bg-[#fc2e6b]/10 p-3 rounded-full">
                  <Clock className="w-6 h-6 text-[#fc2e6b]" />
                </div>
                <h2 className="text-2xl font-bold text-gray-800 ml-4">Customer Support Hours</h2>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600 font-medium">Monday to Saturday</span>
                  <span className="text-gray-800 font-semibold">10:00 AM - 6:00 PM (IST)</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600 font-medium">Sunday & Public Holidays</span>
                  <span className="text-red-500 font-semibold">Closed</span>
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 hover:shadow-xl transition-all duration-300">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Get in Touch</h2>
              <div className="space-y-6">

                {/* Email Section */}
                <div className="flex items-start space-x-4">
                  <div className="bg-[#fc2e6b]/10 p-3 rounded-full flex-shrink-0">
                    <Mail className="w-6 h-6 text-[#fc2e6b]" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-2">Email Us</h3>
                    <div className="space-y-2">
                      <div>
                        <span className="text-sm text-gray-600">General inquiries:</span>
                        <a href="mailto:contact@bringmart.in" className="block text-[#fc2e6b] hover:underline font-medium">
                          contact@bringmart.in
                        </a>
                      </div>
                      <div>
                        <span className="text-sm text-gray-600">Order-related queries:</span>
                        <a href="mailto:support@bringmart.in" className="block text-[#fc2e6b] hover:underline font-medium">
                          support@bringmart.in
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Phone Section */}
                <div className="flex items-start space-x-4">
                  <div className="bg-[#fc2e6b]/10 p-3 rounded-full flex-shrink-0">
                    <Phone className="w-6 h-6 text-[#fc2e6b]" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-2">Call Us</h3>
                    <div>
                      <span className="text-sm text-gray-600">Customer Service Hotline:</span>
                      <a href="tel:+918069645311" className="block text-[#fc2e6b] hover:underline font-bold text-lg">
                        0657 4022692
                      </a>
                    </div>
                  </div>
                </div>

                {/* Address Section */}
                <div className="flex items-start space-x-4">
                  <div className="bg-[#fc2e6b]/10 p-3 rounded-full flex-shrink-0">
                    <MapPin className="w-6 h-6 text-[#fc2e6b]" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-2">Visit Us</h3>
                    <address className="text-gray-600 not-italic leading-relaxed">
                      <strong className="text-gray-800">BringMart Ecommerce Private Limited</strong><br />
                      H.NO.34, Jeeta Singh Bagan,<br />
                      Namda basti, Golmuri,<br />
                      East Singhbhum, Jamshedpur<br />
                      Jharkhand, India - 831003
                    </address>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">

            {/* Social Media */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300">
              <h3 className="text-xl font-bold text-gray-800 mb-4">Connect with Us</h3>
              <p className="text-gray-600 mb-6 text-sm">Follow us for the latest updates, promotions, and more:</p>
              <div className="space-y-3">
                <a href="https://www.facebook.com/share/1JCYhKgSrj/" className="flex items-center space-x-3 p-3 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors group">
                  <Facebook className="w-5 h-5 text-blue-600 group-hover:scale-110 transition-transform" />
                  <span className="text-blue-600 font-medium">Facebook</span>
                </a>
                <a href="https://www.instagram.com/bringmart.in/" className="flex items-center space-x-3 p-3 rounded-lg bg-pink-50 hover:bg-pink-100 transition-colors group">
                  <Instagram className="w-5 h-5 text-pink-600 group-hover:scale-110 transition-transform" />
                  <span className="text-pink-600 font-medium">Instagram</span>
                </a>
                <a href="https://x.com/bringmart1" className="flex items-center space-x-3 p-3 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors group">
                  <Twitter className="w-5 h-5 text-blue-600 group-hover:scale-110 transition-transform" />
                  <span className="text-blue-600 font-medium">Twitter</span>
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300">
              <h3 className="text-xl font-bold text-gray-800 mb-4">Quick Help</h3>
              <div className="space-y-3">
                <a href="/faqs" className="flex items-center space-x-3 p-3 rounded-lg bg-gray-50 hover:bg-[#fc2e6b]/5 hover:text-[#fc2e6b] transition-all group">
                  <HelpCircle className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  <span className="font-medium">FAQ Section</span>
                </a>
                {/* <a href="#" className="flex items-center space-x-3 p-3 rounded-lg bg-gray-50 hover:bg-[#fc2e6b]/5 hover:text-[#fc2e6b] transition-all group">
                  <MessageCircle className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  <span className="font-medium">Live Chat</span>
                </a> */}
              </div>
            </div>

            {/* Feedback */}
            <div className="bg-gradient-to-br from-[#fc2e6b] to-[#e91e63] rounded-2xl shadow-lg p-6 text-white">
              <h3 className="text-xl font-bold mb-4">Feedback & Suggestions</h3>
              <p className="text-white/90 mb-4 text-sm">
                We're always looking to improve our services and appreciate your feedback.
              </p>
              {/* <a
                href="mailto:support@bringmart.in"
                className="inline-block bg-white text-[#fc2e6b] px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors shadow-md"
              >
                Send Feedback
              </a> */}
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-12 bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Before reaching out, check out our FAQ section for quick answers to common questions about orders, returns, shipping, and more.
            </p>
          </div>
          <div className="text-center">
            <a
              href="/faqs"
              className="inline-flex items-center space-x-2 bg-[#fc2e6b] text-white px-8 py-4 rounded-lg font-semibold hover:bg-[#e91e63] transition-colors shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <HelpCircle className="w-5 h-5" />
              <span>View FAQ Section</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactUsPage;