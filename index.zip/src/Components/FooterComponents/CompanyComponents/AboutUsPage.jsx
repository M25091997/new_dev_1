import React, { useEffect } from 'react';
import { ChevronRight, ShoppingBag, Truck, Clock, Shield, Users, Heart } from 'lucide-react';

const AboutUsPage = () => {

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const features = [
    {
      icon: <Truck className="w-8 h-8" />,
      title: "Fast Delivery",
      description: "Quick and reliable delivery right to your doorstep"
    },
    {
      icon: <Clock className="w-8 h-8" />,
      title: "Save Time",
      description: "Focus on what matters while we handle your shopping"
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Quality Assured",
      description: "Fresh groceries and quality products guaranteed"
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Customer First",
      description: "Dedicated to providing exceptional service experience"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <nav className="flex items-center space-x-2 text-sm">
            <a href="/" className="text-gray-600 hover:text-[#fc2e6bed] transition-colors">
              Home
            </a>
            <ChevronRight className="w-4 h-4 text-gray-400" />
            <span className="text-[#fc2e6bed] font-medium">About Us</span>
          </nav>
        </div>
      </div>

      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-pink-50 to-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6">
                About{' '}
                <span className="text-[#fc2e6bed]">BringMart</span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed mb-8">
                Your go-to home delivery platform for all your daily essentials.
                Bringing convenience and quality right to your doorstep.
              </p>
              <div className="flex items-center space-x-4">
                <div className="bg-[#fc2e6bed] p-3 rounded-full">
                  <ShoppingBag className="w-6 h-6 text-white" />
                </div>
                <span className="text-gray-700 font-medium">Simplifying your shopping experience</span>
              </div>
            </div>
            <div className="relative">
              <div className="bg-[#fc2e6bed] rounded-3xl p-8 transform rotate-3 shadow-2xl">
                <div className="bg-white rounded-2xl p-6 transform -rotate-3">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-pink-50 p-4 rounded-xl">
                      <Truck className="w-8 h-8 text-[#fc2e6bed] mb-2" />
                      <p className="text-sm font-medium text-gray-700">Fast Delivery</p>
                    </div>
                    <div className="bg-pink-50 p-4 rounded-xl">
                      <Heart className="w-8 h-8 text-[#fc2e6bed] mb-2" />
                      <p className="text-sm font-medium text-gray-700">Quality Products</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="prose prose-lg mx-auto">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
            <p className="text-gray-700 text-lg leading-relaxed mb-6">
              Welcome to <strong className="text-[#fc2e6bed]">BringMart</strong>, your go-to home delivery platform for all your daily essentials. Whether you're looking for fresh groceries, household items, or everyday necessities, we've got you covered. With just a click, your products are delivered right to your doorstep.
            </p>

            <p className="text-gray-700 text-lg leading-relaxed mb-6">
              Our mission is to simplify your shopping experience by bringing the essentials of life to you quickly and efficiently. We understand the value of time, and that's why we are dedicated to making your life easier by offering a seamless, fast, and reliable service. BringMart is here to take care of your needs, allowing you to focus on what truly matters.
            </p>

            <p className="text-gray-700 text-lg leading-relaxed">
              Join us and experience the convenience of having everything you need delivered in no time.
            </p>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose <span className="text-[#fc2e6bed]">BringMart</span>?
            </h2>
            <p className="text-xl text-gray-600">
              We're committed to making your life easier with our exceptional service
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow group">
                <div className="text-[#fc2e6bed] mb-4 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-to-r from-pink-50 to-pink-100 rounded-2xl p-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Ready to Get Started?
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Experience the convenience of BringMart today and let us take care of your daily needs.
            </p>
            <a  href="/" className="bg-[#fc2e6bed] hover:bg-[#e0276a] text-white font-semibold px-8 py-4 rounded-full transition-colors shadow-lg hover:shadow-xl">
              Start Shopping Now
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutUsPage;