import React, { useEffect, useState } from 'react';
import { Shield, Eye, Lock, Users, FileText, Clock, Globe, ChevronDown, ChevronUp, Mail, Phone, MapPin } from 'lucide-react';

const PrivacyPolicyPage = () => {
  const [activeSection, setActiveSection] = useState(1);

  const toggleSection = (sectionId) => {
    setActiveSection(activeSection === sectionId ? null : sectionId);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const sections = [
    {
      id: 1,
      title: "Information We Collect",
      icon: <Eye className="w-5 h-5" />,
      content: [
        {
          subtitle: "Information You Provide Directly",
          items: [
            "Account Information: When you register, we collect your name, email address, phone number, delivery address, and payment details.",
            "Support Requests: Information you provide when you contact our customer support team.",
            "Reviews and Feedback: Any ratings, reviews, or comments you leave on the platform."
          ]
        },
        {
          subtitle: "Information We Collect Automatically",
          items: [
            "Device Information: Details about your device, including the device type, operating system, browser type, and IP address.",
            "Location Information: Precise geolocation data to fulfill orders and estimate delivery times.",
            "Usage Data: Information about how you interact with our app or website, such as pages visited, features used, and time spent."
          ]
        },
        {
          subtitle: "Information from Third Parties",
          items: [
            "Payment Processors: Transaction details when you make purchases through our platform.",
            "Social Media: If you link your BringMart account with a social media platform, we may collect relevant profile information as permitted by that platform."
          ]
        }
      ]
    },
    {
      id: 2,
      title: "How We Use Your Information",
      icon: <FileText className="w-5 h-5" />,
      content: [
        {
          subtitle: "We use the information we collect to provide, enhance, and personalize your experience on the BringMart platform. Specifically, we use your information to:",
          items: [
            "Process Your Orders: Ensure accurate and timely order fulfillment, including delivery to your specified location.",
            "Improve Our Services: Analyze usage trends to enhance the functionality and user experience of our app and website.",
            "Communicate with You: Send order updates, promotional offers, service announcements, and respond to your inquiries or feedback.",
            "Ensure Security: Protect your account and our platform against fraud, unauthorized access, and other security threats.",
            "Personalize Your Experience: Provide recommendations and tailored content based on your preferences and previous interactions.",
            "Comply with Legal Obligations: Adhere to applicable laws, regulations, and legal processes, including responding to government or legal requests."
          ]
        }
      ]
    },
    {
      id: 3,
      title: "How We Share Your Information",
      icon: <Users className="w-5 h-5" />,
      content: [
        {
          subtitle: "We value your privacy and only share your information in ways that are necessary to operate and enhance our services. Specifically, we may share your information with:",
          items: [
            "Service Providers: Third-party vendors, such as delivery partners, payment processors, and customer support providers, who help us deliver products and services to you.",
            "Business Partners: Collaborators who assist us in offering promotions, discounts, or co-branded services, subject to applicable data protection laws.",
            "Legal and Regulatory Authorities: When required to comply with applicable laws, legal processes, or government requests, or to protect the rights, safety, and property of BringMart, its users, or the public.",
            "Corporate Transactions: In the event of a merger, acquisition, or sale of all or part of our business, your information may be transferred as part of that transaction."
          ]
        }
      ]
    },
    {
      id: 4,
      title: "Your Choices and Rights",
      icon: <Shield className="w-5 h-5" />,
      content: [
        {
          subtitle: "At BringMart, we believe in empowering you to make informed decisions about your personal information. You have the following choices and rights regarding your data:",
          items: [
            "Access and Review: You can request access to the personal information we hold about you and review it for accuracy.",
            "Update or Correct: You have the right to update or correct any inaccuracies in your personal information through your account settings or by contacting us.",
            "Delete Your Information: You can request the deletion of your personal information, subject to legal and operational requirements, by reaching out to us via the provided contact details.",
            "Manage Marketing Preferences: You can opt out of receiving promotional communications by updating your preferences in your account settings or by following the unsubscribe instructions included in our communications.",
            "Restrict Processing: In certain situations, you may request to restrict the processing of your personal information, such as if you contest its accuracy or object to its processing.",
            "Data Portability: You have the right to request a copy of your personal information in a portable format, where technically feasible.",
            "Withdraw Consent: If we process your personal information based on your consent, you can withdraw that consent at any time, though this may affect your ability to use certain features of our platform.",
            "Lodge a Complaint: If you believe we have violated your rights, you have the right to lodge a complaint with a relevant data protection authority."
          ]
        }
      ]
    },
    {
      id: 5,
      title: "Data Retention",
      icon: <Clock className="w-5 h-5" />,
      content: [
        {
          subtitle: "At BringMart, we retain your personal information only for as long as necessary to fulfill the purposes outlined in this Privacy Policy. The specific retention period for your data depends on factors such as the type of information, the purpose for which it was collected, and applicable legal or regulatory requirements.",
          items: [
            "Account Information: We retain your account information as long as your account is active. If you choose to deactivate or delete your account, we will retain your information only to the extent necessary to comply with legal obligations or for legitimate business purposes.",
            "Transaction Records: Information related to purchases, deliveries, and payments may be retained for audit, tax, and accounting purposes for the duration required by law.",
            "Marketing Preferences: We retain your preferences and opt-out requests to ensure we respect your choices in future communications."
          ]
        }
      ]
    },
    {
      id: 6,
      title: "Security of Your Information",
      icon: <Lock className="w-5 h-5" />,
      content: [
        {
          subtitle: "At BringMart, the security of your personal information is a top priority. We implement a variety of industry-standard security measures to protect your data from unauthorized access, disclosure, alteration, or destruction.",
          items: [
            "We use secure encryption protocols, firewalls, access controls, and regular security assessments to ensure that your data remains safe at all times.",
            "While we strive to use commercially acceptable means to protect your personal information, no method of transmission over the internet or method of electronic storage is 100% secure.",
            "We continuously monitor our systems for vulnerabilities and potential threats and take immediate action to address any issues.",
            "We encourage you to protect your account credentials, avoid sharing sensitive information over unsecured networks, and contact us immediately if you suspect any unauthorized activity on your account."
          ]
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Professional Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <nav className="flex items-center text-sm" aria-label="Breadcrumb">
            <a href="#" className="text-gray-500 hover:text-[#fc2e6b] transition-colors font-medium">
              Home
            </a>
            <span className="mx-3 text-gray-300">/</span>
            <span className="text-[#fc2e6b] font-semibold">Privacy Policy</span>
          </nav>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-white border-b">
        <div className="max-w-6xl mx-auto px-6 py-16 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#fc2e6b] to-[#e91e63] rounded-2xl mb-8 shadow-lg">
            <Shield className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
            Privacy Policy
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Your privacy is fundamental to how we operate. This policy explains how we collect, use, and protect your personal information when you use BringMart.
          </p>
          <div className="mt-8 text-sm text-gray-500">
            Last updated: January 2025
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-16">

        {/* Introduction Card */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mb-12">
          <div className="flex items-start space-x-4">
            <div className="w-6 h-6 bg-[#fc2e6b] rounded-full flex-shrink-0 mt-1"></div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Agreement to Terms</h3>
              <p className="text-gray-700 leading-relaxed">
                By accessing or using BringMart, you agree to the terms described in this policy. We are committed to protecting your personal information and being transparent about our data practices.
              </p>
            </div>
          </div>
        </div>

        {/* Main Sections */}
        <div className="space-y-4">
          {sections.map((section) => (
            <div key={section.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <button
                onClick={() => toggleSection(section.id)}
                className="w-full px-8 py-6 flex items-center justify-between hover:bg-gray-50 transition-all duration-200 group"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-[#fc2e6b]/10 to-[#e91e63]/10 rounded-lg flex items-center justify-center group-hover:from-[#fc2e6b]/20 group-hover:to-[#e91e63]/20 transition-all duration-200">
                    <div className="text-[#fc2e6b]">{section.icon}</div>
                  </div>
                  <h2 className="text-xl font-semibold text-gray-900 text-left">{section.title}</h2>
                </div>
                <div className="text-[#fc2e6b] transition-transform duration-200">
                  {activeSection === section.id ?
                    <ChevronUp className="w-5 h-5" /> :
                    <ChevronDown className="w-5 h-5" />
                  }
                </div>
              </button>

              {activeSection === section.id && (
                <div className="px-8 pb-8 border-t border-gray-100 bg-gray-50/30">
                  <div className="pt-8 space-y-8">
                    {section.content.map((contentBlock, index) => (
                      <div key={index}>
                        {contentBlock.subtitle && (
                          <h4 className="text-gray-900 font-medium mb-6 leading-relaxed text-base">
                            {contentBlock.subtitle}
                          </h4>
                        )}
                        <div className="space-y-4">
                          {contentBlock.items.map((item, itemIndex) => (
                            <div key={itemIndex} className="flex items-start space-x-4">
                              <div className="w-1.5 h-1.5 bg-[#fc2e6b] rounded-full mt-2.5 flex-shrink-0"></div>
                              <p className="text-gray-700 leading-relaxed text-sm">{item}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Additional Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-16">

          {/* Children's Privacy */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500/10 to-blue-600/10 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900">Children's Privacy</h3>
            </div>
            <p className="text-gray-700 leading-relaxed">
              BringMart is not intended for use by individuals under the age of 13. We do not knowingly collect or solicit personal information from children under 13 without verifiable parental consent.
            </p>
          </div>

          {/* International Users */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-green-500/10 to-green-600/10 rounded-lg flex items-center justify-center">
                <Globe className="w-5 h-5 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900">International Users</h3>
            </div>
            <p className="text-gray-700 leading-relaxed">
              If you are accessing our platform from outside our primary region, please be aware that your information may be transferred to, stored, and processed in a country where data protection laws may differ.
            </p>
          </div>
        </div>

        {/* Policy Updates */}
        <div className="bg-gradient-to-r from-[#fc2e6b] to-[#e91e63] rounded-xl shadow-lg p-10 text-white mt-16">
          <div className="text-center max-w-4xl mx-auto">
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <FileText className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold mb-6">Changes to This Privacy Policy</h3>
            <p className="text-white/90 mb-8 text-lg leading-relaxed">
              We reserve the right to update or modify this Privacy Policy at any time to reflect changes in our practices, technology, or legal requirements. We will notify you of significant changes through appropriate channels.
            </p>
            <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
              <p className="text-white/80 text-sm">
                By continuing to use our services after changes are made, you acknowledge and agree to the updated Privacy Policy.
              </p>
            </div>
          </div>
        </div>

        {/* Contact Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 mt-16 overflow-hidden">
          <div className="bg-gradient-to-r from-gray-50 to-gray-100 px-8 py-6 border-b border-gray-200">
            <h3 className="text-2xl font-bold text-gray-900">Questions About This Policy?</h3>
            <p className="text-gray-600 mt-2">
              If you have any questions about this Privacy Policy or our data practices, please don't hesitate to contact us.
            </p>
          </div>

          <div className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

              {/* Email Contact */}
              <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-[#fc2e6b]/10 to-[#e91e63]/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-6 h-6 text-[#fc2e6b]" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Email Support</h4>
                <a
                  href="mailto:support@bringmart.in"
                  className="text-[#fc2e6b] hover:text-[#e91e63] transition-colors font-medium"
                >
                  support@bringmart.in
                </a>
              </div>

              {/* Phone Contact */}
              <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500/10 to-blue-600/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Phone className="w-6 h-6 text-blue-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Phone Support</h4>
                <a href="tel:06574022692" className="text-gray-600">
                  0657-4022692
                </a>

              </div>

              {/* Address */}
              <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-green-500/10 to-green-600/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-6 h-6 text-green-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Office Address</h4>
                <address className="text-gray-600 not-italic leading-relaxed">
                  <strong className="text-gray-800">BringMart Ecommerce Private Limited</strong><br />
                  H.NO.34, Jeeta Singh Bagan,<br />
                  Namda basti, Golmuri,<br />
                  East Singhbhum, Jamshedpur<br />
                  Jharkhand, India - 831003
                </address>
              </div>
            </div>

            <div className="mt-8 text-center">
              <a
                href="mailto:privacy@bringmart.in"
                className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-[#fc2e6b] to-[#e91e63] text-white font-semibold rounded-lg hover:from-[#e91e63] hover:to-[#d81b60] transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                <Mail className="w-5 h-5 mr-2" />
                Contact Privacy Team
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicyPage;