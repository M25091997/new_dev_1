import React, { useEffect, useState } from 'react';
import { FileText, Eye, Lock, Users, Shield, Clock, Globe, ChevronDown, ChevronUp, Scale, AlertTriangle, Building2, Calendar, Mail } from 'lucide-react';

const TermsConditionsPage = () => {
  const [activeSection, setActiveSection] = useState(null);

  const toggleSection = (sectionId) => {
    setActiveSection(activeSection === sectionId ? null : sectionId);
  };

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const sections = [
    {
      id: 1,
      title: "Acceptance of Terms",
      icon: <FileText className="w-5 h-5" />,
      content: [
        {
          subtitle: "By accessing and using BringMart's services, you acknowledge that you have read, understood, and agree to be bound by these Terms and Conditions.",
          items: [
            "These terms constitute a legally binding agreement between you and BringMart Ecommerce Private Limited.",
            "If you do not agree with any part of these terms, you must discontinue use of our services immediately.",
            "Your continued use of our platform constitutes acceptance of any updates or modifications to these terms.",
            "You must be at least 18 years old or have parental/guardian consent to use our services.",
            "By creating an account, you represent that all information provided is accurate and complete."
          ]
        }
      ]
    },
    {
      id: 2,
      title: "User Account and Registration",
      icon: <Users className="w-5 h-5" />,
      content: [
        {
          subtitle: "Account Creation and Management",
          items: [
            "You must provide accurate, current, and complete information during registration.",
            "You are responsible for maintaining the confidentiality of your account credentials.",
            "You must notify us immediately of any unauthorized use of your account.",
            "We reserve the right to suspend or terminate accounts that violate these terms.",
            "One person may maintain only one active account unless specifically authorized."
          ]
        },
        {
          subtitle: "Account Security",
          items: [
            "You are solely responsible for all activities that occur under your account.",
            "Use strong passwords and enable two-factor authentication when available.",
            "Do not share your login credentials with third parties.",
            "Report any security breaches or suspicious activity immediately."
          ]
        }
      ]
    },
    {
      id: 3,
      title: "Product Information and Pricing",
      icon: <Eye className="w-5 h-5" />,
      content: [
        {
          subtitle: "Product Accuracy and Availability",
          items: [
            "We strive to provide accurate product descriptions, images, and pricing information.",
            "Product availability is subject to change without notice.",
            "We reserve the right to correct any errors in product information or pricing.",
            "Colors and images may vary slightly due to display settings and photography.",
            "We do not guarantee that all products will be available at all times."
          ]
        },
        {
          subtitle: "Pricing and Payment",
          items: [
            "All prices are listed in Indian Rupees (INR) and include applicable taxes unless stated otherwise.",
            "Prices may change without prior notice, but confirmed orders will honor the original price.",
            "Delivery charges, if applicable, will be clearly displayed before order confirmation.",
            "Payment must be completed at the time of order placement for most payment methods.",
            "We accept various payment methods as displayed on our platform during checkout."
          ]
        }
      ]
    },
    {
      id: 4,
      title: "Order Processing and Fulfillment",
      icon: <Clock className="w-5 h-5" />,
      content: [
        {
          subtitle: "Order Confirmation and Processing",
          items: [
            "Order confirmation does not guarantee product availability or delivery.",
            "We reserve the right to cancel orders due to product unavailability, pricing errors, or other legitimate reasons.",
            "Orders are processed in the sequence they are received, subject to product availability.",
            "Bulk orders may require additional verification and processing time.",
            "Special requests or customizations are accommodated when possible but not guaranteed."
          ]
        },
        {
          subtitle: "Delivery Terms",
          items: [
            "Delivery timeframes are estimates and may vary due to factors beyond our control.",
            "You must provide accurate delivery address and contact information.",
            "Someone must be available to receive the delivery during the scheduled time.",
            "Delivery attempts will be made as per our delivery policy.",
            "Additional charges may apply for special delivery requests or remote locations."
          ]
        }
      ]
    },
    {
      id: 5,
      title: "User Conduct and Prohibited Activities",
      icon: <Shield className="w-5 h-5" />,
      content: [
        {
          subtitle: "Acceptable Use",
          items: [
            "Use our services only for lawful purposes and in accordance with these terms.",
            "Respect other users and our staff in all interactions.",
            "Provide honest and accurate reviews and feedback.",
            "Do not attempt to circumvent security measures or access unauthorized areas.",
            "Report any bugs, errors, or suspicious activities to our support team."
          ]
        },
        {
          subtitle: "Prohibited Activities",
          items: [
            "Creating multiple accounts to abuse promotions or circumvent restrictions.",
            "Using automated systems or bots to access our services.",
            "Attempting to reverse engineer, modify, or hack our platform.",
            "Posting false, misleading, or defamatory content.",
            "Engaging in any activity that could harm our reputation or operations.",
            "Violating any applicable laws or regulations while using our services."
          ]
        }
      ]
    },
    {
      id: 6,
      title: "Intellectual Property Rights",
      icon: <Lock className="w-5 h-5" />,
      content: [
        {
          subtitle: "Our Intellectual Property",
          items: [
            "All content, trademarks, logos, and intellectual property on our platform belong to BringMart or our licensors.",
            "You may not copy, reproduce, distribute, or create derivative works without written permission.",
            "Our brand name, logo, and design elements are protected trademarks.",
            "Product images and descriptions may be subject to third-party intellectual property rights.",
            "Any unauthorized use of our intellectual property may result in legal action."
          ]
        },
        {
          subtitle: "User-Generated Content",
          items: [
            "You retain ownership of content you create, but grant us rights to use it for our services.",
            "You are responsible for ensuring your content does not infringe on third-party rights.",
            "We may remove or modify user-generated content that violates these terms.",
            "Reviews and ratings become part of our platform and may be used for promotional purposes."
          ]
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Professional Header */}
      <div className="bg-white border-b-2 border-gray-100">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <nav className="flex items-center text-sm" aria-label="Breadcrumb">
            <ol className="flex items-center space-x-2">
              <li>
                <a href="#" className="text-gray-500 hover:text-[#fc2e6b] transition-colors">
                  Home
                </a>
              </li>
              <li className="text-gray-300">•</li>
              <li>
                <span className="text-[#fc2e6b] font-medium">Terms & Conditions</span>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Professional Hero Section */}
      <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
        <div className="max-w-6xl mx-auto px-6 py-16 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-[#fc2e6b] rounded-full mb-6">
            <Scale className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Terms & Conditions
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Legal agreement governing the use of BringMart services and platform
          </p>
          <div className="flex items-center justify-center mt-8 space-x-6 text-sm text-gray-400">
            <div className="flex items-center">
              <Calendar className="w-4 h-4 mr-2" />
              Last Updated: January 2025
            </div>
            <div className="flex items-center">
              <Building2 className="w-4 h-4 mr-2" />
              BringMart Ecommerce Pvt. Ltd.
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12">
        {/* Executive Summary */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-10">
          <div className="flex items-start space-x-4">
            <div className="bg-amber-100 p-3 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Executive Summary</h2>
              <p className="text-gray-700 leading-relaxed text-lg mb-4">
                These Terms and Conditions constitute a legally binding agreement between you and BringMart Ecommerce Private Limited. 
                By accessing or using our services, you agree to comply with and be bound by these terms.
              </p>
              <p className="text-gray-600 leading-relaxed">
                If you do not agree with any part of these terms, you must discontinue use of our services immediately. 
                Please read these terms carefully before proceeding.
              </p>
            </div>
          </div>
        </div>

        {/* Terms Sections */}
        <div className="space-y-4">
          {sections.map((section) => (
            <div key={section.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <button
                onClick={() => toggleSection(section.id)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition-colors group"
              >
                <div className="flex items-center space-x-4">
                  <div className="bg-gray-100 group-hover:bg-[#fc2e6b]/10 p-3 rounded-lg transition-colors">
                    <div className="text-gray-600 group-hover:text-[#fc2e6b] transition-colors">
                      {section.icon}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">{section.title}</h3>
                    <p className="text-sm text-gray-500 mt-1">Section {section.id}</p>
                  </div>
                </div>
                <div className="text-gray-400 group-hover:text-[#fc2e6b] transition-colors">
                  {activeSection === section.id ? 
                    <ChevronUp className="w-5 h-5" /> : 
                    <ChevronDown className="w-5 h-5" />
                  }
                </div>
              </button>

              {activeSection === section.id && (
                <div className="border-t border-gray-200 bg-gray-50">
                  <div className="p-6 space-y-8">
                    {section.content.map((contentBlock, index) => (
                      <div key={index}>
                        {contentBlock.subtitle && (
                          <div className="mb-6">
                            <h4 className="text-lg font-semibold text-gray-900 mb-3">
                              {contentBlock.subtitle}
                            </h4>
                          </div>
                        )}
                        <div className="space-y-4">
                          {contentBlock.items.map((item, itemIndex) => (
                            <div key={itemIndex} className="flex items-start space-x-4 p-4 bg-white rounded-lg border border-gray-100">
                              <div className="flex-shrink-0 w-6 h-6 bg-[#fc2e6b]/10 rounded-full flex items-center justify-center mt-0.5">
                                <div className="w-2 h-2 bg-[#fc2e6b] rounded-full"></div>
                              </div>
                              <p className="text-gray-700 leading-relaxed">{item}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Legal Information Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Shield className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Limitation of Liability</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">
              BringMart's liability is limited to the maximum extent permitted by applicable law. We shall not be liable 
              for any indirect, incidental, special, or consequential damages arising from your use of our services.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-green-100 p-2 rounded-lg">
                <Globe className="w-5 h-5 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Governing Law</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">
              These terms are governed by and construed in accordance with the laws of India. Any legal disputes 
              shall be subject to the exclusive jurisdiction of courts in Jamshedpur, Jharkhand.
            </p>
          </div>
        </div>

        {/* Terms Updates Notice */}
        <div className="bg-[#fc2e6b] rounded-lg shadow-lg p-8 text-white mt-12">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-6">
              <FileText className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold mb-4">Amendments to Terms</h3>
            <p className="text-white/90 mb-6 max-w-3xl mx-auto leading-relaxed">
              We reserve the right to modify these Terms and Conditions at any time. Material changes will be 
              communicated through appropriate channels including email notifications and platform announcements.
            </p>
            <div className="inline-flex items-center bg-white/10 rounded-lg px-4 py-2">
              <Calendar className="w-4 h-4 mr-2" />
              <span className="text-sm font-medium">Review these terms periodically for updates</span>
            </div>
          </div>
        </div>

        {/* Professional Contact Section */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mt-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Legal Inquiries</h3>
            <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
              For questions regarding these Terms and Conditions, intellectual property matters, or other legal concerns, 
              please contact our legal department.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <a
                href="mailto:legal@bringmart.in"
                className="inline-flex items-center bg-[#fc2e6b] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#e91e63] transition-colors shadow-sm"
              >
                <Mail className="w-4 h-4 mr-2" />
                legal@bringmart.in
              </a>
              <div className="flex items-center text-gray-500 text-sm">
                <Building2 className="w-4 h-4 mr-2" />
                BringMart Ecommerce Private Limited
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsConditionsPage;