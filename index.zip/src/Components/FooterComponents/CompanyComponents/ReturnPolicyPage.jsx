import React, { useEffect, useState } from 'react';
import { RefreshCw, Package, Clock, Shield, CheckCircle, XCircle, AlertTriangle, ChevronDown, ChevronUp, Truck, CreditCard, FileText, Phone, Mail, Info } from 'lucide-react';

const ReturnPolicyPage = () => {
  const [activeSection, setActiveSection] = useState(null);

  const toggleSection = (sectionId) => {
    setActiveSection(activeSection === sectionId ? null : sectionId);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const sections = [
    {
      id: 1,
      title: "Return Policy Overview",
      icon: <RefreshCw className="w-5 h-5" />,
      content: [
        {
          subtitle: "General Return Guidelines",
          items: [
            "Returns are accepted within 24 hours of delivery for grocery items, and within 7 days for other eligible products, provided they are in original condition.",
            "All returned items must be unopened, unused, and in their original packaging with all tags and labels intact.",
            "Proof of purchase (order confirmation or receipt) is required for all returns.",
            "Items must be returned in the same condition as received, including all accessories and documentation.",
            "Perishable items, personal care products, and customized items are generally non-returnable for hygiene and safety reasons."
          ]
        },
        {
          subtitle: "Return Process",
          items: [
            "Contact our customer support team within 7 days of delivery to initiate a return request.",
            "Provide your order number, item details, and reason for return.",
            "Our team will guide you through the return process and provide return instructions.",
            "Pack the item securely in its original packaging and arrange for pickup or drop-off as instructed.",
            "Refunds will be processed within 5-7 business days after we receive and inspect the returned item."
          ]
        }
      ]
    },
    {
      id: 2,
      title: "Exchange Policy",
      icon: <Package className="w-5 h-5" />,
      content: [
        {
          subtitle: "Exchange Eligibility",
          items: [
            "Exchanges are available for items that are damaged, defective, or incorrect at the time of delivery.",
            "Size or variant exchanges may be accommodated subject to availability and within 7 days of delivery.",
            "The replacement item must be of equal or lesser value than the original purchase.",
            "Exchange requests must be initiated within 7 days of receiving the original item.",
            "Items being exchanged must meet the same condition requirements as returns."
          ]
        },
        {
          subtitle: "Exchange Process",
          items: [
            "Contact customer support immediately if you receive a damaged, defective, or incorrect item.",
            "Provide clear photos of the issue and your order details for faster processing.",
            "We will arrange for pickup of the original item and delivery of the replacement simultaneously when possible.",
            "If immediate replacement is not available, we will process a refund and you can place a new order.",
            "No additional charges apply for exchanges due to our error or defective products.",            
            "Replacement/Exchange product will be delivered in 5-7 business days.",
          ]
        }
      ]
    },
    {
      id: 3,
      title: "Refund Information",
      icon: <CreditCard className="w-5 h-5" />,
      content: [
        {
          subtitle: "Refund Processing",
          items: [
            "Refunds are processed to the original payment method used for the purchase.",
            "Processing time varies by payment method: Credit/Debit cards (5-7 business days), Digital wallets (3-5 business days).",
            "Refund amount will include the item cost but may exclude delivery charges unless the return is due to our error.",
            "Partial refunds may apply if items are returned in used or damaged condition at our discretion.",
            "You will receive an email confirmation once your refund has been processed.",
            "refund will be credited to the original payment method within 5-7 business days"
          ]
        },
        {
          subtitle: "Refund Exceptions",
          items: [
            "Delivery charges are refundable only if the return is due to damaged, defective, or incorrect items.",
            "Processing fees, if any, are non-refundable unless the return is due to our error.",
            "Promotional discounts and coupon values are adjusted proportionally in partial refunds.",
          ]
        }
      ]
    },
    {
      id: 4,
      title: "Non-Returnable Items",
      icon: <XCircle className="w-5 h-5" />,
      content: [
        {
          subtitle: "Items That Cannot Be Returned",
          items: [
            "Perishable goods including fresh fruits, vegetables, dairy products, meat, and bakery items.",
            "Personal care and hygiene products including cosmetics, toiletries, and health supplements once opened.",
            "Prescription medicines and medical devices for safety and regulatory compliance.",
            "Digital products, gift cards, and downloadable content.",
            "Items damaged due to misuse, normal wear and tear, or customer negligence.",
            "Customized or personalized products made specifically for the customer."
          ]
        },
        {
          subtitle: "Special Conditions",
          items: [
            "Electrical appliances may have specific return conditions based on manufacturer warranty terms.",
            "Bulk orders or wholesale purchases may have different return policies communicated at the time of purchase.",
            "Items purchased during special sales or clearance events may have modified return terms.",
            "International orders may have additional restrictions based on customs and shipping regulations."
          ]
        }
      ]
    },
    {
      id: 5,
      title: "Quality Guarantee",
      icon: <Shield className="w-5 h-5" />,
      content: [
        {
          subtitle: "Our Commitment to Quality",
          items: [
            "We guarantee the freshness and quality of all perishable items at the time of delivery.",
            "If you receive damaged or spoiled perishable items, contact us immediately for a replacement or refund.",
            "All products are carefully inspected before dispatch to ensure they meet our quality standards.",
            "We work with trusted suppliers and maintain proper storage conditions to preserve product quality.",
            "Quality issues reported within 24 hours of delivery will be prioritized for immediate resolution."
          ]
        },
        {
          subtitle: "Damaged or Defective Items",
          items: [
            "Report damaged or defective items immediately upon delivery for fastest resolution.",
            "Provide clear photos of the damage or defect to expedite the resolution process.",
            "We will arrange immediate replacement or full refund for items damaged during transit.",
            "Manufacturing defects are covered under our quality guarantee and manufacturer warranty terms.",
            "No questions asked replacement for items that don't meet our quality standards."
          ]
        }
      ]
    },
    {
      id: 6,
      title: "How to Initiate Returns/Exchanges",
      icon: <FileText className="w-5 h-5" />,
      content: [
        {
          subtitle: "Contact Methods",
          items: [
            "Call our customer support hotline during business hours for immediate assistance.",
            "Use the 'Return/Exchange' option in your account dashboard for self-service requests.",
            "Email our support team with your order details and return/exchange request.",
            "Use the live chat feature on our website or app for real-time support.",
            "Visit our help center for step-by-step guides and frequently asked questions."
          ]
        },
        {
          subtitle: "Required Information",
          items: [
            "Order number and purchase date for verification.",
            "Item details including product name, quantity, and batch number if applicable.",
            "Clear description of the issue or reason for return/exchange.",
            "Photos of the product and packaging if reporting damage or defects.",
            "Preferred resolution (refund, exchange, or store credit) and contact information for updates."
          ]
        }
      ]
    }
  ];

  const quickStats = [
    { icon: <Clock className="w-6 h-6" />, number: "7 Days", label: "Return Window", description: "For most products" },
    { icon: <Truck className="w-6 h-6" />, number: "Free", label: "Return Pickup", description: "No additional cost" },
    { icon: <CreditCard className="w-6 h-6" />, number: "5-7 Days", label: "Refund Processing", description: "After inspection" },
    { icon: <CheckCircle className="w-6 h-6" />, number: "100%", label: "Quality Guarantee", description: "Your satisfaction" }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Professional Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Breadcrumbs */}
          <nav className="flex py-4" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <a href="#" className="text-gray-500 hover:text-[#fc2e6b] transition-colors text-sm">
                  Home
                </a>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <span className="text-[#fc2e6b] font-medium text-sm">Return & Exchange Policy</span>
                </div>
              </li>
            </ol>
          </nav>
          
          {/* Professional Title Section */}
          <div className="py-12 text-center">
            <div className="max-w-3xl mx-auto">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">Return & Exchange Policy</h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Clear guidelines for hassle-free returns and exchanges
              </p>
              <div className="mt-6 inline-flex items-center px-4 py-2 bg-blue-50 text-blue-700 rounded-full text-sm font-medium">
                <Info className="w-4 h-4 mr-2" />
                Last updated: January 2025
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Key Metrics Section */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {quickStats.map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-[#fc2e6b]/10 text-[#fc2e6b] rounded-lg mb-4 group-hover:bg-[#fc2e6b] group-hover:text-white transition-all duration-300">
                  {stat.icon}
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">
                  {stat.number}
                </div>
                <div className="text-gray-900 font-medium mb-1">
                  {stat.label}
                </div>
                <div className="text-sm text-gray-500">
                  {stat.description}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Executive Summary */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0">
              <div className="w-10 h-10 bg-[#fc2e6b]/10 rounded-lg flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-[#fc2e6b]" />
              </div>
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">Policy Overview</h2>
              <p className="text-gray-700 leading-relaxed">
                At BringMart, we are committed to ensuring customer satisfaction through transparent and fair return and exchange policies. 
                This document outlines our comprehensive guidelines for product returns, exchanges, and refunds to help you understand 
                your rights and our procedures.
              </p>
            </div>
          </div>
        </div>

        {/* Main Policy Sections */}
        <div className="space-y-4">
          {sections.map((section) => (
            <div key={section.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <button
                onClick={() => toggleSection(section.id)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition-colors focus:outline-none focus:ring-2 focus:ring-[#fc2e6b] focus:ring-inset"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-[#fc2e6b]/10 rounded-lg flex items-center justify-center">
                    <div className="text-[#fc2e6b]">{section.icon}</div>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">{section.title}</h3>
                </div>
                <div className="text-gray-400">
                  {activeSection === section.id ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </button>

              {activeSection === section.id && (
                <div className="border-t border-gray-100">
                  <div className="p-6 space-y-6">
                    {section.content.map((contentBlock, index) => (
                      <div key={index}>
                        {contentBlock.subtitle && (
                          <h4 className="text-base font-semibold text-gray-900 mb-3">
                            {contentBlock.subtitle}
                          </h4>
                        )}
                        <ul className="space-y-2">
                          {contentBlock.items.map((item, itemIndex) => (
                            <li key={itemIndex} className="flex items-start space-x-3">
                              <div className="flex-shrink-0 w-1.5 h-1.5 bg-[#fc2e6b] rounded-full mt-2"></div>
                              <p className="text-gray-700 text-sm leading-relaxed">{item}</p>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Support & Contact Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-12">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-[#fc2e6b]/10 rounded-lg flex items-center justify-center">
                <Phone className="w-4 h-4 text-[#fc2e6b]" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Customer Support</h3>
            </div>
            <p className="text-gray-600 text-sm mb-4">
              Our dedicated support team is available to assist you with returns and exchanges.
            </p>
            <div className="space-y-3">
              <div className="flex items-center space-x-3 text-sm">
                <Phone className="w-4 h-4 text-gray-400" />
                <span className="text-gray-700">0657-4022692</span>
              </div>
              <div className="flex items-center space-x-3 text-sm">
                <Mail className="w-4 h-4 text-gray-400" />
                <span className="text-gray-700">support@bringmart.in</span>
              </div>
              <div className="flex items-center space-x-3 text-sm">
                <Clock className="w-4 h-4 text-gray-400" />
                <span className="text-gray-700">10 AM - 6 PM (Mon-Sat)</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-[#fc2e6b]/10 rounded-lg flex items-center justify-center">
                <Info className="w-4 h-4 text-[#fc2e6b]" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Important Notes</h3>
            </div>
            <p className="text-gray-600 text-sm leading-relaxed">
              Special circumstances such as festival seasons, promotional periods, and bulk orders may have 
              modified return policies. Specific terms will be communicated at the time of purchase.
            </p>
          </div>
        </div>

        {/* Policy Updates Notice */}
        <div className="bg-gradient-to-r from-[#fc2e6b] to-[#e91e63] rounded-lg shadow-sm p-8 text-white mt-12">
          <div className="text-center max-w-3xl mx-auto">
            <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <RefreshCw className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-4">Policy Updates</h3>
            <p className="text-white/90 leading-relaxed mb-6">
              We reserve the right to modify this Return & Exchange Policy to reflect changes in our services, 
              legal requirements, or business practices. Customers will be notified of significant changes through 
              appropriate channels.
            </p>
            <p className="text-white/80 text-sm">
              Continued use of our services after policy updates constitutes acceptance of the revised terms.
            </p>
          </div>
        </div>

        {/* Contact CTA */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 text-center mt-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Need Assistance?</h3>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
            Our customer support team is ready to help you with any questions about returns, exchanges, or refunds.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="mailto:support@bringmart.in"
              className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-sm font-medium rounded-lg text-white bg-[#fc2e6b] hover:bg-[#e91e63] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#fc2e6b] transition-colors"
            >
              <Mail className="w-4 h-4 mr-2" />
              Email Support
            </a>
            <a
              href="tel:0657-4022692"
              className="inline-flex items-center justify-center px-6 py-3 border border-gray-300 text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#fc2e6b] transition-colors"
            >
              <Phone className="w-4 h-4 mr-2" />
              Call Support
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReturnPolicyPage;