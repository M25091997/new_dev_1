import React, { useEffect, useState } from 'react';
import { XCircle, Clock, CreditCard, AlertTriangle, CheckCircle, Shield, ChevronDown, ChevronUp, Package, PhoneCall, FileText, Calendar } from 'lucide-react';
import CancellationPolicyImage from '../../../assets/CancellationPolicy.png'

const CancellationPolicyPage = () => {
  const [activeSection, setActiveSection] = useState(null);

  const toggleSection = (sectionId) => {
    setActiveSection(activeSection === sectionId ? null : sectionId);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const sections = [
    {
      id: 1,
      title: "Order Cancellation Timeline",
      icon: <Clock className="w-6 h-6" />,
      content: [
        {
          subtitle: "Before Order Processing",
          items: [
            "Orders can be cancelled free of charge within 1 hour of placement if not yet processed.",
            "Self-service cancellation available through your account dashboard or mobile app.",
            "Automatic cancellation if payment fails or is not completed within 30 minutes of order placement.",
            "No cancellation charges apply for orders cancelled before our team begins processing.",
            "Full refund processed immediately for prepaid orders cancelled within this window."
          ]
        },
        {
          subtitle: "After Order Processing Begins",
          items: [
            "Orders can be cancelled up to 2 hours after placement with potential processing charges.",
            "Cancellation requests must be made through customer support once processing has begun.",
            "Processing charges may apply ranging from ₹20-₹50 depending on order value and preparation stage.",
            "Perishable items and specially prepared orders may not be eligible for cancellation once processing starts.",
            "Partial cancellations possible for multi-item orders if some items haven't been processed yet."
          ]
        },
        {
          subtitle: "After Dispatch",
          items: [
            "Orders cannot be cancelled once dispatched from our fulfillment center.",
            "Dispatched orders must go through our return process if you no longer want the items.",
            "Exception made for damaged or incorrect items received, which can be exchanged immediately.",
            "Return policy applies for dispatched orders with applicable return charges and conditions.",
            "Track your order to know its current status and cancellation eligibility."
          ]
        }
      ]
    },
    {
      id: 2,
      title: "Cancellation Methods",
      icon: <PhoneCall className="w-6 h-6" />,
      content: [
        {
          subtitle: "Self-Service Cancellation",
          items: [
            "Log into your BringMart account and navigate to 'My Orders' section.",
            "Click on the order you wish to cancel and select 'Cancel Order' if available.",
            "Choose cancellation reason from the dropdown menu for our feedback and improvement.",
            "Confirm cancellation and receive immediate confirmation via email and SMS.",
            "Self-service option available only for orders that haven't entered processing stage."
          ]
        },
        {
          subtitle: "Customer Support Cancellation",
          items: [
            "Call our customer support hotline for immediate cancellation assistance.",
            "Use live chat feature on our website or mobile app for real-time cancellation support.",
            "Email cancellation requests with order number and reason to our support team.",
            "WhatsApp support available for quick cancellation requests and confirmations.",
            "Support team can provide detailed information about cancellation charges if applicable."
          ]
        },
        {
          subtitle: "Bulk Order Cancellations",
          items: [
            "Large or wholesale orders may require special cancellation procedures and approval.",
            "Contact our business support team for bulk order cancellation requests.",
            "Cancellation charges for bulk orders may vary based on preparation and processing stage.",
            "Alternative arrangements like order modification or partial cancellation may be offered.",
            "Extended cancellation window possible for bulk orders with advance notice and coordination."
          ]
        }
      ]
    },
    {
      id: 3,
      title: "Refund Process",
      icon: <CreditCard className="w-6 h-6" />,
      content: [
        {
          subtitle: "Refund Timeline",
          items: [
            "Immediate refund processing for orders cancelled within 1 hour of placement.",
            "2-4 business days for refunds to reflect in your account for most payment methods.",
            "Credit/Debit card refunds typically take 5-7 business days depending on your bank.",
            "Digital wallet and UPI refunds are usually processed within 24-48 hours.",
            "Bank transfer refunds may take 3-5 business days to reflect in your account."
          ]
        },
        {
          subtitle: "Refund Amount Calculation",
          items: [
            "Full order amount refunded for cancellations made before processing begins.",
            "Order amount minus applicable cancellation charges for orders cancelled after processing starts.",
            "Delivery charges refunded only if the order was cancelled due to our error or inability to deliver.",
            "Processing fees, if any, are deducted from the refund amount for late cancellations.",
            "Promotional discounts and coupon values are refunded proportionally based on cancelled items."
          ]
        },
        {
          subtitle: "Refund Methods",
          items: [
            "Refunds processed to the original payment method used for the purchase.",
            "Store credit option available for faster refund processing if preferred by customer.",
            "Cash on Delivery orders don't require refund processing as no advance payment was made.",
            "Gift card purchases refunded as store credit that can be used for future orders.",
            "Partial refunds for multi-item orders where only some items are cancelled."
          ]
        }
      ]
    },
    {
      id: 4,
      title: "Non-Cancellable Items",
      icon: <XCircle className="w-6 h-6" />,
      content: [
        {
          subtitle: "Time-Sensitive Products",
          items: [
            "Fresh produce, dairy products, and frozen items cannot be cancelled once processing begins.",
            "Bakery items and specially prepared food products have limited cancellation windows.",
            "Same-day delivery orders may not be cancellable due to immediate processing requirements.",
            "Pre-ordered items for specific delivery dates may have stricter cancellation policies.",
            "Seasonal and festival special items may have modified cancellation terms communicated at purchase."
          ]
        },
        {
          subtitle: "Customized & Personalized Orders",
          items: [
            "Customized products made specifically for the customer cannot be cancelled once production starts.",
            "Personalized items with customer name, message, or specifications are non-cancellable.",
            "Gift wrapping and special packaging requests cannot be cancelled once processing begins.",
            "Bulk orders with specific customer requirements may have limited cancellation options.",
            "Made-to-order items have different cancellation policies communicated at the time of purchase."
          ]
        },
        {
          subtitle: "Special Categories",
          items: [
            "Prescription medicines and health supplements cannot be cancelled for regulatory compliance.",
            "Digital products, gift cards, and vouchers are non-cancellable once delivered or activated.",
            "Items on special promotion or clearance sale may have restricted cancellation policies.",
            "Pre-paid service bookings and appointments have separate cancellation terms.",
            "Items purchased using store credit or promotional offers may have specific cancellation conditions."
          ]
        }
      ]
    },
    {
      id: 5,
      title: "Cancellation Charges",
      icon: <FileText className="w-6 h-6" />,
      content: [
        {
          subtitle: "Charge Structure",
          items: [
            "No cancellation charges for orders cancelled within 1 hour of placement.",
            "₹20-₹50 processing charges may apply for orders cancelled after processing begins.",
            "Percentage-based charges (2-5% of order value) for high-value orders cancelled late.",
            "Flat charges for specific product categories like electronics or appliances.",
            "Bulk order cancellation charges calculated based on preparation stage and order complexity."
          ]
        },
        {
          subtitle: "Waived Charges",
          items: [
            "Cancellation charges waived if the cancellation is due to our error or service failure.",
            "No charges for cancellations due to product unavailability or delivery issues from our end.",
            "Medical emergencies or unforeseen circumstances may qualify for charge waiver at our discretion.",
            "First-time customers may receive one-time waiver of cancellation charges as goodwill gesture.",
            "Premium customers and frequent buyers may have reduced or waived cancellation charges."
          ]
        },
        {
          subtitle: "Charge Calculation",
          items: [
            "Cancellation charges clearly displayed before confirming the cancellation request.",
            "Charges calculated based on order value, processing stage, and product category.",
            "Transparent breakdown provided showing order amount, charges, and final refund amount.",
            "Option to proceed or retain the order after seeing the applicable charges.",
            "Charges deducted from refund amount and detailed in the refund confirmation."
          ]
        }
      ]
    },
    {
      id: 6,
      title: "Special Circumstances",
      icon: <Shield className="w-6 h-6" />,
      content: [
        {
          subtitle: "Emergency Cancellations",
          items: [
            "Medical emergencies, family crises, or unforeseen circumstances considered for flexible cancellation.",
            "Documentation may be required for emergency cancellation requests to waive standard charges.",
            "Compassionate consideration given for genuine emergency situations affecting delivery or receipt.",
            "Emergency contact available 24/7 for urgent cancellation requests due to critical situations.",
            "Special approval process for emergency cancellations with expedited refund processing."
          ]
        },
        {
          subtitle: "Service Disruptions",
          items: [
            "Orders automatically eligible for free cancellation during natural disasters or service disruptions.",
            "System outages or technical issues that prevent order modification allow flexible cancellation.",
            "Strike, bandh, or civil disturbances affecting delivery enable cancellation without charges.",
            "Pandemic or health emergency related restrictions provide extended cancellation windows.",
            "Force majeure events beyond our control allow customers to cancel orders without penalty."
          ]
        },
        {
          subtitle: "Customer Account Issues",
          items: [
            "Account security concerns or unauthorized orders can be cancelled immediately without charges.",
            "Payment disputes or card fraud cases allow for immediate order cancellation and investigation.",
            "Multiple order placement errors due to website issues can be resolved with free cancellation.",
            "Customer dissatisfaction with previous orders may allow flexible cancellation for subsequent orders.",
            "Technical errors in pricing or product description enable free cancellation and order correction."
          ]
        }
      ]
    }
  ];

  const quickStats = [
    { icon: <Clock className="w-8 h-8" />, number: "1 Hour", label: "Free Cancellation" },
    { icon: <CreditCard className="w-8 h-8" />, number: "2-4 Days", label: "Refund Processing" },
    { icon: <PhoneCall className="w-8 h-8" />, number: "24/7", label: "Support Available" },
    { icon: <CheckCircle className="w-8 h-8" />, number: "100%", label: "Refund Guarantee" }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumbs */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <a href="#" className="text-gray-600 hover:text-[#fc2e6b] transition-colors">
                  Home
                </a>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <span className="text-[#fc2e6b] font-medium">Cancellation Policy</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <img src={CancellationPolicyImage} alt="" />
        </div>
      </div>

      {/* Quick Stats */}
      <div className="bg-[#fc2e6b] py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {quickStats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-white mb-4 flex justify-center">
                  {stat.icon}
                </div>
                <div className="text-2xl lg:text-3xl font-bold text-white mb-2">
                  {stat.number}
                </div>
                <div className="text-pink-100 text-lg">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">

        {/* Introduction */}
        <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <AlertTriangle className="w-6 h-6 text-[#fc2e6b]" />
            <h2 className="text-2xl font-bold text-gray-800">Cancellation Guidelines</h2>
          </div>
          <p className="text-gray-700 text-lg leading-relaxed">
            At BringMart, we understand that circumstances can change and you may need to cancel your order. This Cancellation Policy explains our procedures, timelines, charges, and refund process to ensure transparency and help you make informed decisions.
          </p>
        </div>

        {/* Main Sections */}
        <div className="space-y-6">
          {sections.map((section) => (
            <div key={section.id} className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
              <button
                onClick={() => toggleSection(section.id)}
                className="w-full flex items-center justify-between p-6 hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center space-x-4">
                  <div className="bg-[#fc2e6b]/10 p-3 rounded-full">
                    <div className="text-[#fc2e6b]">{section.icon}</div>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-800">{section.title}</h2>
                </div>
                <div className="text-[#fc2e6b]">
                  {activeSection === section.id ? <ChevronUp className="w-6 h-6" /> : <ChevronDown className="w-6 h-6" />}
                </div>
              </button>

              {activeSection === section.id && (
                <div className="px-6 pb-6 border-t border-gray-100">
                  <div className="pt-6 space-y-6">
                    {section.content.map((contentBlock, index) => (
                      <div key={index}>
                        {contentBlock.subtitle && (
                          <p className="text-gray-700 font-medium mb-4 leading-relaxed">
                            {contentBlock.subtitle}
                          </p>
                        )}
                        <ul className="space-y-3">
                          {contentBlock.items.map((item, itemIndex) => (
                            <li key={itemIndex} className="flex items-start space-x-3">
                              <div className="flex-shrink-0 w-2 h-2 bg-[#fc2e6b] rounded-full mt-2"></div>
                              <p className="text-gray-600 leading-relaxed">{item}</p>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Additional Important Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-12">

          {/* Quick Cancellation Guide */}
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-[#fc2e6b]/10 p-2 rounded-full">
                <Package className="w-5 h-5 text-[#fc2e6b]" />
              </div>
              <h3 className="text-xl font-bold text-gray-800">Quick Cancellation</h3>
            </div>
            <p className="text-gray-600 text-sm leading-relaxed mb-4">
              Cancel your order in just a few steps through your account dashboard or by contacting our support team.
            </p>
            <div className="space-y-2">
              <p className="text-sm"><strong>Step 1:</strong> Login to your account</p>
              <p className="text-sm"><strong>Step 2:</strong> Go to 'My Orders'</p>
              <p className="text-sm"><strong>Step 2:</strong> click on 'View Details'</p>
              <p className="text-sm"><strong>Step 3:</strong> Select 'Cancel Order'</p>
              <p className="text-sm"><strong>Step 4:</strong> Confirm cancellation</p>
            </div>
          </div>

          {/* Cancellation Support */}
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-[#fc2e6b]/10 p-2 rounded-full">
                <PhoneCall className="w-5 h-5 text-[#fc2e6b]" />
              </div>
              <h3 className="text-xl font-bold text-gray-800">Cancellation Support</h3>
            </div>
            <p className="text-gray-600 text-sm leading-relaxed mb-4">
              Our customer support team is available 24/7 to help you with order cancellations and refund queries.
            </p>
            <div className="space-y-2">
              <p className="text-sm">
                <strong>Phone:</strong>{" "}
                <a href="tel:06574022692" className="text-sm text-blue-600 hover:underline">0657-4022692</a>
              </p>
              <p className="text-sm">
                <strong>Email:</strong>{" "}
                <a href="mailto:support@bringmart.in" className="text-sm text-blue-600 hover:underline">support@bringmart.in</a>
              </p>
            </div>
          </div>
        </div>

        {/* Refund Guarantee */}
        <div className="bg-gradient-to-br from-[#fc2e6b] to-[#e91e63] rounded-2xl shadow-lg p-8 text-white mt-12">
          <div className="text-center">
            <CheckCircle className="w-12 h-12 text-white mx-auto mb-4" />
            <h3 className="text-2xl font-bold mb-4">100% Refund Guarantee</h3>
            <p className="text-white/90 mb-6 max-w-3xl mx-auto">
              We guarantee full refunds for eligible cancellations processed according to our policy terms.
              Your money is safe with us, and we ensure transparent and timely refund processing for all cancelled orders.
            </p>
            <p className="text-white/80 text-sm">
              All refunds are processed securely and tracked until they reach your account.
            </p>
          </div>
        </div>

        {/* Policy Updates */}
        <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 mt-8">
          <div className="flex items-center space-x-3 mb-4">
            <Calendar className="w-6 h-6 text-[#fc2e6b]" />
            <h3 className="text-2xl font-bold text-gray-800">Policy Updates & Modifications</h3>
          </div>
          <p className="text-gray-700 leading-relaxed mb-4">
            This Cancellation Policy may be updated periodically to reflect changes in our services, payment methods, or business operations.
            Significant changes will be communicated to customers through email notifications and website announcements.
          </p>
          <p className="text-gray-600 text-sm">
            The policy version effective at the time of your order placement will apply to that specific order.
            We encourage customers to review our policies regularly for the most current information.
          </p>
        </div>

        {/* Contact Information */}
        <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 mt-8 text-center">
          <h3 className="text-2xl font-bold text-gray-800 mb-4">Need to Cancel Your Order?</h3>
          <p className="text-gray-600 mb-6">
            Our cancellation support team is ready to assist you with quick and hassle-free order cancellations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="mailto:support@bringmart.in"
              className="inline-block bg-[#fc2e6b] text-white px-8 py-3 rounded-lg font-semibold hover:bg-[#e91e63] transition-colors shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Email Cancellation Team
            </a>
            <a
              href="tel:0657-4022692"
              className="inline-block bg-gray-100 text-gray-800 px-8 py-3 rounded-lg font-semibold hover:bg-gray-200 transition-colors shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Call Support Now
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CancellationPolicyPage;