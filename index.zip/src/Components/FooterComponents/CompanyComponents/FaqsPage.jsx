import React, { useEffect, useState } from 'react';
import { ChevronDown, Search, ShoppingCart, Truck, CreditCard, RotateCcw, Shield, Clock, MapPin, Phone, Mail, MessageCircle, HelpCircle, X } from 'lucide-react';

const FAQsPage = () => {
  const [activeCategory, setActiveCategory] = useState('general');
  const [expandedFAQ, setExpandedFAQ] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const faqCategories = [
    { id: 'general', name: 'General', icon: MessageCircle },
    { id: 'ordering', name: 'Ordering', icon: ShoppingCart },
    { id: 'delivery', name: 'Delivery', icon: Truck },
    { id: 'payment', name: 'Payment', icon: CreditCard },
    { id: 'returns', name: 'Returns & Refunds', icon: RotateCcw },
    { id: 'account', name: 'Account', icon: Shield },
  ];

  const faqData = {
    general: [
      {
        question: "What is BringMart?",
        answer: "BringMart is your trusted online marketplace offering a wide range of products from groceries and electronics to fashion and home essentials. We connect you with local vendors and brands to provide quality products at competitive prices with fast delivery."
      },
      {
        question: "In which cities does BringMart operate?",
        answer: "BringMart proudly operates across all cities in Jharkhand, including Ranchi, Jamshedpur, Dhanbad, Bokaro, Hazaribagh, and more. We're dedicated to expanding our reach and delivering quality service to every corner of the state."
      },
      {
        question: "What are BringMart's operating hours?",
        answer: "Our platform is available 24/7 for browsing and placing orders. Customer support is available from 10:00 AM to 6:00 PM, Monday through Sunday. Delivery timings vary by location and are typically between 7:00 AM to 11:00 PM."
      },
      {
        question: "How can I contact BringMart customer support?",
        answer: "You can reach our customer support team through multiple channels: Call us at 0657-4022692, email us at support@bringmart.in, or use the live chat feature on our website/app. We're here to help!"
      },
      {
        question: "Is BringMart app available for download?",
        answer: "The BringMart app is currently under development and will be available soon on both Android and iOS. Stay tuned for a seamless shopping experience with exclusive app-only deals once it's live!"
      }
    ],
    ordering: [
      {
        question: "How do I place an order on BringMart?",
        answer: "Placing an order is simple: 1) Browse products or search for what you need, 2) Add items to your cart, 3) Select delivery address and time slot, 4) Choose payment method, 5) Review and confirm your order. You'll receive an order confirmation via SMS and email."
      },
      {
        question: "Can I modify or cancel my order after placing it?",
        answer: "You can modify or cancel your order within 15 minutes of placing it, provided it hasn't been picked up by our delivery partner. Go to 'My Orders' section and select 'Cancel Order' or contact customer support for assistance."
      },
      {
        question: "What is the minimum order value?",
        answer: "The minimum order value on BringMart is just ₹10, making it easy and affordable to shop for your daily needs. No high minimums—just great value, every time!"
      },
      {
        question: "How do I track my order?",
        answer: "Once your order is confirmed. You can track your order in real-time through the 'My Orders' section in your account."
      }
    ],
    delivery: [
      {
        question: "What are the delivery charges?",
        answer: "Delivery charges vary by location and order value. Orders above ₹499 qualify for free delivery in most areas. Express delivery (within 2 hours) may have additional charges of ₹49-99 depending on your location."
      },
      {
        question: "How fast is the delivery?",
        answer: "BringMart offers two convenient delivery options: 🚀 Instant Delivery – Get your order delivered within 15 to 30 minutes for eligible products and locations. 🕓 Scheduled Delivery – Choose your preferred delivery date and time slot at checkout. Available Dates: From today to the next 5 days. Available Time Slots: ☀️ 7 AM – 10 AM, 🌤️ 10 AM – 1 PM, ☀️ 1 PM – 4 PM, 🌆 4 PM – 7 PM, 🌙 7 PM – 10 PM."

      },
      {
        question: "Can I schedule my delivery?",
        answer: "Absolutely! BringMart offers Scheduled Delivery where you can choose your preferred date and time slot during checkout. Available dates range from today to the next 5 days. Time slots include: ☀️ 7 AM – 10 AM, 🌤️ 10 AM – 1 PM, ☀️ 1 PM – 4 PM, 🌆 4 PM – 7 PM, and 🌙 7 PM – 10 PM."
      },

      {
        question: "What if I'm not available during delivery?",
        answer: "If you're not available, our delivery partner will attempt to contact you. You can reschedule the delivery or authorize someone else to receive the order. For perishable items, we may need to return them if no one is available."
      },
    ],
    payment: [
      {
        question: "What payment methods do you accept?",
        answer: "We accept all major payment methods including: Credit/Debit Cards (Visa, MasterCard, RuPay), UPI (Google Pay, PhonePe, Paytm), Net Banking, Digital Wallets (Paytm, Mobikwik), and Cash on Delivery (COD) for eligible orders."
      },
      {
        question: "Is it safe to pay online on BringMart?",
        answer: "Yes, absolutely! Your payments are 100% secure. We use trusted payment gateways with SSL encryption, and we never store your payment details."
      },
      {
        question: "Can I pay cash on delivery?",
        answer: "Cash on Delivery (COD) is available for orders of ₹2000 or less, depending on your location. A small handling fee of ₹1–₹12 may apply. COD availability may vary by product and area."

      },
      {
        question: "What if my payment fails?",
        answer: "If your payment fails, the order will be automatically cancelled and any amount debited will be refunded within 3-5 business days. You can retry placing the order with a different payment method."
      },
    ],
    returns: [
      {
        question: "What is your return policy?",
        answer: "We offer easy returns within 7 days of delivery for most products. Items should be unused, in original packaging with tags intact. Perishable items, personal care products, and customized items are not eligible for return."
      },
      {
        question: "How do I return a product?",
        answer: "To return a product: 1) Go to 'My Orders' and select the item, 2) Choose 'Return Item' and select reason, 3) Schedule pickup or drop-off, 4) Our team will collect the item and process your refund once verified."
      },
      {
        question: "When will I get my refund?",
        answer: "Refunds are processed within 24-48 hours of item verification. The amount will be credited to your original payment method within 3-7 business days. For COD orders, refunds are processed to your BringMart wallet or bank account."
      },
      {
        question: "Can I exchange a product instead of returning?",
        answer: "Yes! For fashion and lifestyle products, you can exchange for a different size or color within 7 days. Exchange is subject to availability and price difference (if any) will be adjusted accordingly."
      },
      {
        question: "What if I receive a damaged or wrong product?",
        answer: "If you receive a damaged or incorrect product, report it within 24 hours through our app/website or call customer support. We'll arrange immediate replacement or full refund at no extra cost."
      }
    ],
    account: [
      {
        question: "How do I create a BringMart account?",
        answer: "You can create an account by clicking 'Sign Up' on our website/app. Enter your mobile number, verify with OTP, and complete your profile."
      },
      {
        question: "Can I shop without creating an account?",
        answer: "Yes, you can browse and add items to cart as a guest. However, creating an account helps you track orders, save addresses, access exclusive deals, and enjoy a personalized shopping experience."
      },
      {
        question: "How do I reset my password?",
        answer: "Click on 'Forgot Password' on the login page, enter your registered mobile number or email, and follow the instructions sent via SMS/email to reset your password."
      },
      {
        question: "How can I update my profile information?",
        answer: "Log into your account and go to 'My Profile' section. You can update your name, email, and addresses. Some changes may require verification for security purposes."
      },
      {
        question: "Is my personal information secure?",
        answer: "Absolutely! We follow strict data protection policies and use advanced security measures to protect your personal information. We never share your data with third parties without your consent."
      }
    ]
  };

  const toggleFAQ = (index) => {
    setExpandedFAQ(expandedFAQ === index ? null : index);
  };

  const filteredFAQs = faqData[activeCategory].filter(faq =>
    faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Professional Header Section */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-16">
          <div className="text-center max-w-4xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 rounded-full flex items-center justify-center" style={{ backgroundColor: '#fc2e6bed' }}>
                <HelpCircle className="w-10 h-10 text-white" />
              </div>
            </div>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed mb-8">
              Find answers to common questions about BringMart services, policies, and features.
              Our comprehensive FAQ section is designed to help you quickly resolve any queries.
            </p>
            <div className="flex flex-wrap justify-center gap-6 text-sm text-gray-500">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>Updated Daily</span>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4" />
                <span>24/7 Support Available</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                <span>Secure & Trusted</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Enhanced Search Bar */}
        <div className="max-w-3xl mx-auto mb-12">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-6 flex items-center pointer-events-none">
              <Search className="w-5 h-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search through our knowledge base..."
              className="w-full py-5 pl-14 pr-6 text-gray-800 placeholder-gray-500 bg-white rounded-2xl shadow-lg border border-gray-200 outline-none focus:border-2 focus:shadow-xl transition-all duration-200"
              style={{ '--tw-ring-color': '#fc2e6bed' }}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          {searchQuery && (
            <p className="text-sm text-gray-500 mt-3 text-center">
              Searching for "{searchQuery}" across all categories
            </p>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Enhanced Categories Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden sticky top-8">
              <div className="p-6 border-b border-gray-100">
                <h3 className="font-bold text-xl text-gray-900">Browse by Category</h3>
                <p className="text-sm text-gray-500 mt-1">Select a category to view related questions</p>
              </div>
              <div className="p-4 space-y-2">
                {faqCategories.map((category) => {
                  const IconComponent = category.icon;
                  return (
                    <button
                      key={category.id}
                      onClick={() => setActiveCategory(category.id)}
                      className={`w-full flex items-center gap-4 p-4 rounded-xl text-left transition-all duration-200 group ${activeCategory === category.id
                        ? 'text-white shadow-lg transform scale-105'
                        : 'text-gray-700 hover:bg-gray-50 hover:shadow-md'
                        }`}
                      style={activeCategory === category.id ? { backgroundColor: '#fc2e6bed' } : {}}
                    >
                      <div className={`p-2 rounded-lg ${activeCategory === category.id ? 'bg-white/20' : 'bg-gray-100 group-hover:bg-gray-200'
                        }`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <span className="font-semibold block">{category.name}</span>
                        <span className="text-xs opacity-75">
                          {faqData[category.id].length} questions
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Enhanced FAQ Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
              <div className="p-8 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 rounded-xl" style={{ backgroundColor: '#fc2e6bed20' }}>
                    {React.createElement(faqCategories.find(cat => cat.id === activeCategory)?.icon, {
                      className: "w-6 h-6",
                      style: { color: '#fc2e6bed' }
                    })}
                  </div>
                  <div>
                    <h2 className="text-3xl font-bold text-gray-900">
                      {faqCategories.find(cat => cat.id === activeCategory)?.name}
                    </h2>
                    <p className="text-gray-600 mt-1">
                      {filteredFAQs.length} question{filteredFAQs.length !== 1 ? 's' : ''} available
                    </p>
                  </div>
                </div>
              </div>

              <div className="divide-y divide-gray-100">
                {filteredFAQs.length > 0 ? (
                  filteredFAQs.map((faq, index) => (
                    <div key={index} className="group hover:bg-gray-50 transition-colors duration-200">
                      <button
                        onClick={() => toggleFAQ(index)}
                        className="w-full p-8 flex items-start justify-between text-left"
                      >
                        <div className="flex items-start gap-4 flex-1 pr-4">
                          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center mt-1 group-hover:bg-gray-200 transition-colors duration-200">
                            <span className="text-sm font-semibold text-gray-600">{index + 1}</span>
                          </div>
                          <h3 className="font-semibold text-lg text-gray-900 group-hover:text-gray-700 leading-relaxed">
                            {faq.question}
                          </h3>
                        </div>
                        <div className="flex-shrink-0 ml-4">
                          <ChevronDown
                            className={`w-6 h-6 text-gray-400 transition-all duration-200 ${expandedFAQ === index ? 'rotate-180' : ''
                              }`}
                            style={{ color: expandedFAQ === index ? '#fc2e6bed' : '' }}
                          />
                        </div>
                      </button>

                      <div className={`overflow-hidden transition-all duration-300 ${expandedFAQ === index ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                        }`}>
                        <div className="px-8 pb-8">
                          <div className="ml-12 pl-4 border-l-2 border-gray-200">
                            <p className="text-gray-600 leading-relaxed text-base">
                              {faq.answer}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-16 text-center">
                    <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-6">
                      <Search className="w-10 h-10 text-gray-300" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-3">No matching questions found</h3>
                    <p className="text-gray-500 max-w-md mx-auto">
                      We couldn't find any questions matching your search. Try different keywords or browse our categories.
                    </p>
                    <button
                      onClick={() => setSearchQuery('')}
                      className="mt-6 px-6 py-3 rounded-xl text-white font-semibold hover:shadow-lg transition-all duration-200"
                      style={{ backgroundColor: '#fc2e6bed' }}
                    >
                      Clear Search
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Contact Support Section */}
      <div className="bg-white border-t-2 border-gray-100">
        <div className="max-w-7xl mx-auto px-4 py-16">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Need Additional Support?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Our dedicated customer support team is available to assist you with any questions
              not covered in our FAQ section. Choose your preferred contact method below.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Phone Support */}
            <div className="text-center p-8 rounded-2xl bg-gradient-to-br from-gray-50 to-white border border-gray-200 hover:shadow-xl hover:border-gray-300 transition-all duration-300 group">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-200" style={{ backgroundColor: '#fc2e6bed' }}>
                <Phone className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-xl text-gray-900 mb-3">Phone Support</h3>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Speak directly with our support team for immediate assistance
              </p>
              <div className="space-y-2">
                <p className="text-sm text-gray-500">Available: Mon-Sat, 10:00 AM - 6:00 PM</p>
                <a href="tel:06574022692" className="font-bold text-2xl" style={{ color: '#fc2e6b' }}>
                  0657-4022692
                </a>
                <p className="text-xs text-gray-400">Toll-free number</p>
              </div>
            </div>

            {/* Email Support */}
            <div className="text-center p-8 rounded-2xl bg-gradient-to-br from-gray-50 to-white border border-gray-200 hover:shadow-xl hover:border-gray-300 transition-all duration-300 group">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-200" style={{ backgroundColor: '#fc2e6bed' }}>
                <Mail className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-xl text-gray-900 mb-3">Email Support</h3>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Send us detailed queries and receive comprehensive responses
              </p>
              <div className="space-y-2">
                <p className="text-sm text-gray-500">Response time: Within 24 hours</p>
                <a href="mailto:support@bringmart.in" className="font-bold text-lg" style={{ color: '#fc2e6b' }}>
                  support@bringmart.in
                </a>
                <p className="text-xs text-gray-400">Include your order number for faster assistance</p>
              </div>
            </div>

            {/* Live Chat */}
            <div className="text-center p-8 rounded-2xl bg-gradient-to-br from-gray-50 to-white border border-gray-200 hover:shadow-xl hover:border-gray-300 transition-all duration-300 group">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-200" style={{ backgroundColor: '#fc2e6bed' }}>
                <MessageCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-xl text-gray-900 mb-3">Live Chat</h3>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Get instant help through our real-time chat system
              </p>
              <div className="space-y-4">
                <p className="text-sm text-gray-500">Average response: Under 2 minutes</p>
                <button
                  onClick={openModal}
                  className="px-8 py-3 rounded-xl text-white font-semibold hover:shadow-lg hover:scale-105 transition-all duration-200"
                  style={{ backgroundColor: '#fc2e6bed' }}
                >
                  Start Live Chat
                </button>
                <p className="text-xs text-gray-400">Available 24/7</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Live Chat Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full mx-auto shadow-2xl transform transition-all duration-300 scale-100">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: '#fc2e6bed' }}>
                  <MessageCircle className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Live Chat</h3>
              </div>
              <button
                onClick={closeModal}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-8 text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-orange-100 to-pink-100 flex items-center justify-center mx-auto mb-6">
                <Clock className="w-10 h-10 text-orange-500" />
              </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Coming Soon!
              </h2>

              <p className="text-gray-600 leading-relaxed mb-6">
                We're working hard to bring you an amazing live chat experience. Our real-time chat support will be available very soon to provide you with instant assistance.
              </p>

              <div className="bg-gray-50 rounded-xl p-4 mb-6">
                <h4 className="font-semibold text-gray-900 mb-2">In the meantime, you can:</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Call us at 0657-4022692</li>
                  <li>• Email us at support@bringmart.in</li>
                  <li>• Browse our comprehensive FAQ section</li>
                </ul>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={closeModal}
                  className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-colors duration-200"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    closeModal();
                    window.location.href = 'tel:06574022692';
                  }}
                  className="flex-1 px-6 py-3 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-200"
                  style={{ backgroundColor: '#fc2e6bed' }}
                >
                  Call Now
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FAQsPage;