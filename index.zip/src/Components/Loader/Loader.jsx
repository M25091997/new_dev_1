import { Loader } from "@mantine/core";
const LoaderComponets = () => {
    return <Loader color="orange" size="lg" type="dots" />;
}

export default LoaderComponets;