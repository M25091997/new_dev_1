import { useState } from 'react';
import { Plus, Minus } from 'lucide-react';

const CategoryItem = ({ item, level = 0, selectedCategories, onCategorySelect }) => {
  const [isExpanded, setIsExpanded] = useState(level === 0);
  const hasSubcategories = item.subcategories && item.subcategories.length > 0;

  const handleToggle = (e) => {
    e.stopPropagation();
    setIsExpanded(!isExpanded);
  };

  const handleCheckboxChange = (e) => {
    e.stopPropagation();
    onCategorySelect(item.id);
  };

  return (
    <div className="w-full">
      <div 
        className="flex items-center cursor-pointer py-1"
        onClick={handleToggle}
      >
        <div className="flex items-center" style={{ marginLeft: `${level * 16}px` }}>
          {hasSubcategories && (
            isExpanded ? 
              <Minus className="w-4 h-4 mr-2" /> : 
              <Plus className="w-4 h-4 mr-2" />
          )}
          <input
            type="checkbox"
            checked={selectedCategories[item.id] || false}
            onChange={handleCheckboxChange}
            className="mr-2 rounded"
            onClick={(e) => e.stopPropagation()}
          />
          <span className={level === 0 ? "text-[#fc2e6bed] font-bold" : ""}>
            {item.name}
          </span>
          {item.count && (
            <span className="text-gray-500 text-sm ml-2">({item.count})</span>
          )}
        </div>
      </div>

      {isExpanded && hasSubcategories && (
        <div className="mt-1">
          {item.subcategories.map((subcategory) => (
            <CategoryItem
              key={subcategory.id}
              item={subcategory}
              level={level + 1}
              selectedCategories={selectedCategories}
              onCategorySelect={onCategorySelect}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const CategorySidebar = ({ categories }) => {
  const [selectedCategories, setSelectedCategories] = useState({});

  const handleCategorySelect = (categoryId) => {
    setSelectedCategories(prev => ({
      ...prev,
      [categoryId]: !prev[categoryId]
    }));
  };

  return (
    <div className="w-full p-4 rounded-lg shadow-sm">
      <h2 className="text-lg font-semibold mb-4">Category</h2>
      {categories.map((category) => (
        <CategoryItem
          key={category.id}
          item={category}
          selectedCategories={selectedCategories}
          onCategorySelect={handleCategorySelect}
        />
      ))}
    </div>
  );
};

export default CategorySidebar;