import {
    Facebook,
    Instagram,
    Linkedin,
    Twitter,
    Mail,
    Phone,
    MapPin,
    Download,
    ChevronDown,
    ChevronUp,
    X,
    Smartphone,
    Bell,
    Calendar
} from "lucide-react"
import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useSelector } from "react-redux"

const Footer = () => {
    const [expandedSections, setExpandedSections] = useState({})
    const [showAppModal, setShowAppModal] = useState(false)
    const navigate = useNavigate()
    const shop = useSelector((state) => state.shop?.shop)
    const categories = shop?.categories || []

    // Map footer links to their corresponding routes
    const getRouteForLink = (link) => {
        const linkMap = {
            "About us": "/about-us",
            FAQs: "/faqs",
            "Contact us": "/contact-us",
            "Terms and Conditions": "/terms-and-conditions",
            "Privacy Policy": "/privacy-policy",
            "Return and Exchange Policy": "/return-policy",
            "Shipping Policy": "/shipping-policy",
            "Cancellation Policy": "/cancellation-policy",
        }
        return linkMap[link] || "#"
    }

    const toggleSection = (section) => {
        setExpandedSections((prev) => ({
            ...prev,
            [section]: !prev[section],
        }))
    }

    const handleCategoryClick = (category) => {
        if (category?.has_child) {
            navigate(`/category/${category?.slug}`)
        } else {
            navigate("/products")
        }
    }

    const handleAppDownloadClick = () => {
        setShowAppModal(true)
    }

    const closeModal = () => {
        setShowAppModal(false)
    }

    // Distribute categories evenly across 3 columns for better layout
    const categoriesPerColumn = Math.ceil(categories.length / 3)
    const categoryColumns = [
        categories.slice(0, categoriesPerColumn),
        categories.slice(categoriesPerColumn, categoriesPerColumn * 2),
        categories.slice(categoriesPerColumn * 2),
    ]

    return (
        <>
            <footer className="w-full bg-gradient-to-b from-gray-50 to-gray-100">
                {/* Main Footer Content */}
                <div className="max-w-7xl mx-auto px-4 py-12">
                    {/* Desktop View - Grid Layout */}
                    <div className="hidden lg:block">
                        <div className="grid grid-cols-4 gap-12 mb-12">
                            {/* Three Category Columns */}
                            {categoryColumns.map((columnCategories, columnIndex) => (
                                <div key={columnIndex} className="space-y-4">
                                    <h3 className="font-bold text-sm text-gray-900 uppercase tracking-wide border-b-2 border-[#fc2e6b] pb-2 mb-4">
                                        Categories {columnIndex + 1}
                                    </h3>
                                    <ul className="space-y-3">
                                        {columnCategories.map((category) => (
                                            <li key={category.slug}>
                                                <button
                                                    onClick={() => handleCategoryClick(category)}
                                                    className="text-sm text-gray-600 hover:text-[#fc2e6b] hover:font-medium transition-all duration-200 block py-1 text-left w-full hover:translate-x-1"
                                                >
                                                    {category.name}
                                                </button>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            ))}

                            {/* Company Section - Last Column */}
                            <div className="space-y-8">
                                <div className="space-y-4">
                                    <h3 className="font-bold text-sm text-gray-900 uppercase tracking-wide border-b-2 border-[#fc2e6b] pb-2 mb-4">
                                        Company
                                    </h3>
                                    <ul className="space-y-3">
                                        {[
                                            "About us",
                                            "FAQs",
                                            "Contact us",
                                            "Terms and Conditions",
                                            "Privacy Policy",
                                            "Return and Exchange Policy",
                                            "Shipping Policy",
                                            "Cancellation Policy",
                                        ].map((item) => (
                                            <li key={item}>
                                                <Link
                                                    to={getRouteForLink(item)}
                                                    className="text-sm text-gray-600 hover:text-[#fc2e6b] hover:font-medium transition-all duration-200 block py-1 hover:translate-x-1"
                                                >
                                                    {item}
                                                </Link>
                                            </li>
                                        ))}
                                    </ul>
                                </div>

                                {/* Support Cards - Integrated into Company Column */}
                                <div className="space-y-4">
                                    <h3 className="font-bold text-sm text-gray-900 uppercase tracking-wide border-b-2 border-[#fc2e6b] pb-2 mb-4">
                                        Support
                                    </h3>
                                    <div className="space-y-3">
                                        <div className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all duration-300">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 bg-gradient-to-br from-[#fc2e6b] to-[#ff4d7a] rounded-lg flex items-center justify-center">
                                                    <Phone className="w-4 h-4 text-white" />
                                                </div>
                                                <div>
                                                    <div className="text-xs font-semibold text-gray-800">Customer Center</div>

                                                    <div className="text-xs text-[#fc2e6b]">
                                                        <Link to="/contact-us" className="hover:underline">bringmart.in/contact</Link>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <div className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all duration-300">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                                                    <Mail className="w-4 h-4 text-white" />
                                                </div>
                                                <div>
                                                    <div className="text-xs font-semibold text-gray-800">Email Support</div>
                                                    <a href="mailto:support@bringmart.in" className="text-xs text-blue-600 hover:underline">
                                                        support@bringmart.in
                                                    </a>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Mobile View - Accordion Style */}
                    <div className="lg:hidden space-y-4 mb-8">
                        {/* Support Cards Mobile */}
                        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-6">
                            <h3 className="font-bold text-base text-gray-900 mb-4 text-center">Customer Support</h3>
                            <div className="grid grid-cols-1 gap-3">
                                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                                    <div className="w-10 h-10 bg-gradient-to-br from-[#fc2e6b] to-[#ff4d7a] rounded-lg flex items-center justify-center">
                                        <Phone className="w-5 h-5 text-white" />
                                    </div>
                                    <div>
                                        <div className="text-sm font-semibold text-gray-800">Customer Center</div>
                                        <div className="text-xs text-[#fc2e6b]">bringmart.in/contact</div>
                                    </div>
                                </div>

                                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                                        <Mail className="w-5 h-5 text-white" />
                                    </div>
                                    <div>
                                        <div className="text-sm font-semibold text-gray-800">Email Support</div>
                                        <div className="text-xs text-blue-600">help@bringmart.in</div>
                                    </div>
                                </div>

                                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                                    <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center">
                                        <MapPin className="w-5 h-5 text-white" />
                                    </div>
                                    <div>
                                        <div className="text-sm font-semibold text-gray-800">Live Chat</div>
                                        <div className="text-xs text-green-600">Available 24/7</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Category Sections Mobile - Split into 3 sections */}
                        {categoryColumns.map((columnCategories, columnIndex) => (
                            <div key={columnIndex} className="bg-white rounded-xl shadow-sm border border-gray-200">
                                <button
                                    onClick={() => toggleSection(`CATEGORIES_${columnIndex + 1}`)}
                                    className="w-full flex justify-between items-center p-4 text-left"
                                >
                                    <span className="font-semibold text-gray-800 text-sm uppercase tracking-wide">
                                        Categories {columnIndex + 1}
                                    </span>
                                    {expandedSections[`CATEGORIES_${columnIndex + 1}`] ? (
                                        <ChevronUp className="w-5 h-5 text-[#fc2e6b]" />
                                    ) : (
                                        <ChevronDown className="w-5 h-5 text-gray-400" />
                                    )}
                                </button>
                                {expandedSections[`CATEGORIES_${columnIndex + 1}`] && (
                                    <div className="px-4 pb-4">
                                        <div className="space-y-2">
                                            {columnCategories.map((category) => (
                                                <button
                                                    key={category.slug}
                                                    onClick={() => handleCategoryClick(category)}
                                                    className="text-sm text-gray-600 hover:text-[#fc2e6b] py-2 px-3 rounded-lg hover:bg-pink-50 transition-all duration-200 w-full text-left"
                                                >
                                                    {category.name}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))}

                        {/* Company Section Mobile */}
                        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                            <button
                                onClick={() => toggleSection("COMPANY")}
                                className="w-full flex justify-between items-center p-4 text-left"
                            >
                                <span className="font-semibold text-gray-800 text-sm uppercase tracking-wide">Company</span>
                                {expandedSections["COMPANY"] ? (
                                    <ChevronUp className="w-5 h-5 text-[#fc2e6b]" />
                                ) : (
                                    <ChevronDown className="w-5 h-5 text-gray-400" />
                                )}
                            </button>
                            {expandedSections["COMPANY"] && (
                                <div className="px-4 pb-4">
                                    <div className="space-y-2">
                                        {[
                                            "About us",
                                            "FAQs",
                                            "Contact us",
                                            "Terms and Conditions",
                                            "Privacy Policy",
                                            "Return and Exchange Policy",
                                            "Shipping Policy",
                                            "Cancellation Policy",
                                        ].map((item) => (
                                            <Link
                                                key={item}
                                                to={getRouteForLink(item)}
                                                className="text-sm text-gray-600 hover:text-[#fc2e6b] py-2 px-3 rounded-lg hover:bg-pink-50 transition-all duration-200 block"
                                            >
                                                {item}
                                            </Link>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* App Download & Social Links */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8 pt-8 border-t border-gray-300">
                        <div className="text-center lg:text-left">
                            <h3 className="font-bold text-lg text-gray-900 mb-3">Shop on the Go</h3>
                            <p className="text-gray-600 text-sm mb-4">Get the best deals right in your pocket</p>
                            <div className="flex justify-center lg:justify-start">
                                <button
                                    onClick={handleAppDownloadClick}
                                    className="bg-gray-900 rounded-xl p-4 flex items-center gap-3 hover:bg-gray-800 transition-all duration-200 shadow-lg"
                                >
                                    <Download className="w-6 h-6 text-white" />
                                    <div className="text-left">
                                        <div className="text-xs text-gray-300">Get it on</div>
                                        <div className="text-white font-semibold text-sm">Google Play</div>
                                    </div>
                                </button>
                            </div>
                        </div>

                        <div className="text-center lg:text-right">
                            <h3 className="font-bold text-lg text-gray-900 mb-3">Stay Connected</h3>
                            <p className="text-gray-600 text-sm mb-4">Follow us for updates and exclusive offers</p>
                            <div className="flex justify-center lg:justify-end gap-3">
                                <a href="https://www.facebook.com/share/1JCYhKgSrj/" className="group">
                                    <div className="w-12 h-12 bg-gradient-to-br from-[#fc2e6b] to-[#ff4d7a] rounded-xl p-2.5 group-hover:scale-110 transition-all duration-200 shadow-lg">
                                        <Facebook className="w-7 h-7 text-white" />
                                    </div>
                                </a>
                                <a href="https://x.com/bringmart1" className="group">
                                    <div className="w-12 h-12 bg-gradient-to-br from-[#fc2e6b] to-[#ff4d7a] rounded-xl p-2.5 group-hover:scale-110 transition-all duration-200 shadow-lg">
                                        <Twitter className="w-7 h-7 text-white" />
                                    </div>
                                </a>
                                <a href="https://www.instagram.com/bringmart.in/" className="group">
                                    <div className="w-12 h-12 bg-gradient-to-br from-[#fc2e6b] to-[#ff4d7a] rounded-xl p-2.5 group-hover:scale-110 transition-all duration-200 shadow-lg">
                                        <Instagram className="w-7 h-7 text-white" />
                                    </div>
                                </a>
                                <a href="/" className="group">
                                    <div className="w-12 h-12 bg-gradient-to-br from-[#fc2e6b] to-[#ff4d7a] rounded-xl p-2.5 group-hover:scale-110 transition-all duration-200 shadow-lg">
                                        <Linkedin className="w-7 h-7 text-white" />
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Bottom Bar */}
                <div className="border-t border-gray-300 bg-white">
                    <div className="max-w-7xl mx-auto px-4 py-6">
                        <div className="flex flex-col lg:flex-row justify-between items-center gap-4">
                            <div className="text-sm text-gray-700 font-medium">© 2025 BringMart. All Rights Reserved</div>

                            <div className="flex flex-wrap justify-center gap-4 lg:gap-6">
                                {[
                                    { name: "Sell with BringMart", href: "https://seller.bringmart.in" },
                                    { name: "Terms & Conditions", href: "/terms-and-conditions" },
                                    { name: "Privacy Policy", href: "/privacy-policy" },
                                ].map((link) => (
                                    <a
                                        key={link.name}
                                        href={link.href}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-xs text-gray-600 hover:text-[#fc2e6b] hover:font-medium transition-all duration-200"
                                    >
                                        {link.name}
                                    </a>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </footer>

            {/* App Launch Modal */}
            {showAppModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-2xl max-w-md w-full p-6 relative shadow-2xl">
                        {/* Close Button */}
                        <button
                            onClick={closeModal}
                            className="absolute top-4 right-4 w-8 h-8 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors duration-200"
                        >
                            <X className="w-4 h-4 text-gray-600" />
                        </button>

                        {/* Modal Content */}
                        <div className="text-center">
                            {/* App Icon */}
                            <div className="w-20 h-20 bg-gradient-to-br from-[#fc2e6b] to-[#ff4d7a] rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                                <Smartphone className="w-10 h-10 text-white" />
                            </div>

                            {/* Title */}
                            <h2 className="text-2xl font-bold text-gray-900 mb-3">
                                Our App is Launching Soon!
                            </h2>

                            {/* Description */}
                            <p className="text-gray-600 mb-6 leading-relaxed">
                                We're working hard to bring you the best shopping experience on mobile.
                                Get ready for exclusive deals, faster checkout, and seamless shopping.
                            </p>

                            {/* Features */}
                            {/* <div className="space-y-3 mb-6">
                                <div className="flex items-center gap-3 p-3 bg-pink-50 rounded-lg">
                                    <div className="w-8 h-8 bg-gradient-to-br from-[#fc2e6b] to-[#ff4d7a] rounded-lg flex items-center justify-center">
                                        <Bell className="w-4 h-4 text-white" />
                                    </div>
                                    <span className="text-sm text-gray-700">Get notified when we launch</span>
                                </div>
                                
                                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                                    <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                                        <Download className="w-4 h-4 text-white" />
                                    </div>
                                    <span className="text-sm text-gray-700">Fast & secure mobile app</span>
                                </div>
                                
                                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                                    <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center">
                                        <Calendar className="w-4 h-4 text-white" />
                                    </div>
                                    <span className="text-sm text-gray-700">Coming Q2 2025</span>
                                </div>
                            </div> */}

                            {/* Call to Action */}
                            <div className="space-y-3">
                                {/* <button
                                    onClick={closeModal}
                                    className="w-full bg-gradient-to-r from-[#fc2e6b] to-[#ff4d7a] text-white font-semibold py-3 px-6 rounded-xl hover:from-[#e8286b] hover:to-[#f04575] transition-all duration-200 shadow-lg"
                                >
                                    Notify Me When Available
                                </button> */}

                                <button
                                    onClick={closeModal}
                                    className="w-full text-white bg-[#fc2e6b] font-medium py-2 rounded-lg transition-colors duration-200"
                                >
                                    Continue Shopping on Web
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </>
    )
}

export default Footer