// import { ChevronRight } from "lucide-react";
// import React from "react";

// const Breadcrumbs = ({ paths }) => {
//   return (
//     <div className="flex items-center space-x-2 sm:text-xs md:text-sm font-medium">
//       {paths.map((path, index) => (
//         <React.Fragment key={index}>
//          <a href="/"> <span className="text-gray-500">{path}</span></a>
//           {index < paths.length - 1 && (
//             <ChevronRight />
//           )}
//         </React.Fragment>
//       ))}
//     </div>
//   );
// };

// export default Breadcrumbs;

import { ChevronRight } from "lucide-react";
import React from "react";
import { Link } from "react-router-dom";

const Breadcrumbs = ({ paths }) => {
  return (
    <div className="flex items-center space-x-2 sm:text-xs md:text-sm font-medium py-4 px-4 bg-gray-50">
      {paths.map((path, index) => (
        <React.Fragment key={index}>
          {path.path ? (
            <Link 
              to={path.path} 
              className="text-gray-500 hover:text-rose-500 transition-colors"
            >
              {path.name}
            </Link>
          ) : (
            <span className="text-gray-700 font-medium">{path.name}</span>
          )}
          {index < paths.length - 1 && (
            <ChevronRight className="w-4 h-4 text-gray-400" />
          )}
        </React.Fragment>
      ))}
    </div>
  );
};

export default Breadcrumbs;