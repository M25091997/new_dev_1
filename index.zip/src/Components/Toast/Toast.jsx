import React, { useState, useEffect } from 'react';
import { CheckCircle, AlertCircle, Info, X, Bell } from 'lucide-react';

export const Toast = ({
  message,
  type = 'success',
  duration = 3000,
  onClose,
  position = 'top-right'
}) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      if (onClose) onClose();
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onClose]);

  // Define position classes
  const positionClasses = {
    'top-right': 'top-4 right-4',
    'top-left': 'top-4 left-4',
    'bottom-right': 'bottom-4 right-4',
    'bottom-left': 'bottom-4 left-4',
    'top-center': 'top-4 left-1/2 transform -translate-x-1/2',
    'bottom-center': 'bottom-4 left-1/2 transform -translate-x-1/2'
  };

  // Define type-based styles
  const typeStyles = {
    success: {
      bgColor: 'bg-gradient-to-r from-green-500 to-emerald-600',
      icon: <CheckCircle className="w-5 h-5 text-white" />,
      borderColor: 'border-green-400'
    },
    error: {
      bgColor: 'bg-gradient-to-r from-red-500 to-rose-600',
      icon: <AlertCircle className="w-5 h-5 text-white" />,
      borderColor: 'border-red-400'
    },
    warning: {
      bgColor: 'bg-gradient-to-r from-amber-500 to-orange-600',
      icon: <Bell className="w-5 h-5 text-white" />,
      borderColor: 'border-amber-400'
    },
    info: {
      bgColor: 'bg-gradient-to-r from-blue-500 to-indigo-600',
      icon: <Info className="w-5 h-5 text-white" />,
      borderColor: 'border-blue-400'
    }
  };

  const { bgColor, icon, borderColor } = typeStyles[type] || typeStyles.success;

  if (!isVisible) return null;

  return (
    <div
      className={`fixed ${positionClasses[position]} z-50 transform transition-all duration-500 ease-in-out ${isVisible ? 'translate-y-0 opacity-100' : '-translate-y-2 opacity-0'}`}
    >
      <div
        className={`flex items-center gap-2 min-w-72 max-w-md px-4 py-3 rounded-lg shadow-lg ${bgColor} border-l-4 ${borderColor} backdrop-blur-sm text-white`}
      >
        <div className="flex-shrink-0">
          {icon}
        </div>

        <div className="flex-grow text-sm font-medium">
          {message}
        </div>

        <button
          onClick={() => {
            setIsVisible(false);
            if (onClose) onClose();
          }}
          className="flex-shrink-0 ml-2 p-1 rounded-full hover:bg-white hover:bg-opacity-20 transition-colors duration-200"
          aria-label="Close"
        >
          <X className="w-4 h-4 text-white" />
        </button>
      </div>

      {/* Progress bar */}
      <div className="relative h-1 -mt-1 mx-1 rounded-b-lg overflow-hidden bg-black bg-opacity-10">
        <div
          className="absolute top-0 left-0 h-full bg-white bg-opacity-30"
          style={{
            width: '100%',
            animation: `shrink ${duration}ms linear forwards`
          }}
        />
      </div>

      <style jsx>{`
        @keyframes shrink {
          from { width: 100%; }
          to { width: 0%; }
        }
      `}</style>
    </div>
  );
};