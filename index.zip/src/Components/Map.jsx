import React from "react";
import { GoogleMap, useLoadScript, MarkerF } from "@react-google-maps/api";
import constants from "../constants/constants";
import { Loader } from '@mantine/core';

const MapComponent = ({ selectedLocation }) => {
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: constants.GOOGLE_MAP_API_KEY,
  });
  const mapRef = React.useRef();
  const onMapLoad = React.useCallback((map) => {
    mapRef.current = map;
  }, []);
  if (loadError) return "Error";
  if (!isLoaded) return <div className="flex justify-center items-center h-full">
    <Loader color="orange" size="lg" type="dots" />
  </div>;;

  return (
    <div>
      <GoogleMap
        mapContainerStyle={{
          height: "300px",
        }}
        center={selectedLocation}
        zoom={16}
        onLoad={onMapLoad}
      >
        <MarkerF
          position={selectedLocation}
          icon={"http://maps.google.com/mapfiles/ms/icons/red-dot.png"}
        />
      </GoogleMap>
    </div>
  );
};

export default MapComponent;