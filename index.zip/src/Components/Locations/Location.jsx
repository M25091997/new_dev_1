import React, { useState, useRef, useMemo, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { useTranslation } from 'react-i18next';
import { setCity, setFirstVisit } from '../../model/reducer/locationReducer';
import { setSetting } from '../../model/reducer/settingReducer';
import { setShop } from '../../model/reducer/shopReducer';
import { loadGoogleMaps, isGoogleMapsLoaded } from '../../utils/LoadGoogleMaps/LoadGoogleMap';
import Loader from '../Loader/Loader';
import { LocateFixed, MapPin, Search, X } from 'lucide-react';
import api from '../../api/api';

const Location = (props) => {
  const dispatch = useDispatch();
  const setting = useSelector(state => state.setting);
  const user = useSelector(state => state.user);
  const { firstVisit } = useSelector(state => state.city);
  const { t } = useTranslation();

  // State for Google Maps components
  const [GoogleMapComponent, setGoogleMapComponent] = useState(null);
  const [StandaloneSearchBoxComponent, setStandaloneSearchBoxComponent] = useState(null);
  const [MarkerFComponent, setMarkerFComponent] = useState(null);
  const [mapsLoaded, setMapsLoaded] = useState(isGoogleMapsLoaded());
  const [mapsError, setMapsError] = useState(null);

  // UI State
  const [showManualInput, setShowManualInput] = useState(true);
  const [isloading, setisloading] = useState(false);
  const [currLocationClick, setcurrLocationClick] = useState(false);
  const [errorMsg, seterrorMsg] = useState("");
  const [isAddressLoading, setisAddressLoading] = useState(false);
  const [awaitingPermission, setAwaitingPermission] = useState(false);
  const [localLocation, setlocalLocation] = useState({
    city: "",
    formatted_address: "",
    lat: null,
    lng: null,
  });

  const inputRef = useRef();

  // Load Google Maps and components
  useEffect(() => {
    let mounted = true;

    const loadMapsAndComponents = async () => {
      try {
        // Load Google Maps API
        await loadGoogleMaps(import.meta.env.VITE_APP_MAP_API);

        // Dynamically import components
        const { GoogleMap, StandaloneSearchBox, MarkerF } = await import('@react-google-maps/api');

        if (mounted) {
          setGoogleMapComponent(() => GoogleMap);
          setStandaloneSearchBoxComponent(() => StandaloneSearchBox);
          setMarkerFComponent(() => MarkerF);
          setMapsLoaded(true);

          // Try to get current location if permission granted
          if (props.locationPermission === 'granted') {
            handleCurrentLocationClick();
          }
        }
      } catch (error) {
        if (mounted) {
          setMapsError(error.message);
          toast.error('Failed to load maps');
          console.error('Maps loading error:', error);
        }
      }
    };

    if (!isGoogleMapsLoaded()) {
      loadMapsAndComponents();
    } else {
      setMapsLoaded(true);
    }

    return () => {
      mounted = false;
    };
  }, [props.locationPermission]);

  const center = useMemo(() => ({
    lat: localLocation.lat || 20.5937, // Default to India center if no location
    lng: localLocation.lng || 78.9629,
  }), [localLocation.lat, localLocation.lng]);

  const handlePlaceChanged = () => {
    if (!mapsLoaded || !inputRef.current) return;

    setisloading(true);
    const [place] = inputRef.current.getPlaces();
    try {
      if (place) {
        let city_name = place.address_components[0].long_name;
        let loc_lat = place.geometry.location.lat();
        let loc_lng = place.geometry.location.lng();
        let formatted_address = place.formatted_address;
        fetchCity(city_name, loc_lat, loc_lng)
          .then((res) => {
            if (res.status === 1) {
              setlocalLocation({
                city: res.data.name,
                formatted_address: formatted_address,
                lat: loc_lat,
                lng: loc_lng,
              });
              setisloading(false);
              setShowManualInput(false);
            } else {
              setisloading(false);
              toast.error("We don't deliver at selected city");
            }
          })
          .catch(error => {
            console.log(error);
            setisloading(false);
            toast.error("Error fetching city data");
          });
      } else {
        setisloading(false);
      }
    } catch (e) {
      toast.error("Location not found!");
      setisloading(false);
    }
  };

  const fetchCity = async (city_name, loc_lat, loc_lng) => {
    const response = await api.getCity(loc_lat, loc_lng);
    const res = await response.json();
    return res;
  };

  const handleCurrentLocationClick = () => {
    if (!mapsLoaded) {
      toast.error("Maps not loaded yet, please try again.");
      return;
    }

    setisloading(true);
    setcurrLocationClick(true);
    seterrorMsg("");

    if (!("geolocation" in navigator)) {
      onError({
        code: 0,
        message: "Geolocation not supported",
      });
      return;
    }

    if (props.locationPermission === 'denied') {
      toast.error("Please enable location permissions in your browser settings");
      setisloading(false);
      setcurrLocationClick(false);
      return;
    }

    setAwaitingPermission(true);
    navigator.geolocation.getCurrentPosition(
      onSuccess,
      onError,
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  };

const onSuccess = (location) => {
  if (!mapsLoaded || !window.google?.maps) {
    toast.error("Maps not loaded yet, please try again.");
    setisloading(false);
    setcurrLocationClick(false);
    setAwaitingPermission(false);
    return;
  }

  setAwaitingPermission(false);
  const geocoder = new window.google.maps.Geocoder();

  geocoder.geocode({
    location: {
      lat: location.coords.latitude,
      lng: location.coords.longitude,
    },
    componentRestrictions: { country: 'IN' },
  }).then(response => {
    if (response.results[0]) {
      // Try to find the most specific address first
      let address = response.results.find(r => 
        r.types.includes('street_address') ||
        r.types.includes('route') ||
        r.types.includes('premise') ||
        r.types.includes('sublocality') ||
        r.types.includes('locality')
      ) || response.results[0];

      // If we still don't have a good address, try the next results
      if (!address && response.results.length > 1) {
        address = response.results[1];
      }

      getAvailableCity(response).then(res => {
        if (res.status === 1) {
          setlocalLocation({
            city: res.data.name,
            formatted_address: address.formatted_address,
            lat: parseFloat(location.coords.latitude),
            lng: parseFloat(location.coords.longitude),
          });
          seterrorMsg("");
          setShowManualInput(false);
        } else {
          seterrorMsg(res.message);
          setlocalLocation({
            city: address.address_components[0]?.long_name || 'Unknown',
            formatted_address: address.formatted_address,
            lat: parseFloat(location.coords.latitude),
            lng: parseFloat(location.coords.longitude),
          });
        }
        setisloading(false);
      }).catch(error => {
        console.log("error " + error);
        setisloading(false);
      });
    } else {
      console.log("No result found");
      setisloading(false);
    }
  }).catch(error => {
    console.log(error);
    setisloading(false);
  });
};

  const onError = (error) => {
    setAwaitingPermission(false);
    console.log(error);
    setisloading(false);
    setcurrLocationClick(false);

    if (error.code === error.PERMISSION_DENIED) {
      toast.error("Location access was denied. Please enable it to use this feature.");
      props.requestLocation?.();
    } else if (error.code === error.TIMEOUT) {
      toast.error("Location request timed out. Please try again or enter manually.");
    } else {
      toast.error("Error getting your location. Please try again or enter manually.");
    }
  };

  const getAvailableCity = async (response) => {
    if (!mapsLoaded || !window.google?.maps) {
      return { status: 0, message: "Maps not loaded" };
    }

    var results = response.results;
    var c, lc, component;
    var found = false, message = "";
    for (var r = 0, rl = results.length; r < 2; r += 1) {
      var flag = false;
      var result = results[r];
      for (c = 0, lc = result.address_components.length; c < 2; c += 1) {
        component = result.address_components[c];

        const response = await api.getCity(result.geometry.location.lat(), result.geometry.location.lng()).catch(error => console.log("error: ", error));
        const res = await response.json();

        if (res.status === 1) {
          flag = true;
          found = true;
          return res;
        } else {
          found = false;
          message = res.message;
        }
        if (flag === true) {
          break;
        }
      }
      if (flag === true) {
        break;
      }
    }
    if (found === false) {
      return {
        status: 0,
        message: message,
      };
    }
  };

  const onMarkerDragStart = () => {
    setisAddressLoading(true);
  };

  const onMarkerDragEnd = (e) => {
    if (!mapsLoaded || !window.google?.maps) {
      toast.error("Maps not loaded yet, please try again.");
      setisAddressLoading(false);
      return;
    }

    const geocoder = new window.google.maps.Geocoder();
    geocoder.geocode({
      location: {
        lat: e.latLng.lat(),
        lng: e.latLng.lng(),
      },
    })
      .then(response => {
        if (response.results[0]) {
          getAvailableCity(response)
            .then(res => {
              if (res.status === 1) {
                setlocalLocation({
                  city: res.data.name,
                  formatted_address: response.results[0].formatted_address,
                  lat: (response.results[0].geometry.location.lat()),
                  lng: (response.results[0].geometry.location.lng()),
                });
                setisAddressLoading(false);
                seterrorMsg("");
              } else {
                setlocalLocation({
                  city: null,
                  formatted_address: response.results[0].formatted_address,
                  lat: (response.results[0].geometry.location.lat()),
                  lng: (response.results[0].geometry.location.lng()),
                });
                setisAddressLoading(false);
                setisloading(false);
                seterrorMsg(res.message);
              }
            })
            .catch(error => console.log("error " + error));
        } else {
          console.log("No result found");
        }
      })
      .catch(error => {
        console.log(error);
      });
  };

  const confirmCurrentLocation = async () => {
    if (errorMsg) {
      toast.error(errorMsg);
      return;
    }
     // Add validation for coordinates
  if (!localLocation.lat || !localLocation.lng) {
    toast.error("Please select a valid location");
    return;
  }
    setisloading(true);

    try {
      const result = await fetchCity(localLocation.city, localLocation.lat, localLocation.lng);
      if (result.status === 1) {
        dispatch(setCity({
          status: 'fulfill',
          data: {
            id: result.data.id,
            name: localLocation.city,
            state: result.data.state,
            formatted_address: localLocation.formatted_address,
            latitude: result.data.latitude,
            longitude: result.data.longitude,
            min_amount_for_free_delivery: result.data.min_amount_for_free_delivery,
            delivery_charge_method: result.data.delivery_charge_method,
            fixed_charge: result.data.fixed_charge,
            per_km_charge: result.data.per_km_charge,
            time_to_travel: result.data.time_to_travel,
            max_deliverable_distance: result.data.max_deliverable_distance,
            distance: result.data.distance,
          },
        }));

        await fetchShop(result.data.latitude, result.data.longitude);

        localStorage.setItem('locationSet', 'true');
        dispatch(setFirstVisit(false));

        // Call the close function from props
        if (props.close) {
          props.close();
        }
      } else {
        seterrorMsg(result.message);
      }
    } catch (error) {
      console.error("Error confirming location:", error);
      toast.error("Failed to set location");
    } finally {
      setisloading(false);
      setcurrLocationClick(false);
    }
  };

  const fetchShop = async (latitude, longitude) => {
    try {
      const response = await api.getShop(latitude, longitude, user?.jwtToken);
      const result = await response.json();
      if (result?.status == 1) {
        dispatch(setShop({ data: result?.data }));
      }
    } catch (error) {
      console.log(error?.message);
    }
  };

  if (mapsError) {
    return (
      <div className="flex flex-col justify-center items-center p-8">
        <div className="text-red-500 mb-4">{mapsError}</div>
        <button
          onClick={() => window.location.reload()}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Retry
        </button>
      </div>
    );
  }

  if (!mapsLoaded) {
    return (
      <div className="flex flex-col justify-center items-center p-8">
        <Loader />
        <p className="mt-4 text-gray-600 text-center">Loading maps...</p>
      </div>
    );
  }

  return (
    <>
      {setting.setting && GoogleMapComponent && StandaloneSearchBoxComponent && MarkerFComponent && (
        <div className="map-container">
          {isloading ? (
            <div className='flex flex-col justify-center items-center p-8'>
              <Loader />
              {awaitingPermission && (
                <p className="mt-4 text-gray-600 text-center">
                  Waiting for location permission...
                </p>
              )}
            </div>
          ) : (
            <>
              {showManualInput ? (
                <div className="search-locations p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Select Delivery Location</h2>
                    <button
                      onClick={() => setShowManualInput(false)}
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="flex gap-4 mb-4">
                    <button
                      onClick={handleCurrentLocationClick}
                      className="flex-1 flex items-center justify-center gap-2 border border-orange-500 text-orange-500 rounded-md p-2 hover:bg-orange-400 hover:text-white transition duration-300"
                      disabled={props.locationPermission === 'denied'}
                    >
                      <LocateFixed className="w-4 h-4" />
                      Use Current Location
                    </button>
                  </div>

                  <div className="relative">
                    <StandaloneSearchBoxComponent
                      onLoad={(ref) => (inputRef.current = ref)}
                      onPlacesChanged={handlePlaceChanged}
                    >
                      <div className="relative">
                        <input
                          type="text"
                          id="text-places"
                          className="w-full p-3 pl-10 border border-gray-300 rounded-md focus:outline-orange-300"
                          placeholder="Enter your address"
                        />
                        <Search className="absolute left-3 top-3.5 w-4 h-4 text-gray-400" />
                      </div>
                    </StandaloneSearchBoxComponent>
                  </div>
                </div>
              ) : (
                <>
                  <div className="relative w-full">
                    <GoogleMapComponent
                      streetViewControl={false}
                      zoom={15}
                      center={center}
                      mapContainerStyle={{ height: "400px" }}
                      options={{
                        disableDefaultUI: true,
                        zoomControl: true,
                        fullscreenControl: true,
                      }}
                    >
                      <button
                        className="absolute z-10 top-2 left-2 w-10 h-10 p-0 rounded-none border-none bg-white text-[var(--primary-color)] text-xl"
                        onClick={() => setShowManualInput(true)}
                      >
                        <Search className="w-5 h-5" />
                      </button>
                      <button
                        className="absolute z-10 top-2 right-2 w-10 h-10 p-0 rounded-none border-none bg-white text-[var(--primary-color)] text-xl"
                        onClick={handleCurrentLocationClick}
                      >
                        <LocateFixed className="w-5 h-5" />
                      </button>
                      <MarkerFComponent
                        position={center}
                        draggable={true}
                        onDragStart={onMarkerDragStart}
                        onDragEnd={onMarkerDragEnd}
                        icon={{
                          url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(
                            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23fc2e6b"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>'
                          )}`,
                          scaledSize: new window.google.maps.Size(40, 40),
                          anchor: new window.google.maps.Point(20, 40),
                        }}
                      />
                    </GoogleMapComponent>
                  </div>

                  <div className="p-4">
                    <p className="text-xl mb-2">
                      <b>Address:</b> {isAddressLoading ? "Loading..." : localLocation.formatted_address}
                    </p>

                    {errorMsg && (
                      <div className="mt-2 p-2 bg-red-50 text-red-600 rounded-md text-sm">
                        {errorMsg}
                      </div>
                    )}

                    <button
                      type="button"
                      className="w-full mt-4 p-3 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition duration-300"
                      onClick={confirmCurrentLocation}
                      disabled={!localLocation.formatted_address}
                    >
                      Confirm Location
                    </button>
                  </div>
                </>
              )}
            </>
          )}
        </div>
      )}
    </>
  );
};

export default Location;