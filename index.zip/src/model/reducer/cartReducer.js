import { createAction, createSlice } from "@reduxjs/toolkit";

const initialState = {
  status: "loading",
  cart: null,
  checkout: null,
  promo_code: null,
  is_wallet_checked: 0,
  same_seller_flag: 0,
  cartProducts: [],
  cartSubTotal: 0,
  guestCart: [],
  isGuest: true,
  guestCartTotal: 0,
};

// export const updateCartItemQuantity = createAction("cart/updateCartItemQuantity");
// export const updateGuestCartItemQuantity = createAction("cart/updateGuestCartItemQuantity");

export const cartReducer = createSlice({
  name: "cart",
  initialState,
  reducers: {
    setCart: (state, action) => {
      state.status = "fulfill";
      state.cart = action.payload.data;
      state.isGuest = false;

      if (action.payload.data?.cart) {
        state.cartProducts = action.payload.data.cart.map((product) => ({
          id: `${product.product_id}_${product.product_variant_id}`,
          product_id: product.product_id,
          product_variant_id: product.product_variant_id,
          quantity: product.qty,
          price: product.price,
          discounted_price: product.discounted_price,
          name: product.name,
          image: product.image_url,
          measurement: product.measurement,
          unit_code: product.unit_code,
          stock: product.stock,
          is_unlimited_stock: product.is_unlimited_stock,
          total_allowed_quantity: product.total_allowed_quantity,
          slug: product.slug,
          status: product.status === 1,
        }));

        state.cartSubTotal = action.payload.data.sub_total || 0;
      }
    },
    setCartCheckout: (state, action) => {
      state.checkout = action.payload.data;
    },
    setCartPromo: (state, action) => {
      state.promo_code = action.payload.data;
    },
    clearCartPromo: (state) => {
      state.promo_code = null;
      if (state.cart) {
        state.cart.promo_code = null;
      }
    },
    setWallet: (state, action) => {
      state.is_wallet_checked = action.payload.data;
    },
    setSellerFlag: (state, action) => {
      state.same_seller_flag = action.payload.data;
    },
    setCartProducts: (state, action) => {
      state.cartProducts = action.payload.data;
    },
    setCartSubTotal: (state, action) => {
      state.cartSubTotal = action.payload.data;
    },
    setIsGuest: (state, action) => {
      state.isGuest = action.payload.data;
      if (!action.payload.data) {
        // Clear guest cart when logging in
        state.guestCart = [];
        state.guestCartTotal = 0;
      }
    },
    addtoGuestCart: (state, action) => {
      if (!Array.isArray(state.guestCart)) {
        state.guestCart = [];
      }

      const newItems = Array.isArray(action.payload.data)
        ? action.payload.data
        : [action.payload.data];

      newItems.forEach((newItem) => {
        const existingItemIndex = state.guestCart.findIndex(
          (item) => item.product_variant_id === newItem.product_variant_id
        );

        if (existingItemIndex >= 0) {
          state.guestCart[existingItemIndex].quantity += newItem.quantity;
        } else {
          state.guestCart.push({
            ...newItem,
            id: `${newItem.product_id}_${newItem.product_variant_id}`,
          });
        }
      });

      // Recalculate guest cart total
      state.guestCartTotal = state.guestCart.reduce((total, item) => {
        return (
          total +
          (item.discounted_price > 0
            ? item.discounted_price * item.quantity
            : item.price * item.quantity)
        );
      }, 0);
    },
    updateGuestCartItemQuantity: (state, action) => {
      const { id, quantity } = action.payload;
      const itemIndex = state.guestCart.findIndex((item) => item.id === id);

      if (itemIndex >= 0) {
        state.guestCart[itemIndex].quantity = quantity;

        // Recalculate guest cart total
        state.guestCartTotal = state.guestCart.reduce((total, item) => {
          return (
            total +
            (item.discounted_price > 0
              ? item.discounted_price * item.quantity
              : item.price * item.quantity)
          );
        }, 0);
      }
    },
    removeFromGuestCart: (state, action) => {
      const id = action.payload;
      state.guestCart = state.guestCart.filter((item) => item.id !== id);

      // Recalculate guest cart total
      state.guestCartTotal = state.guestCart.reduce((total, item) => {
        return (
          total +
          (item.discounted_price > 0
            ? item.discounted_price * item.quantity
            : item.price * item.quantity)
        );
      }, 0);
    },
    updateCartItemQuantity: (state, action) => {
      const { product_id, product_variant_id, quantity } = action.payload;

      if (state.cart?.cart) {
        const itemIndex = state.cart.cart.findIndex(
          (item) =>
            item.product_id === product_id &&
            item.product_variant_id === product_variant_id
        );

        if (itemIndex >= 0) {
          state.cart.cart[itemIndex].qty = quantity;

          // Update cartProducts
          const productIndex = state.cartProducts.findIndex(
            (p) =>
              p.product_id === product_id &&
              p.product_variant_id === product_variant_id
          );

          if (productIndex >= 0) {
            state.cartProducts[productIndex].quantity = quantity;
          }

          // Recalculate subtotal
          state.cartSubTotal = state.cart.cart.reduce((total, item) => {
            return (
              total +
              (item.discounted_price > 0
                ? item.discounted_price * item.qty
                : item.price * item.qty)
            );
          }, 0);
        }
      }
    },
    removeCartItem: (state, action) => {
      const { product_id, product_variant_id } = action.payload;

      if (state.cart?.cart) {
        state.cart.cart = state.cart.cart.filter(
          (item) =>
            !(
              item.product_id === product_id &&
              item.product_variant_id === product_variant_id
            )
        );

        // Update cartProducts
        state.cartProducts = state.cartProducts.filter(
          (p) =>
            !(
              p.product_id === product_id &&
              p.product_variant_id === product_variant_id
            )
        );

        // Recalculate subtotal
        state.cartSubTotal = state.cart.cart.reduce((total, item) => {
          return (
            total +
            (item.discounted_price > 0
              ? item.discounted_price * item.qty
              : item.price * item.qty)
          );
        }, 0);
      }
    },
    setGuestCartTotal: (state, action) => {
      state.guestCartTotal = action.payload.data;
    },
    clearCart: (state) => {
      state.cart = null;
      state.cartProducts = [];
      state.cartSubTotal = 0;
      state.guestCart = [];
      state.guestCartTotal = 0;
      state.isGuest = true;
      state.promo_code = null;
      state.guestCart = [];
      state.guestCartTotal = 0;
    },
    // New action to handle merging guest cart after login
    mergeGuestCart: (state) => {
      if (!state.isGuest && state.guestCart.length > 0) {
        // This will trigger the API call to merge carts
        state.status = "loading";
      }
    },
  },
});

export const {
  setCart,
  setCartCheckout,
  setCartPromo,
  clearCartPromo,
  setWallet,
  setSellerFlag,
  setCartProducts,
  setCartSubTotal,
  setIsGuest,
  addtoGuestCart,
  updateGuestCartItemQuantity,
  removeFromGuestCart,
  setGuestCartTotal,
  updateCartItemQuantity,
  removeCartItem,
  clearCart,
  mergeGuestCart,
} = cartReducer.actions;

export default cartReducer.reducer;
