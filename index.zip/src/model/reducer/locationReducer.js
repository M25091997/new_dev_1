import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  status: "loading", // fulfill
  city: null,
  firstVisit: true, // Added this new state
};

export const locationReducer = createSlice({
  name: "city",
  initialState,
  reducers: {
    setCity: (state, action) => {
      state.status = "fulfill"; 
      state.city = action.payload.data;
      state.firstVisit = false; // Automatically set firstVisit to false when city is set
    },
    setFirstVisit: (state, action) => {
      state.firstVisit = action.payload;
    },
  },
});

export const { setCity, setFirstVisit } = locationReducer.actions;
export default locationReducer.reducer;
