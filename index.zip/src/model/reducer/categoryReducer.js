// categoryReducer.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  status: "loading",
  category: [], // This will store all categories from the shop
  selectedCategory: null, // This will store the currently selected category and its children
  allCategories: [], // This will store the complete category tree
};

export const categoryReducer = createSlice({
  name: "category",
  initialState,
  reducers: {
    setCategory: (state, action) => {
      state.status = "fulfill";
      state.category = action.payload;
    },
    setAllCategories: (state, action) => {
      state.allCategories = action.payload;
    },
    setSelectedCategory: (state, action) => {
      state.selectedCategory = action.payload;
    },
    clearSelectedCategory: (state) => {
      state.selectedCategory = null;
    },
    clearCategory: (state) => {
      state.category = [];
      state.status = "loading";
    },
  },
});

export const {
  setCategory,
  setAllCategories,
  setSelectedCategory,
  clearSelectedCategory,
  clearCategory,
} = categoryReducer.actions;
export default categoryReducer.reducer;
