// favouriteReducer.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    status: 'loading', //fulfill
    favorite: null,
    favouritelength: 0,
    favouriteProducts: []  // Changed from favouriteProductIds to store full products
};

export const favouriteReducer = createSlice({
    name: "favourite",
    initialState,
    reducers: {
        setFavourite: (state, action) => {
            state.status = "fulfill";
            state.favorite = action.payload.data;
        },
        setFavouriteLength: (state, action) => {
            state.favouritelength = action.payload.data;
        },
        setFavouriteProducts: (state, action) => {
            state.favouriteProducts = action.payload.data;
        },
        addFavoriteProduct: (state, action) => {
            const product = action.payload.data;
            const exists = state.favouriteProducts.some(p => p.id === product.id);
            if (!exists) {
                state.favouriteProducts = [...state.favouriteProducts, product];
                state.favouritelength += 1;
            }
        },
        removeFavoriteProduct: (state, action) => {
            state.favouriteProducts = state.favouriteProducts.filter(
                p => p.id !== action.payload.data
            );
            state.favouritelength = Math.max(0, state.favouritelength - 1);
        },
        toggleFavoriteProduct: (state, action) => {
            const product = action.payload.data;
            const exists = state.favouriteProducts.some(p => p.id === product.id);
            if (exists) {
                state.favouriteProducts = state.favouriteProducts.filter(
                    p => p.id !== product.id
                );
                state.favouritelength -= 1;
            } else {
                state.favouriteProducts = [...state.favouriteProducts, product];
                state.favouritelength += 1;
            }
        }
    }
});

export const { 
    setFavourite, 
    setFavouriteLength, 
    setFavouriteProducts, 
    addFavoriteProduct,
    removeFavoriteProduct,
    toggleFavoriteProduct
} = favouriteReducer.actions;
export default favouriteReducer.reducer;