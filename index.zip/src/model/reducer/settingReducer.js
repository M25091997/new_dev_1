// import { createSlice } from "@reduxjs/toolkit";
// const initialState = {
//     status: 'loading', //fulfill
//     setting: null,
//     payment_setting: null,
//     settingsFetchedTime: new Date(),
//     paymentSettingsFetchTime: new Date()
// };
// export const settingReducer = createSlice({
//     name: "setting",
//     initialState,
//     reducers: {
//         setSetting: (state, action) => {
//             state.status = "fulfilled";
//             state.setting = action.payload.data;
//             state.settingsFetchedTime = new Date();
//         },
//         setPaymentSetting: (state, action) => {   
//             state.status = "fulfill";
//             state.payment_setting = action.payload.data;
//             state.paymentSettingsFetchTime = new Date();
//         },
//     }
// });
// export const { setSetting, setPaymentSetting } = settingReducer.actions;
// export default settingReducer.reducer;


// settingReducer.js


// settingReducer.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    status: 'loading',
    setting: null,
    payment_setting: null,
    settingsFetchedTime: new Date(),
    paymentSettingsFetchTime: new Date(),
    enabledPaymentMethods: [] // Initialize as empty array
};

export const settingReducer = createSlice({
    name: "setting",
    initialState,
    reducers: {
        setSetting: (state, action) => {
            state.status = "fulfilled";
            state.setting = action.payload.data;
            state.settingsFetchedTime = new Date();
        },
        setPaymentSetting: (state, action) => {
            state.status = "fulfill";
            state.payment_setting = action.payload.data;
            state.paymentSettingsFetchTime = new Date();

            // Calculate enabled payment methods when payment settings are set
            const paymentSetting = action.payload.data;
            const enabledMethods = [];

            // Check each payment method safely
            if (paymentSetting?.cod_payment_method === "1") enabledMethods.push('cod');
            if (paymentSetting?.stripe_payment_method === "1") enabledMethods.push('stripe');
            if (paymentSetting?.paypal_payment_method === "1") enabledMethods.push('paypal');
            if (paymentSetting?.razorpay_payment_method === "1") enabledMethods.push('razorpay');
            if (paymentSetting?.paystack_payment_method === "1") enabledMethods.push('paystack');
            if (paymentSetting?.cashfree_payment_method === "1") enabledMethods.push('cashfree');
            if (paymentSetting?.paytabs_payment_method === "1") enabledMethods.push('paytabs');
            if (paymentSetting?.phonepay_payment_method === "1") enabledMethods.push('phonepe');
            if (paymentSetting?.midtrans_payment_method === "1") enabledMethods.push('midtrans');

            state.enabledPaymentMethods = enabledMethods;
        },
    }
});

export const { setSetting, setPaymentSetting } = settingReducer.actions;
export default settingReducer.reducer;