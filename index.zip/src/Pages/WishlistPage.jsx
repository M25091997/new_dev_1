import { ArrowLeft, Heart, Trash2, ShoppingCart, X, Grid, List, ChevronRight } from 'lucide-react';
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { addtoGuestCart } from '../model/reducer/cartReducer';
import { removeFavoriteProduct } from '../model/reducer/favouriteReducer';
import ConfirmationDialogWithImage from '../Components/Dialog/ConfirmationDialogWithImage';
import { toast } from 'react-toastify';
import api from '../api/api';

const WishlistPage = () => {
    const { favouriteProducts } = useSelector((state) => state.favourite);
    const { guestCart } = useSelector((state) => state.cart);
    const { user, status, jwtToken } = useSelector((state) => state.user);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [showConfirmDialog, setShowConfirmDialog] = useState(false);
    const [productToRemove, setProductToRemove] = useState(null);
    const [showAddedToast, setShowAddedToast] = useState(false);
    const [addedProduct, setAddedProduct] = useState(null);
    const [viewMode, setViewMode] = useState('grid');
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
    const [isAddingToCart, setIsAddingToCart] = useState(false);

    const isLoggedIn = status === "fulfill" && jwtToken;

    useEffect(() => {
        const handleResize = () => {
            setIsMobile(window.innerWidth < 768);
        };

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const handleAddToCart = async (product) => {
        if (isAddingToCart) return;

        setIsAddingToCart(true);
        try {
            if (isLoggedIn) {
                // Call API to add to cart for logged in users
                const response = await api.addToCart(
                    jwtToken,
                    product.product_id,
                    product.product_variant_id,
                    1 // Default quantity
                );

                const result = await response.json();

                if (result.status === 1) {
                    toast.success(`${product.name} added to cart`);
                } else {
                    toast.error(result.message || 'Failed to add to cart');
                }
            } else {
                // Add to guest cart for non-logged in users
                const cartItem = {
                    id: product.id,
                    name: product.name,
                    price: parseFloat(product.price.replace(/,/g, '')),
                    image: product.image,
                    product_id: product.product_id,
                    product_variant_id: product.product_variant_id,
                    quantity: 1
                };
                dispatch(addtoGuestCart({ data: cartItem }));
                toast.success(`${product.name} added to cart`);
            }

            setAddedProduct(product);
            setShowAddedToast(true);
            setTimeout(() => setShowAddedToast(false), 3000);
        } catch (error) {
            console.error('Error adding to cart:', error);
            toast.error('Failed to add to cart');
        } finally {
            setIsAddingToCart(false);
        }
    };

    const initiateRemove = (product) => {
        setProductToRemove(product);
        setShowConfirmDialog(true);
    };

    const confirmRemove = async () => {
        if (productToRemove) {
            try {
                if (isLoggedIn) {
                    // Call API to remove from wishlist for logged in users
                    const response = await api.removeFromFavorite(jwtToken, productToRemove.id);
                    const result = await response.json();

                    if (result.status === 1) {
                        dispatch(removeFavoriteProduct({ data: productToRemove.id }));
                        toast.success('Removed from wishlist');
                    } else {
                        toast.error(result.message || 'Failed to remove from wishlist');
                    }
                } else {
                    // Remove from local wishlist for guests
                    dispatch(removeFavoriteProduct({ data: productToRemove.id }));
                    toast.success('Removed from wishlist');
                }
            } catch (error) {
                console.error('Error removing from wishlist:', error);
                toast.error('Failed to remove from wishlist');
            } finally {
                setShowConfirmDialog(false);
                setProductToRemove(null);
            }
        }
    };

    const cancelRemove = () => {
        setShowConfirmDialog(false);
        setProductToRemove(null);
    };

    const handleProductClick = (product) => {
        const breadcrumbs = [
            { name: 'Home', path: '/' },
            { name: 'Wishlist', path: '/wishlist' },
            { name: product.name, path: null }
        ];

        const productDetailData = {
            ...product,
            id: product.id,
            name: product.name,
            image_url: product.image || product.image_url, // Handle both image properties
            images: [product.image || product.image_url], // Ensure images array is populated
            price: `₹${product.price}`,
            originalPrice: `₹${parseInt(product.price) + 1000}`,
            discount: "10% Off",
            rating: 4.5,
            reviews: "10",
            stockStatus: "In Stock",
            description: product.description || "No description available",
            brand: product.brand || product.name.split(' ')[0],
            modelNumber: product.id,
            category: product.category || "General"
        };

        navigate(`/product/${product.slug || product.id}`, {
            state: {
                product: productDetailData,
                breadcrumbs
            }
        });
    };

    const ItemCard = ({ item }) => (
        <div
            className={`relative group bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden cursor-pointer 
        ${viewMode === 'grid' ? 'w-full' : 'flex items-center gap-4 p-4'}`}
        >
            <div
                className={`relative ${viewMode === 'grid' ? 'aspect-square' : 'w-24 sm:w-32'}`}
                onClick={() => handleProductClick(item)}
            >
                <img
                    src={item.image || item.image_url || 'https://via.placeholder.com/300'}
                    alt={item.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = 'https://via.placeholder.com/300';
                    }}
                />
            </div>
            <div
                className={`p-2 ${viewMode === 'grid' ? 'text-center' : 'flex-1'}`}
                onClick={() => handleProductClick(item)}
            >
                <h3 className="text-xs sm:text-sm font-bold text-gray-800 truncate">{item.name}</h3>
                <p className="text-xs text-gray-500 mt-1">₹{item.price}</p>
            </div>

            <div className="absolute top-2 right-2 flex gap-1">
                <button
                    onClick={(e) => {
                        e.stopPropagation();
                        handleAddToCart(item);
                    }}
                    className="p-1.5 bg-white rounded-full shadow hover:bg-gray-100"
                    title="Add to cart"
                    disabled={isAddingToCart}
                >
                    <ShoppingCart size={14} />
                </button>
                <button
                    onClick={(e) => {
                        e.stopPropagation();
                        initiateRemove(item);
                    }}
                    className="p-1.5 bg-white rounded-full shadow hover:bg-gray-100 text-red-500"
                    title="Remove from wishlist"
                >
                    <Trash2 size={14} />
                </button>
            </div>
        </div>
    );

    return (
        <div className="min-h-screen bg-gray-50">
            {showConfirmDialog && (
                <ConfirmationDialogWithImage
                    isOpen={showConfirmDialog}
                    title="Remove from Wishlist"
                    message="Are you sure you want to remove this item from your wishlist?"
                    product={productToRemove}
                    onClose={cancelRemove}
                    onConfirm={confirmRemove}
                />
            )}

            {showAddedToast && (
                <div className="fixed bottom-5 right-5 bg-black bg-opacity-80 text-white px-4 py-3 rounded-lg shadow-lg z-50 flex items-center">
                    <ShoppingCart size={18} className="mr-2" />
                    <p className="text-sm">Added {addedProduct?.name} to cart</p>
                </div>
            )}

            <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
                <div className="hidden md:flex items-center justify-between border-b border-gray-200 pb-5 mb-8">
                    <div className="flex items-center">
                        <Link to="/" className="mr-4 text-gray-600 hover:text-gray-900">
                            <ArrowLeft className="w-5 h-5" />
                        </Link>
                        <h1 className="text-3xl font-bold text-gray-900">My Wishlist</h1>
                    </div>

                    <div className="flex items-center space-x-4">
                        <div className="flex border border-gray-300 rounded-md overflow-hidden">
                            <button
                                onClick={() => setViewMode('grid')}
                                className={`p-2 ${viewMode === 'grid' ? 'bg-gray-200' : 'bg-white'} hover:bg-gray-100`}
                                title="Grid view"
                            >
                                <Grid size={18} className={viewMode === 'grid' ? 'text-gray-800' : 'text-gray-500'} />
                            </button>
                            <button
                                onClick={() => setViewMode('list')}
                                className={`p-2 ${viewMode === 'list' ? 'bg-gray-200' : 'bg-white'} hover:bg-gray-100`}
                                title="List view"
                            >
                                <List size={18} className={viewMode === 'list' ? 'text-gray-800' : 'text-gray-500'} />
                            </button>
                        </div>

                        <Link
                            to="/products"
                            className="text-sm font-medium text-pink-600 hover:text-pink-800 flex items-center"
                        >
                            Continue Shopping
                        </Link>
                    </div>
                </div>

                <div className="md:hidden sticky top-0 bg-gray-50 z-10 py-3 -mx-4 px-4 border-b border-gray-200 mb-4">
                    <div className="flex items-center justify-between">
                        <Link to="/" className="text-gray-600 hover:text-gray-900">
                            <ArrowLeft className="w-5 h-5" />
                        </Link>
                        <h1 className="text-lg font-bold text-gray-900">My Wishlist</h1>
                        <div className="flex space-x-2">
                            <button
                                onClick={() => setViewMode('grid')}
                                className={`p-1 rounded ${viewMode === 'grid' ? 'bg-gray-200' : ''}`}
                            >
                                <Grid size={18} className={viewMode === 'grid' ? 'text-gray-800' : 'text-gray-500'} />
                            </button>
                            <button
                                onClick={() => setViewMode('list')}
                                className={`p-1 rounded ${viewMode === 'list' ? 'bg-gray-200' : ''}`}
                            >
                                <List size={18} className={viewMode === 'list' ? 'text-gray-800' : 'text-gray-500'} />
                            </button>
                        </div>
                    </div>
                </div>

                {favouriteProducts.length > 0 ? (
                    <>
                        <div className="flex justify-between items-center mb-6">
                            <p className="text-gray-500">
                                <span className="font-medium text-gray-700">{favouriteProducts.length}</span> items in your wishlist
                            </p>
                        </div>

                        {viewMode === 'grid' ? (
                            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-6">
                                {favouriteProducts.map((product) => (
                                    <ItemCard key={product.id} item={product} />
                                ))}
                            </div>
                        ) : (
                            <div className="space-y-3">
                                {favouriteProducts.map((product) => (
                                    <div
                                        key={product.id}
                                        className="flex bg-white rounded-lg shadow hover:shadow-md transition overflow-hidden"
                                    >
                                        <div
                                            className="w-24 h-24 md:w-32 md:h-32 flex-shrink-0 cursor-pointer"
                                            onClick={() => handleProductClick(product)}
                                        >
                                            <img
                                                src={product.image}
                                                alt={product.name}
                                                className="w-full h-full object-cover"
                                            />
                                        </div>

                                        <div
                                            className="flex-1 p-3 md:p-4 flex items-center cursor-pointer"
                                            onClick={() => handleProductClick(product)}
                                        >
                                            <div className="flex-1">
                                                <h3 className="text-sm md:text-base font-medium text-gray-800 line-clamp-1 md:line-clamp-2">
                                                    {product.name}
                                                </h3>
                                                <p className="text-sm md:text-base font-semibold text-gray-900 mt-0.5">₹{product.price}</p>
                                                <p className="text-xs text-gray-500 mt-1 hidden md:line-clamp-1">
                                                    {product.description || 'No description available'}
                                                </p>
                                            </div>
                                        </div>

                                        <div className="flex flex-col justify-center items-center pr-2 md:pr-4 pl-2 md:w-48 space-y-2">
                                            <button
                                                onClick={() => handleAddToCart(product)}
                                                className="w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white px-3 py-1.5 md:py-2 rounded text-xs md:text-sm font-medium hover:from-pink-600 hover:to-purple-600 flex items-center justify-center"
                                                disabled={isAddingToCart}
                                            >
                                                <ShoppingCart size={14} className="mr-1" />
                                                <span>Add to Cart</span>
                                            </button>

                                            <button
                                                onClick={() => initiateRemove(product)}
                                                className="w-full border border-gray-300 text-gray-600 px-3 py-1.5 md:py-2 rounded text-xs md:text-sm font-medium hover:bg-gray-50 flex items-center justify-center"
                                            >
                                                <Trash2 size={14} className="mr-1 text-red-500" />
                                                <span>Remove</span>
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </>
                ) : (
                    <div className="text-center py-16 px-4">
                        <div className="bg-pink-50 rounded-full h-24 w-24 flex items-center justify-center mx-auto mb-6">
                            <Heart className="h-12 w-12 text-pink-500" />
                        </div>
                        <h3 className="mt-2 text-xl font-semibold text-gray-900">Your wishlist is empty</h3>
                        <p className="mt-2 text-gray-500 max-w-md mx-auto">Start adding products you love to your wishlist to save them for later.</p>
                        <div className="mt-8">
                            <Link
                                to="/products"
                                className="inline-flex items-center px-6 py-3 border border-transparent rounded-full shadow-sm text-base font-medium text-white bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 transition-all"
                            >
                                Discover Products
                            </Link>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default WishlistPage;