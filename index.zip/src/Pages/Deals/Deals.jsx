"use client"

import { useEffect, useState, useRef, useCallback } from "react"
import { useSelector } from "react-redux"
import ProductCard from "../../Components/ProductCard"

const Deals = () => {
    const city = useSelector((state) => state.city.city)
    const [products, setProducts] = useState([])
    const [filteredProducts, setFilteredProducts] = useState([])
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null)
    const [offset, setOffset] = useState(0)
    const [hasMore, setHasMore] = useState(true)
    const limit = 12
    const observer = useRef()

    // Safely get latitude and longitude with defaults
    const latitude = Number.parseFloat(city?.latitude)
    const longitude = Number.parseFloat(city?.longitude)
    console.log("Current coordinates:", latitude, longitude)

    const fetchProducts = useCallback(async () => {
        if (!hasMore || !latitude || !longitude) return;

        try {
            setLoading(true);
            setError(null);

            const response = await fetch("https://admin.bringmart.in/customer/products", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "x-access-key": "903361",
                },
                body: JSON.stringify({
                    latitude,
                    longitude,
                    limit,
                    offset,
                }),
            });

            const data = await response.json();

            if (data.status === 1) {
                // Calculate discount and filter products
                const discountedProducts = data.data
                    .map((product) => {
                        // Calculate discount percentage if not provided
                        if (
                            product.price &&
                            product.discounted_price &&
                            product.price !== product.discounted_price
                        ) {
                            product.discount = Math.round(
                                ((product.price - product.discounted_price) / product.price) * 100
                            );
                        }
                        return product;
                    })
                    .filter((product) => product.price !== product.discounted_price);

                setProducts((prevProducts) => [...prevProducts, ...data.data]);
                setFilteredProducts((prevProducts) => [...prevProducts, ...discountedProducts]);
                setOffset((prevOffset) => prevOffset + limit);
                setHasMore(data.data?.length === limit);
            } else {
                throw new Error(data.message || "Failed to fetch products");
            }
        } catch (err) {
            console.error("API Error:", err);
            setError(err.message || "Failed to fetch products");
        } finally {
            setLoading(false);
        }
    }, [latitude, longitude, offset, hasMore, limit]);


    // Infinite scroll implementation
    const lastProductRef = useCallback(
        (node) => {
            if (loading) return
            if (observer.current) observer.current.disconnect()

            observer.current = new IntersectionObserver((entries) => {
                if (entries[0].isIntersecting && hasMore) {
                    console.log("Reached last product, loading more...")
                    fetchProducts()
                }
            })

            if (node) observer.current.observe(node)
        },
        [loading, hasMore, fetchProducts],
    )

    // Initial fetch
    useEffect(() => {
        console.log("Initializing product fetch with new coordinates")
        setProducts([])
        setFilteredProducts([])
        setOffset(0)
        setHasMore(true)
        fetchProducts()
    }, [latitude, longitude])

    console.log("Current product counts:", {
        allProducts: products.length,
        discountedProducts: filteredProducts.length,
        loading,
        hasMore,
    })

    if (error) {
        console.error("Render error:", error)
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl shadow-lg p-6 max-w-sm w-full text-center">
                    <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg className="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                            />
                        </svg>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Oops! Something went wrong</h3>
                    <p className="text-gray-600 text-sm">{error}</p>
                </div>
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Header Section */}
            <div className="bg-gradient-to-r from-[#fc2e6c] to-[#ff4081] text-white">
                <div className="px-4 py-8">
                    <div className="flex items-center justify-between mb-4">
                        <div>
                            <h1 className="text-2xl font-bold mb-1">🔥 Hot Deals</h1>
                            <p className="text-pink-100 text-sm">Exclusive discounts just for you</p>
                        </div>

                    </div>

                    {/* Stats Bar */}
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
                        <div className="flex items-center justify-between text-sm">

                            <div className="w-px h-8 bg-white/20"></div>
                            <div className="text-center">
                                <div className="font-semibold">Up to 70%</div>
                                <div className="text-pink-100 text-xs">Off</div>
                            </div>
                            <div className="w-px h-8 bg-white/20"></div>
                            <div className="text-center">
                                <div className="font-semibold">Limited</div>
                                <div className="text-pink-100 text-xs">Time</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Content Section */}
            <div className="px-4 py-6">
                {filteredProducts.length === 0 && !loading ? (
                    <div className="text-center py-16">
                        <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={1.5}
                                    d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M9 9l3-3 3 3"
                                />
                            </svg>
                        </div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">No deals available</h3>
                        <p className="text-gray-500 text-sm max-w-xs mx-auto">
                            We're working hard to bring you the best deals. Check back soon!
                        </p>
                    </div>
                ) : (
                    <>
                        {/* Products Grid */}
                        <div className="grid grid-cols-2 gap-3 mb-6">
                            {filteredProducts.map((product, index) => {
                                const isLastItem = index === filteredProducts.length - 1
                                console.log(`Rendering product ${index}`, {
                                    productId: product.id,
                                    isLastItem,
                                    price: product.price,
                                    discountedPrice: product.discounted_price,
                                })

                                return (
                                    <div
                                        ref={isLastItem ? lastProductRef : null}
                                        key={`${product.id}-${index}`}
                                        className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all duration-200 hover:scale-[1.02]"
                                    >
                                        <ProductCard product={product} gradient="from-[#fc2e6c] to-[#ff4081]" />
                                    </div>
                                )
                            })}
                        </div>

                        {/* Loading State */}
                        {loading && (
                            <div className="flex flex-col items-center justify-center py-8">
                                <div className="relative">
                                    <div className="w-12 h-12 border-4 border-gray-200 rounded-full"></div>
                                    <div className="absolute top-0 left-0 w-12 h-12 border-4 border-[#fc2e6c] border-t-transparent rounded-full animate-spin"></div>
                                </div>
                                <p className="text-gray-500 text-sm mt-3">Loading more deals...</p>
                            </div>
                        )}

                        {/* End of Results */}
                        {!hasMore && filteredProducts.length > 0 && (
                            <div className="text-center py-8">
                                <div className="inline-flex items-center justify-center w-12 h-12 bg-gray-100 rounded-full mb-3">
                                    <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                                <p className="text-gray-500 text-sm font-medium">You've seen all deals!</p>
                                <p className="text-gray-400 text-xs mt-1">Check back later for new offers</p>
                            </div>
                        )}
                    </>
                )}
            </div>

            {/* Floating Action Button for Refresh */}
            {error && (
                <button
                    onClick={() => window.location.reload()}
                    className="fixed bottom-6 right-4 bg-[#fc2e6c] text-white p-4 rounded-full shadow-lg hover:bg-[#e91e63] transition-colors duration-200"
                >
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                        />
                    </svg>
                </button>
            )}
        </div>
    )
}

export default Deals
