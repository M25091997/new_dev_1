import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { LogOut, Edit3, User, Mail, Phone, Camera, Check, Upload } from 'lucide-react';
import { logoutAuth, setCurrentUser } from '../model/reducer/authReducer';
import api from '../api/api';
import { toast } from 'react-toastify';

export default function MyAccount() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { user, status, jwtToken } = useSelector((state) => state.user);
    const setting = useSelector((state) => state.setting);

    // Edit state
    const [isEditing, setIsEditing] = useState(false);
    const [formData, setFormData] = useState({
        name: user?.name || '',
        email: user?.email || '',
        mobile: user?.mobile || '',
    });
    const [selectedFile, setSelectedFile] = useState(null);
    const [isUpdating, setIsUpdating] = useState(false);

    // Redirect to login if not authenticated
    useEffect(() => {
        if (status !== 'fulfill' || !user) {
            navigate('/login');
        } else {
            setFormData({
                name: user.name || '',
                email: user.email || '',
                mobile: user.mobile || '',
            });
        }
    }, [status, user, navigate]);

    const handleLogout = () => {
        const confirmLogout = window.confirm('Are you sure you want to logout?');
        if (confirmLogout) {
            dispatch(logoutAuth());
            navigate('/');
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleFileChange = (e) => {
        setSelectedFile(e.target.files[0]);
    };

    const placeHolderImage = (e) => {
        e.target.src = setting.setting?.web_logo;
    };

    const handleUpdateProfile = async (e) => {
        e.preventDefault();
        setIsUpdating(true);

        try {
            let response;
            if (selectedFile) {
                // Validate file type if a file is selected
                if (!["image/png", "image/jpg", "image/jpeg"].includes(selectedFile.type)) {
                    toast.error("Only PNG, JPG, and JPEG files are allowed");
                    setIsUpdating(false);
                    return;
                }

                response = await api.edit_profile(
                    formData.name,
                    formData.email,
                    formData.mobile,
                    selectedFile,
                    jwtToken
                );
            } else {
                response = await api.edit_profile(
                    formData.name,
                    formData.email,
                    formData.mobile,
                    null,
                    jwtToken
                );
            }

            const result = await response.json();

            if (result.status === 1) {
                toast.success(result?.message || "Profile updated successfully");
                // Refresh user data
                const userResponse = await api.getUser(jwtToken);
                const userResult = await userResponse.json();
                if (userResult.status === 1) {
                    dispatch(setCurrentUser({ data: userResult.user }));
                }
                setIsEditing(false);
                setSelectedFile(null);
            } else {
                toast.error(result.message || "Update failed");
            }
        } catch (error) {
            console.error("Update error:", error);
            toast.error("An error occurred during update");
        } finally {
            setIsUpdating(false);
        }
    };

    const cancelEdit = () => {
        setFormData({
            name: user.name || '',
            email: user.email || '',
            mobile: user.mobile || '',
        });
        setSelectedFile(null);
        setIsEditing(false);
    };

    if (status !== 'fulfill' || !user) {
        return null;
    }

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Header */}
            <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
                <div className="max-w-4xl mx-auto px-4 py-4 flex justify-between items-center">
                    <h1 className="text-xl font-semibold text-gray-900">My Account</h1>

                </div>
            </div>

            <div className="max-w-4xl mx-auto px-4 py-6">
                <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-200">
                    {/* Profile Section */}
                    <div className="p-6 border-b border-gray-200">
                        <div className="flex flex-col md:flex-row md:items-center gap-6">
                            {/* Profile Image */}
                            <div className="relative mx-auto md:mx-0">
                                <div className="w-24 h-24 rounded-full overflow-hidden bg-gray-100 border-4 border-white shadow-sm">
                                    {selectedFile ? (
                                        <img
                                            src={URL?.createObjectURL(selectedFile)}
                                            alt="userProfileImage"
                                            className="w-full h-full object-cover"
                                        />
                                    ) : (
                                        <img
                                            onError={placeHolderImage}
                                            src={user?.profile || setting.setting?.web_logo}
                                            alt="profile"
                                            className="w-full h-full object-cover"
                                        />
                                    )}
                                </div>
                                {isEditing && (
                                    <label htmlFor="profile-image" className="absolute -bottom-1 -right-1 cursor-pointer">
                                        <div className="w-8 h-8 bg-[#fc2e6bed] hover:bg-[#ff437bed] rounded-full flex items-center justify-center shadow-lg transition-colors">
                                            <Camera className="w-4 h-4 text-white" />
                                        </div>
                                        <input
                                            type="file"
                                            id="profile-image"
                                            onChange={handleFileChange}
                                            className="hidden"
                                            accept="image/png, image/jpeg, image/jpg"
                                        />
                                    </label>
                                )}
                            </div>

                            {/* Profile Info */}
                            <div className="flex-1 text-center md:text-left">
                                {isEditing ? (
                                    <div className="space-y-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                                            <input
                                                type="text"
                                                name="name"
                                                value={formData.name}
                                                onChange={handleInputChange}
                                                disabled={user.authType === "google"}
                                                className={`w-full px-4 py-2 border rounded-lg ${user.authType === "google" ? 'bg-gray-100 cursor-not-allowed' : 'bg-white'}`}
                                            />
                                            {user.authType === "google" && (
                                                <p className="text-xs text-gray-500 mt-1">Name cannot be changed for Google accounts</p>
                                            )}
                                        </div>
                                    </div>
                                ) : (
                                    <>
                                        <h2 className="text-xl font-semibold text-gray-900">{user.name}</h2>
                                        <p className="text-gray-600">{user.email}</p>
                                        {selectedFile && (
                                            <div className="inline-flex items-center mt-2 px-3 py-1 bg-green-50 border border-green-200 rounded-full text-sm text-green-700">
                                                <Check className="w-4 h-4 mr-1" />
                                                New image selected
                                            </div>
                                        )}
                                    </>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Details Section */}
                    <div className="p-6">
                        <div className="space-y-6">
                            {/* Personal Information */}
                            <div className="space-y-4">
                                <h3 className="font-medium text-gray-900 text-lg">Personal Information</h3>
                                {isEditing ? (
                                    <>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                                            <div className="relative">
                                                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                                                <input
                                                    type="email"
                                                    name="email"
                                                    value={formData.email}
                                                    onChange={handleInputChange}
                                                    disabled={user.authType === "google"}
                                                    className={`w-full pl-10 pr-4 py-2 border rounded-lg ${user.authType === "google" ? 'bg-gray-100 cursor-not-allowed' : 'bg-white'}`}
                                                />
                                            </div>
                                            {user.authType === "google" && (
                                                <p className="text-xs text-gray-500 mt-1">Email cannot be changed for Google accounts</p>
                                            )}
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                                            <div className="relative">
                                                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                                                <input
                                                    type="tel"
                                                    name="mobile"
                                                    value={formData.mobile}
                                                    onChange={handleInputChange}
                                                    disabled={user.authType === "phone"}
                                                    className={`w-full pl-10 pr-4 py-2 border rounded-lg ${user.authType === "phone" ? 'bg-gray-100 cursor-not-allowed' : 'bg-white'}`}
                                                />
                                            </div>
                                            {user.authType === "phone" && (
                                                <p className="text-xs text-gray-500 mt-1">Phone number cannot be changed for phone-verified accounts</p>
                                            )}
                                        </div>
                                    </>
                                ) : (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <p className="text-sm text-gray-500">Email</p>
                                            <p className="font-medium">{user.email}</p>
                                        </div>
                                        <div>
                                            <p className="text-sm text-gray-500">Mobile</p>
                                            <p className="font-medium">{user.country_code} {user.mobile}</p>
                                        </div>
                                    </div>
                                )}
                            </div>

                            {/* Account Details */}
                            <div className="space-y-4">
                                <h3 className="font-medium text-gray-900 text-lg">Account Details</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-sm text-gray-500">Referral Code</p>
                                        <p className="font-medium">{user.referral_code}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-500">Account Balance</p>
                                        <p className="font-medium">₹{user.balance}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-500">Date Of Birth</p>
                                        <p className="font-medium">{user.dob}</p>
                                    </div>
                                    {
                                        user?.status == 1 ? (
                                            <div>
                                                <p className="text-sm text-gray-500">Account Status</p>
                                                <p className="font-medium text-green-600">Active</p>
                                            </div>
                                        ) : (
                                            <div>
                                                <p className="text-sm text-gray-500">Account Status</p>
                                                <p className="font-medium text-red-600">Inactive</p>
                                            </div>
                                        )
                                    }

                                </div>
                            </div>

                            {/* Logout Button */}
                            <div className="pt-4">
                                {isEditing ? (
                                    <div className="flex gap-2">
                                        <button
                                            onClick={cancelEdit}
                                            className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                                        >
                                            Cancel
                                        </button>
                                        <button
                                            onClick={handleUpdateProfile}
                                            disabled={isUpdating}
                                            className={`px-4 py-2 text-sm font-medium text-white rounded-lg transition-colors ${isUpdating ? 'bg-[#fc2e6b99]' : 'bg-[#fc2e6bed] hover:bg-[#ff437bed]'}`}
                                        >
                                            {isUpdating ? 'Saving...' : 'Save Changes'}
                                        </button>
                                    </div>
                                ) : (
                                    <button
                                        onClick={() => setIsEditing(true)}
                                        className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-[#fc2e6bed] rounded-lg hover:bg-[#ff437bed] transition-colors"
                                    >
                                        <Edit3 className="w-4 h-4" />
                                        Edit Profile
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}