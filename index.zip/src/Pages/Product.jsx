import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import ProductListingPage from "../Components/ProductListingPage";

const Product = () => {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const searchQuery = searchParams.get('search');

  // const paths = searchQuery
  //   ? ["Home", "Search", `"${searchQuery}"`]
  //   : ["Home", "Products"];

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <>
      <div className="container mx-auto px-2 md:px-5 mb-20 md:mb-2 bg-gray-50 sm:mb-10">
        {/* <Breadcrumbs paths={paths} /> */}

        {/* Flex container for the main content */}
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Main content area */}
          <div className="w-full">
            <div className="w-full bg-white p-4 rounded-lg shadow-sm">
              <ProductListingPage />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Product;