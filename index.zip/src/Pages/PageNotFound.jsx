import { useEffect, useState } from "react";

const PageNotFound = () => {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768); // Initial check
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    window.addEventListener("resize", handleResize); // Add listener
    return () => window.removeEventListener("resize", handleResize); // Clean up
  }, []);
  return (
    <>
      <div className="flex items-center justify-center">
        <div className="text-center p-8 h-full bg-white rounded-lg">
          <h1 className="text-6xl font-bold text-amber-500">404</h1>
          <p className="mt-4 text-xl text-gray-700">
            Oops! The page you're looking for doesn't exist.
          </p>
          <p className="mt-4 text-lg text-gray-500">
            It may have been moved or deleted.
          </p>
          <a
            href="/"
            className="mt-6 inline-block px-6 py-2 text-white bg-amber-500 rounded-full hover:bg-blue-700"
          >
            Go Home
          </a>
        </div>
      </div>
    </>
  );
};

export default PageNotFound;
