import { useEffect, useState } from "react";
import Breadcrumbs from "../Components/Breadcrumbs";
import Footer from "../Components/Footer";
import DesktopDetails from "../Components/ProductDetails/DesktopDetails";
import MobileDetails from "../Components/ProductDetails/MobileDetails";
import ProductList from "../Components/ProductList";

const ProductDetails = () => {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768); // Initial check
  const paths = ["Home", "Category", "Product", "Details"];
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    window.addEventListener("resize", handleResize); // Add listener
    return () => window.removeEventListener("resize", handleResize); // Clean up
  }, []);

  const images = [
    "https://f.nooncdn.com/p/pnsku/N70105561V/45/_/1725964965/e9c10f81-ed4f-43af-99f9-7f8ca0c0b14f.jpg",
    "https://f.nooncdn.com/p/pnsku/N70105561V/45/_/1725964966/5bbadbf9-a5c2-4a94-bfb7-16a32d650289.jpg",
    "https://f.nooncdn.com/p/pnsku/N70105561V/45/_/1725964968/6d7def6c-adda-4e13-9aee-bd1a8ab5ea30.jpg",
    "https://f.nooncdn.com/p/pnsku/N70105561V/45/_/1725964967/ae6a835a-a869-481f-9095-50486bef23e9.jpg",
    "https://f.nooncdn.com/p/pnsku/N70105561V/45/_/1725964967/ae6a835a-a869-481f-9095-50486bef23e9.jpg",
  ];


  return (
    <>
      <div className="container mx-auto px-2 md:px-5 mb-20 md:mb-2 bg-gray-50 sm:mb-10">
        <Breadcrumbs paths={paths} />
        {!isMobile ? (<>

          <DesktopDetails images={images} />

        </>) : (<>
          <MobileDetails images={images} />
        </>)}
        <div className="productDescription my-2 bg-white p-2">
          <h1 className="text-2xl font-bold font-sans">Product Description</h1>
          <p className="text-gray-600 font-sans">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla
            ultricies, dui at pellentesque aliquet, nisl nunc ultricies
            nisl, ut mollis nisl nunc ultricies nisl. Nulla ultricies, dui at
            pellentesque aliquet, nisl nunc ultricies nisl, ut mollis nisl
            nunc ultricies nisl. Nulla ultricies, dui at pellentesque aliquet,
            nisl nunc ultricies nisl, ut mollis nisl nunc ultricies nisl.
          </p>
        </div>

        <ProductList title="Related Products" />

        <ProductList title="More From This Seller" />
      </div>
      <Footer />
    </>
  );
};

export default ProductDetails;
