import { useState, useEffect, useLayoutEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle, ShoppingBag, Truck, FileText, Package, CreditCard, Phone, MapPin } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Confetti from "../../Components/Confetti/Confetti";

export default function OrderConfirmation() {
  const [orderDetails, setOrderDetails] = useState(null);
  const [calculatedTotal, setCalculatedTotal] = useState(0);
  const navigate = useNavigate();

  useLayoutEffect(() => {
    window.scrollTo(0, 0); // Runs before paint — no visual jump
  }, []);

  useEffect(() => {
    const savedOrder = localStorage.getItem('orderConfirmation');

    if (!savedOrder) {
      navigate('/');
      return;
    }

    try {
      const orderData = JSON.parse(savedOrder);

      // Calculate total manually
      const total = (orderData.subtotal || 0) +
        (orderData.deliveryCharge || 0) +
        (orderData.handlingFee || 0) +
        (orderData.gstOnHandlingFee || 0) -
        (orderData.discount || 0) -
        (orderData.walletDeduction || 0);

      // Ensure total is not negative
      const finalTotal = Math.max(total, 0);

      setOrderDetails(orderData);
      setCalculatedTotal(finalTotal);
    } catch (error) {
      console.error("Failed to parse order data:", error);
      navigate('/');
    }
  }, [navigate]);

  if (!orderDetails) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  // Format date
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-4 relative overflow-hidden">
      <Confetti />

      <motion.div
        className="relative bg-white/95 backdrop-blur-2xl border border-white/20 rounded-3xl shadow-2xl p-8 w-full max-w-2xl text-center z-20 overflow-hidden"
        initial={{ scale: 0.8, opacity: 0, y: 40 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 25,
          delay: 0.2,
        }}
      >
        {/* Success Icon */}
        <div className="relative inline-flex justify-center items-center mb-8">
          <div className="absolute w-24 h-24 bg-emerald-100 rounded-full animate-ping opacity-30"></div>
          <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center shadow-lg">
            <CheckCircle className="w-12 h-12 text-emerald-500" />
          </div>
        </div>

        {/* Main heading */}
        <h1 className="text-4xl font-bold bg-gradient-to-r from-slate-800 via-slate-700 to-slate-800 bg-clip-text text-transparent mb-4 tracking-tight">
          Order Confirmed!
        </h1>

        <p className="text-lg text-slate-600 mb-8">
          Thank you for your order #{orderDetails.orderId}
        </p>

        {/* Order Summary Section */}
        <div className="relative bg-white/80 backdrop-blur-xl border border-slate-200/50 rounded-2xl p-6 mt-8 mb-8 shadow-xl text-left">
          <h3 className="font-bold text-slate-800 text-xl mb-4 flex items-center gap-2">
            <Package className="text-[#fc2e6bed]" />
            Order Summary
          </h3>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-slate-600">Order Number:</span>
              <span className="font-semibold">#{orderDetails.orderId}</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-600">Order Date:</span>
              <span className="font-semibold">{formatDate(orderDetails.orderDate)}</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-600">Delivery Method:</span>
              <span className="font-semibold">
                {orderDetails.deliveryOption === 'instant' ? 'Instant Delivery' : 'Scheduled Delivery'}
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-600">Estimated Delivery:</span>
              <span className="font-semibold">
                {orderDetails.deliveryOption === 'instant' ?
                  '15-30 minutes' :
                  orderDetails.deliveryTime}
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-600">Payment Method:</span>
              <span className="font-semibold">
                {orderDetails.paymentMethod === 'cod' ?
                  'Cash on Delivery' :
                  orderDetails.paymentMethod.charAt(0).toUpperCase() + orderDetails.paymentMethod.slice(1)}
              </span>
            </div>

            <div className="h-px bg-gradient-to-r from-transparent via-slate-300 to-transparent my-4"></div>

            <div className="flex justify-between items-center">
              <span className="text-slate-600">Subtotal:</span>
              <span className="font-semibold">₹{orderDetails.subtotal.toFixed(2)}</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-600">Delivery Fee:</span>
              <span className="font-semibold">₹{orderDetails.deliveryCharge.toFixed(2)}</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-600">Handling Fee:</span>
              <span className="font-semibold">₹{orderDetails.handlingFee.toFixed(2)}</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-600">GST and Charges:</span>
              <span className="font-semibold">₹{orderDetails.gstOnHandlingFee.toFixed(2)}</span>
            </div>

            {orderDetails.discount > 0 && (
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Discount:</span>
                <span className="font-semibold text-green-600">
                  -₹{orderDetails.discount.toFixed(2)}
                </span>
              </div>
            )}

            {orderDetails.walletDeduction > 0 && (
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Wallet Credit:</span>
                <span className="font-semibold text-green-600">
                  -₹{orderDetails.walletDeduction.toFixed(2)}
                </span>
              </div>
            )}

            <div className="h-px bg-gradient-to-r from-transparent via-slate-300 to-transparent my-4"></div>

            <div className="flex justify-between items-center">
              <span className="text-lg font-semibold">Total Amount:</span>
              <span className="text-xl font-bold text-[#fc2e6bed]">
                ₹{calculatedTotal.toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="sm:flex-row gap-4 mt-8">
          <motion.button
            className="group relative flex items-center justify-center gap-3 bg-[#fc2e6bed] hover:bg-[#e64e7ced] text-white font-semibold py-3 px-6 rounded-xl shadow-lg transition-all duration-300 flex-1 overflow-hidden"
            whileHover={{ scale: 1.02, y: -1 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate('/')}
          >
            <ShoppingBag size={20} />
            Continue Shopping
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}