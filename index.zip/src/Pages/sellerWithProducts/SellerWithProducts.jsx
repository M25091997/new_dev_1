"use client"

import { useState, useEffect } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { MapPin, Package, Store, Star, ChevronLeft, AlertCircle } from "lucide-react"
import sellerBanner from "../../assets/images/sellerWithProducts.png"
import ProductCard from "../../Components/ProductCard"

const SellerWithProducts = () => {
    const { sellerName } = useParams()
    const navigate = useNavigate()
    const [seller, setSeller] = useState(null)
    const [products, setProducts] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)
    const [totalProducts, setTotalProducts] = useState(0)
    const [offset, setOffset] = useState(0)
    const [hasMore, setHasMore] = useState(true)
    const [isLoadingMore, setIsLoadingMore] = useState(false)

    const sellerId = new URLSearchParams(window.location.search).get("seller_id")

    useEffect(() => {
        window.scroll(0, 0)
    }, [])

    const fetchSellerAndProducts = async (currentOffset = 0) => {
        try {
            const isInitialLoad = currentOffset === 0
            if (!isInitialLoad) setIsLoadingMore(true)

            setError(null)

            if (!sellerId) {
                throw new Error("Seller ID not found")
            }

            const response = await fetch(
                `https://admin.bringmart.in/customer/sellers/${sellerId}?offset=${currentOffset}`
            )

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`)
            }

            const data = await response.json()

            if (data?.status === 1 && data?.data) {
                if (isInitialLoad) {
                    setSeller(data?.data?.seller)
                    setTotalProducts(data?.data?.total_products || 0)
                }

                const newProducts = data.data.products || []
                const transformedProducts = newProducts.map((product) => {
                    const firstVariant = product.variants?.[0]
                    const price = firstVariant?.price || 0
                    const discountedPrice = firstVariant?.discounted_price || price
                    const discount = price > 0 ? Math.round(((price - discountedPrice) / price) * 100) : 0

                    return {
                        ...product,
                        id: product.id.toString(),
                        image: product.image_url,
                        image_url: product.image_url,
                        price: price,
                        discounted_price: discountedPrice,
                        discount: discount,
                        seller: data.data.seller.store_name,
                        free_delivery: false,
                        express: false,
                        rating: Number.parseFloat(product.rating || 0),
                        rating_count: product.total_rating || 0,
                        variants: product.variants || [],
                        status: product.status || 1,
                        is_unlimited_stock: product.is_unlimited_stock || 0,
                        stock: firstVariant?.stock || 0,
                        stock_unit_name: firstVariant?.stock_unit_name || "PC",
                    }
                })

                if (isInitialLoad) {
                    setProducts(transformedProducts)
                } else {
                    setProducts(prev => [...prev, ...transformedProducts])
                }

                // Check if we've loaded all products
                if (newProducts.length === 0 || (data.data.products && data.data.products.length < 10)) {
                    setHasMore(false)
                }
            } else {
                throw new Error(data.message || "Failed to fetch seller data")
            }
        } catch (err) {
            setError(err.message || "An unknown error occurred")
        } finally {
            setLoading(false)
            setIsLoadingMore(false)
        }
    }

    useEffect(() => {
        fetchSellerAndProducts(0)
    }, [sellerId])

    const handleLoadMore = () => {
        const newOffset = offset + 10
        setOffset(newOffset)
        fetchSellerAndProducts(newOffset)
    }

    function decodeHTMLEntities(text) {
        const txt = document.createElement("textarea")
        txt.innerHTML = text
        return txt.value
    }

    if (loading && offset === 0) {
        return (
            <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
                <div className="relative mb-6">
                    <div className="w-16 h-16 border-3 border-gray-200 border-t-blue-600 rounded-full animate-spin"></div>
                </div>
                <div className="text-center">
                    <h3 className="text-lg font-medium text-gray-900 mb-1">Loading Seller Details</h3>
                    <p className="text-sm text-gray-500">Please wait...</p>
                </div>
            </div>
        )
    }

    if (error) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
                <div className="text-center p-6 bg-white rounded-2xl shadow-sm border max-w-sm w-full">
                    <div className="w-16 h-16 mx-auto mb-4 bg-red-50 rounded-full flex items-center justify-center">
                        <AlertCircle className="w-8 h-8 text-red-500" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Something went wrong</h3>
                    <p className="text-sm text-red-600 mb-4">{error}</p>
                    <button
                        onClick={() => navigate(-1)}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200"
                    >
                        Go Back
                    </button>
                </div>
            </div>
        )
    }

    if (!seller) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
                <div className="text-center p-6 bg-white rounded-2xl shadow-sm max-w-sm w-full">
                    <div className="w-16 h-16 mx-auto mb-4 bg-gray-50 rounded-full flex items-center justify-center">
                        <Store className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Seller Not Found</h3>
                    <p className="text-sm text-gray-500 mb-4">The seller you're looking for doesn't exist.</p>
                    <button
                        onClick={() => navigate(-1)}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200"
                    >
                        Go Back
                    </button>
                </div>
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Header with Back Button */}
            <div className="bg-white border-b border-gray-200 sticky top-0 z-40">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center h-16">
                        <button
                            onClick={() => navigate(-1)}
                            className="flex items-center text-gray-600 hover:text-gray-900 transition-colors duration-200"
                        >
                            <ChevronLeft className="w-5 h-5 mr-1" />
                            <span className="font-medium">Back</span>
                        </button>
                    </div>
                </div>
            </div>

            {/* Seller Banner - Smaller and More Modern */}
            <div className="relative w-full">
                <div className="h-32 sm:h-40 md:h-48 overflow-hidden">
                    <img
                        src={sellerBanner || "/placeholder.svg"}
                        alt="Seller Banner"
                        className="w-full h-full object-cover"
                    />
                </div>
            </div>

            {/* Seller Info Card - Compact and Modern */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="relative -mt-16 mb-8">
                    <div className="bg-white rounded-2xl shadow-sm border p-6">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                            {/* Smaller Logo */}
                            <div className="w-20 h-20 rounded-xl border-2 border-gray-100 shadow-sm overflow-hidden bg-white flex-shrink-0">
                                <img
                                    src={seller.logo_url || "/placeholder.svg"}
                                    alt={seller.store_name}
                                    className="w-full h-full object-contain"
                                    onError={(e) => {
                                        e.target.src = "/placeholder.svg"
                                    }}
                                />
                            </div>

                            <div className="flex-1 min-w-0">
                                <h1 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2 truncate">{seller.store_name}</h1>

                                {/* Compact Stats */}
                                <div className="flex flex-wrap items-center gap-4 mb-3">
                                    <div className="flex items-center text-sm text-gray-600">
                                        <MapPin className="w-4 h-4 mr-1 text-gray-400" />
                                        <span>
                                            {(seller.formatted_address && seller.formatted_address.split(', ').slice(1).join(', ')) || "N/A"}
                                        </span>

                                    </div>
                                    <div className="flex items-center text-sm text-gray-600">
                                        <Package className="w-4 h-4 mr-1 text-gray-400" />
                                        <span>{totalProducts} products</span>
                                    </div>
                                    <div className="flex items-center text-sm text-amber-600">
                                        <Star className="w-4 h-4 mr-1 fill-current" />
                                        <span className="font-medium">4.5</span>
                                    </div>
                                </div>

                                {/* Compact Description */}
                                <p className="text-sm text-gray-600 line-clamp-2">
                                    {decodeHTMLEntities(
                                        seller.store_description?.replace(/<[^>]+>/g, "") || "This seller hasn't added a description yet.",
                                    )}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Products Section */}
                <div className="pb-8">
                    <div className="flex items-center justify-between mb-6">
                        <h2 className="text-xl font-bold text-gray-900">Products</h2>
                        <span className="text-sm text-gray-500">{products.length} of {totalProducts} items</span>
                    </div>

                    {products.length === 0 ? (
                        <div className="text-center py-12 bg-white rounded-2xl shadow-sm border">
                            <Package className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                            <h3 className="text-lg font-medium text-gray-700 mb-2">No Products Available</h3>
                            <p className="text-sm text-gray-500">This seller hasn't added any products yet.</p>
                        </div>
                    ) : (
                        <>
                            {/* Smaller, more compact grid */}
                            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-3 sm:gap-4">
                                {products.map((product) => (
                                    <div key={product.id} className="transform transition-transform duration-200 hover:scale-105">
                                        <ProductCard product={product} gradient="from-blue-500 to-indigo-600" />
                                    </div>
                                ))}
                            </div>

                            {/* Load More Button */}
                            {hasMore && (
                                <div className="text-center mt-8">
                                    <button
                                        onClick={handleLoadMore}
                                        disabled={isLoadingMore}
                                        className={`bg-[#fc2e6b] hover:bg-[#ff4b84] active:bg-[#e1205e] text-white font-semibold py-3 px-6 rounded-2xl transition-all duration-200 shadow-md hover:shadow-lg border border-[#fc2e6b] ${isLoadingMore ? "opacity-70 cursor-not-allowed" : ""
                                            }`}
                                    >
                                        {isLoadingMore ? (
                                            <span className="flex items-center justify-center">
                                                <svg
                                                    className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fill="none"
                                                    viewBox="0 0 24 24"
                                                >
                                                    <circle
                                                        className="opacity-25"
                                                        cx="12"
                                                        cy="12"
                                                        r="10"
                                                        stroke="currentColor"
                                                        strokeWidth="4"
                                                    ></circle>
                                                    <path
                                                        className="opacity-75"
                                                        fill="currentColor"
                                                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                                    ></path>
                                                </svg>
                                                Loading...
                                            </span>
                                        ) : (
                                            "✨ Load More Products"
                                        )}
                                    </button>
                                </div>
                            )}

                            {!hasMore && products.length > 0 && (
                                <div className="text-center mt-8">
                                    <p className="text-sm text-gray-500">You've seen all products from this seller</p>
                                </div>
                            )}
                        </>
                    )}
                </div>
            </div>
        </div>
    )
}

export default SellerWithProducts