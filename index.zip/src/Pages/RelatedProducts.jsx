import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import ProductCard from "../components/ProductCard";

const RelatedProductsPage = ({ product }) => {
    const { jwtToken } = useSelector((state) => state.user);
    const navigate = useNavigate();
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const { city } = useSelector((state) => state.city);

    useEffect(() => {
        const fetchRelatedProducts = async () => {
            if (!product || !product?.slug || !product?.tag_names) {
                console.error("Product tags missing");
                setLoading(false);
                return;
            }

            setLoading(true);
            try {
                const latitude = city?.city?.latitude || 28.6139;
                const longitude = city?.city?.longitude || 77.209;
                const tagNames = product.tag_names
                    .split(",")
                    .map((tag) => tag.trim())
                    .join(",");

                const payload = {
                    latitude,
                    longitude,
                    tag_names: tagNames,
                    tag_slug: product.tag_slug,
                    limit: 10,
                    offset: 0,
                };

                const response = await fetch("https://admin.bringmart.in/customer/products", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${jwtToken}`,
                    },
                    body: JSON.stringify(payload),
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const result = await response.json();

                if (result.status === 1) {
                    const transformedProducts = (result.data || [])
                        .filter(p => p.id !== product.id)
                        .map(item => ({
                            ...item,
                            image: item.image_url,
                            discount: item.cal_discount_percentage,
                            rating: item.average_rating || 4.5,
                            rating_count: item.rating_count || 0,
                            seller_name: item.seller_name || (item.seller?.name || ""),
                            variants: item.variants || [],
                        }));

                    setProducts(transformedProducts);
                } else {
                    console.error("API Error:", result.message);
                }
            } catch (error) {
                console.error("Failed to fetch related products:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchRelatedProducts();
    }, [product?.id, product?.tag_slug, product?.tag_names, city, jwtToken]);

    const handleProductClick = (product) => {
        navigate(`/product/${product.slug}`, {
            state: {
                product: {
                    ...product,
                    // Ensure image_url is included
                    image_url: product.image_url || product.image || "",
                    // Include other required fields
                    images: product.images || [product.image_url || product.image || ""],
                    variants: product.variants || [],
                    seller: product.seller || { name: product.seller_name || "" },
                    // Include any other fields that DesktopDetails expects
                },
                breadcrumbs: [
                    { name: "Home", path: "/" },
                    { name: product.category?.name || "Category", path: "#" },
                    { name: product.name, path: null },
                ],
            },
        });
    };

    if (!product || !product.tag_names) return null;

    return (
        <div className="bg-gray-50 py-8 border-t border-gray-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">
                    Similar Products
                </h2>

                {loading ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                        {[...Array(4)].map((_, i) => (
                            <div key={i} className="bg-gray-100 rounded-lg h-64 animate-pulse"></div>
                        ))}
                    </div>
                ) : products.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                        {products.map((item) => (
                            <div
                                key={item.id}
                                onClick={() => handleProductClick(item)}
                                className="cursor-pointer"
                            >
                                <ProductCard
                                    product={item}
                                    isMobile={false}
                                />
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-8">
                        <p className="text-gray-500">No similar products found</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default RelatedProductsPage;