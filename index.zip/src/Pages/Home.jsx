import { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import api from "../api/api"
import HomeMiddleBanner from "../assets/images/homeBannerMultiple.png"
import homeFashionBanner from "../assets/images/homeFashionBanner.png"
import BestSellerProducts from "../Components/Home/BestSellerProducts"
import DeskTopCategoryCarousel from "../Components/Home/DeskTopCategoryCarousel"
import DeskTopHomeBanner from "../Components/Home/DeskTopHomeBanner"
import MobileTopCategoryCarousel from "../Components/Home/MobileTopCategoryCarousel"
import RecommendedProducts from "../Components/Home/RecommedProducts"
import ShopBySeller from "../Components/Home/ShopBySeller"
import MobileBannerSlider from "../Components/Navbar/MobileBannerSlider"
import { setShop } from "../model/reducer/shopReducer"
import Brands from "../Components/Home/Brands"
import SetDeliveryLocations from "../Components/Models/SetDeliveryLocations"
import { setFirstVisit } from "../model/reducer/locationReducer"

// Enhanced Modern Skeleton Components with improved animations and styling
const SkeletonBanner = () => (
    <div className="relative bg-gradient-to-br from-slate-200 via-slate-100 to-slate-200 h-48 md:h-72 w-full rounded-3xl overflow-hidden shadow-sm">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-pulse"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-slate-300/30 to-transparent animate-shimmer"></div>
        {/* Decorative elements */}
        <div className="absolute top-4 left-4 w-24 h-6 bg-white/20 rounded-full"></div>
        <div className="absolute bottom-4 right-4 w-32 h-8 bg-white/20 rounded-lg"></div>
    </div>
)

const SkeletonCarousel = ({ isMobile = false }) => (
    <div className="space-y-4 p-4 bg-white rounded-2xl shadow-sm border border-slate-100">
        {/* Enhanced Title skeleton */}
        <div className="relative h-7 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-lg w-40 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent animate-shimmer"></div>
        </div>

        {/* Enhanced Carousel items - small rounded icons in a single row */}
        <div className="flex space-x-4 overflow-hidden pb-2">
            {[...Array(isMobile ? 6 : 10)].map((_, i) => (
                <div key={i} className="flex-shrink-0 flex flex-col items-center space-y-3">
                    {/* Enhanced small rounded icon with better gradient */}
                    <div className="relative w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br from-slate-200 via-slate-100 to-slate-200 rounded-full overflow-hidden shadow-sm ring-2 ring-slate-100">
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-pulse"></div>
                        <div className="absolute inset-0 bg-gradient-to-br from-transparent via-slate-300/30 to-transparent animate-shimmer"></div>
                        {/* Inner circle for depth */}
                        <div className="absolute inset-2 bg-white/30 rounded-full"></div>
                    </div>
                    {/* Enhanced label skeleton */}
                    <div className="relative h-3 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-full w-14 overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></div>
                    </div>
                </div>
            ))}
        </div>
    </div>
)

const SkeletonProductCard = () => (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-md transition-shadow duration-300">
        {/* Enhanced Product image */}
        <div className="relative h-44 md:h-48 bg-gradient-to-br from-slate-200 via-slate-100 to-slate-200 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-pulse"></div>
            <div className="absolute inset-0 bg-gradient-to-br from-transparent via-slate-300/30 to-transparent animate-shimmer"></div>
            {/* Decorative product placeholder */}
            <div className="absolute inset-4 bg-white/20 rounded-xl"></div>
            {/* Price tag placeholder */}
            <div className="absolute top-3 right-3 w-12 h-6 bg-white/30 rounded-full"></div>
        </div>

        {/* Enhanced Product details */}
        <div className="p-4 space-y-3">
            {/* Product name - two lines */}
            <div className="space-y-2">
                <div className="relative h-4 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-md w-full overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></div>
                </div>
                <div className="relative h-4 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-md w-3/4 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></div>
                </div>
            </div>

            {/* Price section */}
            <div className="flex items-center space-x-2">
                <div className="relative h-5 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-md w-16 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></div>
                </div>
                <div className="relative h-4 bg-gradient-to-r from-slate-300 via-slate-200 to-slate-300 rounded-md w-12 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"></div>
                </div>
            </div>

            {/* Enhanced Rating */}
            <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                    <div
                        key={i}
                        className="relative w-4 h-4 bg-gradient-to-r from-amber-200 via-amber-100 to-amber-200 rounded-full overflow-hidden"
                    >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></div>
                    </div>
                ))}
                <div className="ml-2 relative h-3 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded w-8 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></div>
                </div>
            </div>
        </div>
    </div>
)

const SkeletonProductList = ({ title = true, count = 10 }) => (
    <div className="space-y-6">
        {title && (
            <div className="flex items-center justify-between">
                <div className="relative h-7 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-lg w-48 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent animate-shimmer"></div>
                </div>
                <div className="relative h-6 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-full w-24 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></div>
                </div>
            </div>
        )}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
            {[...Array(count)].map((_, i) => (
                <SkeletonProductCard key={i} />
            ))}
        </div>
    </div>
)

const SkeletonSellerCard = () => (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-md transition-shadow duration-300">
        {/* Enhanced Seller image/banner */}
        <div className="relative h-28 bg-gradient-to-br from-slate-200 via-slate-100 to-slate-200 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-pulse"></div>
            <div className="absolute inset-0 bg-gradient-to-br from-transparent via-slate-300/30 to-transparent animate-shimmer"></div>
            {/* Seller logo placeholder */}
            <div className="absolute bottom-3 left-3 w-12 h-12 bg-white/30 rounded-full ring-2 ring-white/50"></div>
        </div>

        {/* Enhanced Seller details */}
        <div className="p-4 space-y-3">
            {/* Seller name */}
            <div className="relative h-5 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-md w-3/4 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></div>
            </div>

            {/* Product count and rating */}
            <div className="space-y-2">
                <div className="relative h-4 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-md w-1/2 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></div>
                </div>
                <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                        <div
                            key={i}
                            className="relative w-3 h-3 bg-gradient-to-r from-amber-200 via-amber-100 to-amber-200 rounded-full overflow-hidden"
                        >
                            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    </div>
)

const SkeletonShopBySeller = () => (
    <div className="space-y-6 p-6 bg-gradient-to-br from-pink-50 to-orange-50 rounded-3xl">
        {/* Enhanced Title with subtitle */}
        <div className="text-center space-y-3">
            <div className="relative h-8 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-lg w-48 mx-auto overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent animate-shimmer"></div>
            </div>
            <div className="relative h-4 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-md w-64 mx-auto overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></div>
            </div>
        </div>

        {/* Enhanced Seller grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 md:gap-6">
            {[...Array(8)].map((_, i) => (
                <SkeletonSellerCard key={i} />
            ))}
        </div>
    </div>
)

const SkeletonBrands = () => (
    <div className="space-y-6 p-6 bg-white rounded-2xl shadow-sm border border-slate-100">
        {/* Enhanced Title */}
        <div className="text-center">
            <div className="relative h-7 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 rounded-lg w-36 mx-auto overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent animate-shimmer"></div>
            </div>
        </div>

        {/* Enhanced Brand logos in a scrollable row */}
        <div className="flex space-x-6 overflow-hidden pb-2">
            {[...Array(12)].map((_, i) => (
                <div
                    key={i}
                    className="relative flex-shrink-0 w-24 h-24 bg-gradient-to-br from-slate-200 via-slate-100 to-slate-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300"
                >
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-pulse"></div>
                    <div className="absolute inset-0 bg-gradient-to-br from-transparent via-slate-300/30 to-transparent animate-shimmer"></div>
                    {/* Brand logo placeholder */}
                    <div className="absolute inset-3 bg-white/30 rounded-xl"></div>
                </div>
            ))}
        </div>
    </div>
)

// Add custom CSS for shimmer animation
const SkeletonStyles = () => {
    useEffect(() => {
        // Create a style element and append it to the head
        const styleElement = document.createElement('style');
        styleElement.innerHTML = `
      @keyframes shimmer {
        0% { transform: translateX(-100%); }
        100% { transform: translateX(100%); }
      }
      .animate-shimmer {
        animation: shimmer 2s infinite;
      }
    `;
        document.head.appendChild(styleElement);

        // Cleanup function to remove the style element when component unmounts
        return () => {
            document.head.removeChild(styleElement);
        };
    }, []);

    return null; // This component doesn't render anything
};

export default function Home() {
    const { city } = useSelector((state) => state.city)
    const [isMobile, setIsMobile] = useState(window.innerWidth <= 768)
    const [loading, setLoading] = useState(true)
    const [locationPermission, setLocationPermission] = useState(null)
    const dispatch = useDispatch()

    const isLocationSet = () => {
        return localStorage.getItem('locationSet') === 'true' || city?.status === 'fulfill'
    }


    useEffect(() => {
        window.scrollTo(0, {
            behaviour: "smooth",
        });

        checkLocationPermission();

        // Only show modal if location isn't set
        if (!isLocationSet()) {
            dispatch(setFirstVisit(true));
        }
    }, []);

    // useEffect(() => {
    //     // Show location modal if:
    //     // 1. No city is set (status is not 'fulfill')
    //     // 2. Or if permission is not granted
    //     if (city?.status !== 'fulfill') {
    //         setShowLocationModal(true);
    //     }
    // }, [city?.status]);

    const checkLocationPermission = async () => {
        if (navigator.permissions) {
            try {
                const permissionStatus = await navigator.permissions.query({ name: 'geolocation' });
                setLocationPermission(permissionStatus.state);

                permissionStatus.onchange = () => {
                    setLocationPermission(permissionStatus.state);
                }
            } catch (e) {
                console.error("Permission query failed:", e);
                setLocationPermission('prompt');
            }
        } else {
            setLocationPermission('prompt');
        }
    };


    const handleLocationSuccess = () => {
        localStorage.setItem('locationSet', 'true');
        dispatch(setFirstVisit(false));
        // No need to manually close here, it's handled in SetDeliveryLocations
    }
    const handleLocationClose = () => {
        // Only allow closing if this isn't the first visit
        if (localStorage.getItem('locationSet') === 'true') {
            setShowLocationModal(false)
        }
    }

    useEffect(() => {
        const fetchShopData = async () => {
            try {
                // Only fetch shop data if location is set
                if (isLocationSet() && city?.status === 'fulfill') {
                    const response = await api.getShop(city?.data?.latitude, city?.data?.longitude)

                    if (!response.ok) {
                        throw new Error("Failed to fetch shop data")
                    }

                    const data = await response.json()
                    dispatch(setShop(data))
                }
            } catch (err) {
                console.error("Error fetching shop data:", err)
            } finally {
                setLoading(false)
            }
        }

        fetchShopData()

        const handleResize = () => {
            setIsMobile(window.innerWidth <= 768)
        }

        window.addEventListener("resize", handleResize)
        return () => window.removeEventListener("resize", handleResize)
    }, [dispatch, city])

    if (loading) {
        return (
            <>
                {/* Location Modal - shown when no location is set */}
                {(!isLocationSet() || city?.firstVisit) && (
                    <SetDeliveryLocations
                        isOpen={true}
                        onClose={() => { }}
                        onSuccess={handleLocationSuccess}
                        locationPermission={locationPermission}
                        forceOpen={true}
                    />
                )}
                <SkeletonStyles />
                <div className="bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
                    {isMobile ? (
                        <div className="space-y-6 p-4">
                            {/* Mobile Banner Skeleton */}
                            <SkeletonBanner />

                            {/* Mobile Category Carousel */}
                            <SkeletonCarousel isMobile={true} />

                            {/* Recommended Products */}
                            <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-6">
                                <SkeletonProductList count={6} />
                            </div>

                            {/* Best Seller Products */}
                            <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-6">
                                <SkeletonProductList count={6} />
                            </div>

                            {/* Shop by Seller */}
                            <SkeletonShopBySeller />

                            {/* Fashion Banner */}
                            <SkeletonBanner />

                            {/* Brands */}
                            <SkeletonBrands />
                        </div>
                    ) : (
                        <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 md:px-8 space-y-10 py-8">
                            {/* Desktop Banner */}
                            <SkeletonBanner />

                            {/* Desktop Category Carousel */}
                            <SkeletonCarousel isMobile={false} />

                            {/* Middle Banner */}
                            <SkeletonBanner />

                            {/* Recommended Products */}
                            <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-8">
                                <SkeletonProductList count={10} />
                            </div>

                            {/* Best Seller Products */}
                            <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-8">
                                <SkeletonProductList count={10} />
                            </div>

                            {/* Shop by Seller */}
                            <SkeletonShopBySeller />

                            {/* Fashion Banner */}
                            <SkeletonBanner />

                            {/* Brands */}
                            <SkeletonBrands />
                        </div>
                    )}
                </div>
            </>
        )
    }

    return (
        <>
            {(!isLocationSet() || city?.firstVisit) && (
                <SetDeliveryLocations
                    isOpen={true}
                    onClose={handleLocationClose}
                    onSuccess={handleLocationSuccess}
                    locationPermission={locationPermission}
                    forceOpen={city?.firstVisit} // Only force open for first visit
                    firstVisit={city?.firstVisit}
                />
            )}
            {isMobile ? (
                <>
                    <div className="bg-gray-50 min-h-screen">
                        <MobileBannerSlider />

                        <div className="-mt-5">
                            <MobileTopCategoryCarousel />
                        </div>

                        <div className="-mt-6">
                            <RecommendedProducts />
                        </div>

                        <div className="-mt-4">
                            <BestSellerProducts />
                        </div>

                        <div className="-mt-10">
                            <ShopBySeller />

                            <div className="mt-2 rounded-lg overflow-hidden shadow-md">
                                <img
                                    src={homeFashionBanner || "/placeholder.svg"}
                                    alt="Banner Image"
                                    className="w-full h-auto object-cover"
                                    style={{ maxHeight: "250px" }}
                                />
                            </div>
                        </div>

                        <div className="my-6">
                            <Brands />
                        </div>
                    </div>
                </>
            ) : (
                <>
                    {/* Desktop Layout */}
                    <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 md:px-8">
                        <DeskTopHomeBanner />
                        <DeskTopCategoryCarousel />
                    </div>

                    <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 md:px-8 mb-12 md:mb-6">
                        <img
                            src={HomeMiddleBanner || "/placeholder.svg"}
                            alt="Home Middle Banner"
                            className="w-full h-auto rounded-lg shadow-sm"
                        />
                    </div>

                    <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 md:px-8 mb-12 md:mb-6">
                        <RecommendedProducts />
                    </div>

                    <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 md:px-8 mb-12 md:mb-6">
                        <BestSellerProducts />
                    </div>

                    <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 md:px-8 mb-12 md:mb-6">
                        <ShopBySeller />
                        <img
                            src={homeFashionBanner || "/placeholder.svg"}
                            alt="bannerImage"
                            className="mt-4 w-full h-auto max-h-96 object-cover rounded-lg shadow-sm"
                        />
                    </div>

                    <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 md:px-8 mb-12 md:mb-6">
                        <Brands />
                    </div>
                </>
            )}
        </>
    )
}