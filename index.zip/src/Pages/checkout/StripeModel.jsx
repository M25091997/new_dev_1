// import React from 'react';
// import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
// import { toast } from 'react-toastify';
// import api from '../../api/api';
// import { useDispatch } from 'react-redux';
// import { deductUserBalance } from '../../model/reducer/authReducer';

// const StripeModal = ({
//   setIsOrderPlaced,
//   setShow,
//   orderID,
//   client_secret,
//   transaction_id,
//   amount,
//   setWalletAmount,
//   walletAmount,
//   walletDeductionAmt
// }) => {
//   const stripe = useStripe();
//   const elements = useElements();
//   const dispatch = useDispatch();

//   const handleSubmit = async (event) => {
//     event.preventDefault();
//     if (!stripe || !elements) return;

//     const { error, paymentIntent } = await stripe.confirmCardPayment(client_secret, {
//       payment_method: {
//         card: elements.getElement(CardElement),
//       }
//     });

//     if (error) {
//       toast.error(error.message);
//     } else if (paymentIntent.status === 'succeeded') {
//       await api.addTransaction(user?.jwtToken, orderID, transaction_id, "Stripe", "order")
//         .then(response => response.json())
//         .then(result => {
//           if (result.status === 1) {
//             toast.success("Payment successful!");
//             setIsOrderPlaced(true);
//             setShow(false);
//             dispatch(deductUserBalance({ data: walletDeductionAmt }));
//           } else {
//             toast.error(result.message);
//           }
//         });
//     }
//   };

//   return (
//     <form onSubmit={handleSubmit}>
//       <CardElement className="mb-4 p-2 border rounded" />
//       <button 
//         type="submit" 
//         disabled={!stripe}
//         className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
//       >
//         Pay {amount}
//       </button>
//     </form>
//   );
// };

// export default StripeModal;


import React from 'react';
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { toast } from 'react-toastify';

const StripeModel = ({ orderId, transactionId, amount, onSuccess, onError }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = React.useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);

    if (!stripe || !elements) {
      return;
    }

    try {
      const { error, paymentIntent } = await stripe.confirmCardPayment(transactionId, {
        payment_method: {
          card: elements.getElement(CardElement),
        }
      });

      if (error) {
        onError(error.message);
        return;
      }

      if (paymentIntent.status === 'succeeded') {
        // Call your API to confirm the payment
        const response = await api.addTransaction(
          user?.jwtToken,
          orderId,
          paymentIntent.id,
          "Stripe",
          "order"
        );
        const result = await response.json();

        if (result.status === 1) {
          onSuccess();
        } else {
          onError(result.message || "Payment failed");
        }
      }
    } catch (error) {
      onError(error.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="mb-4">
        <CardElement
          options={{
            style: {
              base: {
                fontSize: '16px',
                color: '#424770',
                '::placeholder': {
                  color: '#aab7c4',
                },
              },
              invalid: {
                color: '#9e2146',
              },
            },
          }}
        />
      </div>
      <button
        type="submit"
        disabled={!stripe || loading}
        className="w-full bg-pink-600 hover:bg-pink-700 text-white py-2 px-4 rounded-md transition duration-150 ease-in-out disabled:opacity-50"
      >
        {loading ? 'Processing...' : `Pay ${amount}`}
      </button>
    </form>
  );
};

export default StripeModel;