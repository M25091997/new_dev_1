import PaystackPop from "@paystack/inline-js"
import { GoogleMap, MarkerF } from "@react-google-maps/api"
import { Elements } from "@stripe/react-stripe-js"
import { loadStripe } from "@stripe/stripe-js"
import { Check, Clock, CreditCard, FolderPen, MapPin, NotepadText } from "lucide-react"
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { BiCurrentLocation } from "react-icons/bi"
import { PiWallet } from "react-icons/pi"
import { useRazorpay } from "react-razorpay"
import { useDispatch, useSelector } from "react-redux"
import { useLocation, useNavigate } from "react-router-dom"
import { toast } from "react-toastify"
import api from "../../api/api"
import { setAddress, setSelectedAddress } from "../../model/reducer/addressReducer"
import { deductUserBalance } from "../../model/reducer/authReducer"
import { clearCart, setCartCheckout, setCartProducts, setCartSubTotal } from "../../model/reducer/cartReducer"
import StripeModel from "./StripeModel"
import ConfirmationDialog from "../../Components/Dialog/ConfirmationDialog"
import { setPaymentSetting } from "../../model/reducer/settingReducer"
import StripeIcon from "../../utils/Checkout_stripe.svg"
import cashfree from "../../utils/ic_cashfree.svg"
import cod from "../../utils/ic_cod.svg"
import paypal from "../../utils/ic_paypal.svg"
import paystack from "../../utils/ic_paystack.svg"
import rozerpay from "../../utils/ic_razorpay.svg"
import paytabs from "../../utils/Icons/ic_paytabs.svg"
import Midtrans from "../../utils/Icons/Midtrans.svg"
import PhonepeSVG from "../../utils/Icons/Phonepe.svg"
import { isGoogleMapsLoaded, loadGoogleMaps } from "../../utils/LoadGoogleMaps/LoadGoogleMap"

const CheckoutPage = () => {
  const setting = useSelector((state) => state.setting)
  const user = useSelector((state) => state.user)
  const cart = useSelector((state) => state.cart)
  const promoCode = useSelector((state) => state.promoCode)
  const city = useSelector((state) => state.city)
  const dispatch = useDispatch()
  const [step, setStep] = useState(1)
  const [steps, setSteps] = useState(1)
  const [showAddressForm, setShowAddressForm] = useState(false)
  const [addresses, setAddresses] = useState([])
  const [selectedAddressIndex, setSelectedAddressIndex] = useState(null)
  const [isDeleting, setIsDeleting] = useState(false)
  const [addressToDelete, setAddressToDelete] = useState(null)
  const [deliveryOption, setDeliveryOption] = useState("instant")
  const [selectedDate, setSelectedDate] = useState(null)
  const [deliveryTime, setDeliveryTime] = useState("2pm-5pm")
  const [paymentMethod, setPaymentMethod] = useState("cod")
  const [orderNote, setOrderNote] = useState("")
  const [subtotal, setSubtotal] = useState(0)
  const [currentMonthIndex, setCurrentMonthIndex] = useState(new Date().getMonth())
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear())
  const [codAllow, setCodAllow] = useState(0)
  const [isWalletChecked, setIsWalletChecked] = useState(false)
  const [walletDeductionAmt, setWalletDeductionAmt] = useState(0)
  const [isFullWalletPay, setIsFullWalletPay] = useState(false)
  const [loadingPlaceOrder, setLoadingPlaceOrder] = useState(false)
  const [orderId, setOrderId] = useState(null)
  const [paymentUrl, setPaymentUrl] = useState(null)
  const [stripeClientSecret, setStripeClientSecret] = useState(null)
  const [stripeOrderId, setStripeOrderId] = useState(null)
  const [stripeTransactionId, setStripeTransactionId] = useState(null)
  const [showStripeModal, setShowStripeModal] = useState(false)
  const [isOrderPlaced, setIsOrderPlaced] = useState(false)
  const [loadingSaveAddress, setLoadingSaveAddress] = useState(false)
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false)
  const [totalPayment, setTotalPayment] = useState(0)
  const [deliveryCharge, setDeliveryCharge] = useState(0)
  const [editingAddress, setEditingAddress] = useState(null)
  const [mapLoaded, setMapLoaded] = useState(isGoogleMapsLoaded());
  const [mapsError, setMapsError] = useState(null);
  const [locationPermission, setLocationPermission] = useState(null);

  const navigate = useNavigate()

  const ProgressSteps = [
    { number: 1, label: "Address" },
    { number: 2, label: "Delivery" },
    { number: 3, label: "Payment" },
    { number: 4, label: "Summary" },
  ]

  const handleStepChange = (newStep) => {
    setSteps(newStep)
  }

  if (mapsError) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md text-center">
          <div className="text-red-500 mb-4">{mapsError}</div>
          <button
            onClick={() => window.location.reload()}
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  const paymentMethodComponents = {
    cod: {
      name: "Cash On Delivery",
      description: "Pay when your order arrives",
      icon: cod,
      enabled: setting?.payment_setting?.cod_payment_method === "1",
    },
    stripe: {
      name: "Credit/Debit Card",
      description: "Secure payment via card",
      icon: StripeIcon,
      enabled: setting?.payment_setting?.stripe_payment_method === "1",
    },
    paypal: {
      name: "PayPal",
      description: "Fast and secure payment",
      icon: paypal,
      enabled: setting?.payment_setting?.paypal_payment_method === "1",
    },
    razorpay: {
      name: "Razorpay",
      description: "Secure payment gateway",
      icon: rozerpay,
      enabled: setting?.payment_setting?.razorpay_payment_method === "1",
    },
    paystack: {
      name: "Paystack",
      description: "Secure payment for Africa",
      icon: paystack,
      enabled: setting?.payment_setting?.paystack_payment_method === "1",
    },
    cashfree: {
      name: "Cashfree",
      description: "Secure payment gateway",
      icon: cashfree,
      enabled: setting?.payment_setting?.cashfree_payment_method === "1",
    },
    paytabs: {
      name: "Paytabs",
      description: "Secure payment gateway",
      icon: paytabs,
      enabled: setting?.payment_setting?.paytabs_payment_method === "1",
    },
    phonepe: {
      name: "PhonePe",
      description: "UPI payments",
      icon: PhonepeSVG,
      enabled: setting?.payment_setting?.phonepe_payment_method === "1",
    },
    midtrans: {
      name: "Midtrans",
      description: "Indonesian payments",
      icon: Midtrans,
      enabled: setting?.payment_setting?.midtrans_payment_method === "1",
    },
  }


  const location = useLocation()
  const { address, selected_address } = useSelector((state) => state.address)
  const { Razorpay } = useRazorpay()
  const stripePromise = setting?.payment_setting?.stripe_publishable_key
    ? loadStripe(setting.payment_setting.stripe_publishable_key)
    : null

  // Address Form State
  const [newAddress, setNewAddress] = useState({
    name: "",
    mobile: "",
    alternate_mobile: "",
    address: "",
    landmark: "",
    area: "",
    city: "",
    state: "",
    country: "",
    pincode: "",
    type: "Home",
    is_default: false,
    latitude: city.city ? city.city.latitude : 0,
    longitude: city.city ? city.city.longitude : 0,
  })

  const [mapPosition, setMapPosition] = useState({
    lat: Number.parseFloat(city.city ? city.city.latitude : 0),
    lng: Number.parseFloat(city.city ? city.city.longitude : 0),
  })

  const [errors, setErrors] = useState({})
  const [isGeocoding, setIsGeocoding] = useState(false)
  const typingTimeout = useRef(null)
  const autocompleteRef = useRef(null)
  const autocomplete = useRef(null)

  const calculateHandlingFee = (subtotal) => {
    const amount = Number.parseFloat(subtotal) || 0
    let handlingFee = 0
    if (amount >= 10 && amount < 3000) handlingFee = 7
    else if (amount >= 3000 && amount < 5000) handlingFee = 8
    else if (amount >= 5000 && amount < 10000) handlingFee = 9
    else if (amount >= 10000) handlingFee = 12
    return {
      baseFee: handlingFee,
      total: handlingFee,
    }
  }

  //  useEffect hook to load Google Maps API
  useEffect(() => {
    let mounted = true;

    const loadMaps = async () => {
      try {
        await loadGoogleMaps(import.meta.env.VITE_APP_MAP_API);
        if (mounted) {
          setMapLoaded(true);
        }
      } catch (error) {
        if (mounted) {
          setMapsError(error.message);
          toast.error('Failed to load Google Maps API');
          console.error('Google Maps loading error:', error);
        }
      }
    };

    if (!isGoogleMapsLoaded()) {
      loadMaps();
    } else {
      setMapLoaded(true);
    }

    return () => {
      mounted = false;
    };
  }, []);

  // location permission check
  useEffect(() => {
    const checkLocationPermission = async () => {
      if (navigator.permissions) {
        try {
          const permissionStatus = await navigator.permissions.query({ name: 'geolocation' });
          setLocationPermission(permissionStatus.state);

          permissionStatus.onchange = () => {
            setLocationPermission(permissionStatus.state);
          };
        } catch (e) {
          console.error("Permission query failed:", e);
          setLocationPermission('prompt');
        }
      } else {
        setLocationPermission('prompt');
      }
    };

    checkLocationPermission();
  }, []);


  // Initialize Google Places Autocomplete
  useEffect(() => {
    if (mapLoaded && window.google && window.google.maps && !autocomplete.current && autocompleteRef.current) {
      autocomplete.current = new window.google.maps.places.Autocomplete(autocompleteRef.current, {
        types: ["geocode"],
        componentRestrictions: { country: 'IN' } // Restrict to India if needed
      });

      autocomplete.current.addListener("place_changed", () => {
        const place = autocomplete.current.getPlace();
        if (!place.geometry) {
          toast.error("No details available for this place");
          return;
        }

        let address = "",
          city = "",
          state = "",
          pincode = "",
          country = "",
          area = "",
          landmark = "";

        place.address_components.forEach((component) => {
          if (component.types.includes("street_number") || component.types.includes("route")) {
            address = address ? `${component.long_name} ${address}` : component.long_name;
          }
          if (component.types.includes("locality")) {
            city = component.long_name;
          }
          if (component.types.includes("administrative_area_level_1")) {
            state = component.long_name;
          }
          if (component.types.includes("postal_code")) {
            pincode = component.long_name;
          }
          if (component.types.includes("country")) {
            country = component.long_name;
          }
          if (component.types.includes("sublocality") || component.types.includes("neighborhood")) {
            area = component.long_name;
          }
          if (component.types.includes("point_of_interest") || component.types.includes("establishment")) {
            landmark = component.long_name;
          }
        });

        setLocalNewAddress(prev => ({
          ...prev,
          address: address || place.formatted_address || prev.address,
          landmark: landmark || prev.landmark,
          area: area || prev.area,
          city: city || prev.city,
          state: state || prev.state,
          pincode: pincode || prev.pincode,
          country: country || prev.country,
          latitude: place.geometry.location.lat().toString(),
          longitude: place.geometry.location.lng().toString(),
        }));

        setLocalMapPosition({
          lat: place.geometry.location.lat(),
          lng: place.geometry.location.lng(),
        });
      });
    }

    return () => {
      if (autocomplete.current && window.google?.maps?.event) {
        window.google.maps.event.clearInstanceListeners(autocomplete.current);
      }
    };
  }, [mapLoaded]);


  useEffect(() => {
    return () => {
      // Cleanup the timeout when component unmounts
      if (typingTimeout.current) {
        clearTimeout(typingTimeout.current);
      }

      // Cleanup Google Maps autocomplete
      if (autocomplete.current && window.google?.maps?.event) {
        window.google.maps.event.clearInstanceListeners(autocomplete.current);
      }
    };
  }, []);

  const handleStreetChange = useCallback(
    (e) => {
      const { name, value } = e.target;

      // Update the address immediately for user feedback
      setLocalNewAddress(prev => {
        const updatedAddress = { ...prev, [name]: value };

        // Clear any existing timeout
        if (typingTimeout.current) {
          clearTimeout(typingTimeout.current);
        }

        // Only trigger geocoding after a pause in typing
        typingTimeout.current = setTimeout(() => {
          if (value.trim() !== "" && window.google && window.google.maps) {
            const geocoder = new window.google.maps.Geocoder();
            const fullAddress = `${value}, ${updatedAddress.city}, ${updatedAddress.state}, ${updatedAddress.country}`;

            geocoder.geocode({ address: fullAddress }, (results, status) => {
              if (status === "OK" && results[0]) {
                const location = results[0].geometry.location;
                setLocalMapPosition({
                  lat: location.lat(),
                  lng: location.lng(),
                });
                setLocalNewAddress(prev => ({
                  ...prev,
                  latitude: location.lat().toString(),
                  longitude: location.lng().toString(),
                }));
              }
            });
          }
        }, 1000);

        return updatedAddress;
      });
    },
    [] // Empty dependency array since we're using functional updates
  );
  const handleCurrentLocation = () => {
    if (!mapLoaded || !window.google?.maps) {
      toast.error('Google Maps not loaded yet, please try again.');
      return;
    }

    if (!navigator.geolocation) {
      toast.error("Geolocation is not supported by your browser");
      return;
    }

    if (locationPermission === 'denied') {
      toast.error('Please enable location permissions in your browser settings');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const latLng = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        }

        setMapPosition({
          lat: Number.parseFloat(latLng.lat),
          lng: Number.parseFloat(latLng.lng),
        })

        setNewAddress((prev) => ({
          ...prev,
          latitude: latLng.lat.toString(),
          longitude: latLng.lng.toString(),
        }))

        // Reverse geocode to get address details
        const geocoder = new window.google.maps.Geocoder()
        geocoder.geocode({ location: latLng }, (results, status) => {
          if (status === "OK" && results[0]) {
            let address = "",
              country = "",
              pincode = "",
              landmark = "",
              area = "",
              state_ = "",
              city = ""

            results[0].address_components.forEach((res_add) => {
              if (
                res_add.types.includes("premise") ||
                res_add.types.includes("plus_code") ||
                res_add.types.includes("route")
              ) {
                address = res_add.long_name
              }
              if (res_add.types.includes("political")) {
                landmark = res_add.long_name
              }
              if (
                res_add.types.includes("administrative_area_level_3") ||
                res_add.types.includes("administrative_area_level_2") ||
                res_add.types.includes("sublocality")
              ) {
                area = res_add.long_name
              }
              if (res_add.types.includes("administrative_area_level_1")) {
                state_ = res_add.long_name
              }
              if (res_add.types.includes("country")) {
                country = res_add.long_name
              }
              if (res_add.types.includes("postal_code")) {
                pincode = res_add.long_name
              }
              if (res_add.types.includes("locality")) {
                city = res_add.long_name
              }
            })

            setNewAddress((prev) => ({
              ...prev,
              address: address || results[0].formatted_address || prev.address,
              landmark: landmark || prev.landmark,
              city: city || prev.city,
              area: area || prev.area,
              state: state_ || prev.state,
              pincode: pincode || prev.pincode,
              country: country || prev.country,
            }))
          }
        })
      },
      (error) => {
        console.log("Geolocation error:", error)
      },
    )
  }

  const onMarkerDragEnd = (e) => {
    if (!mapLoaded || !window.google?.maps) {
      toast.error('Google Maps not loaded yet, please try again.');
      return;
    }
    setIsGeocoding(true)
    const prev_latlng = {
      lat: mapPosition.lat,
      lng: mapPosition.lng,
    }

    const geocoder = new window.google.maps.Geocoder()
    geocoder
      .geocode({
        location: {
          lat: e.latLng.lat(),
          lng: e.latLng.lng(),
        },
      })
      .then((response) => {
        if (response.results[0]) {
          setMapPosition({
            lat: Number.parseFloat(e.latLng.lat()),
            lng: Number.parseFloat(e.latLng.lng()),
          })

          let address = "",
            country = "",
            pincode = "",
            landmark = "",
            area = "",
            state_ = "",
            city = ""

          response.results[0].address_components.forEach((res_add) => {
            if (
              res_add.types.includes("premise") ||
              res_add.types.includes("plus_code") ||
              res_add.types.includes("route")
            ) {
              address = res_add.long_name
            }
            if (res_add.types.includes("political")) {
              landmark = res_add.long_name
            }
            if (
              res_add.types.includes("administrative_area_level_3") ||
              res_add.types.includes("administrative_area_level_2") ||
              res_add.types.includes("sublocality")
            ) {
              area = res_add.long_name
            }
            if (res_add.types.includes("administrative_area_level_1")) {
              state_ = res_add.long_name
            }
            if (res_add.types.includes("country")) {
              country = res_add.long_name
            }
            if (res_add.types.includes("postal_code")) {
              pincode = res_add.long_name
            }
            if (res_add.types.includes("locality")) {
              city = res_add.long_name
            }
          })

          if (address === "" || area === "") {
            setMapPosition({
              lat: prev_latlng.lat,
              lng: prev_latlng.lng,
            })
          } else {
            setNewAddress((prev) => ({
              ...prev,
              address: address,
              landmark: landmark,
              city: city,
              area: area,
              pincode: pincode,
              country: country,
              state: state_,
              latitude: e.latLng.lat().toString(),
              longitude: e.latLng.lng().toString(),
            }))
          }
          setIsGeocoding(false)
        }
      })
      .catch((error) => {
        console.log(error)
        setIsGeocoding(false)
      })
  }

  const validateNewAddress = () => {
    const newErrors = {}
    if (!newAddress.name) newErrors.name = "Name is required"
    if (!newAddress.mobile) newErrors.mobile = "Mobile number is required"
    if (!newAddress.address) newErrors.address = "Street address is required"
    if (!newAddress.city) newErrors.city = "City is required"
    if (!newAddress.state) newErrors.state = "State is required"
    if (!newAddress.pincode) newErrors.pincode = "ZIP code is required"
    if (!newAddress.country) newErrors.country = "Country is required"
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleInputChange = useCallback((e) => {
    const { name, value, type, checked } = e.target
    setNewAddress((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))
  }, [])

  const handleAddressTypeChange = useCallback((type) => {
    setNewAddress((prev) => ({ ...prev, type }))
  }, [])

  const resetForm = () => {
    setNewAddress({
      name: "",
      mobile: "",
      alternate_mobile: "",
      address: "",
      landmark: "",
      area: "",
      city: "",
      state: "",
      country: "",
      pincode: "",
      type: "Home",
      is_default: false,
      latitude: city.city ? city.city.latitude : 0,
      longitude: city.city ? city.city.longitude : 0,
    })
    setErrors({})
    setMapPosition({
      lat: Number.parseFloat(city.city ? city.city.latitude : 0),
      lng: Number.parseFloat(city.city ? city.city.longitude : 0),
    })
    setShowAddressForm(false)
  }

  const memoizedAddresses = useMemo(() => addresses, [addresses])

  const saveNewAddress = async () => {
    if (!validateNewAddress()) {
      return
    }

    setLoadingSaveAddress(true)
    try {
      // Prepare address data for API
      const addressData = {
        name: newAddress.name,
        mobile: newAddress.mobile.toString(),
        alternate_mobile: newAddress.alternate_mobile ? newAddress.alternate_mobile.toString() : "",
        address: newAddress.address,
        landmark: newAddress.landmark || "",
        area: newAddress.area || "",
        city: newAddress.city,
        state: newAddress.state,
        country: newAddress.country,
        pincode: newAddress.pincode,
        type: newAddress.type,
        is_default: newAddress.is_default ? 1 : 0,
        latitude: newAddress.latitude || "0",
        longitude: newAddress.longitude || "0",
      }

      const response = await api.addAddress(
        user?.jwtToken,
        addressData.name,
        addressData.mobile,
        addressData.type,
        addressData.address,
        addressData.landmark,
        addressData.area,
        addressData.pincode,
        addressData.city,
        addressData.state,
        addressData.country,
        addressData.alternate_mobile,
        addressData.latitude,
        addressData.longitude,
        addressData.is_default,
      )

      const result = await response.json()

      if (result.status !== 1) {
        toast.error(result.message || "Failed to save address")
        return
      }

      // Get the saved address with real ID from backend
      const savedAddress = result.data

      // Update local state with the new address
      const updatedAddresses = [...addresses, savedAddress]
      setAddresses(updatedAddresses)
      setSelectedAddressIndex(updatedAddresses.length - 1)
      dispatch(setAddress({ data: updatedAddresses }))
      dispatch(setSelectedAddress({ data: savedAddress }))

      resetForm()
      toast.success("Address saved successfully!")
    } catch (error) {
      console.error("Error saving address:", error)
      toast.error("Failed to save address")
    } finally {
      setLoadingSaveAddress(false)
    }
  }

  useEffect(() => {
    if (user?.jwtToken) {
      // Clear addresses when user changes
      setAddresses([])
      setSelectedAddressIndex(null)
      dispatch(setAddress({ data: [] }))
      dispatch(setSelectedAddress({ data: null }))

      // Then fetch new addresses
      const fetchAddresses = async () => {
        try {
          const response = await api.getAddress(user.jwtToken)
          const result = await response.json()
          if (result.status === 1) {
            setAddresses(result.data)
            dispatch(setAddress({ data: result.data }))
            // Set default address if exists
            const defaultAddress = result.data.find((addr) => addr.is_default === 1)
            if (defaultAddress) {
              setSelectedAddressIndex(result.data.findIndex((addr) => addr.id === defaultAddress.id))
              dispatch(setSelectedAddress({ data: defaultAddress }))
            }
          }
        } catch (error) {
          console.error("Error fetching addresses:", error)
          toast.error("Failed to load addresses")
        }
      }

      fetchAddresses()
    }
  }, [user?.jwtToken, dispatch])

  const handleDeleteAddress = (address_id) => {
    setAddressToDelete(address_id)
    setIsConfirmDialogOpen(true) // Open confirmation dialog
  }

  const handleConfirmDelete = async () => {
    if (!addressToDelete) return

    setIsDeleting(true)
    try {
      const response = await api.deleteAddress(user?.jwtToken, addressToDelete)
      const result = await response.json()

      if (result.status === 1) {
        // Remove the deleted address from local state
        const updatedAddresses = addresses.filter((addr) => addr.id !== addressToDelete)
        setAddresses(updatedAddresses)
        dispatch(setAddress({ data: updatedAddresses }))

        // If the deleted address was the selected one, clear selection
        if (selectedAddressIndex !== null && addresses[selectedAddressIndex]?.id === addressToDelete) {
          setSelectedAddressIndex(null)
          dispatch(setSelectedAddress({ data: null }))
        }

        toast.success("Address deleted successfully")
      } else {
        toast.error(result.message || "Failed to delete address")
      }
    } catch (error) {
      console.error("Error deleting address:", error)
      toast.error("Failed to delete address")
    } finally {
      setIsDeleting(false)
      setIsConfirmDialogOpen(false)
      setAddressToDelete(null)
    }
  }

  const nextStep = () => setStep((prev) => prev + 1)
  const prevStep = () => setStep((prev) => prev - 1)

  const checkCodAllowance = useCallback(async () => {
    console.log("Checking COD allowance...") // Debug log

    if (!address?.selected_address) {
      console.log("No selected address for COD check")
      return
    }

    try {
      const response = await api.getCartSeller(
        user?.jwtToken,
        address.selected_address.latitude,
        address.selected_address.longitude,
        1,
      )

      const result = await response.json()
      console.log("COD allowance result:", result) // Debug log

      setCodAllow(result?.data?.cod_allowed)

      // If COD isn't allowed and that was selected, switch to another method
      if (result?.data?.cod_allowed !== 1 && paymentMethod === "cod") {
        const firstEnabled = Object.keys(paymentMethodComponents).find(
          (method) => paymentMethodComponents[method].enabled && method !== "cod",
        )
        if (firstEnabled) {
          setPaymentMethod(firstEnabled)
        }
      }
    } catch (error) {
      console.error("COD allowance check failed:", error)
    }
  }, [address?.selected_address, user?.jwtToken, paymentMethod, paymentMethodComponents])

  useEffect(() => {
    // If coming from cart slider with state, initialize from that
    if (location.state?.cartItems) {
      const cartItems = location.state.cartItems
      const calculatedSubtotal = location.state.subtotal || 0

      setSubtotal(calculatedSubtotal)
      dispatch(setCartProducts({ data: cartItems }))
      dispatch(setCartSubTotal({ data: calculatedSubtotal }))

      // Set checkout data if needed
      dispatch(
        setCartCheckout({
          data: {
            cart: cartItems,
            sub_total: calculatedSubtotal,
            total_amount: calculatedSubtotal,
            delivery_charge: { total_delivery_charge: 0 }, // Default to 0, will be updated later
          },
        }),
      )
    }
  }, [location.state, dispatch])

  useEffect(() => {
    const fetchCart = async () => {
      let latitude, longitude

      if (address?.selected_address) {
        latitude = address.selected_address.latitude
        longitude = address.selected_address.longitude
      } else if (city?.city) {
        latitude = city.city.latitude
        longitude = city.city.longitude
      } else {
        latitude = "0"
        longitude = "0"
      }

      try {
        const response = await api.getCart(user?.jwtToken, latitude, longitude, 1)
        const result = await response.json()

        if (result.status === 1) {
          dispatch(setCartCheckout({ data: result.data }))
          setCodAllow(result?.data?.cod_allowed)
          setDeliveryCharge(result?.data?.delivery_charge?.total_delivery_charge || 0) // Add fallback to 0

          // Calculate total payment
          let calculatedTotal = result.data.total_amount
          if (promoCode?.isPromoCode) {
            calculatedTotal -= promoCode.discount
          } else if (result.data.promo_code) {
            calculatedTotal -= result.data.promo_code.discount
          }

          // Add handling fee
          const handlingFeeDetails = calculateHandlingFee(subtotal)
          const handlingFee = handlingFeeDetails.total

          setTotalPayment(calculatedTotal)
        }
      } catch (error) {
        console.error("Error fetching cart:", error)
      }
    }

    fetchCart()
  }, [address?.selected_address, city?.city, user?.jwtToken, dispatch, deliveryCharge, promoCode, subtotal])

  useEffect(() => {
    if (cart?.checkout) {
      // Calculate base total
      let calculatedTotal = cart.checkout.total_amount

      // Apply promo code discount if available
      if (promoCode?.isPromoCode) {
        calculatedTotal -= promoCode.discount
      } else if (cart?.promo_code) {
        calculatedTotal -= cart.promo_code.discount
      }

      // Add handling fee
      const handlingFeeDetails = calculateHandlingFee(subtotal)
      const handlingFee = handlingFeeDetails.total

      // Apply wallet deduction if checked
      if (isWalletChecked) {
        if (calculatedTotal <= user?.user?.balance) {
          setIsFullWalletPay(true)
          setWalletDeductionAmt(calculatedTotal)
          calculatedTotal = 0
        } else {
          setIsFullWalletPay(false)
          setWalletDeductionAmt(user?.user?.balance)
          calculatedTotal -= user?.user?.balance
        }
      }

      setTotalPayment(calculatedTotal > 0 ? calculatedTotal : 0)
    }
  }, [cart, promoCode, isWalletChecked, user?.user?.balance, subtotal])

  useEffect(() => {
    if (location.state?.subtotal) {
      setSubtotal(location.state.subtotal)
    }
    // Load cart data from Redux
    if (cart?.checkout) {
      if (cart?.checkout) {
        // Initialize cart items
        const cartItems =
          cart.checkout.cart?.map((item) => ({
            id: `${item.product_id}_${item.product_variant_id}`,
            product_id: item.product_id,
            product_variant_id: item.product_variant_id,
            quantity: item.qty,
            price: item.price,
            discounted_price: item.discounted_price,
            name: item.name,
            image: item.image_url,
            measurement: item.measurement,
            unit_code: item.unit_code,
            stock: item.stock,
            is_unlimited_stock: item.is_unlimited_stock,
            total_allowed_quantity: item.total_allowed_quantity,
            slug: item.slug,
            status: item.status === 1,
          })) || []

        // Set subtotal from cart data
        const calculatedSubtotal = cart.checkout.sub_total || 0

        // Update state
        setSubtotal(calculatedSubtotal)
        dispatch(setCartProducts({ data: cartItems }))
        dispatch(setCartSubTotal({ data: calculatedSubtotal }))
      }
    }

    // Load saved addresses from Redux
    if (address) {
      setAddresses(address)
    }

    // Set selected address if exists
    if (selected_address) {
      const index = address?.findIndex((addr) => JSON.stringify(addr) === JSON.stringify(selected_address))
      if (index !== -1) {
        setSelectedAddressIndex(index)
      }
    }
  }, [location.state, address, selected_address, cart?.checkout, dispatch])

  useEffect(() => {
    checkCodAllowance()
  }, [address?.selected_address, user?.jwtToken, checkCodAllowance])

  useEffect(() => {
    if (!setting.payment_setting) {
      console.log("Payment setting not found in Redux, fetching...")
      const fetchPaymentSettings = async () => {
        try {
          const response = await api.getPaymentSettings()
          console.log("Fetched response:", response)
          const result = await response.json()
          console.log("Raw result from API:", result)

          if (result?.data && result?.status == 1) {
            try {
              console.log("Base64 string to decode:", result.data)
              const decodedString = atob(result.data)
              const parsedData = JSON.parse(decodedString)
              console.log("Decoded payment settings:", parsedData)

              dispatch(
                setPaymentSetting({
                  data: parsedData,
                }),
              )
            } catch (decodeError) {
              console.error("Failed to decode payment settings:", decodeError)
              dispatch(setPaymentSetting({ data: result.data }))
            }
          } else {
            console.warn("No 'data' found in API result.")
          }
        } catch (error) {
          console.error("Failed to fetch payment settings:", error)
        }
      }

      fetchPaymentSettings()
    } else {
      console.log("Payment setting already loaded:", setting.payment_setting)
    }
  }, [dispatch, setting.payment_setting])

  // console.log("Decoded setting.payment_setting:", setting?.payment_setting);

  useEffect(() => {
    if (location.state?.subtotal) {
      setSubtotal(location.state.subtotal)
    }

    // Load saved addresses from Redux
    if (address) {
      setAddresses(address)
    }

    // Set selected address if exists
    if (selected_address) {
      const index = address?.findIndex((addr) => JSON.stringify(addr) === JSON.stringify(selected_address))
      if (index !== -1) {
        setSelectedAddressIndex(index)
      }

      // Check COD allowance only after we have selected address
      checkCodAllowance()
    }
  }, [location.state, address, selected_address, user?.jwtToken, checkCodAllowance])

  const initializeRazorpay = () => {
    return new Promise((resolve) => {
      const script = document.createElement("script")
      script.src = "https://checkout.razorpay.com/v1/checkout.js"
      script.onload = () => {
        resolve(true)
      }
      script.onerror = () => {
        resolve(false)
      }
      document.body.appendChild(script)
    })
  }

  const handleRazorpayPayment = useCallback(
    async (order_id, razorpay_transaction_id, amount, name, email, mobile, app_name) => {
      const res = await initializeRazorpay()

      if (!res) {
        console.error("RazorPay SDK Load Failed")
        return
      }

      const key = setting?.payment_setting?.razorpay_key
      const convertedAmount = Math.floor(amount * 100)

      const options = {
        key: key,
        amount: convertedAmount,
        currency: "INR",
        name: name,
        description: app_name,
        image: setting?.setting?.web_settings?.web_logo,
        order_id: razorpay_transaction_id,
        handler: async (res) => {
          if (res.razorpay_payment_id) {
            await api
              .addRazorpayTransaction(
                user?.jwtToken,
                order_id,
                res.razorpay_payment_id,
                res.razorpay_order_id,
                res.razorpay_payment_id,
                res.razorpay_signature,
              )
              .then((response) => response.json())
              .then((result) => {
                if (result.status === 1) {
                  toast.success(result.message)
                  setIsOrderPlaced(true)
                  dispatch(setCartProducts({ data: [] }))
                  dispatch(setCartSubTotal({ data: 0 }))
                } else {
                  toast.error(result.message)
                }
              })
              .catch((error) => {
                console.log(error)
              })
          }
        },
        modal: {
          confirm_close: true,
          ondismiss: async (reason) => {
            if (reason === undefined) {
              handleRazorpayCancel(order_id)
              dispatch(deductUserBalance({ data: walletDeductionAmt || 0 }))
            }
          },
        },
        prefill: {
          name: name,
          email: email,
          contact: mobile,
        },
        theme: {
          color: setting?.setting?.web_settings?.color,
        },
      }

      const rzpay = new window.Razorpay(options)
      rzpay.open()
    },
    [Razorpay, setting?.setting?.web_settings?.color],
  )

  const handleRazorpayCancel = (order_id) => {
    api.deleteOrder(user?.jwtToken, order_id)
    setWalletDeductionAmt(walletDeductionAmt)
    setIsOrderPlaced(false)
  }

  const handlePayStackPayment = (email, amount, currency, support_email, orderid) => {
    const handler = PaystackPop.setup({
      key: setting?.payment_setting?.paystack_public_key,
      email: email,
      amount: Number.parseFloat(amount) * 100,
      currency: currency,
      ref: new Date().getTime().toString(),
      label: support_email,
      onClose: () => {
        api.deleteOrder(user?.jwtToken, orderid)
        dispatch(setCartProducts({ data: [] }))
      },
      callback: async (response) => {
        setLoadingPlaceOrder(true)
        await api
          .addTransaction(user?.jwtToken, orderid, response.reference, paymentMethod, "order")
          .then((response) => response.json())
          .then((result) => {
            setLoadingPlaceOrder(false)
            if (result.status === 1) {
              toast.success(result.message)
              setIsOrderPlaced(true)
              dispatch(setCartProducts({ data: [] }))
              dispatch(setCartSubTotal({ data: 0 }))
            } else {
              toast.error(result.message)
            }
          })
          .catch((error) => console.log(error))
      },
    })

    handler.openIframe()
  }

  const handlePlaceOrder = async () => {
    if (!selectedAddressIndex && selectedAddressIndex !== 0) {
      toast.error("Please select or add a delivery address")
      return
    }

    // Get cart items from location state or Redux
    const cartItems = location.state?.cartItems || cart?.cart || []
    console.log("Cart items:", cartItems)

    // Prepare product variant IDs and quantities arrays
    const productVariantIds = cartItems.map((item) => item.product_variant_id)
    const quantities = cartItems.map((item) => item.quantity)

    // Calculate all amounts properly
    const subtotal = cartItems.reduce((sum, item) => {
      return sum + (item.discounted_price > 0 ? item.discounted_price * item.quantity : item.price * item.quantity)
    }, 0)

    const deliveryCharge = cart?.checkout?.delivery_charge?.total_delivery_charge || 0
    const handlingFeeDetails = calculateHandlingFee(subtotal)
    const handlingFee = handlingFeeDetails.baseFee // Now using baseFee directly
    const discount = promoCode?.isPromoCode ? promoCode.discount : cart?.promo_code?.discount || 0

    const totalBeforeDeductions = subtotal + deliveryCharge + handlingFee
    const totalAfterDeductions = totalBeforeDeductions - discount - walletDeductionAmt
    const finalTotal = Math.max(totalAfterDeductions, 0) // Ensure not negative

    const selectedAddress = addresses[selectedAddressIndex]

    // Prepare delivery time string
    let deliveryTimeStr
    if (deliveryOption === "instant") {
      deliveryTimeStr = "Instant Delivery"
    } else {
      if (!selectedDate || !deliveryTime) {
        toast.error("Please select delivery date and time")
        return
      }
      const formattedDate = `${selectedDate.getDate()}-${selectedDate.getMonth() + 1}-${selectedDate.getFullYear()}`
      deliveryTimeStr = `${formattedDate} ${deliveryTime}`
    }

    setLoadingPlaceOrder(true)

    try {
      const orderData = {
        product_variant_id: productVariantIds,
        quantity: quantities,
        total: totalBeforeDeductions,
        delivery_charge: deliveryCharge,
        final_total: finalTotal,
        payment_method: paymentMethod.toUpperCase(),
        address_id: selectedAddress.id,
        delivery_time: deliveryTimeStr,
        promocode_id: promoCode?.isPromoCode ? promoCode.code : cart?.promo_code?.promo_code_id || 0,
        wallet_balance: isWalletChecked ? walletDeductionAmt : 0,
        wallet_used: isWalletChecked ? 1 : 0,
        order_note: orderNote || "",
        status: paymentMethod.toLowerCase() === "cod" || paymentMethod.toLowerCase() === "wallet" ? 2 : 1,
      }

      console.log("Final Order payload:", orderData)

      // Call the API to place the order
      const response = await api.placeOrder(
        user?.jwtToken,
        orderData.product_variant_id,
        orderData.quantity,
        orderData.total, // Send as sub_total
        orderData.delivery_charge,
        orderData.final_total,
        orderData.payment_method,
        orderData.address_id,
        orderData.delivery_time,
        orderData.promocode_id,
        orderData.wallet_balance,
        orderData.wallet_used,
        orderData.order_note,
      )

      const result = await response.json()

      if (result?.status !== 1) {
        dispatch(clearCart());
        toast.error(result?.message || "Failed to place order")
        setLoadingPlaceOrder(false)
        return
      }

      setOrderId(result?.data?.order_id)
      // Prepare order confirmation data
      // Order confirmation data
      const confirmationData = {
        orderId: result.data.order_id,
        orderDate: new Date().toISOString(),
        subtotal: subtotal,
        deliveryCharge: deliveryCharge,
        handlingFee: handlingFee,
        gstOnHandlingFee: handlingFee * 0.18, // If you need to show this separately
        discount: promoCode?.isPromoCode ? promoCode.discount : cart?.promo_code?.discount || 0,
        walletDeduction: isWalletChecked ? walletDeductionAmt : 0,
        totalAmount: totalAfterDeductions > 0 ? totalAfterDeductions : 0, // This is the final amount customer pays
        deliveryOption: deliveryOption,
        deliveryTime: deliveryOption === 'instant' ? '15-30 minutes' : `${selectedDate} ${deliveryTime}`,
        paymentMethod: paymentMethod,
        address: addresses[selectedAddressIndex],
        products: cart?.cart || location.state?.cartItems || []
      };
      console.log("Confirmation data:", confirmationData);
      // Store order details in localStorage before redirecting
      localStorage.setItem('orderConfirmation', JSON.stringify(confirmationData));

      // Handle different payment methods
      if (paymentMethod === "cod" || isFullWalletPay) {
        // For COD or full wallet payment
        setIsOrderPlaced(true)
        navigate('/order-confirmation');
        dispatch(setCartProducts({ data: [] }))
        dispatch(setCartSubTotal({ data: 0 }))
        if (isWalletChecked) {
          dispatch(deductUserBalance({ data: walletDeductionAmt }))
        }
      } else {
        // Handle online payment methods
        switch (paymentMethod) {
          case "razorpay":
            const razorpayResponse = await api.initiate_transaction(
              user?.jwtToken,
              result?.data?.order_id,
              "Razorpay",
              "order",
            )
            const razorpayResult = await razorpayResponse.json()

            if (razorpayResult.status === 1) {
              handleRazorpayPayment(
                result.data.order_id,
                razorpayResult.data.transaction_id,
                totalPayment, // Use the calculated totalPayment
                user.user.name,
                user.user.email,
                user.user.mobile,
                setting.setting?.app_name,
              )
            } else {
              api.deleteOrder(user?.jwtToken, result.data.order_id)
              toast.error(razorpayResult.message)
            }
            break

          case "stripe":
            const stripeResponse = await api.initiate_transaction(
              user?.jwtToken,
              result.data.order_id,
              "Stripe",
              "order",
            )
            const stripeResult = await stripeResponse.json()

            if (stripeResult.status === 1) {
              setStripeOrderId(result.data.order_id)
              setStripeClientSecret(stripeResult.data.client_secret)
              setStripeTransactionId(stripeResult.data.id)
              setShowStripeModal(true)
            } else {
              api.deleteOrder(user?.jwtToken, result.data.order_id)
              toast.error(stripeResult.message)
            }
            break

          case "paypal":
            const paypalResponse = await api.initiate_transaction(
              user?.jwtToken,
              result.data.order_id,
              "Paypal",
              "order",
            )
            const paypalResult = await paypalResponse.json()

            if (paypalResult.status === 1) {
              setPaymentUrl(paypalResult.data.paypal_redirect_url)
              if (isWalletChecked) {
                dispatch(deductUserBalance({ data: walletDeductionAmt }))
              }
              window.open(`${paypalResult.data.paypal_redirect_url}&&amount=${subtotal}`, "_parent")
            } else {
              toast.error(paypalResult.message)
              api.deleteOrder(user?.jwtToken, result.data.order_id)
            }
            break

          case "cashfree":
            const cashfreeResponse = await api.initiate_transaction(
              user?.jwtToken,
              result?.data?.order_id,
              "Cashfree",
              "order",
            )
            const cashfreeResult = await cashfreeResponse.json()

            if (cashfreeResult.status === 1) {
              if (isWalletChecked) {
                dispatch(deductUserBalance({ data: walletDeductionAmt }))
              }
              // Use window.location.href instead of window.open
              window.location.href = cashfreeResult.data.redirectUrl
            } else {
              toast.error(cashfreeResult.message)
              api.deleteOrder(user?.jwtToken, result.data.order_id)
            }
            break

          case "paytabs":
            const paytabsResponse = await api.initiate_transaction(
              user?.jwtToken,
              result.data.order_id,
              "Paytabs",
              "order",
            )
            const paytabsResult = await paytabsResponse.json()

            if (paytabsResult.status === 1) {
              setPaymentUrl(paytabsResult.data.redirectUrl)
              if (isWalletChecked) {
                dispatch(deductUserBalance({ data: walletDeductionAmt }))
              }
              window.open(paytabsResult.data.redirectUrl, "_parent")
            } else {
              toast.error(paytabsResult.message)
              api.deleteOrder(user?.jwtToken, result.data.order_id)
            }
            break

          case "phonepe":
            const phonepeResponse = await api.initiate_transaction(
              user?.jwtToken,
              result.data.order_id,
              "Phonepe",
              "order",
            )
            const phonepeResult = await phonepeResponse.json()

            if (phonepeResult.status === 1) {
              setPaymentUrl(phonepeResult.data.redirectUrl)
              if (isWalletChecked) {
                dispatch(deductUserBalance({ data: walletDeductionAmt }))
              }
              window.open(phonepeResult.data.redirectUrl, "_parent")
            } else {
              toast.error(phonepeResult.message)
              api.deleteOrder(user?.jwtToken, result.data.order_id)
            }
            break

          case "midtrans":
            const midtransResponse = await api.initiate_transaction(
              user?.jwtToken,
              result.data.order_id,
              "Midtrans",
              "order",
            )
            const midtransResult = await midtransResponse.json()

            if (midtransResult.status === 1) {
              setPaymentUrl(midtransResult.data.midtrans_redirect_url.snapUrl)
              if (isWalletChecked) {
                dispatch(deductUserBalance({ data: walletDeductionAmt }))
              }
              window.open(midtransResult.data.snapUrl, "_parent")
            } else {
              toast.error(midtransResult.message)
              api.deleteOrder(user?.jwtToken, result.data.order_id)
            }
            break

          default:
            // For wallet or other direct payments
            setIsOrderPlaced(true)
            dispatch(setCartProducts({ data: [] }))
            dispatch(setCartSubTotal({ data: 0 }))
            if (isWalletChecked) {
              dispatch(deductUserBalance({ data: walletDeductionAmt }))
            }
        }
      }
    } catch (error) {
      console.error(error)
      toast.error("An error occurred while placing your order")
    } finally {
      setLoadingPlaceOrder(false)
    }
  }

  const AddressStep = React.memo(
    ({
      addresses,
      selectedAddressIndex,
      setSelectedAddressIndex,
      showAddressForm,
      setShowAddressForm,
      nextStep,
      setEditingAddress,
    }) => {
      const dispatch = useDispatch();
      const city = useSelector((state) => state.city);
      const [localNewAddress, setLocalNewAddress] = useState({
        id: null,
        name: '',
        mobile: '',
        alternate_mobile: '',
        address: '',
        landmark: '',
        area: '',
        city: '',
        state: '',
        country: '',
        pincode: '',
        type: 'Home',
        is_default: false,
        latitude: city.city ? city.city.latitude : 0,
        longitude: city.city ? city.city.longitude : 0,
      });

      const [localErrors, setLocalErrors] = useState({});
      const [isGeocoding, setIsGeocoding] = useState(false);
      const [mapLoaded, setMapLoaded] = useState(isGoogleMapsLoaded());
      const [mapsError, setMapsError] = useState(null);
      const [locationPermission, setLocationPermission] = useState(null);
      const typingTimeout = useRef(null);
      const autocompleteRef = useRef(null);
      const autocomplete = useRef(null);

      const [localMapPosition, setLocalMapPosition] = useState({
        lat: parseFloat(city.city ? city.city.latitude : 0),
        lng: parseFloat(city.city ? city.city.longitude : 0),
      });

      // Load Google Maps API
      useEffect(() => {
        let mounted = true;

        const loadMaps = async () => {
          try {
            await loadGoogleMaps(import.meta.env.VITE_APP_MAP_API);
            if (mounted) {
              setMapLoaded(true);
            }
          } catch (error) {
            if (mounted) {
              setMapsError(error.message);
              toast.error('Failed to load Google Maps API');
              console.error('Google Maps loading error:', error);
            }
          }
        };

        if (!isGoogleMapsLoaded()) {
          loadMaps();
        } else {
          setMapLoaded(true);
        }

        return () => {
          mounted = false;
        };
      }, []);

      // Check location permission
      useEffect(() => {
        const checkLocationPermission = async () => {
          if (navigator.permissions) {
            try {
              const permissionStatus = await navigator.permissions.query({ name: 'geolocation' });
              setLocationPermission(permissionStatus.state);

              permissionStatus.onchange = () => {
                setLocationPermission(permissionStatus.state);
              };
            } catch (e) {
              console.error("Permission query failed:", e);
              setLocationPermission('prompt');
            }
          } else {
            setLocationPermission('prompt');
          }
        };

        checkLocationPermission();
      }, []);

      // Initialize Google Places Autocomplete
      useEffect(() => {
        if (mapLoaded && window.google && window.google.maps && autocompleteRef.current && !autocomplete.current) {
          autocomplete.current = new window.google.maps.places.Autocomplete(autocompleteRef.current, {
            types: ['geocode'],
            componentRestrictions: { country: 'IN' },
          });

          autocomplete.current.addListener('place_changed', () => {
            const place = autocomplete.current.getPlace();
            if (!place.geometry) {
              toast.error('No details available for this place');
              return;
            }

            if (typingTimeout.current) {
              clearTimeout(typingTimeout.current);
              typingTimeout.current = null;
            }

            let address = '',
              city = '',
              state = '',
              pincode = '',
              country = '',
              area = '',
              landmark = '';

            place.address_components.forEach((component) => {
              if (component.types.includes('street_number') || component.types.includes('route')) {
                address = address ? `${component.long_name} ${address}` : component.long_name;
              }
              if (component.types.includes('locality')) {
                city = component.long_name;
              }
              if (component.types.includes('administrative_area_level_1')) {
                state = component.long_name;
              }
              if (component.types.includes('postal_code')) {
                pincode = component.long_name;
              }
              if (component.types.includes('country')) {
                country = component.long_name;
              }
              if (component.types.includes('sublocality') || component.types.includes('neighborhood')) {
                area = component.long_name;
              }
              if (component.types.includes('point_of_interest') || component.types.includes('establishment')) {
                landmark = component.long_name;
              }
            });

            const lat = place.geometry.location.lat();
            const lng = place.geometry.location.lng();

            setLocalNewAddress((prev) => ({
              ...prev,
              address: address || place.formatted_address || prev.address,
              landmark: landmark || prev.landmark,
              area: area || prev.area,
              city: city || prev.city,
              state: state || prev.state,
              pincode: pincode || prev.pincode,
              country: country || prev.country,
              latitude: lat.toString(),
              longitude: lng.toString(),
            }));

            setLocalMapPosition({ lat, lng });
          });
        }

        return () => {
          if (autocomplete.current && window.google?.maps) {
            window.google.maps.event.clearInstanceListeners(autocomplete.current);
          }
        };
      }, [mapLoaded]);

      const scrollToFirstError = () => {
        const firstError = Object.keys(localErrors)[0];
        if (firstError) {
          const element = document.querySelector(`[name="${firstError}"]`);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
            element.focus();
          }
        }
      };

      const handleStreetChange = useCallback(
        (e) => {
          const { name, value } = e.target;

          setLocalNewAddress((prev) => ({
            ...prev,
            [name]: value,
            isManualInput: true,
          }));

          if (typingTimeout.current) {
            clearTimeout(typingTimeout.current);
          }

          if (!value.trim() || !mapLoaded || !window.google || !window.google.maps) {
            return;
          }

          typingTimeout.current = setTimeout(() => {
            const geocoder = new window.google.maps.Geocoder();
            const fullAddress = `${value}, ${localNewAddress.city || ''}, ${localNewAddress.state || ''}, ${localNewAddress.country || ''}`.trim();

            setIsGeocoding(true);
            geocoder.geocode({ address: fullAddress }, (results, status) => {
              setIsGeocoding(false);
              if (status === 'OK' && results[0]) {
                const location = results[0].geometry.location;
                const lat = location.lat();
                const lng = location.lng();

                setLocalMapPosition({ lat, lng });

                setLocalNewAddress((prev) => {
                  if (prev.isManualInput && prev.address !== value) {
                    return {
                      ...prev,
                      isManualInput: false,
                      latitude: lat.toString(),
                      longitude: lng.toString(),
                    };
                  }

                  let city = prev.city,
                    state = prev.state,
                    country = prev.country,
                    pincode = prev.pincode,
                    area = prev.area,
                    landmark = prev.landmark;

                  results[0].address_components.forEach((component) => {
                    if (component.types.includes('locality')) {
                      city = component.long_name;
                    }
                    if (component.types.includes('administrative_area_level_1')) {
                      state = component.long_name;
                    }
                    if (component.types.includes('country')) {
                      country = component.long_name;
                    }
                    if (component.types.includes('postal_code')) {
                      pincode = component.long_name;
                    }
                    if (component.types.includes('sublocality') || component.types.includes('neighborhood')) {
                      area = component.long_name;
                    }
                    if (component.types.includes('point_of_interest') || component.types.includes('establishment')) {
                      landmark = component.long_name;
                    }
                  });

                  return {
                    ...prev,
                    isManualInput: false,
                    city,
                    state,
                    country,
                    pincode,
                    area,
                    landmark,
                    latitude: lat.toString(),
                    longitude: lng.toString(),
                  };
                });
              } else {
                toast.error(
                  status === 'ZERO_RESULTS'
                    ? 'No location found for this address. Please refine your input.'
                    : 'Error geocoding address. Please try again.'
                );
              }
            });
          }, 1000);
        },
        [localNewAddress.city, localNewAddress.state, localNewAddress.country, mapLoaded]
      );

      const handleCurrentLocation = () => {
        if (!mapLoaded || !window.google?.maps) {
          toast.error('Google Maps not loaded yet, please try again.');
          return;
        }

        if (!navigator.geolocation) {
          toast.error('Geolocation is not supported by your browser');
          return;
        }

        if (locationPermission === 'denied') {
          toast.error('Please enable location permissions in your browser settings');
          return;
        }

        navigator.geolocation.getCurrentPosition(
          (position) => {
            const latLng = {
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            };

            setLocalMapPosition({
              lat: parseFloat(latLng.lat),
              lng: parseFloat(latLng.lng),
            });

            setLocalNewAddress((prev) => ({
              ...prev,
              latitude: latLng.lat.toString(),
              longitude: latLng.lng.toString(),
            }));

            // Reverse geocode to get address details
            const geocoder = new window.google.maps.Geocoder();
            geocoder.geocode({ location: latLng }, (results, status) => {
              if (status === 'OK' && results[0]) {
                let address = '',
                  country = '',
                  pincode = '',
                  landmark = '',
                  area = '',
                  state_ = '',
                  city = '';

                results[0].address_components.forEach((res_add) => {
                  if (res_add.types.includes('premise') || res_add.types.includes('plus_code') || res_add.types.includes('route')) {
                    address = res_add.long_name;
                  }
                  if (res_add.types.includes('political')) {
                    landmark = res_add.long_name;
                  }
                  if (
                    res_add.types.includes('administrative_area_level_3') ||
                    res_add.types.includes('administrative_area_level_2') ||
                    res_add.types.includes('sublocality')
                  ) {
                    area = res_add.long_name;
                  }
                  if (res_add.types.includes('administrative_area_level_1')) {
                    state_ = res_add.long_name;
                  }
                  if (res_add.types.includes('country')) {
                    country = res_add.long_name;
                  }
                  if (res_add.types.includes('postal_code')) {
                    pincode = res_add.long_name;
                  }
                  if (res_add.types.includes('locality')) {
                    city = res_add.long_name;
                  }
                });

                setLocalNewAddress((prev) => ({
                  ...prev,
                  address: address || results[0].formatted_address || prev.address,
                  landmark: landmark || prev.landmark,
                  city: city || prev.city,
                  area: area || prev.area,
                  state: state_ || prev.state,
                  pincode: pincode || prev.pincode,
                  country: country || prev.country,
                }));
              }
            });
          },
          (error) => {
            console.log('Geolocation error:', error);
            if (error.code === error.PERMISSION_DENIED) {
              toast.error('Location access was denied. Please enable it to use this feature.');
            } else if (error.code === error.TIMEOUT) {
              toast.error('Location request timed out. Please try again or enter manually.');
            } else {
              toast.error('Error getting your location. Please try again or enter manually.');
            }
          }
        );
      };

      const onMarkerDragEnd = (e) => {
        if (!mapLoaded || !window.google?.maps) {
          toast.error('Google Maps not loaded yet, please try again.');
          return;
        }

        setIsGeocoding(true);
        const prev_latlng = {
          lat: localMapPosition.lat,
          lng: localMapPosition.lng,
        };

        const geocoder = new window.google.maps.Geocoder();

        geocoder.geocode(
          {
            location: {
              lat: e.latLng.lat(),
              lng: e.latLng.lng(),
            },
          },
          (response) => {
            if (response.results[0]) {
              setLocalMapPosition({
                lat: parseFloat(e.latLng.lat()),
                lng: parseFloat(e.latLng.lng()),
              });

              let address = '',
                country = '',
                pincode = '',
                landmark = '',
                area = '',
                state_ = '',
                city = '';
              response.results[0].address_components.forEach((res_add) => {
                if (res_add.types.includes('premise') || res_add.types.includes('plus_code') || res_add.types.includes('route')) {
                  address = res_add.long_name;
                }
                if (res_add.types.includes('political')) {
                  landmark = res_add.long_name;
                }
                if (
                  res_add.types.includes('administrative_area_level_3') ||
                  res_add.types.includes('administrative_area_level_2') ||
                  res_add.types.includes('sublocality')
                ) {
                  area = res_add.long_name;
                }
                if (res_add.types.includes('administrative_area_level_1')) {
                  state_ = res_add.long_name;
                }
                if (res_add.types.includes('country')) {
                  country = res_add.long_name;
                }
                if (res_add.types.includes('postal_code')) {
                  pincode = res_add.long_name;
                }
                if (res_add.types.includes('locality')) {
                  city = res_add.long_name;
                }
              });

              if (address === '' || area === '') {
                setLocalMapPosition({
                  lat: prev_latlng.lat,
                  lng: prev_latlng.lng,
                });
              } else {
                setLocalNewAddress((prev) => ({
                  ...prev,
                  address: address,
                  landmark: landmark,
                  city: city,
                  area: area,
                  pincode: pincode,
                  country: country,
                  state: state_,
                  latitude: e.latLng.lat().toString(),
                  longitude: e.latLng.lng().toString(),
                }));
              }
              setIsGeocoding(false);
            }
          }
        );
      };

      const validateNewAddress = () => {
        const newErrors = {};

        // Required fields validation
        if (!localNewAddress.name.trim()) newErrors.name = "Name is required";
        if (!localNewAddress.mobile.trim()) newErrors.mobile = "Mobile number is required";
        if (!localNewAddress.address.trim()) newErrors.address = "Street address is required";
        if (!localNewAddress.landmark?.trim()) newErrors.landmark = "Landmark is required";
        if (!localNewAddress.area?.trim()) newErrors.area = "Area is required";
        if (!localNewAddress.city.trim()) newErrors.city = "City is required";
        if (!localNewAddress.state.trim()) newErrors.state = "State is required";
        if (!localNewAddress.pincode.trim()) newErrors.pincode = "ZIP code is required";
        if (!localNewAddress.country.trim()) newErrors.country = "Country is required";

        // Mobile number validation
        if (localNewAddress.mobile && !/^\d{10,15}$/.test(localNewAddress.mobile)) {
          newErrors.mobile = "Enter a valid mobile number";
        }

        // Pincode validation
        if (localNewAddress.pincode && !/^\d+$/.test(localNewAddress.pincode)) {
          newErrors.pincode = "ZIP code must be numeric";
        }

        setLocalErrors(newErrors);
        return Object.keys(newErrors).length === 0;
      };

      const handleInputChange = (e) => {
        const { name, value, type, checked } = e.target;
        setLocalNewAddress((prev) => ({
          ...prev,
          [name]: type === 'checkbox' ? checked : value,
        }));
      };

      const handleAddressTypeChange = (type) => {
        setLocalNewAddress((prev) => ({ ...prev, type }));
      };

      const resetForm = () => {
        setLocalNewAddress({
          id: null,
          name: '',
          mobile: '',
          alternate_mobile: '',
          address: '',
          landmark: '',
          area: '',
          city: '',
          state: '',
          country: '',
          pincode: '',
          type: 'Home',
          is_default: false,
          latitude: city.city ? city.city.latitude : 0,
          longitude: city.city ? city.city.longitude : 0,
        });
        setLocalErrors({});
        setLocalMapPosition({
          lat: parseFloat(city.city ? city.city.latitude : 0),
          lng: parseFloat(city.city ? city.city.longitude : 0),
        });
        setShowAddressForm(false);
        setEditingAddress(null);
      };

      const MapComponent = React.memo(() => {
        if (!mapLoaded) {
          return (
            <div className="flex flex-col justify-center items-center h-full">
              <svg
                className="animate-spin h-8 w-8 text-pink-500"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              <p className="mt-2 text-gray-600">Loading map...</p>
            </div>
          );
        }

        return (
          <div className="h-full relative">
            <button
              onClick={handleCurrentLocation}
              className="absolute top-4 right-4 z-10 bg-white p-2 rounded-full shadow-md hover:bg-gray-100"
              disabled={locationPermission === 'denied' || isGeocoding}
            >
              <BiCurrentLocation size={20} />
            </button>
            {isGeocoding && (
              <div className="absolute top-4 left-4 z-10 bg-white p-2 rounded shadow-md text-gray-600">
                Updating location...
              </div>
            )}
            <GoogleMap
              zoom={15}
              center={localMapPosition}
              mapContainerStyle={{ width: "100%", height: "100%" }}
              options={{
                disableDefaultUI: true,
                zoomControl: true,
                fullscreenControl: true,
              }}
              onClick={(e) => {
                if (!isGeocoding) {
                  const lat = e.latLng.lat();
                  const lng = e.latLng.lng();
                  setLocalMapPosition({ lat, lng });
                  setLocalNewAddress((prev) => ({
                    ...prev,
                    latitude: lat.toString(),
                    longitude: lng.toString(),
                  }));
                }
              }}
            >
              <MarkerF position={localMapPosition} draggable={true} onDragEnd={onMarkerDragEnd} />
            </GoogleMap>
          </div>
        );
      });

      const saveNewAddress = async () => {
        // Validate the form first
        if (!validateNewAddress()) {
          // Scroll to the first error
          const firstError = Object.keys(localErrors)[0];
          if (firstError) {
            const element = document.querySelector(`[name="${firstError}"]`);
            if (element) {
              element.scrollIntoView({ behavior: 'smooth', block: 'center' });
              element.focus();
            }
          }
          return;
        }

        setLoadingSaveAddress(true);
        try {
          // Prepare address data for API
          const addressData = {
            name: localNewAddress.name.trim(),
            mobile: localNewAddress.mobile.toString().trim(),
            alternate_mobile: localNewAddress.alternate_mobile ? localNewAddress.alternate_mobile.toString().trim() : "",
            address: localNewAddress.address.trim(),
            landmark: localNewAddress.landmark?.trim() || "",
            area: localNewAddress.area?.trim() || "",
            city: localNewAddress.city.trim(),
            state: localNewAddress.state.trim(),
            country: localNewAddress.country.trim(),
            pincode: localNewAddress.pincode.trim(),
            type: localNewAddress.type,
            is_default: localNewAddress.is_default ? 1 : 0,
            latitude: localNewAddress.latitude || "0",
            longitude: localNewAddress.longitude || "0",
          };

          let result;
          if (localNewAddress.id) {
            // Update existing address
            const response = await api.updateAddress(
              user?.jwtToken,
              localNewAddress.id,
              addressData.name,
              addressData.mobile,
              addressData.type,
              addressData.address,
              addressData.landmark,
              addressData.area,
              addressData.pincode,
              addressData.city,
              addressData.state,
              addressData.country,
              addressData.alternate_mobile,
              addressData.latitude,
              addressData.longitude,
              addressData.is_default,
            );
            result = await response.json();
          } else {
            // Create new address
            const response = await api.addAddress(
              user?.jwtToken,
              addressData.name,
              addressData.mobile,
              addressData.type,
              addressData.address,
              addressData.landmark,
              addressData.area,
              addressData.pincode,
              addressData.city,
              addressData.state,
              addressData.country,
              addressData.alternate_mobile,
              addressData.latitude,
              addressData.longitude,
              addressData.is_default,
            );
            result = await response.json();
          }

          if (result.status !== 1) {
            toast.error(result.message || "Failed to save address");
            return;
          }

          // Update local state with the new/updated address
          let updatedAddresses;
          if (localNewAddress.id) {
            updatedAddresses = addresses.map(addr =>
              addr.id === localNewAddress.id ? result.data : addr
            );
          } else {
            updatedAddresses = [...addresses, result.data];
          }

          // If this address is set as default, remove default from others
          if (localNewAddress.is_default) {
            updatedAddresses = updatedAddresses.map(addr => {
              if (addr.id !== result.data.id && addr.is_default === 1) {
                return { ...addr, is_default: 0 };
              }
              return addr;
            });
          }

          setAddresses(updatedAddresses);
          dispatch(setAddress({ data: updatedAddresses }));

          // If this is a new address or the updated address is default, select it
          if (!localNewAddress.id || localNewAddress.is_default) {
            const index = updatedAddresses.findIndex(addr => addr.id === result.data.id);
            setSelectedAddressIndex(index);
            dispatch(setSelectedAddress({ data: result.data }));
          }

          resetForm();
          toast.success(`Address ${localNewAddress.id ? "updated" : "saved"} successfully!`);
        } catch (error) {
          console.error("Error saving address:", error);
          toast.error("Failed to save address. Please try again.");
        } finally {
          setLoadingSaveAddress(false);
        }
      };

      const handleAddressSelect = (index) => {
        console.log("Address selected:", addresses[index]);
        setSelectedAddressIndex(index);
        dispatch(setSelectedAddress({ data: addresses[index] }));
      };

      const handleNext = () => {
        if (selectedAddressIndex !== null) {
          nextStep();
        } else if (addresses.length === 0 && showAddressForm) {
          if (validateNewAddress()) {
            saveNewAddress();
          } else {
            scrollToFirstError();
          }
        } else {
          toast.error("Please select or add an address");
        }
      };

      const handleEditAddress = (address) => {
        setEditingAddress(address);
        setShowAddressForm(true);
        setLocalNewAddress({
          id: address.id,
          name: address.name,
          mobile: address.mobile,
          alternate_mobile: address.alternate_mobile || '',
          address: address.address,
          landmark: address.landmark || '',
          area: address.area || '',
          city: address.city,
          state: address.state,
          country: address.country,
          pincode: address.pincode,
          type: address.type || 'Home',
          is_default: address.is_default === 1,
          latitude: address.latitude || (city.city ? city.city.latitude : 0),
          longitude: address.longitude || (city.city ? city.city.longitude : 0),
        });
        setLocalMapPosition({
          lat: parseFloat(address.latitude || (city.city ? city.city.latitude : 0)),
          lng: parseFloat(address.longitude || (city.city ? city.city.longitude : 0)),
        });
      };

      return (
        <div className="w-full">
          <ConfirmationDialog
            isOpen={isConfirmDialogOpen}
            message="Do you really want to delete this address?"
            onClose={() => setIsConfirmDialogOpen(false)}
            onConfirm={handleConfirmDelete}
          />

          <div className="bg-white border-b border-gray-200 px-6 py-4">
            <h2 className="text-lg sm:text-3xl font-bold text-gray-900">Delivery Address</h2>
            <p className="text-gray-600 text-sm">Choose where you'd like your order delivered</p>
          </div>

          <div className="px-6 py-8">
            {addresses.length > 0 && (
              <div className="mb-8">
                <h3 className="text-sm sm:text-xl font-semibold mb-6 text-gray-800 flex items-center">
                  <MapPin className="h-5 w-5 mr-2" style={{ color: "#fc2e6bed" }} />
                  Your Saved Addresses
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                  {addresses.map((address, index) => (
                    <div
                      key={index}
                      className={`border-2 rounded-xl p-4 sm:p-6 cursor-pointer transition-all duration-300 ${selectedAddressIndex === index
                        ? "border-[#fc2e6bed] bg-[#fc2e6bed]/5 shadow-lg"
                        : "border-gray-200 hover:border-[#fc2e6bed]/50 hover:shadow-md"
                        }`}
                      onClick={() => handleAddressSelect(index)}
                    >
                      {/* Header with name and action buttons */}
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center flex-wrap gap-2">
                          <h4 className="font-semibold text-gray-900 text-base sm:text-lg">{address.name}</h4>
                          {address.is_default && (
                            <span className="text-[10px] sm:text-xs px-2.5 py-1 rounded-full bg-green-100 text-green-700 font-medium">
                              Default
                            </span>
                          )}
                        </div>

                        <div className="flex items-center space-x-2">
                          <span
                            className="text-[10px] sm:text-xs px-2.5 py-1 rounded-full font-medium"
                            style={{ backgroundColor: "#fc2e6bed", color: "white" }}
                          >
                            {address.type}
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEditAddress(address);
                            }}
                            className="text-blue-500 hover:text-blue-700 p-1"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-4 w-4 sm:h-5 sm:w-5"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                              />
                            </svg>
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteAddress(address.id);
                            }}
                            className="text-red-500 hover:text-red-700 p-1"
                            disabled={isDeleting && addressToDelete === address.id}
                          >
                            {isDeleting && addressToDelete === address.id ? (
                              <svg
                                className="animate-spin h-4 w-4 sm:h-5 sm:w-5 text-red-500"
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                              >
                                <circle
                                  className="opacity-25"
                                  cx="12"
                                  cy="12"
                                  r="10"
                                  stroke="currentColor"
                                  strokeWidth="4"
                                ></circle>
                                <path
                                  className="opacity-75"
                                  fill="currentColor"
                                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                ></path>
                              </svg>
                            ) : (
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="h-4 w-4 sm:h-5 sm:w-5"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                                />
                              </svg>
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Address Details */}
                      <div className="space-y-2 text-gray-600 text-sm sm:text-base">
                        <p className="font-medium">{address.address}</p>
                        {address.landmark && <p>Near: {address.landmark}</p>}
                        <p>
                          {address.city}, {address.state} {address.pincode}
                        </p>
                        <p>{address.country}</p>

                        <div className="pt-3 mt-3 border-t border-gray-100 flex items-center text-xs sm:text-sm">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-4 w-4 mr-2 text-gray-500"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                            />
                          </svg>
                          {address.mobile}
                        </div>
                      </div>

                      {selectedAddressIndex === index && (
                        <div className="mt-4 flex justify-end">
                          <span
                            className="text-xs font-medium px-3 py-1 rounded-full"
                            style={{ backgroundColor: "#fc2e6bed", color: "white" }}
                          >
                            Selected
                          </span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

            )}

            <div className="mb-8">
              <button
                onClick={() => {
                  setShowAddressForm(!showAddressForm);
                  if (!showAddressForm) {
                    setEditingAddress(null);
                  }
                }}
                className="flex items-center px-6 py-3 rounded-lg font-medium text-white shadow-md transition-all duration-300 hover:shadow-lg"
                style={{ backgroundColor: "#fc2e6bed" }}
              >
                {showAddressForm ? (
                  <>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 mr-2"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                    Hide Address Form
                  </>
                ) : (
                  <>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 mr-2"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                      />
                    </svg>
                    Add New Address
                  </>
                )}
              </button>
            </div>

            {showAddressForm && (
              <div className="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-50">
                <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                  <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-6xl sm:w-full">
                    <div className="bg-white p-8">
                      <div className="flex justify-between items-center mb-6">
                        <h3 className="text-2xl font-bold text-gray-900 flex items-center">
                          <MapPin className="h-6 w-6 mr-3" style={{ color: "#fc2e6bed" }} />
                          {localNewAddress.id ? "Edit Address" : "Add New Address"}
                        </h3>
                        <button onClick={resetForm} className="text-gray-500 hover:text-gray-700">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-6 w-6"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M6 18L18 6M6 6l12 12"
                            />
                          </svg>
                        </button>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <div className="h-[500px] rounded-lg overflow-hidden border border-gray-200">
                          <MapComponent />
                        </div>

                        <div className="space-y-6">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Full Name <span className="text-red-500">*</span>
                            </label>
                            <input
                              type="text"
                              name="name"
                              value={localNewAddress.name}
                              onChange={handleInputChange}
                              placeholder="Enter your full name"
                              className={`block w-full px-4 py-3 rounded-lg border ${localErrors.name
                                ? "border-red-500 bg-red-50"
                                : "border-gray-300 focus:border-[#fc2e6bed] focus:ring-2 focus:ring-[#fc2e6bed]/20"
                                } transition-colors`}
                              required
                            />
                            {localErrors.name && <p className="mt-1 text-sm text-red-600">{localErrors.name}</p>}
                          </div>

                          <div className="grid gridcols-1 md:grid-cols-2 gap-6">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                Mobile Number <span className="text-red-500">*</span>
                              </label>
                              <div className="relative">
                                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" >
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                                  </svg>
                                </div>
                                <input
                                  type="text"
                                  name="mobile"
                                  value={localNewAddress.mobile}
                                  onChange={handleInputChange}
                                  placeholder="Enter your mobile number"
                                  className={`block w-full pl-10 pr-4 py-3 rounded-lg border ${localErrors.mobile ? "border-red-500 bg-red-50" : "border-gray-300 focus:border-[#fc2e6bed] focus:ring-2 focus:ring-[#fc2e6bed]/20"} transition-colors`}
                                  required
                                />
                              </div>
                              {localErrors.mobile && <p className="mt-1 text-sm text-red-600">{localErrors.mobile}</p>}
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                Alternate Mobile (Optional)
                              </label>
                              <div className="relative">
                                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                  <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    className="h-5 w-5 text-gray-400"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke="currentColor"
                                  >
                                    <path
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      strokeWidth={2}
                                      d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                                    />
                                  </svg>
                                </div>
                                <input
                                  type="text"
                                  name="alternate_mobile"
                                  value={localNewAddress.alternate_mobile}
                                  onChange={handleInputChange}
                                  placeholder="Enter alternate number (optional)"
                                  className="block w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:border-[#fc2e6bed] focus:ring-2 focus:ring-[#fc2e6bed]/20 transition-colors"
                                />
                              </div>
                            </div>
                          </div>

                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Street Address <span className="text-red-500">*</span>
                            </label>
                            <div className="relative">
                              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                <MapPin className="h-5 w-5 text-gray-400" />
                              </div>
                              <input
                                ref={autocompleteRef}
                                type="text"
                                name="address"
                                value={localNewAddress.address}
                                onChange={handleStreetChange}
                                placeholder="Enter your street address"
                                className={`block w-full pl-10 pr-4 py-3 rounded-lg border ${localErrors.address
                                  ? "border-red-500 bg-red-50"
                                  : "border-gray-300 focus:border-[#fc2e6bed] focus:ring-2 focus:ring-[#fc2e6bed]/20"
                                  } transition-colors`}
                                required
                              />
                            </div>
                            {localErrors.address && <p className="mt-1 text-sm text-red-600">{localErrors.address}</p>}
                            {localNewAddress.latitude && localNewAddress.longitude && (
                              <p className="text-xs text-gray-500 mt-1">
                                Coordinates: {Number.parseFloat(localNewAddress.latitude).toFixed(6)},{" "}
                                {Number.parseFloat(localNewAddress.longitude).toFixed(6)}
                              </p>
                            )}
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                Landmark <span className="text-red-500">*</span>
                              </label>
                              <input
                                type="text"
                                name="landmark"
                                value={localNewAddress.landmark}
                                onChange={handleInputChange}
                                placeholder="Enter a nearby landmark"
                                className={`block w-full px-4 py-3 rounded-lg border ${localErrors.landmark ? "border-red-500 bg-red-50" : "border-gray-300"
                                  } focus:border-[#fc2e6bed] focus:ring-2 focus:ring-[#fc2e6bed]/20 transition-colors`}
                                required
                              />
                              {localErrors.landmark && (
                                <p className="mt-1 text-sm text-red-600">{localErrors.landmark}</p>
                              )}
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                Area <span className="text-red-500">*</span>
                              </label>
                              <input
                                type="text"
                                name="area"
                                value={localNewAddress.area}
                                onChange={handleInputChange}
                                placeholder="Enter your area/locality"
                                className={`block w-full px-4 py-3 rounded-lg border ${localErrors.area ? "border-red-500 bg-red-50" : "border-gray-300"
                                  } focus:border-[#fc2e6bed] focus:ring-2 focus:ring-[#fc2e6bed]/20 transition-colors`}
                                required
                              />
                              {localErrors.area && (
                                <p className="mt-1 text-sm text-red-600">{localErrors.area}</p>
                              )}
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                City <span className="text-red-500">*</span>
                              </label>
                              <input
                                type="text"
                                name="city"
                                value={localNewAddress.city}
                                onChange={handleInputChange}
                                placeholder="Enter your city"
                                className={`block w-full px-4 py-3 rounded-lg border ${localErrors.city
                                  ? "border-red-500 bg-red-50"
                                  : "border-gray-300 focus:border-[#fc2e6bed] focus:ring-2 focus:ring-[#fc2e6bed]/20"
                                  } transition-colors`}
                                required
                              />
                              {localErrors.city && <p className="mt-1 text-sm text-red-600">{localErrors.city}</p>}
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                State <span className="text-red-500">*</span>
                              </label>
                              <input
                                type="text"
                                name="state"
                                value={localNewAddress.state}
                                onChange={handleInputChange}
                                placeholder="Enter your state"
                                className={`block w-full px-4 py-3 rounded-lg border ${localErrors.state
                                  ? "border-red-500 bg-red-50"
                                  : "border-gray-300 focus:border-[#fc2e6bed] focus:ring-2 focus:ring-[#fc2e6bed]/20"
                                  } transition-colors`}
                                required
                              />
                              {localErrors.state && <p className="mt-1 text-sm text-red-600">{localErrors.state}</p>}
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">
                                ZIP Code <span className="text-red-500">*</span>
                              </label>
                              <input
                                type="number"
                                name="pincode"
                                value={localNewAddress.pincode}
                                onChange={handleInputChange}
                                placeholder="Enter ZIP code"
                                className={`block w-full px-4 py-3 rounded-lg border ${localErrors.pincode
                                  ? "border-red-500 bg-red-50"
                                  : "border-gray-300 focus:border-[#fc2e6bed] focus:ring-2 focus:ring-[#fc2e6bed]/20"
                                  } transition-colors`}
                                required
                              />
                              {localErrors.pincode && (
                                <p className="mt-1 text-sm text-red-600">{localErrors.pincode}</p>
                              )}
                            </div>
                          </div>

                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Country <span className="text-red-500">*</span>
                            </label>
                            <input
                              type="text"
                              name="country"
                              value={localNewAddress.country}
                              onChange={handleInputChange}
                              placeholder="Enter your country"
                              className={`block w-full px-4 py-3 rounded-lg border ${localErrors.country
                                ? "border-red-500 bg-red-50"
                                : "border-gray-300 focus:border-[#fc2e6bed] focus:ring-2 focus:ring-[#fc2e6bed]/20"
                                } transition-colors`}
                              required
                            />
                            {localErrors.country && <p className="mt-1 text-sm text-red-600">{localErrors.country}</p>}
                          </div>

                          <div className="pt-4">
                            <label className="block text-sm font-medium text-gray-700 mb-3">Address Type</label>
                            <div className="flex flex-wrap gap-3">
                              {["Home", "Office", "Other"].map((type) => (
                                <button
                                  key={type}
                                  type="button"
                                  onClick={() => handleAddressTypeChange(type)}
                                  className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-200 ${localNewAddress.type === type
                                    ? "text-white shadow-md"
                                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                                    }`}
                                  style={localNewAddress.type === type ? { backgroundColor: "#fc2e6bed" } : {}}
                                >
                                  {type}
                                </button>
                              ))}
                            </div>
                          </div>

                          <div className="pt-4 border-t border-gray-100">
                            <div className="flex items-center justify-between">
                              <label htmlFor="isDefault" className="flex items-center cursor-pointer">
                                <span className="text-sm font-medium text-gray-700 mr-3">Set as default address</span>
                                <div className="relative">
                                  <input
                                    type="checkbox"
                                    id="isDefault"
                                    name="is_default"
                                    checked={localNewAddress.is_default}
                                    onChange={handleInputChange}
                                    className="sr-only"
                                  />
                                  <div
                                    className={`block w-14 h-8 rounded-full transition-colors duration-200 ease-in-out ${localNewAddress.is_default ? "bg-[#fc2e6bed]" : "bg-gray-300"
                                      }`}
                                  ></div>
                                  <div
                                    className={`absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform duration-200 ease-in-out ${localNewAddress.is_default ? "transform translate-x-6" : ""
                                      }`}
                                  ></div>
                                </div>
                              </label>
                            </div>
                          </div>

                          <div className="mt-8">
                            <button
                              onClick={() => {
                                if (!validateNewAddress()) {
                                  const firstError = Object.keys(localErrors)[0];
                                  if (firstError) {
                                    const element = document.querySelector(`[name="${firstError}"]`);
                                    if (element) {
                                      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                      element.focus();
                                    }
                                  }
                                  return;
                                }
                                saveNewAddress();
                              }}
                              disabled={loadingSaveAddress}
                              className="w-full py-3 px-4 rounded-lg font-medium text-white shadow-md transition-all duration-300 flex items-center justify-center hover:shadow-lg"
                              style={{ backgroundColor: "#fc2e6bed" }}
                            >
                              {loadingSaveAddress ? (
                                <>
                                  <svg
                                    className="animate-spin h-5 w-5 mr-2 text-white"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                  >
                                    <circle
                                      className="opacity-25"
                                      cx="12"
                                      cy="12"
                                      r="10"
                                      stroke="currentColor"
                                      strokeWidth="4"
                                    ></circle>
                                    <path
                                      className="opacity-75"
                                      fill="currentColor"
                                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                    ></path>
                                  </svg>
                                  Saving...
                                </>
                              ) : (
                                <>
                                  <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    className="h-5 w-5 mr-2"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke="currentColor"
                                  >
                                    <path
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      strokeWidth={2}
                                      d="M5 13l4 4L19 7"
                                    />
                                  </svg>
                                  Save Address
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-8 flex justify-end">
              <button
                onClick={handleNext}
                className="px-8 py-3 rounded-lg font-medium text-white shadow-lg transition-all duration-300 flex items-center hover:shadow-xl"
                style={{ backgroundColor: "#fc2e6bed" }}
              >
                Continue to Delivery
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 ml-2"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      );
    }
  );

  const DeliveryStep = ({
    deliveryOption,
    setDeliveryOption,
    selectedDate,
    setSelectedDate,
    deliveryTime,
    setDeliveryTime,
    nextStep,
    prevStep,
  }) => {
    const today = new Date()
    const availableDates = []

    // Generate next 5 days
    for (let i = 0; i < 5; i++) {
      const date = new Date()
      date.setDate(today.getDate() + i)
      availableDates.push(date)
    }

    const timeSlots = [
      { id: "slot1", label: "7 AM - 10 AM", value: "7am-10am", icon: "☀️" },
      { id: "slot2", label: "10 AM - 1 PM", value: "10am-1pm", icon: "🌤️" },
      { id: "slot3", label: "1 PM - 4 PM", value: "1pm-4pm", icon: "☀️" },
      { id: "slot4", label: "4 PM - 7 PM", value: "4pm-7pm", icon: "🌆" },
      { id: "slot5", label: "7 PM - 10 PM", value: "7pm-10pm", icon: "🌙" },
    ]

    const isToday = (date) => {
      return (
        date.getDate() === today.getDate() &&
        date.getMonth() === today.getMonth() &&
        date.getFullYear() === today.getFullYear()
      )
    }

    const formatDateForLabel = (date) => {
      return date.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })
    }

    return (
      <div className="w-full">
        <div className="bg-white border-b border-gray-200 px-6 py-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2 flex items-center">
            <Clock className="h-8 w-8 mr-3" style={{ color: "#fc2e6bed" }} />
            Delivery Options
          </h2>
          <p className="text-gray-600">Choose when you'd like your order delivered</p>
        </div>

        <div className="px-6 py-8">
          <div className="space-y-8">
            <div className="bg-white border border-gray-200 rounded-xl p-1 shadow-sm">
              <div className="flex flex-col md:flex-row">
                <div
                  className={`flex-1 p-6 rounded-lg cursor-pointer transition-all duration-300 relative overflow-hidden ${deliveryOption === "instant" ? "text-white shadow-lg" : "hover:bg-gray-50"
                    }`}
                  style={deliveryOption === "instant" ? { backgroundColor: "#fc2e6bed" } : {}}
                  onClick={() => setDeliveryOption("instant")}
                >
                  {deliveryOption === "instant" && (
                    <div className="absolute top-0 right-0 w-16 h-16">
                      <div
                        className="absolute transform rotate-45 bg-white text-xs font-bold py-1 px-6 right-[-24px] top-[18px] shadow-md"
                        style={{ color: "#fc2e6bed" }}
                      >
                        SELECTED
                      </div>
                    </div>
                  )}

                  <div className="flex items-center">
                    <div
                      className={`flex items-center justify-center w-12 h-12 rounded-full mr-4 ${deliveryOption === "instant" ? "bg-white bg-opacity-20" : "bg-gray-100"
                        }`}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className={`h-6 w-6 ${deliveryOption === "instant" ? "text-white" : "text-gray-600"}`}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M13 10V3L4 14h7v7l9-11h-7z"
                        />
                      </svg>
                    </div>

                    <div>
                      <div className="flex items-center">
                        <input
                          type="radio"
                          id="instant"
                          name="deliveryOption"
                          checked={deliveryOption === "instant"}
                          onChange={() => setDeliveryOption("instant")}
                          className="h-5 w-5 text-[#fc2e6bed]"
                        />
                        <label
                          htmlFor="instant"
                          className={`ml-3 block text-lg font-semibold ${deliveryOption === "instant" ? "text-white" : "text-gray-800"
                            }`}
                        >
                          Instant Delivery
                        </label>
                      </div>
                      <p
                        className={`ml-8 text-sm mt-1 ${deliveryOption === "instant" ? "text-white text-opacity-90" : "text-gray-500"
                          }`}
                      >
                        Delivery within 15 to 30 minutes
                      </p>
                    </div>
                  </div>
                </div>

                <div className="w-full md:w-1 md:h-auto bg-gray-100 my-2 md:my-0 md:mx-2"></div>

                <div
                  className={`flex-1 p-6 rounded-lg cursor-pointer transition-all duration-300 relative overflow-hidden ${deliveryOption === "scheduled" ? "text-white shadow-lg" : "hover:bg-gray-50"
                    }`}
                  style={deliveryOption === "scheduled" ? { backgroundColor: "#fc2e6bed" } : {}}
                  onClick={() => setDeliveryOption("scheduled")}
                >
                  {deliveryOption === "scheduled" && (
                    <div className="absolute top-0 right-0 w-16 h-16">
                      <div
                        className="absolute transform rotate-45 bg-white text-xs font-bold py-1 px-6 right-[-24px] top-[18px] shadow-md"
                        style={{ color: "#fc2e6bed" }}
                      >
                        SELECTED
                      </div>
                    </div>
                  )}

                  <div className="flex items-center">
                    <div
                      className={`flex items-center justify-center w-12 h-12 rounded-full mr-4 ${deliveryOption === "scheduled" ? "bg-white bg-opacity-20" : "bg-gray-100"
                        }`}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className={`h-6 w-6 ${deliveryOption === "scheduled" ? "text-white" : "text-gray-600"}`}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                        />
                      </svg>
                    </div>

                    <div>
                      <div className="flex items-center">
                        <input
                          type="radio"
                          id="scheduled"
                          name="deliveryOption"
                          checked={deliveryOption === "scheduled"}
                          onChange={() => setDeliveryOption("scheduled")}
                          className="h-5 w-5 text-[#fc2e6bed]"
                        />
                        <label
                          htmlFor="scheduled"
                          className={`ml-3 block text-lg font-semibold ${deliveryOption === "scheduled" ? "text-white" : "text-gray-800"
                            }`}
                        >
                          Schedule Delivery
                        </label>
                      </div>
                      <p
                        className={`ml-8 text-sm mt-1 ${deliveryOption === "scheduled" ? "text-white text-opacity-90" : "text-gray-500"
                          }`}
                      >
                        Choose your preferred delivery day and time
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {deliveryOption === "scheduled" && (
              <div className="space-y-8 mt-6 p-6 bg-white rounded-xl border border-gray-100 shadow-lg transition-all duration-500 animate-fadeIn">
                <div>
                  <h3 className="text-xl font-semibold mb-5 flex items-center text-gray-700">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 mr-2"
                      style={{ color: "#fc2e6bed" }}
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                    Select Delivery Date
                  </h3>

                  <div className="flex overflow-x-auto pb-4 space-x-3 scrollbar-hide">
                    {availableDates.map((date, index) => {
                      const dayName = date.toLocaleDateString("en-US", { weekday: "short" })
                      const dayNumber = date.getDate()
                      const month = date.toLocaleDateString("en-US", { month: "short" })
                      const isSelectedDate =
                        selectedDate &&
                        selectedDate.getDate() === date.getDate() &&
                        selectedDate.getMonth() === date.getMonth()

                      return (
                        <div
                          key={index}
                          className={`flex-shrink-0 w-24 h-28 flex flex-col items-center justify-center rounded-xl cursor-pointer transition-all duration-300 ${isSelectedDate
                            ? "text-white shadow-md transform scale-105"
                            : "bg-white border border-gray-200 hover:border-[#fc2e6bed]/50 hover:shadow-sm"
                            }`}
                          style={isSelectedDate ? { backgroundColor: "#fc2e6bed" } : {}}
                          onClick={() => setSelectedDate(date)}
                        >
                          <div className={`text-sm font-medium ${isSelectedDate ? "text-white" : "text-gray-500"}`}>
                            {dayName}
                          </div>
                          <div className={`text-2xl font-bold mt-1 ${isSelectedDate ? "text-white" : "text-gray-800"}`}>
                            {dayNumber}
                          </div>
                          <div
                            className={`text-xs mt-1 ${isSelectedDate ? "text-white text-opacity-90" : "text-gray-500"}`}
                          >
                            {month}
                          </div>
                          {isToday(date) && (
                            <span
                              className={`text-xs mt-1 px-2 py-0.5 rounded-full ${isSelectedDate
                                ? "bg-white bg-opacity-20 text-white"
                                : "bg-[#fc2e6bed]/10 text-[#fc2e6bed]"
                                }`}
                            >
                              Today
                            </span>
                          )}
                        </div>
                      )
                    })}
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-5 flex items-center text-gray-700">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5 mr-2"
                      style={{ color: "#fc2e6bed" }}
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                    Select Delivery Time
                  </h3>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {timeSlots.map((slot) => (
                      <div
                        key={slot.id}
                        className={`p-4 rounded-xl cursor-pointer transition-all duration-300 ${deliveryTime === slot.value
                          ? "text-white shadow-md transform scale-105"
                          : "bg-white border border-gray-200 hover:border-[#fc2e6bed]/50 hover:shadow-sm"
                          }`}
                        style={deliveryTime === slot.value ? { backgroundColor: "#fc2e6bed" } : {}}
                        onClick={() => setDeliveryTime(slot.value)}
                      >
                        <div className="flex items-center">
                          <span className="text-xl mr-3">{slot.icon}</span>
                          <div>
                            <div
                              className={`text-sm font-medium ${deliveryTime === slot.value ? "text-white" : "text-gray-800"}`}
                            >
                              {slot.label}
                            </div>
                            {deliveryTime === slot.value && (
                              <div className="text-xs text-white text-opacity-90 mt-1">Selected</div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {selectedDate && deliveryTime && (
                    <div className="mt-6 p-4 bg-green-50 border border-green-100 rounded-lg flex items-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                      <span className="text-sm text-green-700">
                        Your order will be delivered on{" "}
                        <span className="font-semibold">{formatDateForLabel(selectedDate)}</span> between{" "}
                        <span className="font-semibold">
                          {timeSlots.find((slot) => slot.value === deliveryTime)?.label}
                        </span>
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="mt-10 flex justify-between items-center">
            <button
              onClick={prevStep}
              className="flex items-center px-6 py-3 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors duration-300"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              Back to Address
            </button>

            <button
              onClick={nextStep}
              disabled={deliveryOption === "scheduled" && (!selectedDate || !deliveryTime)}
              className={`flex items-center px-8 py-3 rounded-lg text-white font-medium shadow-md transition-all duration-300 ${deliveryOption === "scheduled" && (!selectedDate || !deliveryTime)
                ? "bg-gray-300 cursor-not-allowed"
                : "hover:shadow-lg"
                }`}
              style={
                !(deliveryOption === "scheduled" && (!selectedDate || !deliveryTime))
                  ? { backgroundColor: "#fc2e6bed" }
                  : {}
              }
            >
              Continue to Payment
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 ml-2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>

          {deliveryOption === "scheduled" && (!selectedDate || !deliveryTime) && (
            <div className="mt-3 text-center text-sm" style={{ color: "#fc2e6bed" }}>
              Please select both delivery date and time to continue
            </div>
          )}
        </div>
      </div>
    )
  }

  const PaymentStep = ({
    paymentMethod,
    setPaymentMethod,
    orderNote,
    setOrderNote: propsSetOrderNote,
    nextStep,
    prevStep,
    codAllow,
    setting,
    user,
    isWalletChecked,
    setIsWalletChecked,
    isFullWalletPay,
    totalPayment,
  }) => {
    // Use local state for immediate feedback
    const [localOrderNote, setLocalOrderNote] = useState(orderNote)

    console.log("total payment", totalPayment)

    // Update parent state when local state changes
    useEffect(() => {
      propsSetOrderNote(localOrderNote)
    }, [localOrderNote, propsSetOrderNote])

    // Get enabled payment methods from Redux with safety checks
    const enabledPaymentMethods = useSelector((state) => state.setting?.enabledPaymentMethods || [])

    // Define paymentMethodComponents with useMemo to maintain stable reference
    const paymentMethodComponents = useMemo(
      () => ({
        cod: {
          name: "Cash On Delivery",
          description: totalPayment > 2000 ? "Not available for orders above 2000" : "Pay when your order arrives",
          icon: cod,
          enabled: enabledPaymentMethods.includes("cod") && totalPayment <= 2000,
        },
        stripe: {
          name: "Credit/Debit Card",
          description: "Secure payment via card",
          icon: StripeIcon,
          enabled: enabledPaymentMethods.includes("stripe"),
        },
        paypal: {
          name: "PayPal",
          description: "Fast and secure payment",
          icon: paypal,
          enabled: enabledPaymentMethods.includes("paypal"),
        },
        razorpay: {
          name: "Razorpay",
          description: "Secure payment gateway",
          icon: rozerpay,
          enabled: enabledPaymentMethods.includes("razorpay"),
        },
        paystack: {
          name: "Paystack",
          description: "Secure payment for Africa",
          icon: paystack,
          enabled: enabledPaymentMethods.includes("paystack"),
        },
        cashfree: {
          name: "Cashfree",
          description: "Secure payment gateway",
          icon: cashfree,
          enabled: setting?.payment_setting?.cashfree_payment_method === "1",
        },
        paytabs: {
          name: "Paytabs",
          description: "Secure payment gateway",
          icon: paytabs,
          enabled: enabledPaymentMethods.includes("paytabs"),
        },
        phonepe: {
          name: "PhonePe",
          description: "UPI payments",
          icon: PhonepeSVG,
          enabled: enabledPaymentMethods.includes("phonepe"),
        },
        midtrans: {
          name: "Midtrans",
          description: "Indonesian payments",
          icon: Midtrans,
          enabled: enabledPaymentMethods.includes("midtrans"),
        },
      }),
      [enabledPaymentMethods, totalPayment, setting?.payment_setting],
    )

    useEffect(() => {
      // Only set default if no payment method is selected yet
      if (enabledPaymentMethods.length > 0 && !paymentMethod) {
        if (codAllow === 1) {
          setPaymentMethod("cod")
        } else {
          const firstEnabled = Object.keys(paymentMethodComponents).find(
            (method) => paymentMethodComponents[method].enabled && method !== "cod",
          )
          if (firstEnabled) {
            setPaymentMethod(firstEnabled)
          }
        }
      }
    }, [enabledPaymentMethods, codAllow, paymentMethod, paymentMethodComponents, setPaymentMethod])

    // Show a stylish loading animation if payment methods aren't loaded yet
    if (enabledPaymentMethods.length === 0) {
      return (
        <div className="flex justify-center items-center h-64">
          <div className="relative">
            <div
              className="h-16 w-16 rounded-full border-t-4 border-b-4 animate-spin"
              style={{ borderColor: "#fc2e6bed" }}
            ></div>
            <div
              className="h-10 w-10 rounded-full border-t-4 border-b-4 animate-spin absolute top-3 left-3"
              style={{ borderColor: "#fc2e6bed", opacity: 0.5 }}
            ></div>
          </div>
        </div>
      )
    }

    const handleNext = () => {
      if (!paymentMethod && !isFullWalletPay) {
        toast.error("Please select a payment method")
        return
      }

      // Additional validation for COD when total exceeds limit
      if (paymentMethod === "cod" && subtotal > 2000) {
        toast.error("Please select a payment method")
        return
      }

      nextStep()
    }

    return (
      <div className="w-full">
        <div className="bg-white border-b border-gray-200 px-6 py-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Payment Method</h2>
          <p className="text-gray-600">Choose how you'd like to pay for your order</p>
        </div>

        <div className="px-6 py-8">
          {/* Wallet Section */}
          {user?.user?.balance > 0 && (
            <div className="bg-gray-50 p-6 rounded-xl mb-6 border border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <PiWallet className="mr-3" style={{ color: "#fc2e6bed" }} size={24} />
                  <span className="text-lg font-medium">Wallet Balance</span>
                  <span className="ml-3 font-bold text-lg" style={{ color: "#fc2e6bed" }}>
                    {setting?.setting?.currency} {user.user.balance.toFixed(setting?.setting?.decimal_point || 2)}
                  </span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isWalletChecked}
                    onChange={() => setIsWalletChecked(!isWalletChecked)}
                    className="sr-only peer"
                    disabled={isFullWalletPay}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[#fc2e6bed]/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#fc2e6bed]"></div>
                </label>
              </div>

              {isWalletChecked && (
                <div className="mt-3 text-sm text-gray-600">
                  {isFullWalletPay ? (
                    <span className="text-green-600 font-medium">
                      Your wallet balance will cover the entire order amount.
                    </span>
                  ) : (
                    <span>
                      Your wallet will be used for {setting?.setting?.currency}{" "}
                      {walletDeductionAmt?.toFixed(setting?.setting?.decimal_point || 2)} of the total{" "}
                      {setting?.setting?.currency} {totalPayment?.toFixed(setting?.setting?.decimal_point || 2)}.
                    </span>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Payment Methods */}
          {!isFullWalletPay && (
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-6 flex items-center text-gray-800">
                <CreditCard className="h-6 w-6 mr-3" style={{ color: "#fc2e6bed" }} />
                Choose Payment Method
              </h3>

              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {Object.entries(paymentMethodComponents).map(([methodKey, method]) => {
                  if (!method.enabled) return null

                  const isSelected = paymentMethod === methodKey

                  return (
                    <div
                      key={methodKey}
                      className={`relative overflow-hidden rounded-xl transition-all duration-300 cursor-pointer transform ${isSelected ? "scale-[1.02] shadow-lg" : "hover:scale-[1.01] shadow-md"
                        }`}
                      onClick={() => setPaymentMethod(methodKey)}
                    >
                      <div
                        className={`p-6 h-full bg-white border-2 ${isSelected ? "border-[#fc2e6bed]" : "border-gray-200 hover:border-[#fc2e6bed]/50"
                          } transition-colors`}
                      >
                        {isSelected && (
                          <div className="absolute -top-1 -right-1">
                            <div
                              className="text-white p-2 rounded-bl-lg shadow-lg"
                              style={{ backgroundColor: "#fc2e6bed" }}
                            >
                              <svg className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                <path
                                  fillRule="evenodd"
                                  d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                  clipRule="evenodd"
                                />
                              </svg>
                            </div>
                          </div>
                        )}

                        <div className="flex items-center h-full">
                          <div
                            className={`flex-shrink-0 w-14 h-14 rounded-full flex items-center justify-center ${isSelected ? "text-white" : "bg-gray-100"
                              }`}
                            style={isSelected ? { backgroundColor: "#fc2e6bed" } : {}}
                          >
                            <img
                              src={method.icon || "/placeholder.svg"}
                              alt={method.name}
                              className={`h-8 w-8 ${isSelected ? "filter brightness-0 invert" : ""}`}
                            />
                          </div>

                          <div className="ml-4">
                            <h4 className="font-semibold text-gray-900 text-lg">{method.name}</h4>
                            <p className="text-sm text-gray-600 mt-1">{method.description}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* Order Total */}
          <div className="bg-white p-6 rounded-xl border border-gray-200 mb-6 shadow-sm">
            <div className="flex justify-between items-center border-b border-gray-100 pb-4 mb-4">
              <span className="text-lg font-medium text-gray-700">Order Total:</span>
              <span className="text-2xl font-bold" style={{ color: "#fc2e6bed" }}>
                {setting?.setting?.currency} {totalPayment?.toFixed(setting?.setting?.decimal_point || 2)}
              </span>
            </div>

            {isWalletChecked && !isFullWalletPay && (
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">After wallet deduction:</span>
                <span className="font-semibold">
                  {setting?.setting?.currency}{" "}
                  {(totalPayment + walletDeductionAmt)?.toFixed(setting?.setting?.decimal_point || 2)}
                </span>
              </div>
            )}
          </div>

          {/* Order Note Section */}
          <div className="mb-8 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <label htmlFor="orderNote" className="block font-semibold mb-4 flex items-center text-gray-800 text-lg">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 mr-3"
                style={{ color: "#fc2e6bed" }}
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                />
              </svg>
              Special Instructions (Optional)
            </label>

            <div className="relative">
              <textarea
                id="orderNote"
                rows={4}
                value={localOrderNote}
                onChange={(e) => setLocalOrderNote(e.target.value)}
                className="block w-full rounded-lg border-gray-300 bg-white px-4 py-3 text-gray-700 shadow-sm focus:border-[#fc2e6bed] focus:ring-2 focus:ring-[#fc2e6bed]/20 transition-all duration-200"
                placeholder="Add any special instructions for your order..."
                maxLength={200}
              />
              <div className="absolute bottom-3 right-3 px-2 py-1 bg-white bg-opacity-70 rounded-md text-xs font-medium text-gray-500">
                {localOrderNote.length}/200
              </div>
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-between items-center mt-8 sticky bottom-0 bg-white bg-opacity-95 backdrop-filter backdrop-blur-sm py-4 border-t border-gray-100 z-10">
            <button
              onClick={prevStep}
              className="px-6 py-3 border border-gray-200 rounded-xl font-medium text-gray-600 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-200 transition-all duration-300 flex items-center"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Previous
            </button>

            <button
              onClick={handleNext}
              className={`px-8 py-3 rounded-xl font-medium text-white shadow-md transition-all duration-300 flex items-center ${!paymentMethod && !isFullWalletPay
                ? "bg-gray-300 cursor-not-allowed"
                : "hover:shadow-lg transform hover:-translate-y-1"
                }`}
              style={!paymentMethod && !isFullWalletPay ? {} : { backgroundColor: "#fc2e6bed" }}
            >
              Review Order
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 ml-2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    )
  }

  const SummaryStep = ({
    address,
    deliveryOption,
    selectedDate,
    deliveryTime,
    paymentMethod,
    orderNote,
    subtotal,
    prevStep,
    totalPayment,
  }) => {
    const handlingFeeDetails = calculateHandlingFee(subtotal)
    const handlingFee = handlingFeeDetails.total
    const gstOnHandlingFee = handlingFee * 0.18 // Calculate 18% GST separately
    const discount = promoCode?.isPromoCode ? promoCode.discount : cart?.promo_code?.discount || 0

    const totalBeforeDeductions = Number.parseFloat(subtotal) + deliveryCharge + handlingFee + gstOnHandlingFee
    const totalAfterDeductions = totalBeforeDeductions - discount - (isWalletChecked ? walletDeductionAmt : 0)
    const displayTotal = totalAfterDeductions > 0 ? totalAfterDeductions : 0

    // Don't show COD as selected if total exceeds limit
    const displayPaymentMethod = totalPayment > 2000 && paymentMethod === "cod" ? "" : paymentMethod

    return (
      <div className="w-full">
        <div className="bg-white border-b border-gray-200 px-6 py-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Order Summary</h1>
          <p className="text-gray-600">Review your order details before confirming</p>
        </div>

        <div className="px-6 py-8">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            {/* Left Column - Customer & Delivery Info */}
            <div className="xl:col-span-2 space-y-6">
              {/* Customer Information Card */}
              <div className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-200 hover:shadow-md transition-all duration-300">
                <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                  <div className="flex items-center">
                    <div className="p-2 rounded-lg shadow-sm mr-3" style={{ backgroundColor: "#fc2e6bed" }}>
                      <FolderPen className="text-white h-5 w-5" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800">Customer Information</h3>
                  </div>
                </div>

                <div className="p-6">
                  <div className="bg-white rounded-lg p-4 border border-gray-100">
                    <div className="flex items-start space-x-4">
                      <div
                        className="rounded-full h-12 w-12 flex items-center justify-center"
                        style={{ backgroundColor: "#fc2e6bed" }}
                      >
                        <span className="text-lg font-bold text-white">{address.name?.charAt(0)}</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800 text-lg">{address.name}</h4>
                        <div className="mt-3 flex items-start space-x-2">
                          <MapPin className="h-5 w-5 mt-0.5 flex-shrink-0" style={{ color: "#fc2e6bed" }} />
                          <div>
                            <p className="text-gray-700">{address.address}</p>
                            <p className="text-gray-600">
                              {address.city}, {address.state} {address.pincode}
                            </p>
                            <p className="text-gray-600">{address.country}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Delivery Details Card */}
              <div className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-200 hover:shadow-md transition-all duration-300">
                <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                  <div className="flex items-center">
                    <div className="p-2 rounded-lg shadow-sm mr-3" style={{ backgroundColor: "#fc2e6bed" }}>
                      <Clock className="text-white h-5 w-5" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800">Delivery Details</h3>
                  </div>
                </div>

                <div className="p-6">
                  <div className="relative">
                    {/* Vertical timeline line */}
                    {deliveryOption === "scheduled" && (
                      <div
                        className="absolute left-4 top-0 bottom-0 w-0.5"
                        style={{ backgroundColor: "#fc2e6bed" }}
                      ></div>
                    )}

                    <div
                      className={`bg-white rounded-lg p-4 border border-gray-100 relative ${deliveryOption === "instant" ? "bg-[#fc2e6bed]/5" : ""
                        }`}
                    >
                      {deliveryOption === "instant" ? (
                        <div className="flex items-center">
                          <div className="relative mr-4">
                            <div
                              className="h-10 w-10 rounded-full flex items-center justify-center shadow-md"
                              style={{ backgroundColor: "#fc2e6bed" }}
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="h-5 w-5 text-white"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M13 10V3L4 14h7v7l9-11h-7z"
                                />
                              </svg>
                            </div>
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-800">Instant Delivery</h4>
                            <p className="text-gray-600">Your order will arrive in 15-30 minutes</p>
                          </div>
                        </div>
                      ) : (
                        <div className="ml-8 relative">
                          {/* Date circle */}
                          <div
                            className="absolute -left-12 h-8 w-8 rounded-full flex items-center justify-center shadow-md"
                            style={{ backgroundColor: "#fc2e6bed" }}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-4 w-4 text-white"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                              />
                            </svg>
                          </div>

                          <h4 className="font-semibold text-gray-800">Scheduled Delivery</h4>
                          <p className="text-gray-600 mb-2">
                            {selectedDate?.date}{" "}
                            {new Date(selectedDate?.year, selectedDate?.month).toLocaleString("default", {
                              month: "long",
                            })}
                          </p>

                          {/* Time circle */}
                          <div className="mt-4 relative">
                            <div
                              className="absolute -left-12 top-0 h-8 w-8 rounded-full flex items-center justify-center shadow-md"
                              style={{ backgroundColor: "#fc2e6bed", opacity: 0.8 }}
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="h-4 w-4 text-white"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                                />
                              </svg>
                            </div>
                            <h4 className="font-semibold text-gray-800">Time Window</h4>
                            <p className="text-gray-600">{deliveryTime?.replace("-", " to ")}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Method Card */}
              <div className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-200 hover:shadow-md transition-all duration-300">
                <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                  <div className="flex items-center">
                    <div className="p-2 rounded-lg shadow-sm mr-3" style={{ backgroundColor: "#fc2e6bed" }}>
                      <CreditCard className="text-white h-5 w-5" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800">Payment Method</h3>
                  </div>
                </div>

                <div className="p-6">
                  <div className="bg-gray-50 rounded-lg p-4 border border-gray-100">
                    {/* Payment Method Mapping */}
                    {displayPaymentMethod === "cod" && (
                      <div className="flex items-center">
                        <div
                          className="h-12 w-12 rounded-full flex items-center justify-center shadow-md mr-4"
                          style={{ backgroundColor: "#fc2e6bed" }}
                        >
                          <img
                            src={cod || "/placeholder.svg"}
                            alt="COD"
                            className="h-6 w-6 filter brightness-0 invert"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800">Cash On Delivery</h4>
                          <p className="text-gray-600 text-sm">Pay when your order arrives</p>
                        </div>
                      </div>
                    )}

                    {paymentMethod === "stripe" && (
                      <div className="flex items-center">
                        <div
                          className="h-12 w-12 rounded-full flex items-center justify-center shadow-md mr-4"
                          style={{ backgroundColor: "#fc2e6bed" }}
                        >
                          <img
                            src={StripeIcon || "/placeholder.svg"}
                            alt="Stripe"
                            className="h-6 w-6 filter brightness-0 invert"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800">Credit/Debit Card</h4>
                          <p className="text-gray-600 text-sm">Secure card payment</p>
                        </div>
                      </div>
                    )}

                    {paymentMethod === "paypal" && (
                      <div className="flex items-center">
                        <div
                          className="h-12 w-12 rounded-full flex items-center justify-center shadow-md mr-4"
                          style={{ backgroundColor: "#fc2e6bed" }}
                        >
                          <img
                            src={paypal || "/placeholder.svg"}
                            alt="PayPal"
                            className="h-6 w-6 filter brightness-0 invert"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800">PayPal</h4>
                          <p className="text-gray-600 text-sm">Fast and secure payment</p>
                        </div>
                      </div>
                    )}

                    {paymentMethod === "razorpay" && (
                      <div className="flex items-center">
                        <div
                          className="h-12 w-12 rounded-full flex items-center justify-center shadow-md mr-4"
                          style={{ backgroundColor: "#fc2e6bed" }}
                        >
                          <img
                            src={rozerpay || "/placeholder.svg"}
                            alt="Razorpay"
                            className="h-6 w-6 filter brightness-0 invert"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800">Razorpay</h4>
                          <p className="text-gray-600 text-sm">Secure payment gateway</p>
                        </div>
                      </div>
                    )}

                    {paymentMethod === "paystack" && (
                      <div className="flex items-center">
                        <div
                          className="h-12 w-12 rounded-full flex items-center justify-center shadow-md mr-4"
                          style={{ backgroundColor: "#fc2e6bed" }}
                        >
                          <img
                            src={paystack || "/placeholder.svg"}
                            alt="Paystack"
                            className="h-6 w-6 filter brightness-0 invert"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800">Paystack</h4>
                          <p className="text-gray-600 text-sm">Secure payment for Africa</p>
                        </div>
                      </div>
                    )}

                    {paymentMethod === "cashfree" && (
                      <div className="flex items-center">
                        <div
                          className="h-12 w-12 rounded-full flex items-center justify-center shadow-md mr-4"
                          style={{ backgroundColor: "#fc2e6bed" }}
                        >
                          <img
                            src={cashfree || "/placeholder.svg"}
                            alt="Cashfree"
                            className="h-6 w-6 filter brightness-0 invert"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800">Cashfree</h4>
                          <p className="text-gray-600 text-sm">Secure payment gateway</p>
                        </div>
                      </div>
                    )}

                    {paymentMethod === "paytabs" && (
                      <div className="flex items-center">
                        <div
                          className="h-12 w-12 rounded-full flex items-center justify-center shadow-md mr-4"
                          style={{ backgroundColor: "#fc2e6bed" }}
                        >
                          <img
                            src={paytabs || "/placeholder.svg"}
                            alt="Paytabs"
                            className="h-6 w-6 filter brightness-0 invert"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800">Paytabs</h4>
                          <p className="text-gray-600 text-sm">Secure payment gateway</p>
                        </div>
                      </div>
                    )}

                    {paymentMethod === "phonepe" && (
                      <div className="flex items-center">
                        <div
                          className="h-12 w-12 rounded-full flex items-center justify-center shadow-md mr-4"
                          style={{ backgroundColor: "#fc2e6bed" }}
                        >
                          <img
                            src={PhonepeSVG || "/placeholder.svg"}
                            alt="PhonePe"
                            className="h-6 w-6 filter brightness-0 invert"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800">PhonePe</h4>
                          <p className="text-gray-600 text-sm">UPI payments</p>
                        </div>
                      </div>
                    )}

                    {paymentMethod === "midtrans" && (
                      <div className="flex items-center">
                        <div
                          className="h-12 w-12 rounded-full flex items-center justify-center shadow-md mr-4"
                          style={{ backgroundColor: "#fc2e6bed" }}
                        >
                          <img
                            src={Midtrans || "/placeholder.svg"}
                            alt="Midtrans"
                            className="h-6 w-6 filter brightness-0 invert"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800">Midtrans</h4>
                          <p className="text-gray-600 text-sm">Indonesian payments</p>
                        </div>
                      </div>
                    )}

                    {paymentMethod === "wallet" && (
                      <div className="flex items-center">
                        <div
                          className="h-12 w-12 rounded-full flex items-center justify-center shadow-md mr-4"
                          style={{ backgroundColor: "#fc2e6bed" }}
                        >
                          <PiWallet className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800">Wallet Payment</h4>
                          <p className="text-gray-600 text-sm">Payment via your wallet balance</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Order Note Card (if available) */}
              {orderNote && (
                <div className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-200 hover:shadow-md transition-all duration-300">
                  <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                    <div className="flex items-center">
                      <div className="p-2 rounded-lg shadow-sm mr-3" style={{ backgroundColor: "#fc2e6bed" }}>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-5 w-5 text-white"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"
                          />
                        </svg>
                      </div>
                      <h3 className="text-lg font-semibold text-gray-800">Special Instructions</h3>
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="bg-white rounded-lg p-4 border border-gray-100 relative">
                      <p className="text-gray-700 italic px-4 py-2">{orderNote}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Right Column - Price Details */}
            <div className="xl:col-span-1">
              <div className="bg-white rounded-xl overflow-hidden shadow border border-gray-200 hover:shadow-lg transition-all duration-300 sticky top-4">
                <div className="px-6 py-4" style={{ backgroundColor: "#fc2e6bed" }}>
                  <div className="flex items-center">
                    <div className="bg-white p-2 rounded-lg shadow-md mr-3">
                      <NotepadText className="h-5 w-5" style={{ color: "#fc2e6bed" }} />
                    </div>
                    <h3 className="text-lg font-semibold text-white">Price Details</h3>
                  </div>
                </div>

                <div className="p-6">
                  <div className="space-y-4">
                    <div className="bg-white p-4 rounded-lg border border-gray-200 mb-4">
                      <div className="flex justify-between items-center border-b border-gray-100 pb-3 mb-3">
                        <span className="text-gray-600">Subtotal:</span>
                        <span className="font-medium">
                          {setting?.setting?.currency}{" "}
                          {(Number(subtotal) || 0).toFixed(setting?.setting?.decimal_point || 2)}
                        </span>
                      </div>

                      <div className="flex justify-between items-center border-b border-gray-100 pb-3 mb-3">
                        <span className="text-gray-600">Delivery Charge:</span>
                        <span className="font-medium">
                          {setting?.setting?.currency} {deliveryCharge.toFixed(setting?.setting?.decimal_point || 2)}
                        </span>
                      </div>

                      <div className="flex justify-between items-center border-b border-gray-100 pb-3 mb-3">
                        <span className="text-gray-600">Handling Fee:</span>
                        <span className="font-medium">
                          {setting?.setting?.currency} {handlingFee.toFixed(setting?.setting?.decimal_point || 2)}
                        </span>
                      </div>

                      <div className="flex justify-between items-center border-b border-gray-100 pb-3 mb-3">
                        <div className="flex items-center group relative">
                          <span className="text-gray-600">GST and Charges:</span>
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-4 w-4 ml-1 text-gray-400 cursor-pointer"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                            />
                          </svg>
                          <div className="absolute left-0 bottom-full mb-2 hidden group-hover:block w-64 bg-white p-3 rounded-lg shadow-lg border border-gray-200 z-10">
                            <div className="text-sm text-gray-600">
                              <p className="font-medium mb-1">GST on handling fee</p>
                              <p className="text-xs">18% GST applied only on handling fee</p>
                              <p className="text-xs mt-2">
                                Bringmart plays no role in taxes and charges levied by the government
                              </p>
                            </div>
                          </div>
                        </div>
                        <span className="font-medium">
                          {setting?.setting?.currency} {gstOnHandlingFee.toFixed(setting?.setting?.decimal_point || 2)}
                        </span>
                      </div>

                      {discount > 0 && (
                        <div className="flex justify-between items-center border-b border-gray-100 pb-3 mb-3">
                          <span className="text-gray-600">Discount:</span>
                          <span className="font-medium text-green-600">
                            - {setting?.setting?.currency} {discount.toFixed(setting?.setting?.decimal_point || 2)}
                          </span>
                        </div>
                      )}

                      {isWalletChecked && walletDeductionAmt > 0 && (
                        <div className="flex justify-between items-center border-b border-gray-100 pb-3 mb-3">
                          <span className="text-gray-600">Wallet Deduction:</span>
                          <span className="font-medium text-green-600">
                            - {setting?.setting?.currency}{" "}
                            {walletDeductionAmt.toFixed(setting?.setting?.decimal_point || 2)}
                          </span>
                        </div>
                      )}

                      <div className="flex justify-between items-center pt-3">
                        <span className="text-lg font-semibold">Total:</span>
                        <span className="text-xl font-bold" style={{ color: "#fc2e6bed" }}>
                          {setting?.setting?.currency} {displayTotal.toFixed(setting?.setting?.decimal_point || 2)}
                        </span>
                      </div>
                    </div>

                    {/* Order Buttons */}
                    <div className="mt-6 space-y-3">
                      <button
                        onClick={() => handlePlaceOrder()}
                        className="w-full py-3 px-4 font-medium rounded-lg shadow-md hover:shadow-lg transform transition-all duration-300 hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-opacity-50 disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none text-white"
                        style={{ backgroundColor: "#fc2e6bed" }}
                      >
                        {loadingPlaceOrder ? (
                          <div className="flex items-center justify-center">
                            <svg
                              className="animate-spin h-5 w-5 mr-3 text-white"
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                            >
                              <circle
                                className="opacity-25"
                                cx="12"
                                cy="12"
                                r="10"
                                stroke="currentColor"
                                strokeWidth="4"
                              ></circle>
                              <path
                                className="opacity-75"
                                fill="currentColor"
                                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                              ></path>
                            </svg>
                            Processing Order...
                          </div>
                        ) : (
                          <div className="flex items-center justify-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-5 w-5 mr-2"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                            Place Order
                          </div>
                        )}
                      </button>

                      <button
                        onClick={prevStep}
                        className="w-full py-3 px-4 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 font-medium rounded-lg transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-gray-200"
                      >
                        <div className="flex items-center justify-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                          </svg>
                          Review Payment
                        </div>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Stripe Modal
  const StripeModal = () => {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-lg p-6 max-w-md w-full">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Complete Payment</h3>
            <button onClick={() => setShowStripeModal(false)} className="text-gray-500 hover:text-gray-700">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {stripeClientSecret && stripePromise && (
            <Elements stripe={stripePromise} options={{ clientSecret: stripeClientSecret }}>
              <StripeModel
                orderId={stripeOrderId}
                transactionId={stripeTransactionId}
                amount={subtotal}
                onSuccess={() => {
                  setIsOrderPlaced(true)
                  dispatch(setCartProducts({ data: [] }))
                  dispatch(setCartSubTotal({ data: 0 }))
                  if (isWalletChecked) {
                    dispatch(deductUserBalance({ data: walletDeductionAmt }))
                  }
                  setShowStripeModal(false)
                }}
                onError={(message) => {
                  toast.error(message)
                  setShowStripeModal(false)
                }}
              />
            </Elements>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="w-full">
        {/* Header */}
        <div className="bg-white shadow-sm border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <h1 className="text-lg sm:text-4xl font-bold text-gray-900">Checkout</h1>
            <p className="text-gray-600 mt-2">Complete your purchase in just a few steps</p>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="relative">
              {/* Progress Bar */}
              <div className="absolute top-5 left-0 w-full h-1 bg-gray-200 rounded-full">
                <div
                  className="h-1 rounded-full transition-all duration-500 ease-in-out"
                  style={{
                    width: `${((step - 1) / 3) * 100}%`,
                    backgroundColor: "#fc2e6bed",
                  }}
                ></div>
              </div>

              {/* Steps */}
              <div className="relative flex justify-between">
                {ProgressSteps.map((s) => (
                  <div key={s.number} className="flex flex-col items-center">
                    <button
                      onClick={() => {
                        if (s.number <= step) {
                          setStep(s.number)
                        }
                      }}
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${step > s.number
                        ? "text-white shadow-lg cursor-pointer hover:shadow-md"
                        : step === s.number
                          ? "text-white ring-4 ring-opacity-20 cursor-pointer"
                          : "bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed"
                        }`}
                      style={step >= s.number ? { backgroundColor: "#fc2e6bed", ringColor: "#fc2e6bed" } : {}}
                      disabled={s.number > step}
                      title={s.number > step ? "Complete previous steps first" : ""}
                    >
                      {step > s.number ? <Check className="w-5 h-5" /> : s.number}
                    </button>

                    <div className="mt-3 flex flex-col items-center">
                      <span
                        className={`text-sm font-medium ${step >= s.number ? "text-gray-900" : "text-gray-500"}`}
                        style={step >= s.number ? { color: "#fc2e6bed" } : {}}
                      >
                        {s.label}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Current Step Content */}
        <div className="bg-white shadow-sm">
          {step === 1 && (
            <AddressStep
              addresses={addresses}
              selectedAddressIndex={selectedAddressIndex}
              setSelectedAddressIndex={(index) => {
                setSelectedAddressIndex(index)
                dispatch(setSelectedAddress({ data: addresses[index] }))
              }}
              showAddressForm={showAddressForm}
              setShowAddressForm={setShowAddressForm}
              nextStep={nextStep}
              setEditingAddress={setEditingAddress}
            />
          )}

          {step === 2 && (
            <DeliveryStep
              deliveryOption={deliveryOption}
              setDeliveryOption={setDeliveryOption}
              selectedDate={selectedDate}
              setSelectedDate={setSelectedDate}
              deliveryTime={deliveryTime}
              setDeliveryTime={setDeliveryTime}
              nextStep={nextStep}
              prevStep={prevStep}
            />
          )}

          {step === 3 && (
            <PaymentStep
              paymentMethod={paymentMethod}
              setPaymentMethod={setPaymentMethod}
              orderNote={orderNote}
              setOrderNote={setOrderNote}
              nextStep={nextStep}
              prevStep={prevStep}
              codAllow={codAllow}
              setting={setting}
              user={user}
              isWalletChecked={isWalletChecked}
              setIsWalletChecked={setIsWalletChecked}
              isFullWalletPay={isFullWalletPay}
              totalPayment={totalPayment}
            />
          )}

          {step === 4 && (
            <SummaryStep
              address={addresses[selectedAddressIndex] || {}}
              deliveryOption={deliveryOption}
              selectedDate={selectedDate}
              deliveryTime={deliveryTime}
              paymentMethod={paymentMethod}
              orderNote={orderNote}
              subtotal={subtotal}
              prevStep={prevStep}
              totalPayment={totalPayment}
            />
          )}
        </div>
      </div>

      {/* Modals */}
      {showStripeModal && <StripeModal />}
    </div>
  )
}

export default CheckoutPage
