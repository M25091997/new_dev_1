import React from "react";
import Cart from "../Components/Cart";

function CartPage() {
 

  return (
    <>
            
            <Cart />
    </>
  );
}

export default CartPage;
