import { useState, useEffect, useRef } from "react"
import { useNavigate } from "react-router-dom"
import { signInWithPhoneNumber, RecaptchaVerifier } from "firebase/auth"
import FirebaseData from "../utils/firebase/FirebaseData"
import { login } from "../api/apiCollection"
import { useDispatch, useSelector } from "react-redux"
import { setCurrentUser, setAuthType, setAuthId } from "../model/reducer/authReducer"
import {
  setIsGuest,
  setCart,
  setCartProducts,
  setCartSubTotal,
  setGuestCartTotal,
  addtoGuestCart,
} from "../model/reducer/cartReducer"
import NewUserRegisterModal from "../Components/Register/NewUserRegisterModal"
import * as newApi from "../api/apiCollection"
import { setTokenThunk } from "../model/thunk/loginThunk"
import { setSetting } from "../model/reducer/settingReducer"
import { setFavouriteLength, setFavouriteProducts } from "../model/reducer/favouriteReducer"
import api from "../api/api"
import loginBackground from "../assets/loginBackground.png"
import { toast } from "react-toastify"

const MobileLogin = () => {
  const [mobileNumber, setMobileNumber] = useState("")
  const [otp, setOtp] = useState("")
  const [isValidMobile, setIsValidMobile] = useState(false)
  const [showOtp, setShowOtp] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [confirmationResult, setConfirmationResult] = useState(null)
  const [backgroundPosition, setBackgroundPosition] = useState(0)
  const [otpTimer, setOtpTimer] = useState(90)
  const [canResendOtp, setCanResendOtp] = useState(false)
  const animationRef = useRef()
  const timerRef = useRef()
  const [registerModalShow, setRegisterModalShow] = useState(false)
  const [userEmail, setUserEmail] = useState("")
  const [userName, setUserName] = useState("")
  const [recaptchaToken, setRecaptchaToken] = useState("")
  const [fcmToken, setFcmToken] = useState("")

  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { auth, messaging } = FirebaseData()
  const city = useSelector((state) => state.city)
  const cart = useSelector((state) => state.cart)
  const { user } = useSelector((state) => state.user)
  const setting = useSelector((state) => state.setting)

  // Enhanced India Flag Component
  const IndiaFlag = () => (
    <div className="flex items-center justify-center w-8 h-6 rounded-sm overflow-hidden border border-gray-200 shadow-sm bg-white">
      <div className="w-full h-full flex flex-col">
        <div className="h-1/3 bg-orange-500"></div>
        <div className="h-1/3 bg-white flex items-center justify-center relative">
          <div className="w-2 h-2 border border-blue-800 rounded-full flex items-center justify-center bg-white">
            <div className="w-0.5 h-0.5 bg-blue-800 rounded-full"></div>
          </div>
        </div>
        <div className="h-1/3 bg-green-600"></div>
      </div>
    </div>
  )

  // Preload background image
  useEffect(() => {
    const img = new Image()
    img.src = loginBackground
  }, [])

  // Enhanced auto-sliding background animation
  useEffect(() => {
    let startTime = null
    const animationDuration = 25000

    const animateBackground = (timestamp) => {
      if (!startTime) startTime = timestamp
      const elapsed = timestamp - startTime
      const progress = (elapsed % animationDuration) / animationDuration
      const position = 100 - progress * 200
      setBackgroundPosition(position)
      animationRef.current = requestAnimationFrame(animateBackground)
    }

    animationRef.current = requestAnimationFrame(animateBackground)
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  // OTP Timer Effect
  useEffect(() => {
    if (showOtp && otpTimer > 0) {
      timerRef.current = setInterval(() => {
        setOtpTimer((prev) => {
          if (prev <= 1) {
            setCanResendOtp(true)
            return 0
          }
          return prev - 1
        })
      }, 1000)
    } else {
      clearInterval(timerRef.current)
    }
    return () => clearInterval(timerRef.current)
  }, [showOtp, otpTimer])

  // Format timer display
  const formatTimer = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  // Initialize Firebase Messaging
  useEffect(() => {
    const initializeFirebaseMessaging = async () => {
      if (setting?.setting && messaging) {
        try {
          const permission = await Notification.requestPermission()
          if (permission === "granted") {
            const currentToken = await messaging.getToken()
            if (currentToken) {
              setFcmToken(currentToken)
            }
          }
        } catch (error) {
          console.error("Error getting FCM token:", error)
        }
      }
    }

    if (setting.setting?.firebase) {
      initializeFirebaseMessaging()
    }
  }, [setting, messaging])

  // reCAPTCHA initialization
  useEffect(() => {
    const initializeRecaptcha = async () => {
      if (!window.recaptchaVerifier) {
        window.recaptchaVerifier = new RecaptchaVerifier(auth, "recaptcha-container", {
          size: "invisible",
          callback: (token) => {
            setRecaptchaToken(token)
          },
          "expired-callback": () => {
            setRecaptchaToken("")
            window.recaptchaVerifier = null
            initializeRecaptcha()
          },
        })
      }
    }

    initializeRecaptcha()
    return () => {
      if (window.recaptchaVerifier) {
        window.recaptchaVerifier.clear()
        window.recaptchaVerifier = null
      }
    }
  }, [auth])

  // Validate Indian mobile number
  const validateMobileNumber = (number) => /^[6-9]\d{9}$/.test(number)

  const handleMobileChange = (e) => {
    const number = e.target.value
    setMobileNumber(number)
    setIsValidMobile(validateMobileNumber(number))
    setError("")
  }

  const sendOtp = async (isResend = false) => {
    if (isValidMobile) {
      try {
        setLoading(true)
        setError("")
        if (isResend) {
          setOtpTimer(90)
          setCanResendOtp(false)
        }

        const appVerifier = window.recaptchaVerifier
        const formattedPhoneNumber = `+91${mobileNumber}`
        const result = await signInWithPhoneNumber(auth, formattedPhoneNumber, appVerifier)

        setConfirmationResult(result)
        setShowOtp(true)
        if (!isResend) {
          setOtpTimer(90)
          setCanResendOtp(false)
        }
      } catch (error) {
        setError("Failed to send OTP. Please try again.")
        console.error("Error sending OTP:", error)
      } finally {
        setLoading(false)
      }
    }
  }

  const handleContinue = () => sendOtp(false)
  const handleResendOtp = () => {
    if (canResendOtp) {
      sendOtp(true)
    }
  }

  const handleOtpChange = (e) => {
    setOtp(e.target.value)
    setError("")
  }

  const handleChangeMobileNumber = () => {
    setShowOtp(false)
    setOtp("")
    setOtpTimer(90)
    setCanResendOtp(false)
    setConfirmationResult(null)
    setError("")
    clearInterval(timerRef.current)
  }

  const fetchCart = async () => {
    try {
      const latitude = city?.city?.latitude || 0
      const longitude = city?.city?.longitude || 0
      const response = await newApi.getCart({ latitude, longitude })
      const result = await response.json()

      if (result.status === 1) {
        dispatch(setCart({ data: result.data }))
        const productsData = result?.data?.cart.map((product) => ({
          product_id: product.product_id,
          product_variant_id: product.product_variant_id,
          qty: product.qty,
        }))
        dispatch(setCartProducts({ data: productsData }))
        dispatch(setCartSubTotal({ data: result.data.sub_total }))
      } else {
        dispatch(setCartProducts({ data: [] }))
        dispatch(setCartSubTotal({ data: 0 }))
      }
    } catch (error) {
      console.error("Error fetching cart:", error)
    }
  }

  const getCurrentUser = async () => {
    try {
      const response = await newApi.getUser()
      dispatch(setCurrentUser({ data: response.user }))
      toast.success("You're successfully Logged In")
    } catch (error) {
      console.error("Error getting user:", error)
    }
  }

  const handleFetchSetting = async () => {
    try {
      const setting = await newApi.getSetting()
      dispatch(setSetting({ data: setting?.data }))
      dispatch(setFavouriteLength({ data: setting?.data?.favorite_product_ids?.length }))
      dispatch(setFavouriteProducts({ data: setting?.data?.favorite_product_ids }))
    } catch (error) {
      console.error("Error fetching settings:", error)
    }
  }

  const addToCartBulk = async (token) => {
    try {
      const variantIds = cart?.guestCart?.map((p) => p.product_variant_id)
      const quantities = cart?.guestCart?.map((p) => p.qty)
      const response = await api.bulkAddToCart(token, variantIds.join(","), quantities.join(","))
      const result = await response.json()

      if (result.status === 1) {
        dispatch(setGuestCartTotal({ data: 0 }))
        dispatch(addtoGuestCart({ data: [] }))
        await fetchCart()
      } else {
        throw new Error(result.message || "Failed to merge cart")
      }
    } catch (error) {
      console.error("Error adding bulk cart:", error)
      toast.error("Failed to merge your guest cart items. Please try again.")
    }
  }

  const handleLogin = async () => {
    if (otp.length === 6 && confirmationResult) {
      try {
        setLoading(true)
        setError("")
        const result = await confirmationResult.confirm(otp)
        const user = result?.user

        dispatch(setAuthId({ data: user.uid }))

        const loginPayload = {
          id: mobileNumber,
          fcm: fcmToken || "",
          type: "phone",
          platform: "web",
          clientType: "CLIENT_TYPE_WEB",
          captchaResponse: "VALID_RECAPTCHA",
          recaptchaToken: recaptchaToken,
          recaptchaVersion: "RECAPTCHA_ENTERPRISE",
        }

        const response = await login(loginPayload)
        const loginResponse = response

        if (loginResponse.status === 1) {
          const tokenSet = await dispatch(setTokenThunk(loginResponse?.data?.access_token))
          await getCurrentUser()
          dispatch(setAuthType({ data: "phone" }))

          if (loginResponse?.data?.user?.status === 1) {
            dispatch(setIsGuest({ data: false }))
            if (cart?.guestCart?.length > 0) {
              await addToCartBulk(loginResponse?.data.access_token)
            }
          }

          await handleFetchSetting()
          await fetchCart()
          navigate("/")
        } else if (loginResponse.message === "user_does_not_exist") {
          setRegisterModalShow(true)
          setShowOtp(false)
        } else {
          setError(loginResponse.message || "Login failed")
        }
      } catch (error) {
        console.error("Login error:", error)
        if (error.code === "auth/invalid-verification-code") {
          setError("Invalid OTP. Please check and try again.")
        } else if (error.code === "auth/code-expired") {
          setError("OTP has expired. Please request a new one.")
        } else if (error.code === "auth/too-many-requests") {
          setError("Too many attempts. Please try again later.")
        } else if (error.message && error.message.includes("credential")) {
          setError("Invalid OTP. Please enter the correct code.")
        } else {
          setError("Verification failed. Please try again.")
        }
      } finally {
        setLoading(false)
      }
    }
  }

  return (
    <div className="min-h-screen w-full overflow-hidden relative bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Enhanced animated sliding background */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(${loginBackground})`,
          backgroundSize: "contain",
          backgroundRepeat: "repeat-x",
          backgroundPosition: `${backgroundPosition}% center`,
          transition: "none",
          willChange: "background-position",
          // filter: "blur(0.5px)",
        }}
      />

      {/* Enhanced gradient overlay */}
      <div className="absolute inset-0 z-10 bg-gradient-to-br from-white/60 via-slate-50/70 to-blue-100/80" />

      {/* Decorative floating elements */}
      <div className="absolute top-20 left-10 w-24 h-24 bg-gradient-to-r from-blue-400/20 to-indigo-500/20 rounded-full blur-xl animate-pulse" />
      <div className="absolute bottom-32 right-16 w-32 h-32 bg-gradient-to-r from-indigo-400/20 to-purple-500/20 rounded-full blur-xl animate-pulse delay-1000" />
      <div className="absolute top-1/3 left-8 w-16 h-16 bg-gradient-to-r from-blue-300/20 to-indigo-400/20 rounded-full blur-xl animate-pulse delay-500" />

      {/* Main content container */}
      <div className="relative z-20 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Enhanced card design */}
          <div className="bg-white/90 backdrop-blur-2xl rounded-3xl shadow-2xl border border-white/60 overflow-hidden">
            {/* Header section */}
            <div className="bg-[#fc2e6bed] p-8 text-center relative overflow-hidden">
              {/* Decorative background pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-y-12"></div>
              </div>

              {/* Logo */}
              <div className="relative z-10 mb-6">
                <div className="w-20 h-20 mx-auto bg-white/15 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-xl border border-white/20">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-10 w-10 text-white"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"
                    />
                  </svg>
                </div>
              </div>

              <h1 className="text-3xl font-bold text-white mb-3 tracking-tight">
                {!showOtp ? "Welcome Back!" : "Verify Phone"}
              </h1>
              <p className="text-blue-100 text-base font-medium">
                {!showOtp ? "Enter your mobile number to continue" : "We've sent a verification code"}
              </p>
            </div>

            {/* Form section */}
            <div className="p-8">
              {!showOtp && (
                <div className="text-center mb-8">
                  <p className="text-gray-600 text-sm font-medium">Please enter your 10-digit mobile number</p>
                </div>
              )}

              {showOtp && (
                <div className="text-center mb-8">
                  <p className="text-gray-600 text-sm mb-3 font-medium">Enter the 6-digit code sent to</p>
                  <div className="inline-flex items-center gap-3 px-4 py-2 bg-blue-50 rounded-xl border border-blue-100">
                    <IndiaFlag />
                    <span className="font-bold text-blue-700">+91 {mobileNumber}</span>
                  </div>
                </div>
              )}

              {/* Error message */}
              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl animate-fadeIn">
                  <div className="flex items-start">
                    <svg
                      className="w-5 h-5 text-red-500 mr-3 mt-0.5 flex-shrink-0"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <p className="text-red-800 text-sm font-medium leading-relaxed">{error}</p>
                  </div>
                </div>
              )}

              <div className="space-y-6">
                {!showOtp ? (
                  <>
                    {/* Mobile number input - Fixed design */}
                    <div className="space-y-2">
                      <label className="block text-sm font-semibold text-gray-700">Mobile Number</label>
                      <div className="relative">
                        <div className="flex rounded-xl border-2 border-gray-200 focus-within:border-blue-500 focus-within:ring-4 focus-within:ring-blue-500/10 transition-all duration-200 bg-white">
                          {/* Country code section - fixed part */}
                          <div className="flex items-center px-4 py-4 bg-gray-50 border-r border-gray-200 rounded-l-xl">
                            <IndiaFlag />
                            <span className="ml-3 text-gray-700 font-bold text-sm">+91</span>
                          </div>

                          {/* Input field */}
                          <div className="flex-1 relative">
                            <input
                              type="number"
                              value={mobileNumber}
                              onChange={handleMobileChange}
                              placeholder="Enter 10-digit number"
                              maxLength="10"
                              className="w-full px-4 py-4 rounded-r-xl border-0 focus:ring-0 focus:outline-none text-gray-900 placeholder-gray-400 font-medium text-lg"
                            />
                            {isValidMobile && (
                              <div className="absolute inset-y-0 right-0 flex items-center pr-4">
                                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                    <path
                                      fillRule="evenodd"
                                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                      clipRule="evenodd"
                                    />
                                  </svg>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Continue button */}
                    <button
                      onClick={handleContinue}
                      disabled={!isValidMobile || loading}
                      className={`w-full py-4 rounded-xl font-bold text-lg transition-all duration-300 transform ${isValidMobile && !loading
                        ? " bg-[#fc2e6bed] text-white shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] hover:bg-[#fd4a80fa]"
                        : "bg-gray-100 text-gray-400 cursor-not-allowed"
                        }`}
                    >
                      {loading ? (
                        <div className="flex items-center justify-center">
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-3"></div>
                          Sending OTP...
                        </div>
                      ) : (
                        "Send OTP"
                      )}
                    </button>
                  </>
                ) : (
                  <>
                    {/* Timer display */}
                    {otpTimer > 0 && (
                      <div className="text-center mb-6">
                        <div className="inline-flex items-center px-4 py-2 bg-blue-50 text-blue-700 rounded-full text-sm font-bold border border-blue-200">
                          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                            />
                          </svg>
                          Expires in {formatTimer(otpTimer)}
                        </div>
                      </div>
                    )}

                    {/* OTP input */}
                    <div className="space-y-2">
                      <label className="block text-sm font-semibold text-gray-700">Verification Code</label>
                      <div className="relative">
                        <input
                          type="number"
                          value={otp}
                          onChange={handleOtpChange}
                          placeholder="Enter 6-digit OTP"
                          maxLength="6"
                          pattern="\d*"
                          inputMode="numeric"
                          className="w-full px-4 py-4 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all duration-200 bg-white text-gray-900 placeholder-gray-400 text-center text-xl font-mono tracking-widest font-bold focus:outline-none"
                        />
                        {otp.length === 6 && (
                          <div className="absolute inset-y-0 right-0 flex items-center pr-4">
                            <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                <path
                                  fillRule="evenodd"
                                  d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                  clipRule="evenodd"
                                />
                              </svg>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Verify button */}
                    <button
                      onClick={handleLogin}
                      disabled={otp.length !== 6 || loading}
                      className={`w-full py-4 rounded-xl font-bold text-lg transition-all duration-300 transform ${otp.length === 6 && !loading
                        ? " bg-[#fc2e6bed] text-white shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] hover:bg-[#ec487afc]"
                        : "bg-gray-100 text-gray-400 cursor-not-allowed"
                        }`}
                    >
                      {loading ? (
                        <div className="flex items-center justify-center">
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-3"></div>
                          Verifying...
                        </div>
                      ) : (
                        "Verify & Login"
                      )}
                    </button>

                    {/* Action buttons */}
                    <div className="flex flex-col space-y-4 pt-6 border-t border-gray-100">
                      <button
                        onClick={handleResendOtp}
                        disabled={!canResendOtp || loading}
                        className={`text-sm font-bold transition-all duration-200 py-2 px-4 rounded-lg ${canResendOtp && !loading
                          ? "text-[#fc2e6bed] hover:text-[#f81f60ed] hover:bg-blue-50"
                          : "text-gray-400 cursor-not-allowed"
                          }`}
                      >
                        {canResendOtp ? "Resend OTP" : "Resend OTP"}
                      </button>

                      <button
                        onClick={handleChangeMobileNumber}
                        className="text-sm font-bold text-gray-600 hover:text-gray-800 hover:bg-gray-50 transition-all duration-200 py-2 px-4 rounded-lg"
                      >
                        Change Mobile Number
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="px-8 pb-8">
              <p className="text-xs text-gray-500 text-center leading-relaxed">
                By continuing, you agree to our{" "}
                <a href="#" className="text-[#fc2e6bed] hover:underline font-semibold">
                  Terms of Service
                </a>{" "}
                and{" "}
                <a href="#" className="text-[#fc2e6bed] hover:underline font-semibold">
                  Privacy Policy
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Invisible reCAPTCHA container */}
      <div id="recaptcha-container" />

      {/* Registration Modal */}
      <NewUserRegisterModal
        show={registerModalShow}
        onClose={() => setRegisterModalShow(false)}
        mobileNumber={mobileNumber}
        email={userEmail}
        setEmail={setUserEmail}
        name={userName}
        setName={setUserName}
        loading={loading}
        authType="phone"
        fcmToken={fcmToken}
      />

      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
        
        /* Hide number input arrows */
        input[type="number"]::-webkit-outer-spin-button,
        input[type="number"]::-webkit-inner-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }
        
        input[type="number"] {
          -moz-appearance: textfield;
        }
      `}</style>
    </div>
  )
}

export default MobileLogin
