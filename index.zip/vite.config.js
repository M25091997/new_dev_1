import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    chunkSizeWarningLimit: 1500,
    rollupOptions: {
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom'],
          'redux-vendor': ['redux', '@reduxjs/toolkit'],
          'firebase-vendor': ['firebase/app', 'firebase/auth'],
        }
      }
    }
  }
})

