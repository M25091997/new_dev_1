/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}", // adjust path based on your project
  ],
  theme: {
    extend: {
      gridTemplateColumns: {
        '5': 'repeat(5, minmax(0, 1fr))',
      },
    },
  },
  plugins: [],
};
