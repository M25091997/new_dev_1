import { Link } from "react-router-dom";
import { ShoppingCart, Menu, X, ExternalLink, Sparkles, Star } from "lucide-react";
import { useState } from "react";
import logo from '../../assets/logo.png';

export function Navbar() {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    return (
        <header className="sticky top-0 z-50 w-full bg-white/90 backdrop-blur-xl border-b border-gray-200/50 shadow-lg shadow-[#fc2e6bed]/10">
            {/* Top notification bar */}
            <div className="bg-[#fb607f] text-white text-center py-2 text-xs sm:text-sm md:text-base font-medium">
                <div className="flex items-center justify-center gap-2">
                    <Sparkles className="h-3 w-3 sm:h-4 sm:w-4 animate-pulse" />
                    🎉 Join BringMart Franchise - Earn up to ₹10 Lacs/Month!
                    <Star className="h-3 w-3 sm:h-4 sm:w-4 animate-pulse" />
                </div>
            </div>

            <div className="container mx-auto px-4 h-18 flex items-center justify-between">
                {/* Logo */}
                <Link
                    to="/"
                    className="flex items-center space-x-3 group transition-transform hover:scale-105"
                >
                    <div className="relative">
                        <div className="absolute inset-0 bg-[#fc2e6bed] rounded-xl blur opacity-30 group-hover:opacity-50 transition-opacity"></div>

                    </div>
                    <div className="flex flex-col">
                        <img
                            src={logo}
                            alt="BringMart Logo"
                            className="h-12  w-auto"
                        />
                    </div>
                </Link>

                {/* Desktop Navigation */}
                <nav className="hidden lg:flex items-center space-x-8">
                    <div className="flex items-center space-x-6">
                        <Link
                            to="/about-us"
                            className="relative text-gray-700 hover:text-[#fc2e6bed] font-medium transition-all duration-300 group py-2"
                        >
                            <span>About Us</span>
                            <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#fc2e6bed] group-hover:w-full transition-all duration-300"></div>
                        </Link>

                        <Link
                            to="/contact-us"
                            className="relative text-gray-700 hover:text-[#fc2e6bed] font-medium transition-all duration-300 group py-2"
                        >
                            <span>Contact</span>
                            <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#fc2e6bed] group-hover:w-full transition-all duration-300"></div>
                        </Link>

                        <Link
                            to="/franchise-models"
                            className="relative text-gray-700 hover:text-[#fc2e6bed] font-medium transition-all duration-300 group py-2"
                        >
                            <span className="flex items-center gap-1">
                                Franchise
                                <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full animate-pulse">
                                    Hot
                                </span>
                            </span>
                            <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#fc2e6bed] group-hover:w-full transition-all duration-300"></div>
                        </Link>
                    </div>

                    {/* CTA Button */}
                    <a
                        href="https://bringmart.in"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group relative px-6 py-2.5 bg-[#fc2e6bed] text-white font-semibold rounded-full overflow-hidden transition-all duration-300 hover:shadow-lg hover:shadow-[#fc2e6bed]/40 hover:-translate-y-0.5"
                    >
                        <span className="relative flex items-center gap-2">
                            Visit BringMart
                            <ExternalLink className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                        </span>
                    </a>
                </nav>

                {/* Mobile Menu Button */}
                <button
                    onClick={toggleMenu}
                    className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
                >
                    {isMenuOpen ? (
                        <X className="h-6 w-6 text-gray-700" />
                    ) : (
                        <Menu className="h-6 w-6 text-gray-700" />
                    )}
                </button>
            </div>

            {/* Mobile Menu */}
            {isMenuOpen && (
                <div className="lg:hidden absolute top-full left-0 right-0 bg-white/95 backdrop-blur-xl border-b border-gray-200/50 shadow-lg">
                    <div className="container mx-auto px-4 py-6">
                        <nav className="space-y-4">
                            <Link
                                to="/about-us"
                                className="block px-4 py-3 text-gray-700 hover:text-[#fc2e6bed] hover:bg-[#fc2e6bed]/10 rounded-lg font-medium transition-all duration-300"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                About Us
                            </Link>

                            <Link
                                to="/contact-us"
                                className="block px-4 py-3 text-gray-700 hover:text-[#fc2e6bed] hover:bg-[#fc2e6bed]/10 rounded-lg font-medium transition-all duration-300"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                Contact
                            </Link>

                            <Link
                                to="/franchise-models"
                                className="block px-4 py-3 text-gray-700 hover:text-[#fc2e6bed] hover:bg-[#fc2e6bed]/10 rounded-lg font-medium transition-all duration-300"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                <span className="flex items-center gap-2">
                                    Franchise
                                    <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                                        Hot
                                    </span>
                                </span>
                            </Link>

                            <div className="pt-4 border-t border-gray-200">
                                <a
                                    href="https://bringmart.in"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex items-center justify-center gap-2 w-full px-6 py-3 bg-[#fc2e6bed] text-white font-semibold rounded-full transition-all duration-300 hover:shadow-lg hover:shadow-[#fc2e6bed]/40"
                                    onClick={() => setIsMenuOpen(false)}
                                >
                                    Visit BringMart
                                    <ExternalLink className="h-4 w-4" />
                                </a>
                            </div>
                        </nav>
                    </div>
                </div>
            )}
        </header>
    );
}
