import { ArrowRight, BarChart3, Calculator, Crown, IndianRupee, TrendingUp, Zap } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function ProfitSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeTab, setActiveTab] = useState('fully-managed');
  const sectionRef = useRef(null);

  // Calculator Input States
  const [dailyOrders, setDailyOrders] = useState(1000);
  const [orderValue, setOrderValue] = useState(300);
  const [commission, setCommission] = useState(5);

  const navigate = useNavigate();

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      {
        threshold: 0.1,
        rootMargin: "50px"
      }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Update default values when tab changes
  useEffect(() => {
    if (activeTab === 'fully-managed') {
      setDailyOrders(1000);
      setOrderValue(300);
      setCommission(5);
    } else {
      setDailyOrders(1000);
      setOrderValue(300);
      setCommission(12);
    }
  }, [activeTab]);

  // Live Calculations based on user input
  const dailyRevenue = dailyOrders * orderValue * (commission / 100);
  const monthlyRevenue = dailyRevenue * 30;
  
  // For Self Managed, calculate after Bringmart's cut (3%)
  const bringmartCut = activeTab === 'self-managed' ? 0.03 : 0;
  const yourMonthlyIncome = monthlyRevenue * (1 - bringmartCut);

  return (
    <section
      ref={sectionRef}
      className="py-12 md:py-24 bg-gradient-to-br from-slate-900 via-gray-900 to-black relative overflow-hidden"
    >
      {/* Enhanced Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-32 md:w-48 h-32 md:h-48 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-40 md:w-56 h-40 md:h-56 bg-gradient-to-br from-emerald-500/15 to-teal-500/15 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-br from-pink-500/10 to-purple-500/10 rounded-full blur-3xl animate-spin" style={{ animationDuration: '25s' }}></div>
      </div>

      {/* Floating particles */}
      <div className="absolute top-32 left-16 w-2 h-2 bg-purple-400 rounded-full animate-ping opacity-60"></div>
      <div className="absolute top-64 right-20 w-1 h-1 bg-blue-400 rounded-full animate-pulse opacity-40"></div>
      <div className="absolute bottom-40 left-24 w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce opacity-50"></div>

      <div className="container mx-auto px-4 md:px-6 lg:px-8 relative z-10">
        {/* Enhanced Header */}
        <div className={`text-center mb-12 md:mb-16 transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
          }`}>
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-xl border border-white/20 text-white px-4 md:px-6 py-2 md:py-3 rounded-full text-sm md:text-base font-medium mb-6 shadow-lg">
            <IndianRupee className="w-4 h-4 md:w-5 md:h-5 text-green-400" />
            Revenue Calculator
            <BarChart3 className="w-4 h-4 md:w-5 md:h-5 text-purple-400" />
          </div>

          <h2 className="font-bold text-3xl md:text-5xl mb-4 md:mb-6 tracking-tight text-white">
            <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
              Warehouse Franchise
            </span>
            <br />
            <span className="bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 bg-clip-text text-transparent">
              Revenue Models
            </span>
          </h2>

          <p className="text-base md:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Choose your preferred franchise model and discover your potential earnings with our transparent revenue calculations.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className={`flex justify-center mb-8 md:mb-12 transition-all duration-1000 delay-300 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
          }`}>
          <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-1 border border-white/20 shadow-lg">
            <div className="flex">
              <button
                onClick={() => setActiveTab('fully-managed')}
                className={`px-4 md:px-8 py-2 md:py-3 rounded-xl font-semibold text-sm md:text-base transition-all duration-300 flex items-center gap-2 ${activeTab === 'fully-managed'
                    ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-lg'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
              >
                <Crown className="w-4 h-4" />
                <span className="hidden sm:inline">Fully Managed</span>
                <span className="sm:hidden">Managed</span>
              </button>
              <button
                onClick={() => setActiveTab('self-managed')}
                className={`px-4 md:px-8 py-2 md:py-3 rounded-xl font-semibold text-sm md:text-base transition-all duration-300 flex items-center gap-2 ${activeTab === 'self-managed'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
              >
                <Zap className="w-4 h-4" />
                <span className="hidden sm:inline">Self Managed</span>
                <span className="sm:hidden">Self</span>
              </button>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-center">
          {/* Left Calculator Inputs */}
          <div className={`relative transition-all duration-1000 delay-500 ${isVisible ? 'translate-x-0 opacity-100' : '-translate-x-10 opacity-0'
            }`}>
            <div className="relative rounded-2xl md:rounded-3xl shadow-2xl bg-white/10 backdrop-blur-xl border border-white/20 p-6 md:p-8">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 via-pink-500/20 to-blue-500/20 rounded-2xl md:rounded-3xl"></div>

              {/* Calculator Header */}
              <div className="relative mb-6 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-2xl shadow-lg mb-4">
                  <Calculator className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl md:text-2xl font-bold text-white mb-2">
                  Live Calculator
                </h3>
                <p className="text-gray-300 text-sm">
                  Enter your numbers to see real-time calculations
                </p>
              </div>

              {/* Input Fields */}
              <div className="relative space-y-5">
                {/* Daily Orders Input */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-purple-400" />
                    Daily Orders
                  </label>
                  <input
                    type="number"
                    value={dailyOrders}
                    onChange={(e) => setDailyOrders(Number(e.target.value))}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                    placeholder="Enter daily orders"
                    min="0"
                  />
                </div>

                {/* Order Value Input */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                    <IndianRupee className="w-4 h-4 text-emerald-400" />
                    Average Order Value (₹)
                  </label>
                  <input
                    type="number"
                    value={orderValue}
                    onChange={(e) => setOrderValue(Number(e.target.value))}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
                    placeholder="Enter order value"
                    min="0"
                  />
                </div>

                {/* Commission Input */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-blue-400" />
                    Commission Rate (%)
                  </label>
                  <input
                    type="number"
                    value={commission}
                    onChange={(e) => setCommission(Number(e.target.value))}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="Enter commission %"
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Live Preview Badge */}
                <div className="bg-gradient-to-r from-emerald-500/20 to-teal-500/20 rounded-xl p-4 border border-emerald-500/30 mt-6">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Daily Revenue</span>
                    <span className="text-lg font-bold text-emerald-400">
                      ₹{dailyRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Content - Calculations */}
          <div className={`transition-all duration-1000 delay-700 ${isVisible ? 'translate-x-0 opacity-100' : 'translate-x-10 opacity-0'
            }`}>
            {/* Fully Managed Model */}
            {activeTab === 'fully-managed' && (
              <div className="space-y-6">
                <div className="mb-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl shadow-lg">
                      <Crown className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                      Fully Managed Model
                    </h3>
                  </div>
                  <p className="text-gray-300 text-base md:text-lg leading-relaxed">
                    We handle everything! You get guaranteed income with minimal effort.
                  </p>
                </div>

                {/* Calculation Card */}
                <div className="bg-white/10 backdrop-blur-xl rounded-2xl md:rounded-3xl shadow-2xl border border-white/20 p-6 md:p-8 hover:border-white/30 transition-all duration-500">
                  <div className="space-y-4 md:space-y-6">
                    {/* Parameters */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="bg-white/5 rounded-xl p-3 md:p-4 text-center border border-white/10">
                        <p className="text-xs md:text-sm text-gray-400 mb-1">Daily Orders</p>
                        <p className="text-lg md:text-xl font-bold text-white">{dailyOrders.toLocaleString()}</p>
                      </div>
                      <div className="bg-white/5 rounded-xl p-3 md:p-4 text-center border border-white/10">
                        <p className="text-xs md:text-sm text-gray-400 mb-1">Order Value</p>
                        <p className="text-lg md:text-xl font-bold text-white">₹{orderValue.toLocaleString()}</p>
                      </div>
                      <div className="bg-white/5 rounded-xl p-3 md:p-4 text-center border border-white/10">
                        <p className="text-xs md:text-sm text-gray-400 mb-1">Your Commission</p>
                        <p className="text-lg md:text-xl font-bold text-purple-400">{commission}%</p>
                      </div>
                    </div>

                    {/* Calculation */}
                    <div className="bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-xl p-4 md:p-6 border border-purple-500/30">
                      <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-green-400" />
                        Monthly Revenue Calculation
                      </h4>

                      <div className="space-y-3">
                        <p className="text-sm md:text-base text-gray-300">
                          Daily Revenue: {dailyOrders.toLocaleString()} orders × ₹{orderValue.toLocaleString()} × {commission}% =
                          <span className="font-bold text-emerald-400 ml-2">₹{dailyRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                        </p>
                        <p className="text-sm md:text-base text-gray-300">
                          Monthly Revenue: ₹{dailyRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })} × 30 days =
                          <span className="font-bold text-emerald-400 ml-2">₹{monthlyRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                        </p>
                      </div>
                    </div>

                    {/* Monthly Result */}
                    <div className="bg-gradient-to-r from-emerald-500/20 to-teal-500/20 rounded-xl p-4 md:p-6 text-center border border-emerald-500/30">
                      <p className="text-lg md:text-xl font-bold text-white mb-2">Monthly Franchise Income</p>
                      <p className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
                        ₹{(monthlyRevenue / 100000).toFixed(2)}L
                      </p>
                      <p className="text-xs md:text-sm text-gray-400 mt-2">
                        (₹{monthlyRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })})
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Self Managed Model */}
            {activeTab === 'self-managed' && (
              <div className="space-y-6">
                <div className="mb-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl shadow-lg">
                      <Zap className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
                      Self Managed Model
                    </h3>
                  </div>
                  <p className="text-gray-300 text-base md:text-lg leading-relaxed">
                    Higher returns with more control! You manage operations and earn more.
                  </p>
                </div>

                {/* Calculation Card */}
                <div className="bg-white/10 backdrop-blur-xl rounded-2xl md:rounded-3xl shadow-2xl border border-white/20 p-6 md:p-8 hover:border-white/30 transition-all duration-500">
                  <div className="space-y-4 md:space-y-6">
                    {/* Parameters */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="bg-white/5 rounded-xl p-3 md:p-4 text-center border border-white/10">
                        <p className="text-xs md:text-sm text-gray-400 mb-1">Daily Orders</p>
                        <p className="text-lg md:text-xl font-bold text-white">{dailyOrders.toLocaleString()}</p>
                      </div>
                      <div className="bg-white/5 rounded-xl p-3 md:p-4 text-center border border-white/10">
                        <p className="text-xs md:text-sm text-gray-400 mb-1">Order Value</p>
                        <p className="text-lg md:text-xl font-bold text-white">₹{orderValue.toLocaleString()}</p>
                      </div>
                      <div className="bg-white/5 rounded-xl p-3 md:p-4 text-center border border-white/10">
                        <p className="text-xs md:text-sm text-gray-400 mb-1">Total Commission</p>
                        <p className="text-lg md:text-xl font-bold text-emerald-400">{commission}%</p>
                      </div>
                      <div className="bg-white/5 rounded-xl p-3 md:p-4 text-center border border-white/10">
                        <p className="text-xs md:text-sm text-gray-400 mb-1">Bringmart Cut</p>
                        <p className="text-lg md:text-xl font-bold text-red-400">3%</p>
                      </div>
                    </div>

                    {/* Calculation */}
                    <div className="bg-gradient-to-r from-emerald-500/20 to-teal-500/20 rounded-xl p-4 md:p-6 border border-emerald-500/30">
                      <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-green-400" />
                        Monthly Revenue Breakdown
                      </h4>

                      <div className="space-y-3">
                        <p className="text-sm md:text-base text-gray-300">
                          Daily Revenue: {dailyOrders.toLocaleString()} orders × ₹{orderValue.toLocaleString()} × {commission}% =
                          <span className="font-bold text-emerald-400 ml-2">₹{dailyRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                        </p>
                        <p className="text-sm md:text-base text-gray-300">
                          Monthly Revenue: ₹{dailyRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })} × 30 days =
                          <span className="font-bold text-emerald-400 ml-2">₹{monthlyRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                        </p>
                        <div className="border-t border-white/20 pt-3">
                          <p className="text-sm text-gray-400 mb-2">After Bringmart's 3% cut:</p>
                          <p className="text-emerald-300 font-semibold">
                            You Keep: ₹{(yourMonthlyIncome / 100000).toFixed(2)}L monthly
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Monthly Result */}
                    <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl p-4 md:p-6 text-center border border-purple-500/30">
                      <p className="text-lg md:text-xl font-bold text-white mb-2">Your Monthly Income</p>
                      <p className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                        ₹{(yourMonthlyIncome / 100000).toFixed(2)}L
                      </p>
                      <p className="text-xs md:text-sm text-gray-400 mt-2">
                        (₹{yourMonthlyIncome.toLocaleString('en-IN', { maximumFractionDigits: 0 })})
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* CTA Button */}
            <div className={`transition-all duration-1000 delay-900 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0'
              }`}>
              <button onClick={() => navigate("/contact-us")} className="mt-8 w-full md:w-auto px-8 md:px-10 py-4 md:py-5 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 hover:from-purple-500 hover:via-pink-500 hover:to-blue-500 text-white rounded-2xl font-bold text-sm md:text-base flex items-center justify-center gap-3 shadow-2xl hover:shadow-purple-500/50 transition-all duration-500 transform hover:-translate-y-1 hover:scale-105 group">
                <span>Start Your Franchise Journey</span>
                <ArrowRight className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-2" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>

  );
}


