import { Mail, Phone, MapPin, Clock, MessageCircle, User, Building2, Send, CheckCircle, AlertCircle, Warehouse, DollarSign, Calendar, Star, Zap, Globe, Target, X, PartyPopper, Award } from "lucide-react";
import { useState, useEffect } from "react";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile_number: '',
    franchise_type: '', // Changed from franchise_types (array) to franchise_type (string)
    investment_budget: '',
    has_warehouse: '',
    warehouse_size: '',
    planning_to_start: '',
    state: '',
    city: '',
    pincode: '',
    address: '',
    questions_comments: ''
  });

  useEffect(() => {
    const scrollToTop = setTimeout(() => {
      window.scrollTo({ top: 0, behaviour: "smooth" })
    }, 100)
    return () => clearTimeout(scrollToTop);
  }, [])

  const franchiseTypeOptions = [
    "Self-Managed Warehouse Franchise",
    "Fully Managed Warehouse Franchise"
  ];

  const investmentOptions = [
    "10 lakh - 20 lakh",
    "20 lakh - 30 lakh",
    "30 lakh - 40 lakh",
    "40 lakh - 60 lakh"
  ];

  const timelineOptions = [
    "Immediately",
    "1-3 months",
    "3-6 months",
    "Later"
  ];

  const handleSubmit = async (event) => {
    event.preventDefault();

    // Validate required fields
    if (!formData.name || !formData.email || !formData.mobile_number ||
      !formData.franchise_type || !formData.investment_budget ||
      !formData.has_warehouse || !formData.warehouse_size || !formData.planning_to_start ||
      !formData.state || !formData.city || !formData.pincode || !formData.address) {

      // Specific error message for franchise type
      if (!formData.franchise_type) {
        setError('Please select a franchise type.');
      } else {
        setError('Please fill in all required fields.');
      }
      return;
    }

    setLoading(true);
    setError('');

    try {
      // Create payload with franchise_types as array containing the single value
      const payload = {
        ...formData,
        franchise_types: [formData.franchise_type] // Wrap single value in array
      };

      const response = await fetch('https://admin.bringmart.in/customer/franchise_application', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload) // Send the modified payload
      });

      const result = await response.json();

      if (result.status) {
        setSubmitted(true);
        setShowSuccessDialog(true);
        // Reset form
        setFormData({
          name: '',
          email: '',
          mobile_number: '',
          franchise_type: '',
          investment_budget: '',
          has_warehouse: '',
          warehouse_size: '',
          planning_to_start: '',
          state: '',
          city: '',
          pincode: '',
          address: '',
          questions_comments: ''
        });
      } else {
        setError(result.message || 'Something went wrong. Please try again.');
      }
    } catch (err) {
      setError('Network error. Please check your connection and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Success Dialog Component
  const SuccessDialog = () => {
    const [confetti, setConfetti] = useState(true);

    useEffect(() => {
      if (showSuccessDialog) {
        document.body.style.overflow = 'hidden';
        const timer = setTimeout(() => setConfetti(false), 3000);
        return () => {
          clearTimeout(timer);
          document.body.style.overflow = 'unset';
        };
      } else {
        document.body.style.overflow = 'unset';
      }
    }, [showSuccessDialog]);

    if (!showSuccessDialog) return null;

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-black/80 backdrop-blur-md"
          onClick={() => {
            setShowSuccessDialog(false);
            setSubmitted(false);
          }}
        />

        {/* Confetti Effect */}
        {confetti && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {[...Array(30)].map((_, i) => (
              <div
                key={i}
                className="absolute animate-bounce"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `-10px`,
                  animationDelay: `${Math.random() * 2}s`,
                  animationDuration: `${2 + Math.random() * 2}s`,
                }}
              >
                <div
                  className="w-3 h-3 rounded-full"
                  style={{
                    backgroundColor: ['#fc2e6b', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#00bcd4', '#009688'][Math.floor(Math.random() * 8)],
                    transform: `rotate(${Math.random() * 360}deg)`,
                  }}
                />
              </div>
            ))}
          </div>
        )}

        {/* Dialog */}
        <div className="relative bg-gradient-to-br from-gray-900/95 to-black/95 backdrop-blur-2xl rounded-3xl shadow-2xl border border-gray-700/50 max-w-md w-full mx-4 overflow-hidden">

          {/* Animated Background Elements */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute -top-20 -right-20 w-40 h-40 bg-gradient-to-br from-[#fc2e6b]/20 to-purple-600/20 rounded-full blur-2xl animate-pulse"></div>
            <div className="absolute -bottom-20 -left-20 w-40 h-40 bg-gradient-to-br from-green-500/20 to-blue-600/20 rounded-full blur-2xl animate-pulse delay-1000"></div>
          </div>

          {/* Close Button */}
          <button
            onClick={() => {
              setShowSuccessDialog(false);
              setSubmitted(false);
            }}
            className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-gray-800/50 hover:bg-gray-700/50 border border-gray-600/50 flex items-center justify-center transition-all duration-200 hover:scale-110"
          >
            <X className="w-5 h-5 text-gray-400 hover:text-white" />
          </button>

          {/* Content */}
          <div className="relative p-8 text-center">

            {/* Success Icon with Animation */}
            <div className="relative mb-6">
              <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full blur-xl opacity-50 animate-ping"></div>
              <div className="relative w-20 h-20 bg-gradient-to-br from-green-400 via-emerald-500 to-green-600 rounded-full mx-auto flex items-center justify-center shadow-2xl">
                <CheckCircle className="w-10 h-10 text-white animate-bounce" />
              </div>

              {/* Floating celebration icons */}
              <div className="absolute -top-2 -left-2">
                <PartyPopper className="w-6 h-6 text-yellow-400 animate-bounce delay-500" />
              </div>
              <div className="absolute -top-2 -right-2">
                <Award className="w-6 h-6 text-purple-400 animate-bounce delay-700" />
              </div>
              <div className="absolute -bottom-2 left-0">
                <Star className="w-5 h-5 text-pink-400 animate-bounce delay-300" />
              </div>
              <div className="absolute -bottom-2 right-0">
                <Zap className="w-5 h-5 text-blue-400 animate-bounce delay-900" />
              </div>
            </div>

            {/* Success Message */}
            <h2 className="text-2xl lg:text-3xl font-bold text-white mb-4 bg-gradient-to-r from-white to-gray-200 bg-clip-text text-transparent">
              🎉 Application Submitted!
            </h2>

            <p className="text-gray-300 mb-6 leading-relaxed">
              Thank you for your interest in BringMart franchise! Our team will review your application and contact you within <span className="text-[#fc2e6b] font-semibold">24 hours</span>.
            </p>

            {/* Next Steps */}
            <div className="bg-gray-800/50 rounded-2xl p-6 mb-6 border border-gray-700/30">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center justify-center space-x-2">
                <Target className="w-5 h-5 text-[#fc2e6b]" />
                <span>What's Next?</span>
              </h3>
              <div className="space-y-3 text-sm text-gray-300">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-[#fc2e6b] rounded-full flex items-center justify-center text-xs font-bold text-white">1</div>
                  <span>Application review (24 hours)</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-xs font-bold text-white">2</div>
                  <span>Initial consultation call</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center text-xs font-bold text-white">3</div>
                  <span>Franchise agreement discussion</span>
                </div>
              </div>
            </div>

            {/* Quick Contact */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              <a
                href="tel:06574022692"
                className="flex items-center justify-center space-x-2 bg-gradient-to-r from-[#fc2e6b] to-pink-600 hover:from-[#e91e63] hover:to-pink-700 text-white px-4 py-3 rounded-xl font-semibold transition-all duration-300 hover:scale-105 shadow-lg"
              >
                <Phone className="w-4 h-4" />
                <span className="text-sm">Call Us</span>
              </a>
              <a
                href="mailto:support@bringmart.in"
                className="flex items-center justify-center space-x-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-4 py-3 rounded-xl font-semibold transition-all duration-300 hover:scale-105 shadow-lg"
              >
                <Mail className="w-4 h-4" />
                <span className="text-sm">Email</span>
              </a>
            </div>

            {/* Close Button */}
            <button
              onClick={() => {
                setShowSuccessDialog(false);
                setSubmitted(false);
              }}
              className="w-full bg-gray-700/50 hover:bg-gray-600/50 text-gray-300 hover:text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 border border-gray-600/50 hover:border-gray-500/50"
            >
              Continue
            </button>
          </div>
        </div>
      </div>
    );
  };

  const handleFranchiseTypeChange = (franchiseType) => {
    setFormData(prev => ({
      ...prev,
      franchise_type: franchiseType // Set to single value
    }));
  };
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-gray-900 to-black text-white overflow-hidden relative">
      {/* Success Dialog */}
      <SuccessDialog />
      {/* Desktop: Advanced 3D Background Effects */}
      <div className="hidden lg:block absolute inset-0">
        {/* Animated gradient orbs */}
        <div className="absolute -top-60 -right-60 w-96 h-96 bg-gradient-to-br from-purple-600/30 via-pink-500/20 to-[#fc2e6b]/30 rounded-full blur-3xl animate-pulse opacity-80"></div>
        <div className="absolute -bottom-60 -left-60 w-96 h-96 bg-gradient-to-br from-blue-600/30 via-indigo-500/20 to-purple-600/30 rounded-full blur-3xl animate-pulse delay-1000 opacity-80"></div>
        <div className="absolute top-1/3 right-1/4 w-48 h-48 bg-gradient-to-br from-[#fc2e6b]/20 to-orange-400/20 rounded-full blur-2xl animate-bounce delay-500"></div>
        <div className="absolute bottom-1/3 left-1/4 w-64 h-64 bg-gradient-to-br from-cyan-400/20 to-blue-500/20 rounded-full blur-2xl animate-bounce delay-700"></div>

        {/* Grid pattern overlay */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDMpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-20"></div>
      </div>

      {/* Mobile: Clean gradient background */}
      <div className="lg:hidden absolute inset-0 bg-gradient-to-b from-gray-900 via-slate-800 to-black"></div>

      <main className="relative z-10">
        {/* Desktop Hero: Elaborate design with floating elements */}
        <section className="hidden lg:block py-20 xl:py-32 relative">
          <div className="container mx-auto px-8 xl:px-12">
            <div className="text-center relative">
              {/* Floating icons around the main icon */}
              <div className="absolute -top-16 left-1/2 transform -translate-x-1/2">
                <div className="animate-float">
                  <Star className="w-6 h-6 text-yellow-400 absolute -left-20 -top-8" />
                  <Zap className="w-6 h-6 text-blue-400 absolute -right-20 -top-8" />
                  <Globe className="w-6 h-6 text-green-400 absolute -left-16 top-16" />
                  <Target className="w-6 h-6 text-red-400 absolute -right-16 top-16" />
                </div>
              </div>

              {/* Main icon with enhanced styling */}
              <div className="relative inline-flex items-center justify-center mb-8">
                <div className="absolute inset-0 bg-gradient-to-r from-[#fc2e6b] to-purple-600 rounded-full blur-xl opacity-50 animate-pulse scale-110"></div>
                <div className="relative w-28 h-28 bg-gradient-to-br from-[#fc2e6b] via-pink-500 to-purple-600 rounded-full flex items-center justify-center shadow-2xl border border-white/10">
                  <Building2 className="w-14 h-14 text-white drop-shadow-lg" />
                </div>
              </div>

              <h1 className="text-6xl xl:text-7xl font-black bg-gradient-to-r from-white via-gray-100 to-gray-300 bg-clip-text text-transparent mb-6 tracking-tight">
                🧪 Franchise Application
              </h1>
              <div className="max-w-4xl mx-auto">
                <p className="text-2xl text-gray-300 mb-8 leading-relaxed font-light">
                  Transform your entrepreneurial dreams into reality with BringMart's cutting-edge warehouse franchise opportunities
                </p>
                <div className="flex justify-center space-x-8">
                  <div className="flex items-center space-x-2 text-gray-400">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                    <span className="text-lg">Proven Business Model</span>
                  </div>
                  <div className="flex items-center space-x-2 text-gray-400">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                    <span className="text-lg">24/7 Support</span>
                  </div>
                  <div className="flex items-center space-x-2 text-gray-400">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                    <span className="text-lg">Scalable Growth</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Mobile Hero: Compact app-like design */}
        <section className="lg:hidden pt-8 pb-6 px-4">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-[#fc2e6b] to-purple-600 rounded-2xl flex items-center justify-center mb-4 mx-auto shadow-lg">
              <Building2 className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">
              🧪 Franchise Application
            </h1>
            <p className="text-sm text-gray-400 px-4 leading-relaxed">
              Join BringMart and start your warehouse franchise journey today
            </p>
          </div>
        </section>

        {/* Application Form */}
        <section className="pb-8 lg:pb-20">
          <div className="container mx-auto px-4 lg:px-8 xl:px-12">
            {/* Desktop: Split layout with sidebar */}
            <div className="hidden lg:grid lg:grid-cols-12 gap-12">

              {/* Sidebar with stats */}
              <div className="col-span-4 space-y-8">
                <div className="bg-gradient-to-br from-gray-800/60 to-gray-900/80 backdrop-blur-2xl rounded-3xl p-8 border border-gray-700/50 shadow-2xl">
                  <h3 className="text-2xl font-bold text-white mb-6">Why Choose BringMart?</h3>
                  <div className="space-y-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                        <Target className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold text-white">Market Leader</p>
                        <p className="text-sm text-gray-400">Trusted by 1000+ partners</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center">
                        <Zap className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold text-white">Fast ROI</p>
                        <p className="text-sm text-gray-400">Break-even in 8-12 months</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
                        <Globe className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold text-white">Pan-India Network</p>
                        <p className="text-sm text-gray-400">50+ cities covered</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-[#fc2e6b]/20 to-purple-600/20 backdrop-blur-2xl rounded-3xl p-8 border border-[#fc2e6b]/30">
                  <h4 className="text-xl font-bold text-white mb-4">Need Help?</h4>
                  <p className="text-gray-300 mb-6 text-sm leading-relaxed">Our franchise experts are here to guide you through every step of the application process.</p>
                  <div className="space-y-3">
                    <a href="tel:06574022692" className="flex items-center space-x-3 text-[#fc2e6b] hover:text-pink-400 transition-colors">
                      <Phone className="w-5 h-5" />
                      <span className="font-medium">0657-4022692</span>
                    </a>
                    <a href="mailto:support@bringmart.in" className="flex items-center space-x-3 text-[#fc2e6b] hover:text-pink-400 transition-colors">
                      <Mail className="w-5 h-5" />
                      <span className="font-medium">support@bringmart.in</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* Main form */}
              <div className="col-span-8">
                <div className="bg-gray-800/40 backdrop-blur-2xl rounded-3xl p-10 border border-gray-700/50 shadow-2xl">
                  <div className="space-y-12">

                    {/* Personal Information */}
                    <div className="space-y-8">
                      <div className="flex items-center space-x-4">
                        <div className="w-14 h-14 bg-gradient-to-br from-[#fc2e6b] to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
                          <User className="w-7 h-7 text-white" />
                        </div>
                        <div>
                          <h2 className="text-3xl font-bold text-white">Personal Information</h2>
                          <p className="text-gray-400">Tell us about yourself</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-3">
                          <label className="block text-sm font-semibold text-gray-300 mb-2">Full Name *</label>
                          <input
                            type="text"
                            name="name"
                            placeholder="Enter your full name"
                            required
                            maxLength="255"
                            value={formData.name}
                            onChange={handleInputChange}
                            className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white placeholder-gray-400 text-lg backdrop-blur-sm"
                          />
                        </div>

                        <div className="space-y-3">
                          <label className="block text-sm font-semibold text-gray-300 mb-2">Email Address *</label>
                          <input
                            type="email"
                            name="email"
                            placeholder="your.email@example.com"
                            required
                            maxLength="255"
                            value={formData.email}
                            onChange={handleInputChange}
                            className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white placeholder-gray-400 text-lg backdrop-blur-sm"
                          />
                        </div>
                      </div>

                      <div className="space-y-3">
                        <label className="block text-sm font-semibold text-gray-300 mb-2">Mobile Number *</label>
                        <input
                          type="tel"
                          name="mobile_number"
                          placeholder="Enter your mobile number"
                          required
                          maxLength="20"
                          value={formData.mobile_number}
                          onChange={handleInputChange}
                          className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white placeholder-gray-400 text-lg backdrop-blur-sm"
                        />
                      </div>
                    </div>

                    {/* Franchise Information */}
                    <div className="space-y-8">
                      <div className="flex items-center space-x-4">
                        <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center shadow-lg">
                          <Building2 className="w-7 h-7 text-white" />
                        </div>
                        <div>
                          <h2 className="text-3xl font-bold text-white">Franchise Information</h2>
                          <p className="text-gray-400">Choose your franchise model</p>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div>
                          <label className="block text-sm font-semibold text-gray-300 mb-4">Franchise Type *</label>
                          <p className="text-xs text-gray-400 mb-4">Select one option</p>
                          <div className="grid grid-cols-1 gap-4">
                            {franchiseTypeOptions.map((option) => (
                              <label key={option} className="relative cursor-pointer group">
                                <input
                                  type="radio"
                                  name="franchise_type"
                                  checked={formData.franchise_type === option}
                                  onChange={() => handleFranchiseTypeChange(option)}
                                  className="sr-only"
                                />
                                <div className={`p-6 rounded-2xl border-2 transition-all duration-300 ${formData.franchise_type === option
                                  ? 'border-[#fc2e6b] bg-[#fc2e6b]/10 shadow-lg'
                                  : 'border-gray-600 bg-gray-700/30 hover:border-[#fc2e6b]/50'
                                  } ${!formData.franchise_type && error ? 'border-red-500/50 bg-red-900/10' : ''}`}>
                                  <div className="flex items-center justify-between">
                                    <span className="text-white font-semibold text-lg">{option}</span>
                                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${formData.franchise_type === option
                                      ? 'border-[#fc2e6b] bg-[#fc2e6b]'
                                      : 'border-gray-400'
                                      }`}>
                                      {formData.franchise_type === option && (
                                        <div className="w-3 h-3 bg-white rounded-full"></div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </label>
                            ))}
                          </div>
                          {!formData.franchise_type && error && error.includes('franchise type') && (
                            <p className="text-red-400 text-sm mt-2 flex items-center space-x-2">
                              <AlertCircle className="w-4 h-4" />
                              <span>Please select a franchise type</span>
                            </p>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-8">
                          <div className="space-y-3">
                            <label className="block text-sm font-semibold text-gray-300 mb-2">Investment Budget *</label>
                            <select
                              name="investment_budget"
                              required
                              value={formData.investment_budget}
                              onChange={handleInputChange}
                              className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white text-lg backdrop-blur-sm"
                            >
                              <option value="">Select investment budget</option>
                              {investmentOptions.map((option) => (
                                <option key={option} value={option} className="bg-gray-800">{option}</option>
                              ))}
                            </select>
                          </div>

                          <div className="space-y-3">
                            <label className="block text-sm font-semibold text-gray-300 mb-2">Own/Rent Warehouse? *</label>
                            <select
                              name="has_warehouse"
                              required
                              value={formData.has_warehouse}
                              onChange={handleInputChange}
                              className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white text-lg backdrop-blur-sm"
                            >
                              <option value="">Select option</option>
                              <option value="Yes" className="bg-gray-800">Yes</option>
                              <option value="No" className="bg-gray-800">No</option>
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-8">
                          <div className="space-y-3">
                            <label className="block text-sm font-semibold text-gray-300 mb-2">Warehouse Size (sq. ft.) *</label>
                            <input
                              type="text"
                              name="warehouse_size"
                              placeholder="Enter approximate size"
                              required
                              maxLength="255"
                              value={formData.warehouse_size}
                              onChange={handleInputChange}
                              className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white placeholder-gray-400 text-lg backdrop-blur-sm"
                            />
                          </div>

                          <div className="space-y-3">
                            <label className="block text-sm font-semibold text-gray-300 mb-2">Planning to Start *</label>
                            <select
                              name="planning_to_start"
                              required
                              value={formData.planning_to_start}
                              onChange={handleInputChange}
                              className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white text-lg backdrop-blur-sm"
                            >
                              <option value="">Select timeline</option>
                              {timelineOptions.map((option) => (
                                <option key={option} value={option} className="bg-gray-800">{option}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Location Information */}
                    <div className="space-y-8">
                      <div className="flex items-center space-x-4">
                        <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg">
                          <MapPin className="w-7 h-7 text-white" />
                        </div>
                        <div>
                          <h2 className="text-3xl font-bold text-white">Location Information</h2>
                          <p className="text-gray-400">Where will you operate?</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-8">
                        <div className="space-y-3">
                          <label className="block text-sm font-semibold text-gray-300 mb-2">State *</label>
                          <input
                            type="text"
                            name="state"
                            placeholder="Enter your state"
                            required
                            maxLength="255"
                            value={formData.state}
                            onChange={handleInputChange}
                            className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white placeholder-gray-400 text-lg backdrop-blur-sm"
                          />
                        </div>

                        <div className="space-y-3">
                          <label className="block text-sm font-semibold text-gray-300 mb-2">City/Town *</label>
                          <input
                            type="text"
                            name="city"
                            placeholder="Enter your city"
                            required
                            maxLength="255"
                            value={formData.city}
                            onChange={handleInputChange}
                            className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white placeholder-gray-400 text-lg backdrop-blur-sm"
                          />
                        </div>

                        <div className="space-y-3">
                          <label className="block text-sm font-semibold text-gray-300 mb-2">Pin Code *</label>
                          <input
                            type="text"
                            name="pincode"
                            placeholder="Pin code"
                            required
                            maxLength="10"
                            value={formData.pincode}
                            onChange={handleInputChange}
                            className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white placeholder-gray-400 text-lg backdrop-blur-sm"
                          />
                        </div>
                      </div>

                      <div className="space-y-3">
                        <label className="block text-sm font-semibold text-gray-300 mb-2">Complete Address *</label>
                        <textarea
                          name="address"
                          placeholder="Enter your complete address"
                          required
                          rows="4"
                          value={formData.address}
                          onChange={handleInputChange}
                          className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white placeholder-gray-400 text-lg resize-none backdrop-blur-sm"
                        />
                      </div>
                    </div>

                    {/* Additional Information */}
                    <div className="space-y-8">
                      <div className="flex items-center space-x-4">
                        <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
                          <MessageCircle className="w-7 h-7 text-white" />
                        </div>
                        <div>
                          <h2 className="text-3xl font-bold text-white">Additional Information</h2>
                          <p className="text-gray-400">Any questions or comments?</p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <label className="block text-sm font-semibold text-gray-300 mb-2">Questions/Comments (Optional)</label>
                        <textarea
                          name="questions_comments"
                          placeholder="Any questions or comments you'd like to share..."
                          rows="5"
                          value={formData.questions_comments}
                          onChange={handleInputChange}
                          className="w-full px-5 py-4 bg-gray-700/50 border border-gray-600/50 rounded-2xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-300 text-white placeholder-gray-400 text-lg resize-none backdrop-blur-sm"
                        />
                      </div>
                    </div>

                    {/* Submit Button */}
                    <div className="pt-8">
                      <button
                        type="submit"
                        disabled={loading || submitted}
                        onClick={handleSubmit}
                        className="w-full bg-gradient-to-r from-[#fc2e6b] via-pink-500 to-purple-600 text-white py-6 rounded-2xl font-bold text-xl hover:from-[#e91e63] hover:via-pink-600 hover:to-purple-700 transition-all duration-300 shadow-2xl hover:shadow-3xl transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center space-x-4"
                      >
                        {loading ? (
                          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
                        ) : submitted ? (
                          <>
                            <CheckCircle className="w-8 h-8" />
                            <span>Application Submitted!</span>
                          </>
                        ) : (
                          <>
                            <Send className="w-8 h-8" />
                            <span>Submit Application</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Success Message - Remove old one */}
                    {/* Error Message */}
                    {error && (
                      <div className="mt-8 p-6 bg-red-900/50 border border-red-500/50 rounded-2xl backdrop-blur-sm">
                        <p className="text-red-300 font-semibold text-center flex items-center justify-center space-x-3 text-lg">
                          <AlertCircle className="w-6 h-6" />
                          <span>{error}</span>
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Mobile: App-like design */}
            <div className="lg:hidden">
              <div className="bg-gray-900/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-gray-700/50 overflow-hidden">
                <div className="p-4 space-y-6">

                  {/* Personal Information */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-[#fc2e6b] to-pink-600 rounded-xl flex items-center justify-center">
                        <User className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-white">👤 Personal Info</h2>
                        <p className="text-xs text-gray-400">Basic details</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Full Name *</label>
                        <input
                          type="text"
                          name="name"
                          placeholder="Your full name"
                          required
                          maxLength="255"
                          value={formData.name}
                          onChange={handleInputChange}
                          className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white placeholder-gray-500 text-sm"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Email Address *</label>
                        <input
                          type="email"
                          name="email"
                          placeholder="your@email.com"
                          required
                          maxLength="255"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white placeholder-gray-500 text-sm"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Mobile Number *</label>
                        <input
                          type="tel"
                          name="mobile_number"
                          placeholder="Mobile number"
                          required
                          maxLength="20"
                          value={formData.mobile_number}
                          onChange={handleInputChange}
                          className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white placeholder-gray-500 text-sm"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Franchise Information */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center">
                        <Building2 className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-white">🏭 Franchise Info</h2>
                        <p className="text-xs text-gray-400">Business details</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-2">Franchise Type *</label>
                        <p className="text-xs text-gray-500 mb-3">Select one option</p>
                        <div className="space-y-2">
                          {franchiseTypeOptions.map((option) => (
                            <label key={option} className="flex items-center space-x-3 cursor-pointer group">
                              <div className="relative">
                                <input
                                  type="radio"
                                  name="franchise_type"
                                  checked={formData.franchise_type === option}
                                  onChange={() => handleFranchiseTypeChange(option)}
                                  className="sr-only"
                                />
                                <div className={`w-5 h-5 rounded-full border-2 transition-all duration-200 ${formData.franchise_type === option
                                  ? 'border-[#fc2e6b]'
                                  : 'border-gray-500 group-hover:border-[#fc2e6b]'
                                  } ${!formData.franchise_type && error && error.includes('franchise type') ? 'border-red-500' : ''}`}>
                                  {formData.franchise_type === option && (
                                    <div className="w-2 h-2 bg-[#fc2e6b] rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
                                  )}
                                </div>
                              </div>
                              <span className="text-sm text-gray-300 group-hover:text-[#fc2e6b] transition-colors duration-200">{option}</span>
                            </label>
                          ))}
                        </div>
                        {!formData.franchise_type && error && error.includes('franchise type') && (
                          <p className="text-red-400 text-xs mt-2 flex items-center space-x-1">
                            <AlertCircle className="w-3 h-3" />
                            <span>Please select a franchise type</span>
                          </p>
                        )}
                      </div>

                      <div className="grid grid-cols-1 gap-3">
                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1">Investment Budget *</label>
                          <select
                            name="investment_budget"
                            required
                            value={formData.investment_budget}
                            onChange={handleInputChange}
                            className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white text-sm"
                          >
                            <option value="">Select budget</option>
                            {investmentOptions.map((option) => (
                              <option key={option} value={option} className="bg-gray-800">{option}</option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1">Own/Rent Warehouse? *</label>
                          <select
                            name="has_warehouse"
                            required
                            value={formData.has_warehouse}
                            onChange={handleInputChange}
                            className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white text-sm"
                          >
                            <option value="">Select option</option>
                            <option value="Yes" className="bg-gray-800">Yes</option>
                            <option value="No" className="bg-gray-800">No</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1">Warehouse Size (sq. ft.) *</label>
                          <input
                            type="text"
                            name="warehouse_size"
                            placeholder="Size in sq. ft."
                            required
                            maxLength="255"
                            value={formData.warehouse_size}
                            onChange={handleInputChange}
                            className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white placeholder-gray-500 text-sm"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1">Planning to Start *</label>
                          <select
                            name="planning_to_start"
                            required
                            value={formData.planning_to_start}
                            onChange={handleInputChange}
                            className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white text-sm"
                          >
                            <option value="">Select timeline</option>
                            {timelineOptions.map((option) => (
                              <option key={option} value={option} className="bg-gray-800">{option}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Location Information */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-white">📍 Location Info</h2>
                        <p className="text-xs text-gray-400">Where you'll operate</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1">State *</label>
                          <input
                            type="text"
                            name="state"
                            placeholder="State"
                            required
                            maxLength="255"
                            value={formData.state}
                            onChange={handleInputChange}
                            className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white placeholder-gray-500 text-sm"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1">City/Town *</label>
                          <input
                            type="text"
                            name="city"
                            placeholder="City"
                            required
                            maxLength="255"
                            value={formData.city}
                            onChange={handleInputChange}
                            className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white placeholder-gray-500 text-sm"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Pin Code *</label>
                        <input
                          type="text"
                          name="pincode"
                          placeholder="Pin code"
                          required
                          maxLength="10"
                          value={formData.pincode}
                          onChange={handleInputChange}
                          className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white placeholder-gray-500 text-sm"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Complete Address *</label>
                        <textarea
                          name="address"
                          placeholder="Your complete address"
                          required
                          rows="3"
                          value={formData.address}
                          onChange={handleInputChange}
                          className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white placeholder-gray-500 text-sm resize-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Additional Information */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
                        <MessageCircle className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-white">💬 Additional Info</h2>
                        <p className="text-xs text-gray-400">Optional details</p>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-gray-400 mb-1">Questions/Comments (Optional)</label>
                      <textarea
                        name="questions_comments"
                        placeholder="Any questions or comments..."
                        rows="3"
                        value={formData.questions_comments}
                        onChange={handleInputChange}
                        className="w-full px-3 py-3 bg-gray-800/60 border border-gray-700 rounded-xl focus:ring-2 focus:ring-[#fc2e6b] focus:border-transparent outline-none transition-all duration-200 text-white placeholder-gray-500 text-sm resize-none"
                      />
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-4">
                    <button
                      type="submit"
                      disabled={loading || submitted}
                      onClick={handleSubmit}
                      className="w-full bg-gradient-to-r from-[#fc2e6b] to-purple-600 text-white py-4 rounded-xl font-bold text-base hover:from-[#e91e63] hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center space-x-3"
                    >
                      {loading ? (
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      ) : submitted ? (
                        <>
                          <CheckCircle className="w-5 h-5" />
                          <span>Application Submitted!</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-5 h-5" />
                          <span>Submit Application</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Success Message - Remove old mobile one */}
                  {/* Error Message */}
                  {error && (
                    <div className="mt-4 p-4 bg-red-900/50 border border-red-500/50 rounded-xl backdrop-blur-sm">
                      <p className="text-red-300 font-medium text-center flex items-center justify-center space-x-2 text-sm">
                        <AlertCircle className="w-4 h-4" />
                        <span>{error}</span>
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* CSS animations */}
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
      `}</style>
    </div>
  )
}