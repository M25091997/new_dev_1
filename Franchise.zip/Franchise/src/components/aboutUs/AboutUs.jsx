import { Users, Target, Rocket, Zap, Star, ArrowRight, Award, Globe, TrendingUp } from "lucide-react";
import { useEffect } from "react";
import teamMember1 from "../../assets/sunnyProfile.jpeg";
import teamMember3 from "../../assets/anuragProfile.png";
import { useNavigate } from "react-router-dom";

const teamMembers = [
  { name: "Sunny Kumar", role: "Marketing Executive", image: teamMember1 },
  { name: "Anurag Mandal", role: "Marketing Executive", image: teamMember3 },
];

// const stats = [
//   { number: "500+", label: "Active Franchises", icon: Users },
//   { number: "50k+", label: "Orders Processed", icon: Target },
//   { number: "25+", label: "Cities Covered", icon: Rocket },
//   { number: "99.5%", label: "Success Rate", icon: Star },
// ];

const features = [
  {
    title: "Community-Driven Network",
    description: "Empowering local entrepreneurs to build sustainable businesses in their communities",
    icon: Users,
    color: "from-blue-500 to-cyan-500"
  },
  {
    title: "Advanced Technology",
    description: "Cutting-edge logistics technology and AI-powered operations for seamless delivery",
    icon: Zap,
    color: "from-purple-500 to-pink-500"
  },
  {
    title: "Scalable Infrastructure",
    description: "Rapidly expanding network of micro-warehouses strategically placed nationwide",
    icon: Rocket,
    color: "from-orange-500 to-red-500"
  },
  {
    title: "Proven Success Model",
    description: "Data-driven franchise system with comprehensive support and training programs",
    icon: Award,
    color: "from-green-500 to-emerald-500"
  },
];

const values = [
  {
    title: "Innovation First",
    description: "Constantly evolving our technology and processes",
    icon: TrendingUp
  },
  {
    title: "Community Impact",
    description: "Creating opportunities for local entrepreneurs",
    icon: Globe
  },
  {
    title: "Quality Assurance",
    description: "Maintaining the highest standards in every operation",
    icon: Award
  }
];

export default function AboutUs() {

  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Hero Section */}
      <section className="relative py-16 lg:py-20">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/30 via-gray-900 to-blue-900/30">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(120,119,198,0.1),transparent_50%)]"></div>
          <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,transparent,transparent_2px,rgba(255,255,255,0.02)_2px,rgba(255,255,255,0.02)_4px)]"></div>
        </div>

        <div className="relative container mx-auto px-4 text-center">
          <h1 className="text-3xl lg:text-6xl font-bold mb-4 lg:mb-6">
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              About Bring Mart
            </span>
          </h1>
          <p className="text-base lg:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Revolutionizing e-commerce logistics through community-driven warehouse franchises
            and cutting-edge technology solutions.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      {/* <section className="py-8 lg:py-12 bg-gray-900/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-6">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="bg-gray-800/60 backdrop-blur-sm rounded-lg lg:rounded-xl p-3 lg:p-6 text-center border border-gray-700/50 hover:border-blue-500/50 transition-all duration-300 hover:scale-105"
              >
                <stat.icon className="w-5 h-5 lg:w-8 lg:h-8 text-blue-400 mx-auto mb-2" />
                <div className="text-lg lg:text-3xl font-bold text-white mb-1">{stat.number}</div>
                <div className="text-xs lg:text-sm text-gray-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section> */}

      {/* Story & Features Section */}
      <section className="py-12 lg:py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-start">
            {/* Story */}
            <div>
              <h2 className="text-2xl lg:text-4xl font-bold mb-4 lg:mb-6">
                <span className="bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                  Our Story
                </span>
              </h2>

              <div className="space-y-4">
                <p className="text-sm lg:text-base text-gray-300 leading-relaxed">
                  Bring Mart was founded with a vision to transform e-commerce logistics by creating
                  a decentralized network of community-owned warehouses. We recognized that traditional
                  centralized distribution models were inefficient and costly.
                </p>
                <p className="text-sm lg:text-base text-gray-300 leading-relaxed">
                  Our innovative franchise model empowers local entrepreneurs to become integral parts
                  of the e-commerce ecosystem, providing them with technology, training, and ongoing
                  support to build successful warehouse operations in their communities.
                </p>
              </div>

              {/* Values */}
              <div className="mt-6 lg:mt-8 space-y-3">
                {values.map((value, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-gray-800/30 rounded-lg border border-gray-700/30">
                    <value.icon className="w-5 h-5 text-blue-400 flex-shrink-0" />
                    <div>
                      <h3 className="text-sm font-semibold text-white">{value.title}</h3>
                      <p className="text-xs text-gray-400">{value.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Features */}
            <div className="space-y-3 lg:space-y-4">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="group bg-gray-800/60 backdrop-blur-sm rounded-lg lg:rounded-xl p-4 lg:p-5 border border-gray-700/50 hover:border-purple-500/50 transition-all duration-300"
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-8 h-8 lg:w-10 lg:h-10 bg-gradient-to-r ${feature.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <feature.icon className="w-4 h-4 lg:w-5 lg:h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-sm lg:text-lg font-semibold text-white mb-1">
                        {feature.title}
                      </h3>
                      <p className="text-xs lg:text-sm text-gray-400 leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-8 lg:py-12 bg-gray-900/40">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-8">
            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 rounded-xl p-5 lg:p-8 border border-gray-700/50 hover:border-pink-500/50 transition-all duration-300">
              <div className="flex items-center gap-3 mb-3 lg:mb-4">
                <div className="w-8 h-8 lg:w-12 lg:h-12 bg-gradient-to-r from-pink-500 to-pink-600 rounded-lg flex items-center justify-center">
                  <Target className="w-4 h-4 lg:w-6 lg:h-6 text-white" />
                </div>
                <h3 className="text-lg lg:text-2xl font-bold text-white">Mission</h3>
              </div>
              <p className="text-sm lg:text-base text-gray-300 leading-relaxed">
                To democratize e-commerce logistics by empowering local entrepreneurs with
                technology-driven warehouse franchise opportunities that create sustainable
                income and strengthen communities.
              </p>
            </div>

            <div className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 rounded-xl p-5 lg:p-8 border border-gray-700/50 hover:border-purple-500/50 transition-all duration-300">
              <div className="flex items-center gap-3 mb-3 lg:mb-4">
                <div className="w-8 h-8 lg:w-12 lg:h-12 bg-gradient-to-r from-purple-500 to-blue-600 rounded-lg flex items-center justify-center">
                  <Rocket className="w-4 h-4 lg:w-6 lg:h-6 text-white" />
                </div>
                <h3 className="text-lg lg:text-2xl font-bold text-white">Vision</h3>
              </div>
              <p className="text-sm lg:text-base text-gray-300 leading-relaxed">
                To build India's most efficient and community-connected logistics network,
                making same-day delivery accessible nationwide while creating thousands
                of entrepreneurial opportunities.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-12 lg:py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-6 lg:mb-10">
            <h2 className="text-2xl lg:text-4xl font-bold mb-3">
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                Leadership Team
              </span>
            </h2>
            <p className="text-sm lg:text-base text-gray-400">
              Experienced professionals driving innovation and growth
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 lg:gap-6 max-w-2xl mx-auto">
            {teamMembers.map((member, index) => (
              <div
                key={member.name}
                className="bg-gray-800/60 backdrop-blur-sm rounded-xl p-4 lg:p-6 text-center border border-gray-700/50 hover:border-cyan-500/50 transition-all duration-300 hover:scale-105"
              >
                <div className="relative mb-3 lg:mb-4">
                  <div className="w-24 h-24 lg:w-24 lg:h-24 rounded-4xl mx-auto overflow-hidden border-2 border-cyan-400/50">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  </div>
                </div>
                <h3 className="text-sm lg:text-lg font-bold text-white mb-1">{member.name}</h3>
                <p className="text-xs lg:text-sm text-cyan-400">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 lg:py-16 bg-gradient-to-r from-purple-900/60 to-blue-900/60">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-xl lg:text-3xl font-bold text-white mb-3 lg:mb-4">
            Ready to Transform Your Future?
          </h2>
          <p className="text-sm lg:text-base text-gray-300 mb-6 lg:mb-8 max-w-xl mx-auto">
            Join our growing network of successful warehouse franchise partners
          </p>
          <button onClick={() => navigate("/contact-us")} className="group bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 px-6 py-3 lg:px-8 lg:py-4 rounded-lg text-sm lg:text-base font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
            Start Your Journey
            <ArrowRight className="inline-block ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </section>
    </div>
  );
}