import { useEffect, useRef, useState } from "react";
import {
    CheckCircle,
    Briefcase,
    Handshake,
    ShoppingCart,
    Megaphone,
    BarChart,
    Star,
    Sparkles,
    TrendingUp,
    Zap,
    ArrowRight,
    Crown,
} from "lucide-react";

const franchiseWork = [
    "Franchise will pay the rent of the warehouse.",
    "Franchise will pay electricity bill of the warehouse.",
    "Franchise will pay the salary of staff working in warehouse.",
    "Franchise will bear all the operational and petty expenses.",
    "Franchise will keep saleable products in warehouse.",
    "Company will do the interior as per franchise requirement.",
];

const companySupport = [
    "Company will support in purchasing",
    "Company will support in hiring & training",
    "Company will support in operations",
    "Company also will provide IT support",
];

const products =
    "Grocery, Bakery, Stationery, Personal Care, Frozen Branded Foods, Cosmetics, Beverages, Fruits & Vegetables, Household Items, Pet Care, Baby Care, Electronics & Accessories";
const marketingSupport =
    "Pamphlets, Hoardings, Support Social Media Ad";
const income = "Approximate Rs. 3 to 10 Lac Per Month";

// Enhanced animated card component with intersection observer
const AnimatedCard = ({ children, delay = 0, className = "" }) => {
    const [isVisible, setIsVisible] = useState(false);
    const ref = useRef();

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                }
            },
            { threshold: 0.1, rootMargin: "50px" }
        );

        if (ref.current) {
            observer.observe(ref.current);
        }

        return () => {
            if (ref.current) {
                observer.unobserve(ref.current);
            }
        };
    }, []);

    return (
        <div
            ref={ref}
            className={`transform transition-all duration-700 ease-out ${isVisible
                ? "translate-y-0 opacity-100 scale-100"
                : "translate-y-8 opacity-0 scale-95"
                } ${className}`}
            style={{ transitionDelay: `${delay}ms` }}
        >
            {children}
        </div>
    );
};

export default function FranchiseInfo() {
    return (
        <section className="py-8 md:py-24 bg-gradient-to-br from-slate-900 via-gray-900 to-black min-h-screen relative overflow-hidden -mb-40">
            {/* Enhanced Background Effects */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,rgba(139,92,246,0.1)_0%,transparent_50%)]"></div>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_75%,rgba(59,130,246,0.08)_0%,transparent_50%)]"></div>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_10%,rgba(16,185,129,0.05)_0%,transparent_60%)]"></div>

            {/* Floating particles */}
            <div className="absolute top-20 left-10 w-2 h-2 bg-purple-400 rounded-full animate-ping opacity-40"></div>
            <div className="absolute top-40 right-16 w-1 h-1 bg-blue-400 rounded-full animate-pulse opacity-60"></div>
            <div className="absolute bottom-32 left-20 w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce opacity-50"></div>
            <div className="absolute top-60 right-32 w-1 h-1 bg-pink-400 rounded-full animate-pulse opacity-30"></div>
            <div className="absolute bottom-60 left-32 w-2 h-2 bg-cyan-400 rounded-full animate-ping opacity-20"></div>

            <div className="container mx-auto px-3 md:px-4 relative z-10">
                {/* Enhanced Section Heading */}
                <AnimatedCard className="text-center mb-8 md:mb-16">
                    <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-xl border border-white/20 text-white px-4 md:px-6 py-2 md:py-3 rounded-full text-sm md:text-base font-medium mb-4 md:mb-6 shadow-lg">
                        <Crown className="w-4 h-4 md:w-5 md:h-5 text-yellow-400" />
                        Premium Franchise Opportunity
                        <Sparkles className="w-4 h-4 md:w-5 md:h-5 text-purple-400" />
                    </div>

                    <h2 className="font-bold text-2xl md:text-5xl text-white mb-3 md:mb-6 tracking-tight">
                        <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                            BRINGMART WAREHOUSE
                        </span>
                        <br />
                        <span className="bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 bg-clip-text text-transparent">
                            MODEL
                        </span>
                    </h2>

                    <p className="text-sm md:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
                        A comprehensive franchise model designed for success. We provide the
                        <span className="text-purple-300 font-semibold"> products</span>,{" "}
                        <span className="text-blue-300 font-semibold">support</span>, and{" "}
                        <span className="text-emerald-300 font-semibold">systems</span> you need to thrive.
                    </p>

                    <div className="w-24 md:w-32 h-1 bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 mx-auto mt-4 md:mt-6 rounded-full"></div>
                </AnimatedCard>

                {/* Enhanced Mobile App Style Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-8 mb-8 md:mb-16">
                    {/* Product Line */}
                    <AnimatedCard delay={100}>
                        <div className="group bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl hover:shadow-purple-500/25 transition-all duration-500 p-6 md:p-8 border border-white/20 hover:border-white/30 hover:scale-105 hover:bg-white/15 h-full flex flex-col">
                            <div className="flex items-center gap-4 mb-4 md:mb-6">
                                <div className="p-2.5 md:p-3 bg-gradient-to-br from-emerald-400 to-green-600 rounded-xl shadow-2xl shadow-emerald-500/30 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
                                    <ShoppingCart className="w-6 h-6 md:w-8 md:h-8 text-white" />
                                </div>
                                <div className="flex-1">
                                    <h3 className="text-base md:text-xl font-bold bg-gradient-to-r from-emerald-300 to-green-400 bg-clip-text text-transparent">
                                        Product Line
                                    </h3>
                                    <div className="w-12 h-0.5 bg-gradient-to-r from-emerald-400 to-green-500 mt-1"></div>
                                </div>
                            </div>
                            <p className="text-gray-300 leading-relaxed text-sm md:text-base group-hover:text-gray-200 transition-colors duration-300 flex-1">
                                {products}
                            </p>
                        </div>
                    </AnimatedCard>

                    {/* Marketing Support */}
                    <AnimatedCard delay={200}>
                        <div className="group bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl hover:shadow-orange-500/25 transition-all duration-500 p-6 md:p-8 border border-white/20 hover:border-white/30 hover:scale-105 hover:bg-white/15 h-full flex flex-col">
                            <div className="flex items-center gap-4 mb-4 md:mb-6">
                                <div className="p-2.5 md:p-3 bg-gradient-to-br from-orange-400 to-red-500 rounded-xl shadow-2xl shadow-orange-500/30 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
                                    <Megaphone className="w-6 h-6 md:w-8 md:h-8 text-white" />
                                </div>
                                <div className="flex-1">
                                    <h3 className="text-base md:text-xl font-bold bg-gradient-to-r from-orange-300 to-red-400 bg-clip-text text-transparent">
                                        Marketing Support
                                    </h3>
                                    <div className="w-12 h-0.5 bg-gradient-to-r from-orange-400 to-red-500 mt-1"></div>
                                </div>
                            </div>
                            <p className="text-gray-300 leading-relaxed text-sm md:text-base group-hover:text-gray-200 transition-colors duration-300 flex-1">
                                {marketingSupport}
                            </p>
                        </div>
                    </AnimatedCard>

                    {/* Potential Income */}
                    <AnimatedCard delay={300}>
                        <div className="group bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl hover:shadow-purple-500/25 transition-all duration-500 p-6 md:p-8 border border-white/20 hover:border-white/30 hover:scale-105 hover:bg-white/15 h-full flex flex-col">
                            <div className="flex items-center gap-4 mb-4 md:mb-6">
                                <div className="p-2.5 md:p-3 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl shadow-2xl shadow-purple-500/30 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
                                    <BarChart className="w-6 h-6 md:w-8 md:h-8 text-white" />
                                </div>
                                <div className="flex-1">
                                    <h3 className="text-base md:text-xl font-bold bg-gradient-to-r from-purple-300 to-indigo-400 bg-clip-text text-transparent">
                                        Potential Income
                                    </h3>
                                    <div className="w-12 h-0.5 bg-gradient-to-r from-purple-400 to-indigo-500 mt-1"></div>
                                </div>
                            </div>
                            <p className="text-emerald-300 font-bold text-base md:text-lg group-hover:text-emerald-200 transition-colors duration-300 flex-1">
                                {income}
                            </p>
                        </div>
                    </AnimatedCard>
                </div>
            </div>
        </section>
    );
}