import { CheckCircle, Store, Settings, Users, TrendingUp, MapPin, Percent } from "lucide-react"
import { useEffect, useState } from "react";
import Requirements from "../requirements/Requirements";

export default function FranchiseModels() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    document.title = "Bringmart - Warehouse Franchise Types";

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });

    // Trigger animations after component mounts
    setTimeout(() => setIsVisible(true), 200);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Header */}
      {/* <header className="relative bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 text-white py-12 md:py-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-blue-500/5 to-transparent"></div>
        <div className={`container mx-auto px-4 text-center relative z-10 transition-all duration-1000 transform ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <h1 className="text-3xl md:text-5xl font-bold mb-4 md:mb-6 bg-gradient-to-r from-white via-blue-100 to-white bg-clip-text text-transparent">
            Bringmart Warehouse Franchise
          </h1>
          <p className="text-base md:text-xl text-gray-300 animate-fade-in-up delay-300">
            Choose the perfect franchise model for your business goals
          </p>
        </div>
      </header> */}

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 md:py-16 relative z-10">
        {/* Introduction */}
        <div className={`text-center mb-12 md:mb-20 transition-all duration-1000 delay-500 transform ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
          }`}>
          <h2 className="text-2xl md:text-4xl font-bold text-white mb-4 md:mb-6">
            Two Flexible Franchise Models
          </h2>
          <p className="text-base md:text-lg text-gray-300 max-w-3xl mx-auto">
            At <strong className="text-blue-400">Bringmart</strong>, we offer franchise models designed to suit different levels of investment and involvement.
          </p>
        </div>

        {/* Franchise Models */}
        <div className="grid md:grid-cols-2 gap-8 md:gap-10 mb-12 md:mb-20">
          {/* Self-Managed Franchise */}
          <div
            className={`group bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl shadow-2xl border border-gray-700/50 overflow-hidden hover:shadow-blue-500/10 transition-all duration-700 hover:scale-105 transform ${isVisible ? "translate-y-0 opacity-100" : "translate-y-20 opacity-0"
              } delay-700`}
          >
            <div className="bg-gradient-to-r from-blue-600/20 to-blue-700/20 backdrop-blur-sm text-white p-6 md:p-8 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-transparent group-hover:from-blue-500/20 transition-all duration-500"></div>
              <div className="flex items-center mb-3 md:mb-4 relative z-10">
                <div className="p-2 bg-blue-500/20 rounded-xl mr-3 md:mr-4 group-hover:bg-blue-500/30 transition-all duration-300">
                  <Store className="w-6 h-6 md:w-8 md:h-8 text-blue-400" />
                </div>
                <div>
                  <h3 className="text-xl md:text-2xl font-bold">Self-Managed Warehouse Franchise</h3>
                  <p className="text-sm md:text-base text-blue-200">
                    Full operational control with minimal commission sharing
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 md:p-8">
              <h4 className="text-base md:text-lg font-semibold text-white mb-3 md:mb-4 flex items-center">
                <div className="w-1 h-6 bg-blue-500 rounded-full mr-3"></div>
                How it works:
              </h4>
              <p className="text-sm md:text-base text-gray-300 mb-4 md:mb-6">
                The franchise partner fully manages and bears all operational expenses of the warehouse,
                including setup, logistics, and running costs.
              </p>

              {/* Responsibilities List */}
              <div className="space-y-4">
                <div className="flex items-start group/item hover:bg-gray-800/30 p-3 rounded-xl transition-all duration-300">
                  <CheckCircle className="w-5 h-5 text-blue-500 mr-3 mt-0.5 group-hover/item:scale-110 transition-transform duration-300" />
                  <span className="text-sm md:text-base text-gray-300">
                    <strong className="text-white">Franchise Partner's Role:</strong>
                    <ul className="list-disc ml-6 mt-2 space-y-1 text-gray-400">
                      <li>Warehouse rent, electricity, racks & maintenance</li>
                      <li>Delivery & last-mile logistics costs</li>
                      <li>Raw materials, packaging & inventory management</li>
                      <li>Manpower & staff salaries</li>
                      <li>Day-to-day operational expenses</li>
                    </ul>
                  </span>
                </div>

                <div className="flex items-start group/item hover:bg-gray-800/30 p-3 rounded-xl transition-all duration-300">
                  <CheckCircle className="w-5 h-5 text-gray-500 mr-3 mt-0.5 group-hover/item:scale-110 transition-transform duration-300" />
                  <span className="text-sm md:text-base text-gray-300">
                    <strong className="text-white">Bringmart's Role:</strong>
                    <ul className="list-disc ml-6 mt-2 space-y-1 text-gray-400">
                      <li>Training & onboarding support</li>
                      <li>Brand identity & business guidelines</li>
                      <li>advertisement</li>

                    </ul>
                  </span>
                </div>

                <div className="flex items-start group/item hover:bg-green-500/10 p-3 rounded-xl transition-all duration-300">
                  <Percent className="w-5 h-5 text-green-500 mr-3 mt-0.5 group-hover/item:scale-110 transition-transform duration-300" />
                  <span className="text-sm md:text-base text-gray-300">
                    <strong className="text-green-400">Profit Sharing:</strong> Only 3% commission on total sales
                  </span>
                </div>

                <div className="flex items-start group/item hover:bg-red-500/10 p-3 rounded-xl transition-all duration-300">
                  <MapPin className="w-5 h-5 text-red-500 mr-3 mt-0.5 group-hover/item:scale-110 transition-transform duration-300" />
                  <span className="text-sm md:text-base text-gray-300">
                    <strong className="text-red-400">Coverage Area:</strong> 5 km radius per store
                  </span>
                </div>
              </div>
            </div>
          </div>


          {/* Fully Managed Franchise */}
          <div className={`group bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl shadow-2xl border border-gray-700/50 overflow-hidden hover:shadow-purple-500/10 transition-all duration-700 hover:scale-105 transform ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
            } delay-900`}>
            <div className="bg-gradient-to-r from-purple-600/20 to-indigo-700/20 backdrop-blur-sm text-white p-6 md:p-8 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-transparent group-hover:from-purple-500/20 transition-all duration-500"></div>
              <div className="flex items-center mb-3 md:mb-4 relative z-10">
                <div className="p-2 bg-purple-500/20 rounded-xl mr-3 md:mr-4 group-hover:bg-purple-500/30 transition-all duration-300">
                  <Settings className="w-6 h-6 md:w-8 md:h-8 text-purple-400" />
                </div>
                <div>
                  <h3 className="text-xl md:text-2xl font-bold">Fully Managed Warehouse Franchise</h3>
                  <p className="text-sm md:text-base text-purple-200">Hassle-free, professionally managed business</p>
                </div>
              </div>
            </div>

            <div className="p-6 md:p-8">
              <h4 className="text-base md:text-lg font-semibold text-white mb-3 md:mb-4 flex items-center">
                <div className="w-1 h-6 bg-purple-500 rounded-full mr-3"></div>
                How it works:
              </h4>
              <p className="text-sm md:text-base text-gray-300 mb-4 md:mb-6">
                Bringmart takes full responsibility for setting up and operating the warehouse, including:
              </p>

              <div className="space-y-3 mb-6">
                {[
                  "Interior design & infrastructure setup",
                  "Rent, electricity, and delivery costs",
                  "Training, packing materials, and software solutions"
                ].map((item, index) => (
                  <div key={index} className="flex items-center text-sm md:text-base text-gray-300 opacity-0 animate-fade-in-left" style={{ animationDelay: `${1.4 + index * 0.2}s` }}>
                    <div className="w-2 h-2 bg-purple-500 rounded-full mr-3 animate-pulse"></div>
                    {item}
                  </div>
                ))}
              </div>

              <div className="space-y-4">
                <div className="flex items-start group/item hover:bg-gray-800/30 p-3 rounded-xl transition-all duration-300">
                  <CheckCircle className="w-5 h-5 text-purple-500 mr-3 mt-0.5 group-hover/item:scale-110 transition-transform duration-300" />
                  <span className="text-sm md:text-base text-gray-300">
                    <strong className="text-white">Bringmart's Role:</strong> End-to-end management
                  </span>
                </div>

                <div className="flex items-start group/item hover:bg-gray-800/30 p-3 rounded-xl transition-all duration-300">
                  <CheckCircle className="w-5 h-5 text-gray-500 mr-3 mt-0.5 group-hover/item:scale-110 transition-transform duration-300" />
                  <span className="text-sm md:text-base text-gray-300">
                    <strong className="text-white">Franchise Partner's Role:</strong> Initial setup fee only
                  </span>
                </div>

                <div className="flex items-start group/item hover:bg-green-500/10 p-3 rounded-xl transition-all duration-300">
                  <TrendingUp className="w-5 h-5 text-green-500 mr-3 mt-0.5 group-hover/item:scale-110 transition-transform duration-300" />
                  <span className="text-sm md:text-base text-gray-300">
                    <strong className="text-green-400">Profit Sharing:</strong> 5–8% profit share from sales
                  </span>
                </div>

                <div className="flex items-start group/item hover:bg-red-500/10 p-3 rounded-xl transition-all duration-300">
                  <MapPin className="w-5 h-5 text-red-500 mr-3 mt-0.5 group-hover/item:scale-110 transition-transform duration-300" />
                  <span className="text-sm md:text-base text-gray-300">
                    <strong className="text-red-400">Coverage Area:</strong> 5 km radius per store
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Requirements />
      </main>

      <style jsx>{`
        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fade-in-left {
          from {
            opacity: 0;
            transform: translateX(-20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        .animate-fade-in-up {
          animation: fade-in-up 0.8s ease-out forwards;
        }

        .animate-fade-in-left {
          animation: fade-in-left 0.6s ease-out forwards;
        }

        .delay-300 {
          animation-delay: 0.3s;
        }
      `}</style>
    </div>
  )
}