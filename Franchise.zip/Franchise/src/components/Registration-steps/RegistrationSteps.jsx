import { Calendar, Users, CheckCircle, MapPin, Briefcase, Handshake, ArrowRight } from "lucide-react"

const steps = [
    {
        title: "SITE VISIT",
        desc: "Fix your appointment",
        icon: <Calendar className="w-6 h-6 md:w-8 md:h-8 text-white" />,
        color: "bg-gradient-to-br from-amber-400 via-orange-500 to-red-500",
        shadowColor: "shadow-amber-500/40",
        glowColor: "group-hover:shadow-amber-500/60",
    },
    {
        title: "CLIENT MEETING",
        desc: "Our team member will go to your place for an offline meeting",
        icon: <Users className="w-6 h-6 md:w-8 md:h-8 text-white" />,
        color: "bg-gradient-to-br from-purple-500 via-violet-600 to-indigo-600",
        shadowColor: "shadow-purple-500/40",
        glowColor: "group-hover:shadow-purple-500/60",
    },
    {
        title: "FRANCHISE VERIFICATION",
        desc: "Our Project Manager will verify your location",
        icon: <CheckCircle className="w-6 h-6 md:w-8 md:h-8 text-white" />,
        color: "bg-gradient-to-br from-pink-500 via-rose-500 to-red-500",
        shadowColor: "shadow-rose-500/40",
        glowColor: "group-hover:shadow-rose-500/60",
    },
    {
        title: "AREA CODE ACTIVATION",
        desc: "Our project manager will activate your area code",
        icon: <MapPin className="w-6 h-6 md:w-8 md:h-8 text-white" />,
        color: "bg-gradient-to-br from-cyan-400 via-blue-500 to-indigo-600",
        shadowColor: "shadow-blue-500/40",
        glowColor: "group-hover:shadow-blue-500/60",
    },
    {
        title: "AGREEMENT SIGN",
        desc: "You get an agreement with all the franchise details",
        icon: <Handshake className="w-6 h-6 md:w-8 md:h-8 text-white" />,
        color: "bg-gradient-to-br from-emerald-500 via-green-600 to-teal-600",
        shadowColor: "shadow-green-500/40",
        glowColor: "group-hover:shadow-green-500/60",
    },
    {
        title: "HANDLING BRINGMART KIT",
        desc: "Our team will give you all the resources to run a successful warehouse",
        icon: <Briefcase className="w-6 h-6 md:w-8 md:h-8 text-white" />,
        color: "bg-gradient-to-br from-teal-400 via-cyan-500 to-blue-500",
        shadowColor: "shadow-teal-500/40",
        glowColor: "group-hover:shadow-teal-500/60",
    }
]

export default function RegistrationSteps() {
    return (
        <section className="w-full bg-gradient-to-br from-slate-900 via-gray-900 to-black py-12 md:py-20 relative overflow-hidden">
            {/* Enhanced Background Effects */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_30%,rgba(147,51,234,0.1)_0%,transparent_50%)]"></div>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_70%,rgba(59,130,246,0.08)_0%,transparent_50%)]"></div>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.05)_0%,transparent_70%)]"></div>
            
            {/* Floating particles effect */}
            <div className="absolute top-20 left-10 w-2 h-2 bg-purple-400 rounded-full animate-pulse opacity-60"></div>
            <div className="absolute top-40 right-16 w-1 h-1 bg-blue-400 rounded-full animate-pulse opacity-40"></div>
            <div className="absolute bottom-32 left-20 w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse opacity-50"></div>

            <div className="container mx-auto px-4 md:px-12 relative z-10">
                {/* Enhanced Header */}
                <div className="text-center mb-8 md:mb-16">
                    <div className="inline-block mb-4">
                        <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent text-sm md:text-base font-semibold tracking-wider uppercase">
                            Step by Step
                        </span>
                    </div>
                    <h2 className="text-3xl md:text-5xl font-bold text-white mb-3 md:mb-4 tracking-tight">
                        Registration 
                        <span className="bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 bg-clip-text text-transparent"> Process</span>
                    </h2>
                    <p className="text-base md:text-xl text-gray-300 font-light max-w-2xl mx-auto">
                        Complete your franchise journey in 6 simple steps
                    </p>
                    <div className="w-16 md:w-24 h-0.5 md:h-1 bg-gradient-to-r from-amber-400 via-purple-500 to-blue-500 mx-auto mt-4 md:mt-6 rounded-full"></div>
                </div>

           {/* Desktop/Tablet Layout */}
           <div className="hidden md:block relative max-w-6xl lg:max-w-7xl mx-auto">
                    {/* Enhanced timeline */}
                    <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-amber-400 via-purple-500 via-rose-400 via-blue-400 via-emerald-400 to-teal-500 rounded-full shadow-lg"></div>

                    {steps.map((step, index) => (
                        <div key={index} className="relative mb-16 lg:mb-20 last:mb-0">
                            <div className={`flex items-center ${index % 2 === 0 ? "flex-row" : "flex-row-reverse"}`}>
                                {/* Enhanced Content Card */}
                                <div className={`w-5/12 ${index % 2 === 0 ? "pr-8 lg:pr-20" : "pl-8 lg:pl-20"}`}>
                                    <div className={`group bg-white/5 backdrop-blur-xl rounded-2xl lg:rounded-3xl p-5 lg:p-8 border border-white/10 hover:bg-white/10 transition-all duration-500 hover:scale-105 hover:border-white/20 ${step.shadowColor} hover:shadow-2xl ${step.glowColor}`}>
                                        {/* Enhanced step number */}
                                        <div className={`inline-flex items-center justify-center w-8 h-8 lg:w-10 lg:h-10 rounded-xl lg:rounded-2xl bg-gradient-to-br from-white/20 to-white/5 text-white font-bold text-base lg:text-lg mb-4 lg:mb-6 ${index % 2 === 0 ? "" : "ml-auto"} shadow-lg`}>
                                            {index + 1}
                                        </div>

                                        {/* Enhanced content */}
                                        <div className={`flex items-start gap-4 lg:gap-6 ${index % 2 === 0 ? "" : "flex-row-reverse"}`}>
                                            <div className={`flex-shrink-0 w-16 h-16 lg:w-20 lg:h-20 rounded-xl lg:rounded-2xl ${step.color} ${step.shadowColor} shadow-2xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-3 transition-all duration-300`}>
                                                {step.icon}
                                            </div>

                                            <div className={`flex-1 min-w-0 ${index % 2 === 0 ? "text-left" : "text-right"}`}>
                                                <h3 className="text-lg lg:text-2xl font-bold bg-gradient-to-r from-amber-300 to-orange-400 bg-clip-text text-transparent mb-2 lg:mb-4 tracking-wide break-words">
                                                    {step.title}
                                                </h3>
                                                <p className="text-gray-200 leading-relaxed text-sm lg:text-lg break-words">
                                                    {step.desc}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Enhanced connector dot */}
                                <div className={`absolute left-1/2 transform -translate-x-1/2 w-6 h-6 lg:w-8 lg:h-8 rounded-full ${step.color} border-4 border-gray-900 shadow-2xl z-10 ${step.shadowColor}`}></div>

                                <div className="w-5/12"></div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Mobile Layout - Android App Style */}
                <div className="md:hidden space-y-4">
                    {steps.map((step, index) => (
                        <div key={index} className="group">
                            <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-4 border border-white/10 hover:bg-white/8 transition-all duration-300 hover:border-white/20 shadow-lg">
                                <div className="flex items-center gap-4">
                                    {/* Mobile icon container */}
                                    <div className={`flex-shrink-0 w-14 h-14 rounded-xl ${step.color} ${step.shadowColor} shadow-lg flex items-center justify-center group-hover:scale-105 transition-transform duration-200`}>
                                        {step.icon}
                                    </div>

                                    {/* Mobile content */}
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-2 mb-1">
                                            <div className="w-6 h-6 rounded-full bg-gradient-to-br from-white/20 to-white/5 text-white font-bold text-xs flex items-center justify-center">
                                                {index + 1}
                                            </div>
                                            <h3 className="text-xs font-bold bg-gradient-to-r from-amber-300 to-orange-400 bg-clip-text text-transparent tracking-wide">
                                                {step.title}
                                            </h3>
                                        </div>
                                        <p className="text-gray-300 text-xs leading-relaxed">
                                            {step.desc}
                                        </p>
                                    </div>

                                    {/* Mobile arrow */}
                                    <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-white transition-colors duration-200 flex-shrink-0" />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Enhanced Call to action */}
                <div className="text-center mt-12 md:mt-16">
                    <div className="inline-flex items-center gap-3 bg-gradient-to-r from-white/10 to-white/5 backdrop-blur-xl rounded-full px-6 md:px-8 py-3 md:py-4 border border-white/20 hover:border-white/30 transition-all duration-300 hover:scale-105 shadow-lg">
                        <CheckCircle className="w-5 h-5 md:w-6 md:h-6 text-green-400" />
                        <span className="text-white font-medium text-sm md:text-base">
                            Ready to start your warehouse franchise journey?
                        </span>
                    </div>
                </div>
            </div>
        </section>
    )
}