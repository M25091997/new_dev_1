import { useEffect, useRef } from "react";
import {
  ArrowRight,
  Ruler,
  Paintbrush,
  Package,
  TrendingUp,
  Computer,
  BadgeDollarSign,
  FileClock,
  Sparkles,
  Star,
  Zap,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const details = [
  {
    icon: Ruler,
    title: "Area Size",
    value: "1000 sqft to 3000 sqft",
    color: "from-purple-500 to-indigo-600",
    shadowColor: "shadow-purple-500/30",
  },
  {
    icon: Paintbrush,
    title: "Interior Cost",
    value: "Rs.800 to 1200 sq./ft",
    color: "from-pink-500 to-rose-600",
    shadowColor: "shadow-pink-500/30",
  },
  {
    icon: TrendingUp,
    title: "Total Investment",
    value: "Rs. 3208/- per sq./ft.",
    color: "from-emerald-500 to-green-600",
    shadowColor: "shadow-emerald-500/30",
  },
  {
    icon: Computer,
    title: "CRM (Software Fee)",
    value: "Rs. 60,000/- + GST",
    color: "from-blue-500 to-cyan-600",
    shadowColor: "shadow-blue-500/30",
  },
  {
    icon: BadgeDollarSign,
    title: "Franchise Fee",
    value: "Rs. 2,10,000 + GST",
    color: "from-amber-500 to-orange-600",
    shadowColor: "shadow-amber-500/30",
  },
  {
    icon: FileClock,
    title: "Agreement Time",
    value: "3 Years / 5 Years Lock in",
    color: "from-teal-500 to-cyan-600",
    shadowColor: "shadow-teal-500/30",
  }
];

export default function HeroSection() {
  const contentRef = useRef(null);
  const cardsRef = useRef(null);
  const warehouseRef = useRef(null);
  const navigate = useNavigate();

  const handleLearnMore = () => {
    navigate("/franchise-models");
  };

  useEffect(() => {
    document.title = "Bringmart - Warehouse Franchise Opportunity";

    window.scrollTo({
      top: 0,
      behavior: "smooth", // ✅ Smooth scroll
    });
  }, []);


  useEffect(() => {
    const observerOptions = { root: null, threshold: 0.1 };
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = "1";
          entry.target.style.transform = "translateY(0px)";
        }
      });
    }, observerOptions);

    [contentRef.current, cardsRef.current, warehouseRef.current].forEach(
      (el) => el && observer.observe(el)
    );

    // staggered animation for cards
    const cards = cardsRef.current?.children;
    if (cards) {
      Array.from(cards).forEach((card, index) => {
        card.style.transitionDelay = `${index * 100}ms`;
      });
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Enhanced Background */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-fixed"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80')`,
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-black/70 via-black/60 to-purple-900/40"></div>

      {/* Enhanced animated gradient elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 sm:w-96 sm:h-96 bg-gradient-to-br from-purple-400/20 to-blue-600/20 rounded-full animate-pulse blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 sm:w-96 sm:h-96 bg-gradient-to-br from-emerald-400/15 to-teal-600/15 rounded-full animate-pulse blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 sm:w-72 sm:h-72 bg-gradient-to-br from-pink-400/10 to-purple-500/10 rounded-full animate-spin blur-2xl" style={{ animationDuration: '20s' }}></div>

        {/* Floating particles */}
        <div className="absolute top-20 left-10 w-2 h-2 bg-purple-400 rounded-full animate-ping opacity-60"></div>
        <div className="absolute top-40 right-16 w-1 h-1 bg-blue-400 rounded-full animate-pulse opacity-40"></div>
        <div className="absolute bottom-32 left-20 w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce opacity-50"></div>
        <div className="absolute top-60 right-32 w-1 h-1 bg-pink-400 rounded-full animate-pulse opacity-30"></div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 px-3 sm:px-4 lg:px-8 py-6 sm:py-8 lg:py-16">
        <div className="max-w-7xl mx-auto">
          {/* Enhanced Heading & Subheading */}
          <div
            ref={contentRef}
            className="text-center mb-8 sm:mb-12 lg:mb-16 opacity-0 transform translate-y-10 transition-all duration-1000 ease-out"
          >
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 mb-6 border border-white/20">
              <Sparkles className="w-4 h-4 text-yellow-400" />
              <span className="text-white text-sm font-medium">Premium Franchise Opportunity</span>
              <Star className="w-4 h-4 text-yellow-400" />
            </div>

            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 md:mb-6 leading-tight">
              <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                Warehouse Franchise
              </span>
              <br />
              <span className="text-white">Opportunity</span>
            </h1>

            <p className="text-base sm:text-lg md:text-xl text-gray-200 max-w-3xl mx-auto leading-relaxed px-2">
              Join BringMart's expanding network with our{" "}
              <span className="text-purple-300 font-semibold">Warehouse Commercial Capital</span> and{" "}
              <span className="text-blue-300 font-semibold">Capital Franchise models</span>.
            </p>
          </div>

          {/* Details Cards - Responsive Layout */}
          <div
            ref={cardsRef}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-8 sm:mb-12 lg:mb-20 opacity-0 transform translate-y-10 transition-all duration-1000 ease-out"
          >
            {details.map((item, index) => (
              <div
                key={index}
                className="group relative bg-white/10 backdrop-blur-xl rounded-2xl p-4 sm:p-6 border border-white/20 hover:border-white/30 transition-all duration-500 hover:scale-105 hover:bg-white/15 cursor-pointer transform hover:-translate-y-2 shadow-xl hover:shadow-2xl"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                <div className="relative flex items-start space-x-3 sm:space-x-4">
                  <div className={`flex-shrink-0 w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br ${item.color} rounded-xl flex items-center justify-center group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 ${item.shadowColor} shadow-lg`}>
                    <item.icon className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-base sm:text-lg font-bold text-white mb-1 sm:mb-2 group-hover:text-purple-200 transition-colors duration-300">
                      {item.title}
                    </h3>
                    <p className="text-sm text-gray-300 font-medium group-hover:text-gray-200 transition-colors duration-300">
                      {item.value}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Enhanced Warehouse Model Card */}
          <div
            ref={warehouseRef}
            className="opacity-0 transform translate-y-10 transition-all duration-1000 ease-out"
          >
            <div className="max-w-2xl mx-auto relative group">
              {/* Enhanced glow effect */}
              <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 rounded-3xl blur opacity-20 group-hover:opacity-40 transition-opacity duration-500 animate-pulse"></div>

              <div className="relative bg-white/10 backdrop-blur-xl rounded-3xl p-6 md:p-8 border border-white/20 hover:border-white/30 transition-all duration-500 hover:scale-105 shadow-2xl hover:shadow-purple-500/25">
                <div className="text-center">
                  {/* Enhanced icon container */}
                  <div className="relative inline-flex items-center justify-center w-16 h-16 md:w-20 md:h-20 mb-4 md:mb-6">
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-500 via-pink-500 to-blue-500 rounded-2xl group-hover:scale-110 group-hover:rotate-12 transition-all duration-500 shadow-2xl shadow-purple-500/30"></div>
                    <Package className="relative w-8 h-8 md:w-10 md:h-10 text-white z-10" />

                    {/* Animated rings */}
                    <div className="absolute inset-0 border-2 border-white/30 rounded-2xl animate-ping"></div>
                    <div className="absolute -inset-2 border border-purple-400/50 rounded-3xl group-hover:animate-spin transition-all duration-1000"></div>

                    {/* Floating sparkles */}
                    <Zap className="absolute -top-2 -right-2 w-4 h-4 text-yellow-400 animate-pulse" />
                    <Sparkles className="absolute -bottom-1 -left-1 w-3 h-3 text-purple-300 animate-bounce" />
                  </div>

                  <h2 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent mb-3 md:mb-4 tracking-wide group-hover:scale-105 transition-transform duration-500">
                    WAREHOUSE MODEL
                  </h2>

                  <p className="text-sm md:text-lg text-gray-300 mb-6 md:mb-8 leading-relaxed group-hover:text-gray-200 transition-colors duration-300 max-w-lg mx-auto">
                    A proven model for success in the e-commerce space with{" "}
                    <span className="text-emerald-300 font-semibold">guaranteed ROI</span>.
                  </p>

                  {/* Enhanced button */}
                  <div className="relative inline-block">
                    <button
                      onClick={handleLearnMore}
                      className="group/btn relative overflow-hidden px-6 md:px-8 py-3 md:py-4 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 hover:from-purple-500 hover:via-pink-500 hover:to-blue-500 text-white text-sm md:text-lg font-bold rounded-xl md:rounded-2xl transition-all duration-500 hover:scale-110 hover:shadow-2xl hover:shadow-purple-500/50 focus:outline-none focus:ring-4 focus:ring-purple-500/50 transform hover:-translate-y-1"
                    >
                      {/* Shimmer effect */}
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent translate-x-[-100%] group-hover/btn:translate-x-[100%] transition-transform duration-1000"></div>

                      <span className="relative flex items-center justify-center">
                        Learn More
                        <ArrowRight className="ml-2 md:ml-3 w-5 h-5 md:w-6 md:h-6 group-hover/btn:translate-x-2 group-hover/btn:scale-110 transition-all duration-300" />
                      </span>

                      {/* Button glow */}
                      <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl md:rounded-2xl blur opacity-0 group-hover/btn:opacity-50 transition-opacity duration-500 -z-10"></div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}