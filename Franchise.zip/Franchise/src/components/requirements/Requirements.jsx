import { CheckCircle, FileText, Building2, Store, Users, Phone} from "lucide-react";
import { Link } from "react-router-dom";

export default function Requirements() {
  return (
    <section className="bg-gradient-to-b from-gray-900 via-gray-950 to-black text-white">
      <div className="max-w-6xl mx-auto px-3 sm:px-4 py-8 sm:py-12 lg:py-16">

        {/* Section Title */}
        <div className="flex items-center justify-center mb-8 sm:mb-12">
          <CheckCircle className="text-green-400 mr-2 sm:mr-3" size={28} />
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold">
            Franchise Requirements
          </h2>
        </div>

        {/* ===== Documents Required ===== */}
        <div className="mb-12 sm:mb-16">
          <div className="flex items-center mb-6 sm:mb-8">
            <FileText className="text-blue-400 mr-2 sm:mr-3" size={28} />
            <h2 className="text-xl sm:text-2xl md:text-3xl font-bold">
              Documents Required
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
            {/* Personal KYC */}
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:shadow-md sm:hover:shadow-xl hover:shadow-blue-500/20">
              <div className="flex items-center mb-3 sm:mb-4">
                <FileText className="text-blue-400 mr-2 sm:mr-3" size={20} />
                <h3 className="text-lg sm:text-xl font-semibold">Personal KYC</h3>
              </div>
              <ul className="space-y-2 sm:space-y-3 text-gray-300 text-sm sm:text-base">
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-blue-400 rounded-full mt-2 mr-2 sm:mr-3"></span>
                  Aadhar Card (Owner/Partner)
                </li>
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-blue-400 rounded-full mt-2 mr-2 sm:mr-3"></span>
                  PAN Card
                </li>
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-blue-400 rounded-full mt-2 mr-2 sm:mr-3"></span>
                  Passport-size Photos
                </li>
              </ul>
            </div>

            {/* Business Documents */}
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-gray-700 hover:border-purple-500 transition-all duration-300 hover:shadow-md sm:hover:shadow-xl hover:shadow-purple-500/20">
              <div className="flex items-center mb-3 sm:mb-4">
                <Building2 className="text-purple-400 mr-2 sm:mr-3" size={20} />
                <h3 className="text-lg sm:text-xl font-semibold">Business Documents</h3>
              </div>
              <ul className="space-y-2 sm:space-y-3 text-gray-300 text-sm sm:text-base">
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-purple-400 rounded-full mt-2 mr-2 sm:mr-3"></span>
                  GST Certificate
                </li>
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-purple-400 rounded-full mt-2 mr-2 sm:mr-3"></span>
                  Trade License
                </li>
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-purple-400 rounded-full mt-2 mr-2 sm:mr-3"></span>
                  FSSAI License
                </li>
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-purple-400 rounded-full mt-2 mr-2 sm:mr-3"></span>
                  Shop Establishment Certificate
                </li>
              </ul>
            </div>

            {/* Bank Proof */}
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-gray-700 hover:border-green-500 transition-all duration-300 hover:shadow-md sm:hover:shadow-xl hover:shadow-green-500/20">
              <div className="flex items-center mb-3 sm:mb-4">
                <Store className="text-green-400 mr-2 sm:mr-3" size={20} />
                <h3 className="text-lg sm:text-xl font-semibold">Bank Proof</h3>
              </div>
              <ul className="space-y-2 sm:space-y-3 text-gray-300 text-sm sm:text-base">
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-green-400 rounded-full mt-2 mr-2 sm:mr-3"></span>
                  Cancelled Cheque
                </li>
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-green-400 rounded-full mt-2 mr-2 sm:mr-3"></span>
                  Bank Statement (Last 6 months)
                </li>
                  <li className="flex items-start">
                  <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-green-400 rounded-full mt-2 mr-2 sm:mr-3"></span>
                  Income Tax Return (ITR 1-3 Years)
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* ===== Business Requirements ===== */}
        <div className="mb-12 sm:mb-16">
          <div className="flex items-center mb-6 sm:mb-8">
            <Store className="text-orange-400 mr-2 sm:mr-3" size={28} />
            <h2 className="text-xl sm:text-2xl md:text-3xl font-bold">
              Business Requirements
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
            {/* Space */}
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-gray-700 hover:border-orange-500 transition-all duration-300 hover:shadow-md sm:hover:shadow-xl hover:shadow-orange-500/20">
              <div className="flex items-center mb-3 sm:mb-4">
                <Building2 className="text-orange-400 mr-2 sm:mr-3" size={20} />
                <h3 className="text-lg sm:text-xl font-semibold">Space</h3>
              </div>
              <p className="text-gray-300 text-sm sm:text-base">
                Minimum 1000 – 3000 sq. ft. commercial space in a prime location.
              </p>
            </div>

            {/* Investment */}
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-gray-700 hover:border-yellow-500 transition-all duration-300 hover:shadow-md sm:hover:shadow-xl hover:shadow-yellow-500/20">
              <div className="flex items-center mb-3 sm:mb-4">
                <Users className="text-yellow-400 mr-2 sm:mr-3" size={20} />
                <h3 className="text-lg sm:text-xl font-semibold">Investment</h3>
              </div>
              <p className="text-gray-300 text-sm sm:text-base">
                Approx. ₹10–50 Lakhs (Depending on location and setup).
              </p>
            </div>

            {/* Staff */}
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-gray-700 hover:border-pink-500 transition-all duration-300 hover:shadow-md sm:hover:shadow-xl hover:shadow-pink-500/20">
              <div className="flex items-center mb-3 sm:mb-4">
                <Users className="text-pink-400 mr-2 sm:mr-3" size={20} />
                <h3 className="text-lg sm:text-xl font-semibold">Staff</h3>
              </div>
              <p className="text-gray-300 text-sm sm:text-base">
                Minimum 3–10 staff members required for operations.
              </p>
            </div>
          </div>
        </div>

        {/* ===== CTA ===== */}
        <div className="text-center mt-12 sm:mt-16">
          <h3 className="text-xl sm:text-2xl md:text-3xl font-bold mb-4 sm:mb-6">
            Interested in Becoming a Franchise Partner?
          </h3>
          <p className="text-gray-300 text-sm sm:text-base mb-6 sm:mb-8 max-w-2xl mx-auto">
            Join hands with us and be a part of India’s fastest growing retail chain.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="tel:+06574022692"
              className="flex items-center px-5 py-3 text-sm sm:text-base bg-green-500 hover:bg-green-600 rounded-lg font-semibold transition-colors"
            >
              <Phone className="h-4 w-4 mr-2" /> Call Now
            </a>
            <Link
              to="/contact-us"
              className="flex items-center px-5 py-3 text-sm sm:text-base bg-blue-500 hover:bg-blue-600 rounded-lg font-semibold transition-colors"
            >
              Apply Online
            </Link>
          </div>
        </div>

      </div>
    </section>
  );
}
