import React from 'react'
import HeroSection from '../hero-section/HeroSection'
import FranchiseInfo from '../franchise-info/FranchiseInfo'
import ProfitSection from '../ProfileSection/ProfitSection'
import RegistrationSteps from '../Registration-steps/RegistrationSteps'

const Home = () => {
  return (
    <div>
      <HeroSection />
      <FranchiseInfo />
      <RegistrationSteps />
      <ProfitSection />
    </div>
  )
}

export default Home
