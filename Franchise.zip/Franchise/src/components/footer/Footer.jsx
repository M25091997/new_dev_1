import { Link } from "react-router-dom";
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from "lucide-react";
import logo from "../../assets/logo.png";

export function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-gray-300 relative overflow-hidden">
      {/* Decorative background gradient & top line */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900/10 to-purple-900/10"></div>
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-14 relative z-10">
        {/* Top grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">

          {/* Logo + About + Contact */}
          <div>
            <div className="flex justify-center lg:justify-start mb-5">
              <img
                src={logo}
                alt="Bringmart Logo"
                className="h-12 w-auto hover:scale-105 transition-transform duration-300"
              />
            </div>

            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-center lg:justify-start text-gray-400">
                <Mail className="h-4 w-4 mr-2 text-blue-400" />
                <a
                  href="mailto:franchise@bringmart.in"
                  className="hover:text-blue-500 transition-colors duration-300"
                >
                  franchise@bringmart.in
                </a>
              </div>

              <div className="flex items-center justify-center lg:justify-start text-gray-400">
                <Phone className="h-4 w-4 mr-2 text-green-400" />
                <a
                  href="tel:06574022692"
                  className="hover:text-green-500 transition-colors duration-300"
                >
                  0657-4022692
                </a>
              </div>

              <p className="text-sm leading-relaxed text-gray-400 mb-6 max-w-sm mx-auto lg:mx-0">
                Bringmart Ecommerce Private Limited.
              </p>

              <div className="flex items-center justify-center lg:justify-start text-gray-400">
                {/* <MapPin className="h-4 w-4 mr-2 text-red-400" /> */}
                <span>H.NO.34, Jeeta Singh Bagan, Namda basti, Golmuri, East Singhbhum, Jamshedpur, Jharkhand, India - 831003</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6 uppercase tracking-wide relative inline-block">
              Quick Links
              <span className="absolute bottom-0 left-0 w-12 h-0.5 bg-gradient-to-r from-blue-500 to-purple-500"></span>
            </h3>
            <ul className="space-y-3 mt-3">
              {[
                { label: "About Us", to: "/about-us" },
                { label: "Contact", to: "/contact-us" },
                { label: "Bringmart.in", href: "https://bringmart.in" },
                { label: "Franchise FAQs", to: "/faqs" },
              ].map((link, idx) =>
                link.href ? (
                  <li key={idx}>
                    <a
                      href={link.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-400 hover:text-white transition-all duration-300 inline-flex items-center group"
                    >
                      <span className="w-0 h-0.5 bg-blue-500 group-hover:w-4 transition-all duration-300 mr-0 group-hover:mr-2"></span>
                      {link.label}
                    </a>
                  </li>
                ) : (
                  <li key={idx}>
                    <Link
                      to={link.to}
                      className="text-gray-400 hover:text-white transition-all duration-300 inline-flex items-center group"
                    >
                      <span className="w-0 h-0.5 bg-blue-500 group-hover:w-4 transition-all duration-300 mr-0 group-hover:mr-2"></span>
                      {link.label}
                    </Link>
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Social Links */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6 uppercase tracking-wide relative inline-block">
              Follow Us
              <span className="absolute bottom-0 left-0 w-12 h-0.5 bg-gradient-to-r from-pink-500 to-red-500"></span>
            </h3>
            <div className="flex justify-center lg:justify-start space-x-4 mb-6">
              {[
                { href: "https://www.facebook.com/share/1JCYhKgSrj/", icon: Facebook, hover: "hover:bg-blue-600 hover:shadow-blue-500/25" },
                { href: "https://x.com/Bring_mart?t=42hvSSi8c_nF5bAoOU7SHA&s=09", icon: Twitter, hover: "hover:bg-sky-500 hover:shadow-sky-500/25" },
                { href: "https://www.instagram.com/bringmart.in/", icon: Instagram, hover: "hover:bg-gradient-to-br hover:from-purple-500 hover:to-pink-500 hover:shadow-pink-500/25" },
                { href: "https://www.linkedin.com/company/107870064/admin/dashboard/", icon: Linkedin, hover: "hover:bg-blue-700 hover:shadow-blue-700/25" },
              ].map(({ href, icon: Icon, hover }, idx) => (
                <a
                  key={idx}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`group p-3 rounded-full bg-gray-800 transition-all duration-300 hover:scale-110 hover:shadow-lg ${hover}`}
                >
                  <Icon className="h-5 w-5 text-gray-400 group-hover:text-white transition-colors duration-300" />
                </a>
              ))}
            </div>
            <p className="text-sm text-gray-400 text-center lg:text-left">
              Stay connected with us for <br />
              <span className="text-xs">latest updates & opportunities</span>
            </p>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-8 border-t border-gray-700 text-center lg:text-left">
          <div className="items-center justify-center">
            <p className="text-sm text-gray-400">
              &copy; {new Date().getFullYear()} Bringmart. All Rights Reserved.
            </p>
            
          </div>
        </div>
      </div>
    </footer>
  );
}
