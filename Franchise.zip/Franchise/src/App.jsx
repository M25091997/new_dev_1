import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout/Layout";
import Home from "./components/home/Home";
import AboutUs from "./components/aboutUs/AboutUs";
import Contact from "./components/Contact/Contact";
import FranchiseModels from "./components/franchise-model/FranchiseModels";

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about-us" element={<AboutUs />} />
          <Route path="/contact-us" element={<Contact />} />
          <Route path="/franchise-models" element={<FranchiseModels />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;
